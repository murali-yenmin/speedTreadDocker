module.exports = {
    parser: "@typescript-eslint/parser",
    parserOptions: {
        project: "tsconfig.json",
        tsconfigRootDir: __dirname,
        sourceType: "module"
    },
    plugins: ["@typescript-eslint/eslint-plugin", "prettier"],
    extends: ["plugin:@typescript-eslint/recommended", "plugin:prettier/recommended"],
    root: true,
    env: {
        node: true,
        jest: true
    },
    ignorePatterns: [".eslintrc.js"],
    rules: {
        "@typescript-eslint/interface-name-prefix": "off",
        "@typescript-eslint/explicit-function-return-type": "off",
        "@typescript-eslint/explicit-module-boundary-types": "off",
        "@typescript-eslint/no-explicit-any": "off",
        "prettier/prettier": "error",
        quotes: ["error", "double"],
        "dot-notation": ["error", { allowKeywords: true }],
        "linebreak-style": ["error", "unix"],
        "object-curly-spacing": ["error", "always"],
        "no-param-reassign": [
            2,
            {
                props: false
            }
        ],
        "import/no-dynamic-require": 0,
        "global-require": 0,
        "import/prefer-default-export": 0,
        "no-underscore-dangle": 0,
        "no-await-in-loop": 0,
        "no-restricted-syntax": 0,
        "no-return-await": 0,
        "no-console": 0
    }
};
