# API Documentation

This document provides a summary of the available API endpoints in the Speed-Trade-Reconciliation-BE application.

## Authentication API

**Base Path:** `/secure`

| Method | Endpoint             | Description                                          |
|--------|----------------------|------------------------------------------------------|
| POST   | `/login`             | Authenticates a user and logs them into the system.  |
| POST   | `/forgot-password`   | Initiates the forgot password process.               |
| POST   | `/verify-forgot`     | Verifies the forgot password OTP.                    |
| POST   | `/regenerate-password`| Regenerates the user's password.                     |
| POST   | `/change-password`   | Changes the user's password. (Requires authentication) |
| GET    | `/profile-details`   | Gets the logged-in user's profile. (Requires authentication) |

## Currency Pair API

**Base Path:** `/currency-pair`

| Method | Endpoint | Description                |
|--------|----------|----------------------------|
| POST   | `/`      | Creates a new currency pair. |
| PUT    | `/`      | Updates a currency pair.   |
| GET    | `/`      | Gets all currency pairs.   |

## Currency API

**Base Path:** `/currencies`

| Method | Endpoint    | Description                      |
|--------|-------------|----------------------------------|
| POST   | `/`         | Creates a new currency.          |
| PUT    | `/`         | Updates a currency.              |
| GET    | `/get-all`  | Gets all currencies.             |
| PUT    | `/status`   | Updates the status of a currency.|

## Customer Group API

**Base Path:** `/groups`

| Method | Endpoint    | Description                                      |
|--------|-------------|--------------------------------------------------|
| POST   | `/`         | Creates a new customer group.                    |
| PUT    | `/`         | Updates a customer group.                        |
| POST   | `/get-all`  | Gets all customer groups with optional filters.  |

## Management Users API

**Base Path:** `/user`

| Method | Endpoint    | Description                             |
|--------|-------------|-----------------------------------------|
| POST   | `/`         | Creates a new management user.          |
| POST   | `/get-all`  | Gets all users with optional filters.   |
| GET    | `/:id`      | Gets a user by their ID.                |
| PUT    | `/`         | Updates a user.                         |
| PUT    | `/status`   | Updates a user's status.                |

## Media Source API

**Base Path:** `/media-source`

| Method | Endpoint       | Description                               |
|--------|----------------|-------------------------------------------|
| POST   | `/`            | Creates a new media source.               |
| GET    | `/`            | Gets all media sources.                   |
| GET    | `/:unique_id`  | Gets a media source by its unique ID.     |
| PUT    | `/`            | Updates a media source.                   |
| DELETE | `/:unique_id`  | Deletes a media source by its unique ID.  |

## Roles API

**Base Path:** `/roles`

| Method | Endpoint | Description         |
|--------|----------|---------------------|
| GET    | `/`      | Gets all roles.     |
| POST   | `/`      | Creates a new role. |
| PUT    | `/`      | Updates a role.     |

## Transaction API

**Base Path:** `/transaction`

| Method | Endpoint             | Description                                          |
|--------|----------------------|------------------------------------------------------|
| POST   | `/`                  | Creates a new transaction.                           |
| GET    | `/`                  | Gets all transactions with optional filters.         |
| GET    | `/calculate-amount`  | Calculates amount for a transaction.                 |
| PUT    | `/:id`               | Updates a transaction by its ID.                     |
| DELETE | `/:id`               | Deletes a transaction by its ID.                     |

## Order API

**Base Path:** `/order`

| Method | Endpoint                | Description                                                                                                                                                                 |
|--------|-------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| GET    | `/status`               | Gets the list of available order statuses.                                                                                                                                  |
| POST   | `/`                     | Creates a new order.                                                                                                                                                        |
| POST   | `/get-all`              | Gets all orders with optional filters. The response includes `statusCounts` which is an array of objects with `label` and `value` for each order status.                      |
| POST   | `/get-all-report`       | Gets all orders for a report with optional filters. The response includes `statusCounts` which is an array of objects with `label` and `value` for each order status (excluding 'completed'). |
| POST   | `/cumulative-currencies`| Gets cumulative currencies for a given group and settlement currency.                                                                                                       |
| PUT    | `/`                     | Updates an order.                                                                                                                                                           |
| DELETE | `/:id`                  | Deletes an order and its associated transactions by its ID.                                                                                                                 |

## Accounts API

**Base Path:** `/accounts`

| Method | Endpoint | Description                                      |
|--------|----------|--------------------------------------------------|
| GET    | `/`      | Gets all accounts with optional search and limit. |

## Order Transaction API

**Base Path:** `/order-transaction`

| Method | Endpoint                  | Description                                  |
|--------|---------------------------|----------------------------------------------|
| POST   | `/full-pay`               | Gets full pay details for an order.          |
| POST   | `/`                       | Creates a new order transaction.             |
| PUT    | `/`                       | Updates an order transaction.                |
| DELETE | `/:id`                    | Deletes an order transaction by its ID.      |
| GET    | `/order-currencies/:groupId` | Gets order settlement currencies by group ID.|
