import { Module, OnModuleInit } from '@nestjs/common';
// import { AuthModule } from './modules/auth/auth.module';
import { APP_INTERCEPTOR, APP_FILTER } from '@nestjs/core';
import { ResponseInterceptor } from './common/interceptors/response.interceptor';
import { HttpExceptionFilter } from './common/filters/exception.filter';
import { ConfigModule } from './config/config.module';
import { I18nValidationExceptionFilter } from './common/filters/i18n-exception.filter';
import { MailerModule } from '@nestjs-modules/mailer';
import { RolesModule } from './modules/roles/roles.module';
import { AuthModule } from './modules/auth/auth.module';
import { ManagementUsersModule } from './modules/management-users/management-users.module';
import { AppService } from './app.service';
import { CurrencyModule } from './modules/currency/currency.module';
import { CustomerGroupModule } from './modules/customer-group/customer-group.module';
import { MediaSourceModule } from './modules/media-source/media-source.module';
import { CurrencyPairModule } from './modules/currency-pair/currency-pair.module';
import { TransactionModule } from './modules/transaction/transaction.module';
import { DbMaintenanceModule } from './modules/db-maintenance/db-maintenance.module';
import { DbMaintenanceService } from './modules/db-maintenance/db-maintenance.service';
import { OrderModule } from './modules/order/order.module';

import { CurrencyOrderModule } from './modules/currency-order/currency-order.module';

@Module({
  imports: [
    ConfigModule,
    AuthModule,
    ManagementUsersModule,
    MailerModule.forRoot({
      transport: {
        host: 'smtp.gmail.com',
        service: 'gmail',
        port: 587,
        secure: false,
        auth: {
          user: process.env.EMAIL_ADDRESS,
          pass: process.env.EMAIL_PASSWORD,
        },
      },
    }),
    RolesModule,
    CurrencyModule,
    CurrencyPairModule,
    CustomerGroupModule,
    MediaSourceModule,
    TransactionModule,
    OrderModule,
    DbMaintenanceModule,
    CurrencyOrderModule,
  ],
  controllers: [],
  providers: [
    AppService,
    {
      provide: APP_INTERCEPTOR,
      useClass: ResponseInterceptor,
    },
    {
      provide: APP_FILTER,
      useClass: HttpExceptionFilter,
    },
    {
      provide: APP_FILTER,
      useClass: I18nValidationExceptionFilter,
    },
  ],
})
// export class AppModule implements OnModuleInit {
//   constructor(private readonly dbMaintenanceService: DbMaintenanceService) {}

//   async onModuleInit() {
//     await this.dbMaintenanceService.fixTimestampColumns();
//   }
// }
export class AppModule {}
