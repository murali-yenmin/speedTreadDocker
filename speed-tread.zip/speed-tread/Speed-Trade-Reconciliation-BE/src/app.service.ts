import { HttpStatus, Injectable, Logger } from '@nestjs/common';
import { MailerService } from '@nestjs-modules/mailer';
import { AppConfigService } from './config/app-config/app-config.service';
import { sendWelcomeEmail } from './utils/email-templates/user-onboard-mail';
import { forgotPassword } from './utils/email-templates/reset-password-mail';

@Injectable()
export class AppService {
  private logger = new Logger(AppService.name);
  constructor(
    private mailService: MailerService,
    private readonly appConfigService: AppConfigService,
  ) {}

  async sendWelcomeMail(userData) {
    return sendWelcomeEmail(userData, this.mailService, userData?.generatePassword);
  }

  async sendForgotMail(userData, content, subject) {
    return forgotPassword(userData, this.mailService, userData?.secret_key, content, subject);
  }
}
 