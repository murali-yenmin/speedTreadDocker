import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { LoggedAdmin, LoggedUser } from '../interfaces/logged-user.interface';

export const GetLoggedUser = createParamDecorator((data: unknown, ctx: ExecutionContext): LoggedAdmin => {
  const request = ctx.switchToHttp().getRequest();
  return request.user as LoggedAdmin;
});
