import {
  registerDecorator,
  ValidationOptions,
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments,
} from 'class-validator';
import * as utils from 'src/utils';

@ValidatorConstraint({ async: true })
export class MatchPasswordConstraint implements ValidatorConstraintInterface {
  async validate(value: any, args: ValidationArguments) {
    const [relatedPropertyName] = args.constraints;
    const relatedValue = (args.object as any)[relatedPropertyName];

    const decryptedOriginal = await utils.decryptCryptoPwd(relatedValue);
    const decryptedConfirm = await utils.decryptCryptoPwd(value);

    return value ? decryptedOriginal === decryptedConfirm : true;
  }

  defaultMessage(args: ValidationArguments) {
    return 'Passwords do not match';
  }
}

export function MatchPassword(property: string, validationOptions?: ValidationOptions) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      target: object.constructor,
      propertyName,
      options: validationOptions,
      constraints: [property],
      validator: MatchPasswordConstraint,
    });
  };
}
