import { IsNotEmpty, IsOptional, isNotEmpty } from 'class-validator';

export class deleteDto {
  @IsNotEmpty()
  id: string;

  @IsNotEmpty()
  status: boolean;
}
