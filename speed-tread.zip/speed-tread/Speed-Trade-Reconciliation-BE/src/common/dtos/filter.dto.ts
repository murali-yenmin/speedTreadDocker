import { IsNotEmpty, IsOptional, IsString, Min } from 'class-validator';

export class FilterDto {
  @IsNotEmpty()
  cp: number;

  @IsNotEmpty()
  pl: number;

  @IsNotEmpty()
  query: Record<string, any>[];

  @IsOptional()
  sort: Record<string, any>;

  @IsOptional()
  @IsString()
  from_date: string;

  @IsOptional()
  @IsString()
  to_date: string;
}
