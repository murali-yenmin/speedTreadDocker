import { IsNotEmpty } from 'class-validator';

export class getAllParamsDto {
  @IsNotEmpty()
  cp: number;

  @IsNotEmpty()
  pl: number;
}
