import { Type } from "class-transformer";
import { IsDate, IsNotEmpty, IsNotEmptyObject, IsOptional, IsString } from 'class-validator';

export class notificationDTO {
  @IsNotEmptyObject()
  tenant_details: Record<string, any>;

  @IsNotEmpty()
  @IsString()
  description: string;

  @IsNotEmpty()
  category: string;

  @IsNotEmpty()
  system_generated: boolean;

  @IsOptional()
  created_by: Record<string, any>;
}
