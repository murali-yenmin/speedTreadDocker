import { ExceptionFilter, Catch, ArgumentsHost, HttpException } from '@nestjs/common';
import moment from '../../utils/moment';
import { I18nService } from 'nestjs-i18n';
import { AppConfigService } from 'src/config/app-config/app-config.service';
import { Errors } from 'src/message-constants/error.constants';
import { Messages } from 'src/message-constants/message.constants';
import * as utils from 'src/utils';

// Handle MySQL server errors
const fetchMysqlServerErrorMessage = (exception: any): string | { value: string; args: Record<string, any> } => {
  const message = Errors.BadRequest;

  switch (exception.code) {
    case 'ER_DUP_ENTRY': {
      // Example: "Duplicate entry 'test@email.com' for key 'user.email'"
      const match = exception.sqlMessage.match(/for key '(.+?)'/);
      const field = match ? utils.removeUnderscore(match[1].split('.').pop() || match[1]) : 'field';
      return { value: Messages.AlreadyExists, args: { field } };
    }
    case 'ER_NO_REFERENCED_ROW_2':
    case 'ER_ROW_IS_REFERENCED_2':
      return Errors.ConstraintError; // e.g., foreign key constraint
    case 'ER_PARSE_ERROR':
      return Errors.QuerySyntaxError;
    default:
      return message;
  }
};

@Catch()
export class HttpExceptionFilter implements ExceptionFilter {
  constructor(
    private readonly appConfigService: AppConfigService,
    private i18n: I18nService,
  ) {}

  catch(exception: Error, host: ArgumentsHost) {
    const context = host.switchToHttp();
    const response = context.getResponse();
    const request = context.getRequest();
    const language = request.headers['accept-language'] || this.appConfigService.applicationDefaults.language;

    let statusCode = 500;
    let message: any = Errors.InternalServerError;
    let error = 'Internal Server Error';

    if (exception instanceof HttpException) {
      statusCode = exception.getStatus();
      message = exception.getResponse()['message'];
      error = exception.getResponse()['error'];
    } else if (exception.message === 'BADCORS') {
      statusCode = 403;
      message = Errors.CorsError;
      error = 'Forbidden';
    } else if (exception.name === 'QueryFailedError') {
      // TypeORM wraps MySQL errors in QueryFailedError
      statusCode = 400;
      message = fetchMysqlServerErrorMessage(exception);
      error = 'Bad Request';
    }

    response.status(statusCode).json({
      success: false,
      statusCode: statusCode,
      message: utils.getTranslatedMessage(this.i18n, message, language),
      error: error,
      timestamp: moment().tz(this.appConfigService.applicationDefaults.timezone).toISOString(),
    });
  }
}
