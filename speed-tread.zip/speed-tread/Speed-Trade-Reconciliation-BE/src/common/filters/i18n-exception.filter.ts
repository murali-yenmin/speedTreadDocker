import { ArgumentsHost, Catch, ExceptionFilter } from '@nestjs/common';
import moment from '../../utils/moment';
import { I18nService, I18nValidationException } from 'nestjs-i18n';
import { AppConfigService } from 'src/config/app-config/app-config.service';
import * as utils from 'src/utils';

@Catch(I18nValidationException)
export class I18nValidationExceptionFilter implements ExceptionFilter {
  constructor(
    private readonly i18n: I18nService,
    private readonly appConfigService: AppConfigService,
  ) {}

  catch(exception: I18nValidationException, host: ArgumentsHost) {
    const context = host.switchToHttp();
    const response = context.getResponse();

    const args: any = exception.errors[0];
    const messageKey: string = Object.keys(args.constraints).at(0);

    response.status(exception.getStatus()).json({
      success: false,
      statusCode: exception.getStatus(),
      message: utils.removeUnderscore(args.constraints[messageKey]),
      error: exception.message,
      timestamp: moment().tz(this.appConfigService.applicationDefaults.timezone).toISOString(),
    });
  }
}
