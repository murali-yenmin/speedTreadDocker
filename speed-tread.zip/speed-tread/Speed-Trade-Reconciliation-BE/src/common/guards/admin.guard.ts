import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Request } from 'express';
import { AppConfigService } from 'src/config/app-config/app-config.service';
import { LoggedAdmin, LoggedUser } from '../interfaces/logged-user.interface';
import { ManagementUsersService } from 'src/modules/management-users/management-users.service';

@Injectable()
export class AdminGuard implements CanActivate {
  constructor(
    private jwtService: JwtService,
    private userService: ManagementUsersService,
    private readonly appConfigService: AppConfigService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const token = this.extractedTokenFromHeader(request);
    if (!token || token?.toLowerCase() === 'null') {
      throw new UnauthorizedException();
    }
    try {
      const payload = await this.jwtService.verifyAsync(token, {
        secret: this.appConfigService.jwtConstant,
      });

      if (!payload) throw new UnauthorizedException();

      const loggedUser: LoggedAdmin = await this.userService.findOne({
        where: {
          unique_id: payload?.unique_id,
          is_active: true,
        },
        select: {
          unique_id: true,
          email_address: true,
          role: true,
          user_name: true,
          // exclude password
          password: false,
          is_active: true,
        },
      });
      if (!loggedUser) throw new UnauthorizedException();
      if (!loggedUser?.is_active) throw new UnauthorizedException();
      request.user = {
        unique_id: loggedUser.unique_id,
        user_name: loggedUser.user_name,
        email_address: loggedUser.email_address,
        role: loggedUser.role,
        is_active: loggedUser.is_active,
      };

      return true;
    } catch {
      throw new UnauthorizedException();
    }
  }

  private extractedTokenFromHeader(request: Request): string | undefined {
    const [type, token] = request.headers.authorization?.split(' ') ?? [];
    return type === 'Bearer' ? token : undefined;
  }
}
