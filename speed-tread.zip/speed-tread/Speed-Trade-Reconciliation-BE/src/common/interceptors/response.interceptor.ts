import { Injectable, NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import moment from '../../utils/moment';
import { I18nService } from 'nestjs-i18n';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AppConfigService } from 'src/config/app-config/app-config.service';
import { getTranslatedMessage } from 'src/utils';

@Injectable()
export class ResponseInterceptor implements NestInterceptor {
  constructor(
    private readonly i18n: I18nService,
    private readonly appConfigService: AppConfigService,
  ) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const request = context.switchToHttp().getRequest();
    const language = request.headers['accept-language'] || this.appConfigService.applicationDefaults.language; // Default language if not provided in request
    return next.handle().pipe(
      map((result) => {
        const response = context.switchToHttp().getResponse();
        const statusCode = result?.statusCode ? result?.statusCode : 200;
        response.status(statusCode);
        const message = result?.args ? { key: result.message, args: result.args } : result.message;
        return {
          success: result?.status,
          statusCode,
          message: getTranslatedMessage(this.i18n, message, language),
          data: result.data,
          error: result?.error,
          timestamp: moment().tz(this.appConfigService.applicationDefaults.timezone).toISOString(),
        };
      }),
    );
  }
}
