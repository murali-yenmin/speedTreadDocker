export interface Condition {
  operation: string;
  fieldName: string;
  fieldString: string;
}

export interface EmailType {
  to: string;
  subject: string;
  templateName: string;
  variables: Record<string, any>;
}
