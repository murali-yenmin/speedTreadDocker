export interface Application {
  environment: string;
  host: string;
  port: number;
}

export interface ApplicationDefaults {
  language: string;
  timezone: string;
}

export interface DBConnections {
  dbHost: string;
  dbPort: number;
  dbUser: string;
  dbPass: string;
  dbName: string;
}

interface ServiceOptions {
  host: string;
  port: number;
}

export interface CorsOptions {
  origin: string;
  methods: string[];
  allowedHeaders: string[];
}

export interface SendEmail {
  mail_type: string;
  mail_to: string;
  subject?: string;
  data?: Record<string, any>;
  cc?: Record<string, any>[];
  attachments?: Record<string, any>[];
}
