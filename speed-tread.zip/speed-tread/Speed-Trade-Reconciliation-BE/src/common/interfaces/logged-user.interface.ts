export interface LoggedAdmin {
  unique_id: string;
  user_name: string;
  email_address: string;
  role: object;
  is_active: boolean;
}
export interface LoggedUser {
  unique_id: string;
  full_name?: string;
  email_address: string;
  permanent_address?: object;
  phone_number?: object;
  role: string;
  is_active: boolean;
}
