export interface tenantDetails {
  id: string;
  name: string;
  email_address: string;
}

export interface NotificationPayload {
  tenant: tenantDetails;
  description: string;
  category: string;
  system_generated: boolean;
  created_by?: tenantDetails;
}
