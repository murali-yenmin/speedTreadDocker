// import { Request } from 'express';
// import { JwtService } from '@nestjs/jwt';
// import { AppConfigService } from 'src/config/app-config/app-config.service';
// import { UserRoles } from 'src/constants/app.constant';

// export class RoleCheckMiddleware {
//   constructor(
//     private jwtService: JwtService,
//     private configService: AppConfigService,
//   ) {}

//   async validateRole(req: Request, allowedRoles: string[]): Promise<boolean> {
//     const token = req.headers.authorization?.split(' ')[1];

//     if (!token) return false;

//     try {
//       const { id, role } = this.jwtService.verify(token, {
//         secret: this.configService.jwtConstant,
//       });

//       let user;
//       if ([UserRoles.Admin, UserRoles.Super].includes(role)) {
//         user = await this.userService.findOne({ id, is_deleted: false });
//       } else if (role === UserRoles.Tenant) {
//         user = await this.userService.findOne({ id, is_deleted: false });
//       }

//       return !!user && user.is_active && allowedRoles.includes(role);
//     } catch {
//       return false;
//     }
//   }
// }
