import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Application, ApplicationDefaults, CorsOptions, DBConnections } from 'src/common/interfaces/config.interface';

@Injectable()
export class AppConfigService {
  constructor(private configService: ConfigService) {}

  get application(): Application {
    return {
      environment: this.configService.get<string>('NODE_ENV'),
      host: this.configService.get<string>('HOST'),
      port: this.configService.get<number>('PORT'),
    };
  }

  get applicationDefaults(): ApplicationDefaults {
    return {
      language: this.configService.get<string>('DEFAULT_LANGUAGE'),
      timezone: this.configService.get<string>('DEFAULT_TIMEZONE'),
    };
  }

  get passwordExpireDays(): number {
    return this.configService.get<number>('PASSWORD_EXPIRE_DAYS');
  }
  get appURL(): string {
    return this.configService.get<string>('APP_URL');
  }
  get adminURL(): string {
    return this.configService.get<string>('ADMIN_URL');
  }

  get otpExpiresTime(): number {
    return this.configService.get<number>('OTP_EXPIRE_TIME_IN_MIN');
  }

  get jwtConstant(): string {
    return this.configService.get<string>('JWT_CONSTANT');
  }

  get tokenExpiry(): string {
    return this.configService.get<string>('TOKEN_EXPIRY');
  }

  get forgotPasswordLink(): string {
    return this.configService.get<string>('FORGOT_PASSWORD_LINK');
  }

  get dbConfig(): DBConnections {
    return {
      dbHost: process.env.DB_HOST,
      dbPort: Number(process.env.DB_PORT),
      dbUser: process.env.DB_USER,
      dbPass: process.env.DB_PASS,
      dbName: process.env.DB_NAME,
    };
  }

  get cors(): CorsOptions {
    return {
      origin: this.configService.get<string>('CORS_ORIGIN'),
      methods: ['GET', 'POST', 'PUT', 'DELETE'],
      allowedHeaders: ['Content-Type', 'Authorization'],
    };
  }
}
