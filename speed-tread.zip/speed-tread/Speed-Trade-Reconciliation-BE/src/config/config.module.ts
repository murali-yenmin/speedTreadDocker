import { Module } from '@nestjs/common';
import { DatabaseModule } from './database/database.module';
import { AppConfigModule } from './app-config/app-config.module';
import { I18nConfigModule } from './i18n/i18n.module';

@Module({
  imports: [AppConfigModule, I18nConfigModule, DatabaseModule],
})
export class ConfigModule {}
