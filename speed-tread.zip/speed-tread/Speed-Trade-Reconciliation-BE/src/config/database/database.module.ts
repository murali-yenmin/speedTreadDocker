// src/database/database.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppConfigService } from '../app-config/app-config.service';

@Module({
  imports: [
    TypeOrmModule.forRootAsync({
      inject: [AppConfigService],
      useFactory: async (configService: AppConfigService) => ({
        type: 'mysql',
        host: configService.dbConfig.dbHost, // e.g. localhost
        port: configService.dbConfig.dbPort, // e.g. 3306
        username: configService.dbConfig.dbUser, // e.g. root
        password: configService.dbConfig.dbPass, // e.g. root123
        database: configService.dbConfig.dbName, // e.g. nest_app
        autoLoadEntities: true,
        synchronize: false, // ❌ turn off in production
        timezone: '+08:00',
      }),
    }),
  ],
})
export class DatabaseModule {}
