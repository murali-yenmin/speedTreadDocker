import { Module } from '@nestjs/common';
import { AcceptLanguageResolver, I18nJsonLoader, I18nModule } from 'nestjs-i18n';
import * as path from 'path';
import { AppConfigService } from '../app-config/app-config.service';

@Module({
  imports: [
    I18nModule.forRootAsync({
      useFactory: (configService: AppConfigService) => ({
        fallbackLanguage: 'en', // Set default language to English
        loader: I18nJsonLoader, // Use JSON loader
        loaderOptions: {
          path: path.join(__dirname, '../../languages/'), // Ensure this is correct
          watch: true,
        },
      }),
      resolvers: [new AcceptLanguageResolver({ matchType: 'strict-loose' })],
      inject: [AppConfigService],
    }),
  ],
})
export class I18nConfigModule {}
