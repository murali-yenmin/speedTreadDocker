export enum App {
  Admin = 'ADMIN',
  User = 'USER',
  SuperAdmin = 'SUPER_ADMIN',
}
export const Status = {
  Active: 'active',
  Inactive: 'inactive',
};

export const OtpType = {
  AccountVerification: 'email_verification',
  TwoStepVerification: 'two_step_verification',
  ForgotPassword: 'forgot_password',
};

export const SubjectType = {
  AccountVerification: 'Verify Your Account - Secure Your Access',
  TwoStepVerification: 'Confirm Your Identity - Two-Step Verification Code',
  ResetPasswordRequest: 'Password Reset Request - Action Required',
  PasswordResetConfirmation: 'Confirmation: Your Password Has Been Updated',
  ChangePassword: 'Your Password Has Expired - Action Required',
  OnboardAdmin: "Welcome to the Team! Let's Get Started",
  GeneratePassword: 'Your Account Password Has Been Generated - Please Use Securely',
};

export const ReceivableMode = {
  ACH: 'ach',
  CHECK: 'check',
  PORTAL: 'portal',
};
export const Payment = {
  CREDIT: 'CREDIT',
  CREDIT_PERCENT: 0.03,
  DEBIT: 'DEBIT',
  DEBIT_PERCENT: 0.015,
  BANK_ACCOUNT: 'BANK_ACCOUNT',
  BANK_ACCOUNT_PERCENT: 0.015,
};

export enum Mode {
  AUTO = 'auto',
  MANUAL = 'manual',
}

export enum PaymentType {
  FULL = 'full',
  SPLIT = 'split',
}

export enum TenantsFilterTypes {
  WEEKLY = 'weekly',
  ANNUALLY = 'annually',
}

export enum StatusTypes {
  APPROVED = 'approved',
  REJECTED = 'rejected',
  PENDING = 'pending',
  SUBMITTED = 'submitted',
  RESUBMITTED = 'resubmitted',
  IN_REVIEW = 'inreview',
  EXPIRED = 'expired',
  EXPIRING_SOON = 'expiring_soon',
  EXPIRING_TODAY = 'expiring_today',
}

export enum ActivityStatus {
  SUCCESS = 'success',
  FAILED = 'failed',
}
export enum PaymentStatus {
  PAID = 'paid',
  SUCCESS = 'success',
  FAILED = 'failed',
}

export enum EmailDescription {
  OnboardMail = `Welcome to Speed Trade Reconciliation! We're excited to have you on board. To get started, please set your password using the secure link below:`,
  ForgotPasswordMail = `We received a request to reset your password for your Speed Trade Reconciliation account. If you made this request, please use the link below to set a new password:`,
  RegeneratePasswordUsingLink = `We have received a request to reset your password. Please use the link below to create a new password for your account. If you did not request this change, please ignore this email.`,
}

export enum OrderStatus {
  Processing = 'processing',
  Transferring = 'transferring',
  Completed = 'completed',
  Error = 'error',
}
