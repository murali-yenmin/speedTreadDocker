export enum EmailTemplates {
  LocationAPI = 'https://geolocation-db.com/json/',
  AccountVerification = 'email-verification',
  TwoStepVerification = 'two-step-verification',
  PasswordResetSuccess = 'password-reset-confirmation',
  ForgotPassword = 'forgot-password',
  ChangePassword = 'change-password',
  OnboardAdmin = 'onboard-admin',
  OnboardUser = 'onboard-user',
  GeneratePassword = 'generate-password',
}

export enum EmailVariables {
  email_verification = 'Verification email has been triggered and sent to the registered email address.',
  onboard_mail = 'Onboarding email has been successfully sent to the user’s registered email address.',
  two_step_verification = 'OTP has been sent to the registered email address as part of the two-step verification process to verify account access and ensure user identity.',
  forgot_password = 'Password reset email has been triggered and sent to the registered email address.',
  reset_password_confirmation = 'Password has been successfully reset and confirmation has been sent.',
  password_generated = 'Temporary password has been generated and shared with the user securely.',
  admin_onboarded = 'An admin account has been onboarded and login credentials sent to the registered email.',
}

export enum NotificationCategory {
  Account = 'account',
  KYC = 'kyc',
  Rental = 'rental',
  Payment = 'payment',
  Security = 'security',
}
export enum EmailSubject {
  AccountVerification = 'Verify Your Email to Activate Your Account',
  TwoStepVerification = 'Two-Step Verification Code - Confirm Your Identity',
  PasswordResetSuccess = ' Your Password Has Been Successfully Changed',
  ForgotPassword = 'Reset Your Password – Link Verification',
  RegeneratePassword = 'Password Reset Request - Action Required',
  OnboardAdmin = "Welcome to the Team! Let's Get Started",
  OnboardUser = ' Welcome',
  GeneratePassword = 'Your Account Password Has Been Generated - Please Use Securely',
}
