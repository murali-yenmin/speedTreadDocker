import { NestFactory } from '@nestjs/core';
import helmet from 'helmet';
import * as cookieParser from 'cookie-parser';
import * as compression from 'compression';
import * as moment from 'moment-timezone';
import { AppModule } from './app.module';
import { AppConfigService } from './config/app-config/app-config.service';
import { LoggingInterceptor } from './common/interceptors/logger.interceptor';
import { I18nValidationPipe } from 'nestjs-i18n';
import * as express from 'express';

async function app() {
  // Load Configuration
  moment.tz.setDefault(process.env.DEFAULT_TIMEZONE);
  const app = await NestFactory.create(AppModule);
  const appConfig = app.get(AppConfigService);
  // Helmet for adding headers
  app.use(helmet());

  // Set default timezone for moment

  // Set 1 MB body limit for JSON and urlencoded data
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true, limit: '1mb' }));

  // Define CORS options for general routes
  // app.enableCors({
  //   origin(origin, callback) {
  //     if (appConfig.cors.origin === origin) callback(null, true);
  //     else callback(null, true);
  //   },
  //   methods: appConfig.cors.methods,
  //   allowedHeaders: appConfig.cors.allowedHeaders,
  //   credentials: true,
  // });
  app.enableCors();
  // Compression Middleware
  app.use(compression());

  // Cookie Parser
  app.use(cookieParser());

  // CSRF Protection
  // app.use(csurf({ cookie: true }));

  app.useGlobalPipes(
    new I18nValidationPipe({
      transform: true,
      whitelist: true,
      forbidNonWhitelisted: true,
    }),
  );

  app.useGlobalInterceptors(new LoggingInterceptor());

  app.setGlobalPrefix('api/v1/');

  await app.listen(appConfig.application.port);
}
app();
