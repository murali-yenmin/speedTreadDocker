export enum Errors {
  RequestNotFound = 'errors.requestNotFound',
  InternalServerError = 'errors.internalServerError',
  CorsError = 'errors.corsError',
  BadRequest = 'errors.badRequest',
  UnauthorizedAccess = 'errors.unauthorizedAccess',
  AccessForbidden = 'errors.accessForbidden',
  ConstraintError = 'errors.ConstraintError',
  QuerySyntaxError = 'errors.QuerySyntaxError',
  CurrencyPairRateNotConfigured = 'errors.currencyPairRateNotConfigured',
}
