import { MigrationInterface, QueryRunner } from "typeorm";

export class UpdateOrderRate1764695086258 implements MigrationInterface {
    name = 'UpdateOrderRate1764695086258'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`orders\` CHANGE \`rate\` \`rate\` decimal(18,3) NULL DEFAULT '0.000'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`orders\` CHANGE \`rate\` \`rate\` decimal(18,2) NULL DEFAULT '0.00'`);
    }

}
