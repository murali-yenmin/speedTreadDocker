import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class AddSettlementDate1764695086259 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('transactions', [
      new TableColumn({
        name: 'settlement_date',
        type: 'varchar',
        length: '50',
        isNullable: true,
      }),
    ]);

    await queryRunner.addColumns('order_transactions', [
      new TableColumn({
        name: 'settlement_date',
        type: 'varchar',
        length: '50',
        isNullable: true,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn('transactions', 'settlement_date');
    await queryRunner.dropColumn('order_transactions', 'settlement_date');
  }
}
