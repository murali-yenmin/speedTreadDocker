import { Controller, Get, Query } from '@nestjs/common';
import { AccountsService } from './accounts.service';
import { Account } from './entities/account.entity';

@Controller('accounts')
export class AccountsController {
  constructor(private readonly accountsService: AccountsService) {}

  @Get()
  async getAll(@Query('search') search?: string,@Query('limit') limit?: number): Promise<object> {
    return this.accountsService.getAll(search, limit);
  }
}
