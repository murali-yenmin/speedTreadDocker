import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ILike, Like, Repository } from 'typeorm';
import { Account } from './entities/account.entity';
import { sendSuccess } from 'src/utils/response.utils';
import { generate } from 'rxjs';
import { generateRandomId } from 'src/utils';

@Injectable()
export class AccountsService {
  constructor(
    @InjectRepository(Account)
    private readonly accountRepository: Repository<Account>,
  ) {}

  async getAll(search?: string, limit?: number): Promise<object> {
    const qb = this.accountRepository.createQueryBuilder('a');

    if (search) {
      qb.where('a.name LIKE :search', { search: `${search}%` })
        .orderBy(
          `
        CASE
          WHEN a.name = :exact THEN 0
          ELSE 1
        END
        `,
          'ASC',
        )
        .addOrderBy('a.name', 'ASC')
        .setParameter('exact', search);
    } else {
      qb.orderBy('a.name', 'ASC');
    }

    qb.take(limit || 30);

    const result = await qb.getMany();
    return sendSuccess('Accounts retrieved successfully', result);
  }

  async resolveAccountId(accountIdOrName: string): Promise<Account> {
    // Try to find account by unique_id OR name
    let account = await this.accountRepository.findOne({
      where: [{ unique_id: accountIdOrName }, { name: accountIdOrName }],
    });

    // If not found, create a new one
    if (!account) {
      account = this.accountRepository.create({
        name: accountIdOrName,
      });
      await this.accountRepository.save(account);
    }

    return account;
  }
}
