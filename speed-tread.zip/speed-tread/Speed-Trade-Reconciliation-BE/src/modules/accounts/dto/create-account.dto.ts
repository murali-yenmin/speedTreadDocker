import { IsBoolean, IsNotEmpty, IsString, MaxLength } from 'class-validator';

export class CreateAccountDto {
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  name: string;

  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  unique_id: string;

  @IsBoolean()
  status: boolean;
}