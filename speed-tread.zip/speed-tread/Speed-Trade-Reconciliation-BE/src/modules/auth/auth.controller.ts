import { Body, Controller, Get, Post, UseGuards } from '@nestjs/common';
import { LoginDto } from './dto/login.dto';
import { App } from 'src/constants/app.constant';
import { ForgotPasswordDto } from './dto/forgot-password.dto';
import { VerifyForgotPasswordDto } from './dto/verify-forgot-password.dto ';
import { ChangePasswordDto } from './dto/change-password.dto';
import { LoggedAdmin } from 'src/common/interfaces/logged-user.interface';
import { GetLoggedUser } from 'src/common/decorators/logged-admin.decorator';
import { AdminGuard } from 'src/common/guards/admin.guard';
import { AuthService } from './auth.service';
import { ManagementUsersService } from '../management-users/management-users.service';
import { RegeneratePasswordDto } from './dto/email.dto';

@Controller('secure')
export class AuthAdminController {
  constructor(
    private readonly authService: AuthService,
    private usersService: ManagementUsersService,
  ) {}

  /**
   * Authenticates a user and logs them into the system.
   * Initiates the login process using the provided credentials.
   */

  @Post('login')
  login(@Body() data: LoginDto) {
    return this.authService.login(data, App?.Admin);
  }
  /**
   * Authenticates a user and logs them into the system.
   * Initiates the login process using the provided credentials.
   */

  @Post('/forgot-password')
  AdminForgotPassword(@Body() data: ForgotPasswordDto) {
    return this.authService.forgotPassword(data);
  }

  @Post('verify-forgot')
  verifyForgotOtp(@Body() data: VerifyForgotPasswordDto) {
    return this.authService.verifyForgotPassword(data);
  }

  @Post('regenerate-password')
  regeneratePassword(@Body() data: RegeneratePasswordDto) {
    return this.authService.regeneratePassword(data);
  }

  @UseGuards(AdminGuard)
  @Post('change-password')
  changePassword(@Body() data: ChangePasswordDto, @GetLoggedUser() loggedUser: LoggedAdmin) {
    return this.authService.changePassword(data, loggedUser);
  }

  @UseGuards(AdminGuard)
  @Get('profile-details')
  getProfileDetails(@GetLoggedUser() loggedUser: LoggedAdmin) {
    return this.usersService.getUser(loggedUser.unique_id);
  }
}
