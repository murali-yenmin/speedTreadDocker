import { Module } from '@nestjs/common';
import { AuthAdminController } from './auth.controller';
import { JwtModule } from '@nestjs/jwt';
import { JwtHelper } from './jwt.service';
import { AuthService } from './auth.service';
import { ManagementUsersModule } from '../management-users/management-users.module';
import { AppService } from 'src/app.service';

@Module({
  imports: [
    ManagementUsersModule,
    JwtModule.register({
      global: true,
      secret: process.env.JWT_CONSTANT,
      signOptions: {
        expiresIn: '7d',
      },
    }),
  ],
  controllers: [AuthAdminController],
  providers: [AuthService, JwtHelper, AppService],
})
// implements NestModule
export class AuthModule {}
