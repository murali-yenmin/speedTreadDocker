import { LoginDto } from './dto/login.dto';
import { ChangePasswordDto } from './dto/change-password.dto';
import { AppConfigService } from 'src/config/app-config/app-config.service';
import { commonCatch, sendFailure, sendSuccess } from 'src/utils/response.utils';
import * as utils from 'src/utils';
import { Messages } from 'src/message-constants/message.constants';
import { HttpStatus, Injectable, Logger } from '@nestjs/common';
import { VerifyForgotPasswordDto } from './dto/verify-forgot-password.dto ';
import { Errors } from 'src/message-constants/error.constants';
import { LoggedAdmin } from 'src/common/interfaces/logged-user.interface';
import { I18nService } from 'nestjs-i18n';
import { ManagementUsersService } from '../management-users/management-users.service';
import { JwtHelper } from './jwt.service';
import { AppService } from 'src/app.service';
import { RegeneratePasswordDto } from './dto/email.dto';
import { EmailDescription } from 'src/constants/app.constant';
import { EmailSubject } from 'src/constants/email.constants';

@Injectable()
export class AuthService {
  private logger = new Logger(AuthService.name);
  constructor(
    private configService: AppConfigService,
    private userService: ManagementUsersService,
    private appService: AppService,
    private readonly i18n: I18nService,
    private readonly jwtService: JwtHelper,
  ) {}

  /**
   * Asynchronously handles user login.
   * @param data - LoginDto object containing user credentials.
   * @param deviceDetails - DeviceDetailsData object containing device information.
   * @returns Promise of SuccessResponse.
   */
  async login(data: LoginDto, service: any): Promise<any> {
    try {
      const decrypted = await utils?.decryptCryptoPwd(data?.password);

      if (!decrypted) {
        return sendFailure(Messages.InvalidCredentials, HttpStatus.UNAUTHORIZED, { login: false });
      }
      // Attempt to find user by email and password
      const loggedUser = await this.userService.findOne({
        where: {
          email_address: data.email_address?.toLowerCase(),
          is_active: true,
        },
      });

      if (!loggedUser) {
        return sendFailure(Messages.InvalidCredentials, HttpStatus.UNAUTHORIZED, { login: false });
      }
      if (!(await utils.verifyHashPwd(decrypted, loggedUser?.password))) {
        return sendFailure(Messages.InvalidCredentials, HttpStatus.UNAUTHORIZED, { login: false });
      }
      // // Check if user account is active
      if (!loggedUser.is_active) {
        return sendFailure(Messages.AccountBlocked, HttpStatus.FORBIDDEN);
      }
      // // // Generate authentication token
      const token = await this.jwtService.generateToken({
        unique_id: loggedUser?.unique_id,
        user_name: loggedUser?.user_name,
        email_address: loggedUser?.email_address,
        role: loggedUser?.role,
      });

      if (!token) return sendFailure(Errors?.AccessForbidden, HttpStatus?.FORBIDDEN);

      return sendSuccess(Messages.LoginSuccess, { login: true, token });
    } catch (error) {
      this.logger.error('This error is from login');
      this.logger.error(error);
      return commonCatch(error);
    }
  }

  // async resendForgotPasswordMail(data: SendOtpDto): Promise<any> {
  //   try {
  //     const selectedService = await this.getService(service);
  //     const loggedUser = await selectedService.findOne({ email_address: utils.getCaseSensitive(data.email_address) });
  //     if (!loggedUser) return sendFailure(Messages.UserNotFound, HttpStatus?.OK);
  //     if (loggedUser.otp_type === '') return sendFailure(Errors?.BadRequest, HttpStatus?.BAD_REQUEST);
  //     const otp = utils.generateOTP();
  //     // Send OTP to user's email and update OTP in the database
  //     const mail = await Promise.all([
  //       await this.sendOtpEmail(loggedUser?.otp_type, loggedUser, otp),
  //       selectedService.findOneAndUpdate(
  //         { unique_id: loggedUser.unique_id },
  //         {
  //           $set: {
  //             otp: utils.createHashOtp(otp),
  //             otp_expires_at: utils.addMinutes(this.configService.otpExpiresTime),
  //           },
  //         },
  //       ),
  //     ]);
  //     return sendSuccess(Messages.OtpSentSuccess);
  //   } catch (error) {
  //     this.logger.error('This error is from sendOtp');
  //     this.logger.error(error);
  //     return commonCatch(error);
  //   }
  // }

  /**
   * Method to initiate the forgot password process.
   * @param data - Data containing user's email address.
   * @returns A Promise resolving to a success response.
   */
  async forgotPassword(data: RegeneratePasswordDto): Promise<any> {
    try {
      const user = await this.userService.findOne({
        where: {
          email_address: data?.email_address?.toLowerCase(),
          is_active: true,
        },
      });

      if (!user)
        return sendFailure(Messages.UserNotFound, HttpStatus?.OK, {
          error_field: {
            email_address: utils.getTranslatedMessage(
              this.i18n,
              Messages?.UserNotFound,
              this.configService.applicationDefaults.language,
            ),
          },
        });

      if (!user?.is_active) {
        return sendFailure(Messages?.AccountBlocked, HttpStatus?.FORBIDDEN);
      }
      const otp = utils?.generateOTP();
      const hashedOtp = utils?.createHashOtp(otp);
      const updatedData = await this.userService.update(
        { unique_id: user?.unique_id },
        {
          secret_key: hashedOtp,
          key_expires_at: utils.addDays(1),
        },
      );

      this.appService.sendForgotMail(updatedData, EmailDescription?.ForgotPasswordMail, EmailSubject?.ForgotPassword);

      return sendSuccess(Messages.ResetPasswordLinkSent);
    } catch (error) {
      this.logger.error('This error is from forgotPassword');
      this.logger.error(error);
      return sendFailure(Errors?.InternalServerError, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  async changePassword(data: ChangePasswordDto, loggedUser: LoggedAdmin): Promise<any> {
    try {
      const userDetails = await this.userService.findOne({
        where: { unique_id: loggedUser?.unique_id, is_active: true },
      });

      if (!userDetails) {
        return sendFailure(Messages.UserNotExist, HttpStatus.OK);
      }

      const currentPassword = await utils.decryptCryptoPwd(data.current_password);
      if (!currentPassword || !(await utils.verifyHashPwd(currentPassword, userDetails.password))) {
        return sendFailure(Messages.PasswordMismatched, HttpStatus.OK);
      }

      const newPassword = await utils.decryptCryptoPwd(data.password);
      if (await utils.verifyHashPwd(newPassword, userDetails.password)) {
        return sendFailure(Messages.PasswordAlreadyUsed, HttpStatus.OK);
      }

      const hashedPassword = await utils.createHashPwd(newPassword);
      await this.userService.update({ unique_id: loggedUser?.unique_id }, { password: hashedPassword });

      return sendSuccess(Messages.PasswordChangedSuccess);
    } catch (error) {
      this.logger.error('Error in changePassword:', error);
      return commonCatch(error);
    }
  }

  async verifyForgotPassword(data: VerifyForgotPasswordDto): Promise<any> {
    try {
      const user = await this.userService.findOne({
        where: { secret_key: data?.secret_key },
      });

      if (!user) {
        return sendFailure(Messages.ResetPasswordLinkExpired, HttpStatus.OK);
      }

      // if (user?.key_expires_at < new Date()) {
      //   return sendFailure(Messages.ResetPasswordLinkSent, HttpStatus.OK);
      // }
      const decrypted = await utils?.decryptCryptoPwd(data?.new_password);

      // Update password
      await this.userService.update(
        { unique_id: user?.unique_id },
        { password: await utils.createHashPwd(decrypted), is_active: true, secret_key: '' },
      );

      return sendSuccess(Messages.PasswordChangedSuccess);
    } catch (error) {
      this.logger.error('Error in verifyForgotPassword:', error);
      return commonCatch(error);
    }
  }

  async regeneratePassword(data: RegeneratePasswordDto): Promise<any> {
    try {
      const user = await this.userService.findOne({
        where: {
          email_address: data?.email_address?.toLowerCase(),
        },
      });

      if (!user) return sendFailure(Messages.UserNotFound, HttpStatus?.OK);

      if (!user?.is_active) {
        return sendFailure(Messages?.AccountInactiveNoAction, HttpStatus?.OK);
      }
      const otp = utils?.generateOTP();
      const hashedOtp = utils?.createHashOtp(otp);
      await this.userService.update(
        { unique_id: user?.unique_id },
        {
          secret_key: hashedOtp,
          key_expires_at: utils.addDays(1),
        },
      );
      const mailSent = await this.appService.sendForgotMail(
        { ...data, ...user, secret_key: user?.secret_key },
        EmailDescription.RegeneratePasswordUsingLink,
        EmailSubject?.RegeneratePassword,
      );
      if (!mailSent) {
        return sendFailure(Messages.MailNotSent, HttpStatus.OK);
      }
      return sendSuccess(Messages.ResetPasswordLinkSent);
    } catch (error) {
      this.logger.error('Error in regeneratePassword:', error);
      return commonCatch(error);
    }
  }
}
