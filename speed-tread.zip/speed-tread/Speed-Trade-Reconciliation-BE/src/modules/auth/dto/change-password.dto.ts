import { IsNotEmpty, MaxLength, MinLength } from 'class-validator';
import { MatchPassword } from 'src/common/decorators/match-password.decorator';

export class ChangePasswordDto {
  @IsNotEmpty()
  current_password: string;

  @IsNotEmpty()
  password: string;

  @IsNotEmpty()
  @MatchPassword('password', { message: 'Password Mismatched' })
  confirm_password: string;
}
