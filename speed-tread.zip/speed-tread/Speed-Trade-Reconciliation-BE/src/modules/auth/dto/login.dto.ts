import { IsEmail, IsNotEmpty, IsString } from 'class-validator';

export class LoginDto {
  @IsEmail()
  @IsNotEmpty()
  email_address: string;
  @IsNotEmpty()
  password: string;
}
export class GoogleLoginsDto {
  @IsNotEmpty()
  @IsString()
  token: string;
}
