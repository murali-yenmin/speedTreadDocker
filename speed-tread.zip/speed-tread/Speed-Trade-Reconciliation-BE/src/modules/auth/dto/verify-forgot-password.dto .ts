import { IsEmail, IsNotEmpty } from 'class-validator';
import { MatchPassword, MatchPasswordConstraint } from 'src/common/decorators/match-password.decorator';
export class VerifyForgotPasswordDto {
  @IsNotEmpty()
  secret_key: string;

  @IsNotEmpty()
  new_password: string;

  @IsNotEmpty()
  @MatchPassword('new_password', { message: 'Password Mismatched' })
  confirm_password: string;
}
