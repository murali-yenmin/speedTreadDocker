// src/common/helpers/jwt.helper.ts
import { Injectable } from '@nestjs/common';
import * as jwt from 'jsonwebtoken';
import { AppConfigService } from 'src/config/app-config/app-config.service';

@Injectable()
export class JwtHelper {
  private readonly secret: string;
  private readonly expiresIn: string;

  constructor(private readonly appConfigService: AppConfigService) {
    this.secret = this.appConfigService.jwtConstant;
    this.expiresIn = this.appConfigService.tokenExpiry;
  }

  generateToken(payload: object, expiresIn: string = this.expiresIn): string {
    return jwt.sign(payload, this.secret, { expiresIn });
  }

  verifyToken(token: string): any {
    try {
      return jwt.verify(token, this.secret);
    } catch (err) {
      throw new Error('Invalid or expired token');
    }
  }
}
