import { Body, Controller, Get, Param, Post, HttpCode, HttpStatus } from '@nestjs/common';
import { CurrencyOrderService } from './currency-order.service';
import { CurrencyOrder } from './entities/currency-order.entity';
import { BulkUpsertCurrencyOrderDto } from './dto/bulk-upsert-currency-order.dto';

@Controller('currency-order')
export class CurrencyOrderController {
  constructor(private readonly currencyOrderService: CurrencyOrderService) {}

  @Get('/:groupId')
  getCurrencyOrdersWithValues(@Param('groupId') groupId: string): Promise<any> {
    return this.currencyOrderService.getCurrencyOrdersWithValues(groupId, 'order');
  }

  @Get('transaction/:groupId')
  getTransactionsWithValues(@Param('groupId') groupId: string) {
    return this.currencyOrderService.getCurrencyOrdersWithValues(groupId, 'transaction');
  }

  @Post('bulk-upsert')
  async bulkUpsert(@Body() bulkUpsertCurrencyOrderDto: BulkUpsertCurrencyOrderDto) {
    return await this.currencyOrderService.bulkUpsert(bulkUpsertCurrencyOrderDto);
  }
}
