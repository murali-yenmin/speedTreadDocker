import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CurrencyOrder } from './entities/currency-order.entity';
import { CurrencyOrderService } from './currency-order.service';
import { CurrencyOrderController } from './currency-order.controller';
import { TransactionModule } from '../transaction/transaction.module';
import { OrderModule } from '../order/order.module';
import { TransactionService } from '../transaction/transaction.service';
import { Transaction } from '../transaction/entities/transaction.entity';
import { Currency } from '../currency/entity/currency.entity';
import { CurrencyPair } from '../currency-pair/entities/currency-pair.entity';
import { ManagementUsers } from '../management-users/entities/management-user.entity';
import { CustomerGroup } from '../customer-group/entity/customer-group.entity';
import { Account } from '../accounts/entities/account.entity';
import { AccountsModule } from '../accounts/accounts.module';
import { CurrencyModule } from '../currency/currency.module';
import { CurrencyPairModule } from '../currency-pair/currency-pair.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      CurrencyOrder,
      Transaction,
      Currency,
      CurrencyPair,
      ManagementUsers,
      CustomerGroup,
      Account,
    ]),
    OrderModule,
    TransactionModule,
    CurrencyModule,
    CurrencyPairModule,
    AccountsModule,
  ],
  controllers: [CurrencyOrderController],
  providers: [CurrencyOrderService, TransactionService],
  exports: [CurrencyOrderService],
})
export class CurrencyOrderModule {}
