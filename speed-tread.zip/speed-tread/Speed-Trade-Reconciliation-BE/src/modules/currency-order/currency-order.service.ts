import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { CurrencyOrder } from './entities/currency-order.entity';
import { BulkUpsertCurrencyOrderDto } from './dto/bulk-upsert-currency-order.dto';
import { OrderTransactionService } from '../order/order-transaction.service';
import { sendSuccess, commonCatch } from 'src/utils/response.utils';
import { Messages } from 'src/message-constants/message.constants';
import * as utils from 'src/utils';

import { TransactionService } from '../transaction/transaction.service';
import { Transaction } from 'src/modules/transaction/entities/transaction.entity'; // <--- NEW IMPORT
import e from 'express';
import { LoggedAdmin } from 'src/common/interfaces/logged-user.interface';

@Injectable()
export class CurrencyOrderService {
  private readonly logger = new Logger(CurrencyOrderService.name);

  constructor(
    @InjectRepository(CurrencyOrder)
    private readonly currencyOrderRepository: Repository<CurrencyOrder>,
    @InjectRepository(Transaction) // <--- NEW INJECTION
    private readonly transactionRepository: Repository<Transaction>, // <--- NEW PROPERTY
    private readonly orderTransactionService: OrderTransactionService,
    private readonly transactionService: TransactionService,
  ) {}

  async findByGroupId(groupId: string): Promise<CurrencyOrder[]> {
    return this.currencyOrderRepository.find({
      where: { group_id: groupId },
      order: { order: 'ASC' },
      relations: ['currency'],
    });
  }

  async getCurrencyOrdersWithValues(groupId: string, flow: string): Promise<any> {
    try {
      const currencyOrders = await this.currencyOrderRepository.find({
        where: { group_id: groupId },
        order: { order: 'ASC' },
        relations: ['currency'],
      });

      // Fetch values from both transaction and order transaction services concurrently
      const [transactionValues, orderTransactionValues] = await Promise.all([
        this.transactionService.calculateAmountForGroup(null, groupId),
        this.orderTransactionService.calculateAmountForGroup('mismatch', null, groupId),
      ]);

      // Re-implement mismatch detection logic (similar to getMismatchedCurrencies)
      const mismatchedCurrencies = new Set<string>();
      const transactionMap = new Map(transactionValues.map((t) => [t.currency, t]));
      const orderTransactionMap = new Map(orderTransactionValues.map((ot) => [ot.currency, ot]));
      const allCurrencies = new Set([...transactionMap.keys(), ...orderTransactionMap.keys()]);

      for (const currency of allCurrencies) {
        const transactionData = transactionMap.get(currency);
        const orderTransactionData = orderTransactionMap.get(currency);

        // Case 1: OrderTransaction has data, Transaction has nothing (and not both zero)
        if (!transactionData && orderTransactionData) {
          if (!(orderTransactionData.value === 0 && orderTransactionData.overall_calculated_amount === 0)) {
            mismatchedCurrencies.add(currency);
          }
          if (orderTransactionData?.status === 'all_clear' || +orderTransactionData?.value?.toFixed(2) <= 0.05) {
            mismatchedCurrencies.delete(currency);
          }
        }
        // Case 2: Transaction has data, OrderTransaction has nothing (and not both zero)
        else if (transactionData && !orderTransactionData) {
          if (!(transactionData?.value === 0 && transactionData?.overall_calculated_amount === 0)) {
            mismatchedCurrencies.add(currency);
          }
          if (transactionData?.status === 'all_clear' || +transactionData?.value?.toFixed(2) <= 0.05) {
            mismatchedCurrencies.delete(currency);
          }
        }
        // Case 3: Both have data, compare status, value, and overall_calculated_amount
        else if (transactionData && orderTransactionData) {
          if (
            transactionData.status !== orderTransactionData.status ||
            +Math.abs(+transactionData.value?.toFixed(2) - +orderTransactionData.value.toFixed(2))?.toFixed(2) > 0.05 // Math.abs(transactionData.overall_calculated_amount - orderTransactionData.overall_calculated_amount) > 0.05
          ) {
            mismatchedCurrencies.add(currency);
          }

          if (transactionData.status === 'all_clear' && orderTransactionData.status === 'all_clear') {
            mismatchedCurrencies.delete(currency);
          }
        }
      }

      // Determine which set of values to use for enrichment based on 'flow'
      const valuesToUse = flow === 'transaction' ? transactionValues : orderTransactionValues;
      const currencyValuesMap = new Map(valuesToUse.map((cv) => [cv.currency, cv]));

      const enrichedCurrencyOrders = currencyOrders.map((order) => {
        const currencyCode = order.currency.code;
        const isMismatch = mismatchedCurrencies.has(currencyCode);

        const existingValues = currencyValuesMap.get(currencyCode);

        // Destructure overall_calculated_amount if it exists in existingValues
        const { overall_calculated_amount, ...restOfExistingValues } = existingValues || {};

        const values = {
          ...(restOfExistingValues.status
            ? restOfExistingValues
            : {
                status: 'all_clear',
                value: 0.0,
                currency: currencyCode,
              }),
          error: 0,
          processing: 0,
          transferring: 0,
          changes_required: 0,
          is_mismatch: isMismatch,
        };

        return {
          ...order,
          ...values,
          currency: currencyCode,
        };
      });

      return sendSuccess(Messages.CustomerGroupsFetched, enrichedCurrencyOrders);
    } catch (error) {
      return commonCatch(error);
    }
  }

  async bulkUpsert(bulkUpsertCurrencyOrderDto: BulkUpsertCurrencyOrderDto): Promise<object> {
    try {
      const bulkUpsert = await this.updateCurrencyOrders(bulkUpsertCurrencyOrderDto);
      if (!bulkUpsert) {
        return sendSuccess(Messages.CurrencyOrderUpsertFailed);
      } else {
        return sendSuccess(Messages.CurrencyOrderUpsertedSuccessfully);
      }
    } catch (error) {
      this.logger.error('Error in bulkUpsert:', error);
      return commonCatch(error);
    }
  }

  async updateCurrencyOrders(bulkUpsertCurrencyOrderDto: BulkUpsertCurrencyOrderDto): Promise<boolean> {
    try {
      const { group_id, orders } = bulkUpsertCurrencyOrderDto;

      // If no orders are provided, it means all existing orders for this group should be deleted.
      if (!orders?.length) {
        await this.currencyOrderRepository.delete({ group_id });
        return true;
      }

      // Fetch existing orders for this group to preserve unique_id for updates and identify deletions.
      // Ensure 'group_id' is indexed in the database for efficient lookup.
      const existing = await this.currencyOrderRepository.find({
        where: { group_id },
        select: ['unique_id', 'group_id', 'currency_id'],
      });

      const incomingCurrencyIds = new Set(orders.map((order) => order.currency_id));
      const existingCurrencyIds = new Set(existing.map((e) => e.currency_id));

      // Identify currency_ids to be deleted (present in existing but not in incoming)
      const currencyIdsToDelete = Array.from(existingCurrencyIds).filter(
        (currencyId) => !incomingCurrencyIds.has(currencyId),
      );

      // Perform deletion for missing items
      if (currencyIdsToDelete.length > 0) {
        await this.currencyOrderRepository.delete({
          group_id,
          currency_id: In(currencyIdsToDelete), // Use TypeORM's In operator
        });
      }

      // Map existing records by currency_id for quick lookup (for upsert)
      const existingMap = new Map(existing.map((e) => [e.currency_id, e.unique_id]));

      // Prepare values for upsert
      const values = orders.map((order) => ({
        unique_id: existingMap.get(order.currency_id) || utils.generateRandomId(), // existing or new
        group_id,
        currency_id: order.currency_id,
        order: order.order,
      }));

      // Perform upsert for incoming orders (insert new, update existing)
      // Ensure 'group_id' and 'currency_id' together form a unique index
      // or a composite primary key for optimal upsert performance.
      // For extremely large 'values' arrays, consider splitting into batches
      // and calling upsert multiple times to reduce transaction size.
      await this.currencyOrderRepository.upsert(values, ['group_id', 'currency_id']);

      return true;
    } catch (error) {
      this.logger.error('Error in updateCurrencyOrders:', error);
      return false;
    }
  }

  async getCurrencyOrdersWithValuesForGroups(groupIds: string[], flow: string): Promise<any> {
    try {
      const currencyOrders = await this.currencyOrderRepository.find({
        where: { group_id: In(groupIds) },
        order: { order: 'ASC' },
        relations: ['currency'],
      });

      // Fetch values from both transaction and order transaction services concurrently
      const [transactionValues, orderTransactionValues] = await Promise.all([
        this.transactionService.newCalculateAmountFromGroup(groupIds, null),
        this.orderTransactionService.calculateAmountForGroups('mismatch', null, groupIds),
      ]);

      // Re-implement mismatch detection logic (similar to getMismatchedCurrencies)
      const mismatchedCurrencies = new Set<string>(); // Will store "groupId_currency"
      const transactionMap = new Map(transactionValues.map((t) => [`${t.groupId}_${t.currency}`, t]));
      const orderTransactionMap = new Map(orderTransactionValues.map((ot) => [`${ot.groupId}_${ot.currency}`, ot]));
      const allCurrencyGroupPairs = new Set([
        ...transactionValues.map((t) => `${t.groupId}_${t.currency}`),
        ...orderTransactionValues.map((ot) => `${ot.groupId}_${ot.currency}`),
      ]);

      for (const pair of allCurrencyGroupPairs) {
        const transactionData = transactionMap.get(pair);
        const orderTransactionData = orderTransactionMap.get(pair);

        if (!transactionData && !orderTransactionData) {
          continue;
        }

        // Case 1: OrderTransaction has data, Transaction has nothing (and not both zero)
        if (!transactionData && orderTransactionData) {
          if (!(orderTransactionData.value === 0 && orderTransactionData.overall_calculated_amount === 0)) {
            mismatchedCurrencies.add(pair);
          }
          if (orderTransactionData?.status === 'all_clear' || +orderTransactionData?.value?.toFixed(2) <= 0.05) {
            mismatchedCurrencies.delete(pair);
          }
        }
        // Case 2: Transaction has data, OrderTransaction has nothing (and not both zero)
        else if (transactionData && !orderTransactionData) {
          if (!(transactionData?.value === 0 && transactionData?.overall_calculated_amount === 0)) {
            mismatchedCurrencies.add(pair);
          }
          if (transactionData?.status === 'all_clear' || +transactionData?.value?.toFixed(2) <= 0.05) {
            mismatchedCurrencies.delete(pair);
          }
        }
        // Case 3: Both have data, compare status, value, and overall_calculated_amount
        else if (transactionData && orderTransactionData) {
          if (
            transactionData.status !== orderTransactionData.status ||
            +Math.abs(+transactionData.value?.toFixed(2) - +orderTransactionData.value.toFixed(2))?.toFixed(2) > 0.05 // Math.abs(transactionData.overall_calculated_amount - orderTransactionData.overall_calculated_amount) > 0.05
          ) {
            mismatchedCurrencies.add(pair);
          }

          if (transactionData.status === 'all_clear' && orderTransactionData.status === 'all_clear') {
            mismatchedCurrencies.delete(pair);
          }
        }
      }

      const valuesToUse = flow === 'transaction' ? transactionValues : orderTransactionValues;

      // Create a Map keyed by both currency and groupId
      const currencyGroupValuesMap = new Map(valuesToUse.map((cv) => [`${cv.currency}_${cv.groupId}`, cv]));

      const enrichedCurrencyOrders = currencyOrders.map((order) => {
        const currencyCode = order.currency.code;
        const groupId = order.group_id; // assuming each order has a groupId
        const isMismatch = mismatchedCurrencies.has(`${groupId}_${currencyCode}`);

        // Use both currency and groupId to find matching enrichment data
        const existingValues = currencyGroupValuesMap.get(`${currencyCode}_${groupId}`);

        // Destructure overall_calculated_amount if it exists in existingValues
        const { overall_calculated_amount, ...restOfExistingValues } = existingValues || {};

        const values = {
          ...(restOfExistingValues?.status
            ? restOfExistingValues
            : {
                status: 'all_clear',
                value: 0.0,
                currency: currencyCode,
                groupId,
              }),
          error: restOfExistingValues?.error || 0,
          processing: restOfExistingValues?.processing || 0,
          transferring: restOfExistingValues?.transferring || 0,
          changes_required: restOfExistingValues?.changes_required || 0,
          is_mismatch: isMismatch,
        };

        return {
          ...order,
          ...values,
          currency: currencyCode,
        };
      });
      return enrichedCurrencyOrders;
    } catch (error) {
      this.logger.error('Error in getCurrencyOrdersWithValuesForGroups:', error);
      return [];
    }
  }

  async createCurrencyOrderForGroup(groupId: string, currencyId: string): Promise<void> {
    try {
      const existingOrders = await this.currencyOrderRepository.find({
        where: { group_id: groupId },
        order: { order: 'DESC' },
      });

      let newOrder = 1;
      if (existingOrders.length > 0) {
        newOrder = existingOrders[0].order + 1;
      }

      const newCurrencyOrder = this.currencyOrderRepository.create({
        group_id: groupId,
        currency_id: currencyId,
        order: newOrder,
      });

      await this.currencyOrderRepository.save(newCurrencyOrder);
    } catch (error) {
      this.logger.error('Error in createCurrencyOrderForGroup:', error);
    }
  }
}
