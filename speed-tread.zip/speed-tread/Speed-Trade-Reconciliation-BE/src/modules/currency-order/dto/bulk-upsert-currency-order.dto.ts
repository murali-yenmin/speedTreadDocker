import { Type } from 'class-transformer';
import { IsArray, IsInt, IsNotEmpty, IsString, ValidateNested } from 'class-validator';

class CurrencyOrderDto {
  @IsString()
  @IsNotEmpty()
  currency_id: string;

  @IsInt()
  @IsNotEmpty()
  order: number;
}

export class BulkUpsertCurrencyOrderDto {
  @IsString()
  @IsNotEmpty()
  group_id: string;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CurrencyOrderDto)
  orders: CurrencyOrderDto[];
}
