import {
  BeforeInsert,
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';
import * as utils from 'src/utils';
import { Currency } from 'src/modules/currency/entity/currency.entity';

@Entity('currency_order')
export class CurrencyOrder {
  @PrimaryColumn({ type: 'varchar', length: 50 })
  unique_id: string;

  @BeforeInsert()
  generateUniqueId() {
    this.unique_id = utils.generateRandomId();
  }

  @Index()
  @Column({ type: 'varchar', length: 50 })
  group_id: string;

  @Index()
  @Column({ type: 'varchar', length: 50 })
  currency_id: string;

  @ManyToOne(() => Currency, { eager: true })
  @JoinColumn({ name: 'currency_id', referencedColumnName: 'unique_id' })
  currency: Currency;

  @Column({ type: 'int' })
  order: number;

  @CreateDateColumn({ name: 'created_at' })
  created_at: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updated_at: Date;
}
