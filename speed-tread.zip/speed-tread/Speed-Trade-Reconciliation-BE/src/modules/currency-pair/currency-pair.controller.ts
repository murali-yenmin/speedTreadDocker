import { Body, Controller, Delete, Get, Param, Patch, Post, Put, Query } from '@nestjs/common';
import { CurrencyPairService } from './currency-pair.service';
import { CreateCurrencyPairDto, UpdateCurrencyPairDto } from './dto/currency-pair.dto';
import { BulkUpsertCurrencyOrderDto } from '../currency-order/dto/bulk-upsert-currency-order.dto';

@Controller('currency-pair')
export class CurrencyPairController {
  constructor(private readonly currencyPairService: CurrencyPairService) {}

  @Post()
  create(@Body() createCurrencyPairDto: CreateCurrencyPairDto) {
    return this.currencyPairService.createCurrencyPair(createCurrencyPairDto);
  }

  @Put()
  update(@Body() updateCurrencyPairDto: UpdateCurrencyPairDto) {
    return this.currencyPairService.updateCurrencyPair(updateCurrencyPairDto);
  }
  @Put('swap')
  updateSwap(@Body() updateCurrencyPairDto: UpdateCurrencyPairDto) {
    return this.currencyPairService.swapData(updateCurrencyPairDto?.unique_id);
  }

  @Get()
  findAll(@Query('currencyId') currencyId?: string) {
    return this.currencyPairService.getAllCurrencyPairs(currencyId);
  }

  @Get(':id')
  findOne(@Param('currencyId') currencyId: string) {
    return this.currencyPairService.getCurrencyPairById(currencyId);
  }

  @Delete(':id')
  delete(@Param('id') id: string) {
    return this.currencyPairService.deleteCurrencyPair(id);
  }
}
