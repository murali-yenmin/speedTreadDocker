import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CurrencyPairService } from './currency-pair.service';
import { CurrencyPairController } from './currency-pair.controller';
import { CurrencyModule } from '../currency/currency.module';
import { CurrencyPair } from './entities/currency-pair.entity';

import { CurrencyValueModule } from '../currency-value/currency-value.module';
import { Currency } from '../currency/entity/currency.entity';
import { Order } from '../order/entities/order.entity';
import { OrderTransaction } from '../order/entities/order-transaction.entity';
import { Transaction } from '../transaction/entities/transaction.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([CurrencyPair, Currency, Order, OrderTransaction, Transaction]),
    CurrencyValueModule,
  ],
  providers: [CurrencyPairService],
  controllers: [CurrencyPairController],
  exports: [CurrencyPairService],
})
export class CurrencyPairModule {}
