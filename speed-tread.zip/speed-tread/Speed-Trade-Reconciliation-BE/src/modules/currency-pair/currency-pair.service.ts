import { HttpStatus, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DeepPartial, In } from 'typeorm';
import { commonCatch, sendFailure, sendSuccess } from 'src/utils/response.utils';
import { Messages } from 'src/message-constants/message.constants';
import { CurrencyPair } from './entities/currency-pair.entity';
import { CreateCurrencyPairDto, UpdateCurrencyPairDto } from './dto/currency-pair.dto';
import { CurrencyValueService } from '../currency-value/currency-value.service';
import { Currency } from '../currency/entity/currency.entity';
import { Order } from '../order/entities/order.entity';
import { OrderTransaction } from '../order/entities/order-transaction.entity';
import { Transaction } from '../transaction/entities/transaction.entity';

@Injectable()
export class CurrencyPairService {
  private readonly logger = new Logger(CurrencyPairService.name);

  constructor(
    @InjectRepository(CurrencyPair)
    private readonly currencyPairRepository: Repository<CurrencyPair>,
    @InjectRepository(Currency)
    private readonly currencyRepository: Repository<Currency>,
    @InjectRepository(Order)
    private readonly orderRepository: Repository<Order>,
    @InjectRepository(OrderTransaction)
    private readonly orderTransactionRepository: Repository<OrderTransaction>,
    @InjectRepository(Transaction)
    private readonly transactionRepository: Repository<Transaction>,
    private readonly currencyValueService: CurrencyValueService,
  ) {}

  async createCurrencyPair(createCurrencyPairDto: CreateCurrencyPairDto): Promise<any> {
    try {
      let buy, sell;
      const { to, from, is_greater } = createCurrencyPairDto;
      let higher_value = to;
      if (is_greater) {
        higher_value = from;
        (buy = to), (sell = from);
      } else {
        buy = from;
        sell = to;
      }

      // Fetch Currency entities to ensure they exist
      const buyCurrency = await this.currencyRepository.findOne({ where: { unique_id: to } });
      const sellCurrency = await this.currencyRepository.findOne({ where: { unique_id: from } });

      if (!buyCurrency || !sellCurrency) {
        return sendFailure(Messages.CurrencyPairNotFound, HttpStatus.OK);
      }

      // Determine calculation_type based on the rule for the primary pair
      const calculation_type = higher_value === from ? 'multiply' : 'divide';

      // Check if the primary pair already exists (including soft-deleted ones)
      const existingPrimaryPair = await this.currencyPairRepository.findOne({
        where: { buy_currency_id: buy, sell_currency_id: sell },
      });

      if (existingPrimaryPair) {
        if (existingPrimaryPair.is_deleted) {
          // If it exists but was soft-deleted, reactivate it
          existingPrimaryPair.is_deleted = false;
          existingPrimaryPair.is_active = true; // Assuming reactivation means it should be active
          existingPrimaryPair.calculation_type = calculation_type;
          await this.currencyPairRepository.save(existingPrimaryPair);

          // --- Logic for creating/updating opposite currency pair ---
          const oppositeBuyCurrencyId = sell;
          const oppositeSellCurrencyId = buy;
          let type = calculation_type === 'divide' ? 'multiply' : 'divide';

          const existingOppositePair = await this.currencyPairRepository.findOne({
            where: {
              buy_currency_id: oppositeBuyCurrencyId,
              sell_currency_id: oppositeSellCurrencyId,
            },
          });

          if (existingOppositePair) {
            if (existingOppositePair.is_deleted) {
              existingOppositePair.is_deleted = false;
              existingOppositePair.calculation_type = type;
              existingOppositePair.is_active = existingPrimaryPair.is_active; // Inherit active status
              await this.currencyPairRepository.save(existingOppositePair);
            }
          } else {
            // If the opposite pair does not exist, create it
            const oppositeCalculationType = calculation_type === 'multiply' ? 'divide' : 'multiply';
            const oppositeCurrencyPair = this.currencyPairRepository.create({
              buy_currency_id: oppositeBuyCurrencyId,
              sell_currency_id: oppositeSellCurrencyId,
              high_value_currency_id: higher_value, // This might need adjustment based on opposite pair logic
              calculation_type: oppositeCalculationType,
              is_active: existingPrimaryPair.is_active,
              is_deleted: false,
            } as DeepPartial<CurrencyPair>);
            await this.currencyPairRepository.save(oppositeCurrencyPair);
          }
          // --- End Logic for creating/updating opposite currency pair ---

          return sendSuccess(Messages.CurrencyPairCreated, existingPrimaryPair);
        } else {
          // If it exists and is not deleted, it's a conflict
          return sendFailure(Messages.CurrencyPairAlreadyExists, HttpStatus.OK);
        }
      }
      const currencyPair = this.currencyPairRepository.create({
        buy_currency_id: to,
        sell_currency_id: from,
        high_value_currency_id: higher_value,
        calculation_type,
      } as DeepPartial<CurrencyPair>);
      await this.currencyPairRepository.save(currencyPair);

      // --- Logic for creating opposite currency pair ---
      const oppositeBuyCurrencyId = from;
      const oppositeSellCurrencyId = to;

      // Fetch currency entities for the opposite pair to get their codes
      const oppositeBuyCurrency = await this.currencyRepository.findOne({
        where: { unique_id: oppositeBuyCurrencyId },
      });
      const oppositeSellCurrency = await this.currencyRepository.findOne({
        where: { unique_id: oppositeSellCurrencyId },
      });

      if (!oppositeBuyCurrency || !oppositeSellCurrency) {
        // This should ideally not happen if the primary currencies were valid
        this.logger.error('Opposite currencies not found, skipping opposite pair creation.');
      } else {
        const oppositeHigherValueCurrencyId = currencyPair.high_value_currency_id;

        // Determine calculation_type for the opposite pair
        const oppositeCalculationType = calculation_type === 'multiply' ? 'divide' : 'multiply';

        const existingOppositePair = await this.currencyPairRepository.findOne({
          where: {
            buy_currency_id: oppositeBuyCurrencyId,
            sell_currency_id: oppositeSellCurrencyId,
          },
        });

        if (existingOppositePair) {
          if (existingOppositePair.is_deleted) {
            existingOppositePair.is_deleted = false;
            existingOppositePair.is_active = currencyPair.is_active; // Inherit active status from primary
            await this.currencyPairRepository.save(existingOppositePair);
          } else {
            // If it exists and is not deleted, do nothing (it's already there)
          }
        } else {
          const oppositeCurrencyPair = this.currencyPairRepository.create({
            buy_currency_id: oppositeBuyCurrencyId,
            sell_currency_id: oppositeSellCurrencyId,
            high_value_currency_id: oppositeHigherValueCurrencyId,
            calculation_type: oppositeCalculationType,
            is_active: currencyPair.is_active, // Inherit active status from primary
            is_deleted: false,
          } as DeepPartial<CurrencyPair>);
          await this.currencyPairRepository.save(oppositeCurrencyPair);
        }
      }
      // --- End Logic for creating opposite currency pair ---

      const savedCurrencyPair = await this.currencyPairRepository
        .createQueryBuilder('pair')
        .leftJoin('pair.buy_currency', 'buy')
        .leftJoin('pair.sell_currency', 'sell')
        .leftJoin('pair.high_value_currency', 'high_value')
        .select([
          'pair.unique_id AS unique_id',
          'pair.calculation_type AS calculation_type',
          'pair.is_active AS is_active',
          'pair.updated_at AS updated_at',
          'sell.code AS `from`',
          'buy.code AS `to`',
          'high_value.code AS higher_value',
        ])
        .where('pair.is_deleted = :isDeleted AND pair.unique_id = :unique_id', {
          isDeleted: false,
          unique_id: currencyPair?.unique_id,
        })
        .getRawOne();
      return sendSuccess(Messages.CurrencyPairCreated, savedCurrencyPair);
    } catch (error) {
      this.logger.error('Error from createCurrencyPair', error);
      return commonCatch(error);
    }
  }

  async updateCurrencyPair(updateCurrencyPairDto: UpdateCurrencyPairDto): Promise<any> {
    try {
      const { unique_id, is_greater, over_write } = updateCurrencyPairDto;

      if (typeof is_greater !== 'boolean') {
        return sendFailure('is_greater must be a boolean value', HttpStatus.BAD_REQUEST);
      }

      const existingPair = await this.currencyPairRepository.findOne({
        where: { unique_id: unique_id, is_deleted: false },
        relations: ['buy_currency', 'sell_currency'],
      });

      if (!existingPair) {
        return sendFailure(Messages.CurrencyPairNotFound, HttpStatus.NOT_FOUND);
      }
      const new_calculation_type = is_greater
        ? existingPair.high_value_currency_id === existingPair.sell_currency_id
          ? 'multiply'
          : 'divide'
        : existingPair.high_value_currency_id === existingPair.buy_currency_id
          ? 'multiply'
          : 'divide';

      if (new_calculation_type === existingPair.calculation_type) {
        return sendFailure("Couldn't edit, already the same", HttpStatus.OK);
      }

      let isAssociated = false;
      const oppositeCurrencyPair = await this.currencyPairRepository.findOne({
        where: {
          buy_currency_id: existingPair.sell_currency.unique_id,
          sell_currency_id: existingPair.buy_currency.unique_id,
          is_deleted: false,
        },
        relations: ['buy_currency', 'sell_currency'],
      });

      const pairsToCheck = [existingPair];
      if (oppositeCurrencyPair) {
        pairsToCheck.push(oppositeCurrencyPair);
      }

      for (const pair of pairsToCheck) {
        const sellCurrencyCode = pair.sell_currency.code;
        const buyCurrencyCode = pair.buy_currency.code;

        const orderExists = await this.orderRepository.findOne({
          where: [
            { currency: { code: sellCurrencyCode }, settlement_currency: { code: buyCurrencyCode }, is_deleted: false },
          ],
        });
        const orderTransactionExists = await this.orderTransactionRepository.findOne({
          where: [
            {
              sell_currency: { code: sellCurrencyCode },
              settlement_currency: { code: buyCurrencyCode },
              is_deleted: false,
            },
          ],
        });
        const transactionExists = await this.transactionRepository.findOne({
          where: [
            {
              sell_currency: { code: sellCurrencyCode },
              settlement_currency: { code: buyCurrencyCode },
              is_deleted: false,
            },
          ],
        });

        if (orderExists || orderTransactionExists || transactionExists) {
          isAssociated = true;
          break;
        }
      }

      if (isAssociated && !over_write) {
        return sendFailure(Messages.CurrencyPairInUse, HttpStatus.OK, { is_associated: true });
      }

      const new_high_value_currency_id = is_greater
        ? existingPair.sell_currency.unique_id
        : existingPair.buy_currency.unique_id;

      existingPair.calculation_type = new_calculation_type;
      existingPair.high_value_currency_id = new_high_value_currency_id;
      await this.currencyPairRepository.save(existingPair);

      if (oppositeCurrencyPair) {
        const opposite_new_calculation_type = new_calculation_type === 'multiply' ? 'divide' : 'multiply';
        oppositeCurrencyPair.calculation_type = opposite_new_calculation_type;
        oppositeCurrencyPair.high_value_currency_id = new_high_value_currency_id;
        await this.currencyPairRepository.save(oppositeCurrencyPair);
      }

      const currencyPair = await this.currencyPairRepository
        .createQueryBuilder('pair')
        .leftJoin('pair.buy_currency', 'buy')
        .leftJoin('pair.sell_currency', 'sell')
        .leftJoin('pair.high_value_currency', 'high_value')
        .select([
          'pair.unique_id AS `unique_id`',
          'pair.calculation_type AS `calculation_type`',
          'pair.is_active AS `is_active`',
          'pair.updated_at AS `updated_at`',
          'sell.code AS `from`',
          'buy.code AS `to`',
          'high_value.code AS `higher_value`',
        ])
        .where('pair.is_deleted = :isDeleted AND pair.unique_id = :unique_id', {
          isDeleted: false,
          unique_id: unique_id,
        })
        .getRawOne();

      return sendSuccess(Messages.CurrencyPairUpdated, currencyPair);
    } catch (error) {
      this.logger.error('Error from updateCurrencyPair', error);
      return commonCatch(error);
    }
  }

  async getAllCurrencyPairs(currencyId?: string): Promise<any> {
    try {
      const queryBuilder = this.currencyPairRepository
        .createQueryBuilder('pair')
        .leftJoin('pair.buy_currency', 'buy')
        .leftJoin('pair.sell_currency', 'sell')
        .leftJoin('pair.high_value_currency', 'high_value')
        .select([
          'pair.unique_id AS `unique_id`',
          'pair.calculation_type AS `calculation_type`',
          'pair.is_active AS `is_active`',
          'pair.updated_at AS `updated_at`',
          'pair.created_at AS `created_at`',
          'sell.code AS `from`',
          'buy.code AS `to`',
          'sell.unique_id AS `from_unique_id`',
          'buy.unique_id AS `to_unique_id`',
          'high_value.code AS `higher_value`',
        ])
        .where('pair.is_deleted = :isDeleted', { isDeleted: false });

      if (currencyId) {
        queryBuilder.andWhere('(buy.unique_id = :currencyId OR sell.unique_id = :currencyId)', { currencyId });
      }

      const currencyPairs = await queryBuilder.addOrderBy('pair.updated_at', 'DESC').getRawMany();

      const processedPairKeys = new Set<string>();
      const combinedPairs = [];

      for (const pair of currencyPairs) {
        const canonicalKey = [pair.from_unique_id, pair.to_unique_id].sort().join('-');

        if (processedPairKeys.has(canonicalKey)) {
          continue;
        }

        const oppositePair = currencyPairs.find(
          (p) => p.from_unique_id === pair.to_unique_id && p.to_unique_id === pair.from_unique_id,
        );

        if (!oppositePair) {
          continue;
        }

        const pair1 = pair;
        const pair2 = oppositePair;

        const resultObject = [
          {
            unique_id: pair1.unique_id,
            from: pair1.from,
            to: pair1.to,
            calculation_type: pair1.calculation_type,
            is_active: pair1.is_active,
            high_value_currency: pair1.higher_value,
            created_at: pair1.created_at,
          },
          {
            unique_id: pair2.unique_id,
            from: pair2.from,
            to: pair2.to,
            calculation_type: pair2.calculation_type,
            is_active: pair2.is_active,
            high_value_currency: pair2.higher_value,
            created_at: pair2.created_at,
          },
        ];
        combinedPairs.push({ pair: resultObject });
        processedPairKeys.add(canonicalKey);
      }
      return sendSuccess(Messages.CurrencyPairsFetched, combinedPairs);
    } catch (error) {
      this.logger.error('Error from getAllCurrencyPairs', error);
      return commonCatch(error);
    }
  }

  async deleteCurrencyPair(unique_id: string): Promise<any> {
    try {
      const currencyPair = await this.currencyPairRepository.findOne({
        where: { unique_id },
        relations: ['buy_currency', 'sell_currency'],
      });

      if (!currencyPair) {
        return sendFailure(Messages.CurrencyPairNotFound, HttpStatus.OK);
      }
      const oppositePair = await this.currencyPairRepository.findOne({
        where: { buy_currency_id: currencyPair?.sell_currency_id, sell_currency_id: currencyPair?.buy_currency_id },
      });
      const sellCurrencyCode = currencyPair.sell_currency.code;
      const buyCurrencyCode = currencyPair.buy_currency.code;

      const orderExists = await this.orderRepository.findOne({
        where: [
          {
            currency: { code: sellCurrencyCode },
            settlement_currency: { code: buyCurrencyCode },
            is_deleted: false,
          },
          {
            currency: { code: buyCurrencyCode },
            settlement_currency: { code: sellCurrencyCode },
            is_deleted: false,
          },
        ],
      });
      if (orderExists) {
        return sendFailure(Messages.CurrencyPairInUseInOrder, HttpStatus.OK);
      }
      const orderTransactionExists = await this.orderTransactionRepository.findOne({
        where: [
          {
            sell_currency: { code: sellCurrencyCode },
            settlement_currency: { code: buyCurrencyCode },
            is_deleted: false,
          },
          {
            sell_currency: { code: buyCurrencyCode },
            settlement_currency: { code: sellCurrencyCode },
            is_deleted: false,
          },
        ],
      });
      if (orderTransactionExists) {
        return sendFailure(Messages.CurrencyPairInUseInOrderTransaction, HttpStatus.OK);
      }
      const transactionExists = await this.transactionRepository.findOne({
        where: [
          {
            sell_currency: { code: sellCurrencyCode },
            settlement_currency: { code: buyCurrencyCode },
            is_deleted: false,
          },
          {
            sell_currency: { code: buyCurrencyCode },
            settlement_currency: { code: sellCurrencyCode },
            is_deleted: false,
          },
        ],
      });

      if (transactionExists) {
        return sendFailure(Messages.CurrencyPairInUseInTransaction, HttpStatus.OK);
      }

      const ids = [unique_id, oppositePair?.unique_id];
      const data = await this.currencyPairRepository.update({ unique_id: In(ids) }, { is_deleted: true });

      return sendSuccess(Messages.CurrencyPairDeleted, data);
    } catch (error) {
      this.logger.error('Error from deleteCurrencyPair', error);
      return commonCatch(error);
    }
  }

  async calculateAmountInSettlementCurrency(
    sell_currency_code: string,
    settlement_currency_code: string,
    amount: number,
    rate: number,
  ): Promise<number> {
    if (sell_currency_code === settlement_currency_code) {
      return +amount;
    }

    const sellCurrency = await this.currencyRepository.findOne({ where: { code: sell_currency_code } });
    const settlementCurrency = await this.currencyRepository.findOne({ where: { code: settlement_currency_code } });

    if (!sellCurrency || !settlementCurrency) {
      this.logger.warn(`Could not find currency for calculation`);
      return +amount;
    }

    const currencyPair = await this.currencyPairRepository.findOne({
      where: {
        buy_currency_id: settlementCurrency.unique_id,
        sell_currency_id: sellCurrency.unique_id,
        is_deleted: false,
      },
    });

    if (!currencyPair) {
      this.logger.warn(`Could not find currency pair for calculation`);
      return +amount;
    }

    if (currencyPair.calculation_type === 'multiply') {
      return +amount * +rate;
    } else if (currencyPair.calculation_type === 'divide') {
      return +amount / +rate;
    }

    return +amount;
  }

  async getCurrencyPairById(currencyId: string): Promise<any> {
    try {
      const currencyPair = await this.currencyPairRepository.findOne({
        where: {
          unique_id: currencyId,
          is_deleted: false,
        },
        relations: ['buy_currency', 'sell_currency', 'high_value_currency'],
      });

      if (!currencyPair) {
        return sendFailure(Messages.CurrencyPairNotFound, HttpStatus.OK);
      }

      const sellCurrencyCode = currencyPair.sell_currency.code;
      const buyCurrencyCode = currencyPair.buy_currency.code;

      const orderExists = await this.orderRepository.findOne({
        where: [
          {
            currency: { code: sellCurrencyCode },
            settlement_currency: { code: buyCurrencyCode },
            is_deleted: false,
          },
          {
            currency: { code: buyCurrencyCode },
            settlement_currency: { code: sellCurrencyCode },
            is_deleted: false,
          },
        ],
      });

      const orderTransactionExists = await this.orderTransactionRepository.findOne({
        where: [
          {
            sell_currency: { code: sellCurrencyCode },
            settlement_currency: { code: buyCurrencyCode },
            is_deleted: false,
          },
          {
            sell_currency: { code: buyCurrencyCode },
            settlement_currency: { code: sellCurrencyCode },
            is_deleted: false,
          },
        ],
      });

      const transactionExists = await this.transactionRepository.findOne({
        where: [
          {
            sell_currency: { code: sellCurrencyCode },
            settlement_currency: { code: buyCurrencyCode },
            is_deleted: false,
          },
          {
            sell_currency: { code: buyCurrencyCode },
            settlement_currency: { code: sellCurrencyCode },
            is_deleted: false,
          },
        ],
      });

      const isAssociated = !!(orderExists || orderTransactionExists || transactionExists);

      const responseObject = {
        unique_id: currencyPair.unique_id,
        from: currencyPair.sell_currency.code,
        to: currencyPair.buy_currency.code,
        calculation_type: currencyPair.calculation_type,
        is_active: currencyPair.is_active,
        high_value_currency: currencyPair.high_value_currency.code,
        created_at: currencyPair.created_at,
        is_associated: isAssociated,
      };

      return sendSuccess(Messages.CurrencyPairsFetched, responseObject);
    } catch (error) {
      this.logger.error('Error from getCurrencyPairById', error);
      return commonCatch(error);
    }
  }

  async swapData(unique_id): Promise<any> {
    try {
      const existingPair = await this.currencyPairRepository.findOne({
        where: { unique_id: unique_id, is_deleted: false },
      });
      const oppositePair = await this.currencyPairRepository.findOne({
        where: {
          buy_currency_id: existingPair?.sell_currency_id,
          sell_currency_id: existingPair?.buy_currency_id,
          is_deleted: false,
        },
      });
      if (existingPair && oppositePair) {
        await this.currencyPairRepository.update(
          { unique_id: unique_id },
          { calculation_type: oppositePair?.calculation_type },
        );
        await this.currencyPairRepository.update(
          { unique_id: oppositePair?.unique_id },
          { calculation_type: existingPair?.calculation_type },
        );
        return sendSuccess('Currency Pairs swapped successfully');
      } else {
        return sendFailure(Messages?.CurrencyPairNotFound, HttpStatus?.OK);
      }
    } catch (error) {
      this.logger.error('Error from swapData', error);
      return commonCatch(error);
    }
  }
}
