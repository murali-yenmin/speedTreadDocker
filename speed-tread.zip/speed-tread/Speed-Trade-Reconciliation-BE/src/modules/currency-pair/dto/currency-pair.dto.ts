import { PartialType } from '@nestjs/mapped-types';
import { IsBoolean, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class CreateCurrencyPairDto {
  @IsString()
  @IsNotEmpty()
  to: string;

  @IsString()
  @IsNotEmpty()
  from: string;

  @IsBoolean()
  @IsNotEmpty()
  is_greater: boolean;

  @IsBoolean()
  @IsOptional()
  is_active: boolean;
}

export class UpdateCurrencyPairDto extends PartialType(CreateCurrencyPairDto) {
  @IsString()
  @IsNotEmpty()
  unique_id: string;

  @IsBoolean()
  @IsOptional()
  over_write: boolean;

  @IsString()
  @IsOptional()
  to?: string;

  @IsString()
  @IsOptional()
  from?: string;

  @IsString()
  @IsOptional()
  higher_value?: string;

  @IsBoolean()
  @IsOptional()
  is_active?: boolean;
}
