import {
  BeforeInsert,
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryColumn,
  Unique,
  UpdateDateColumn,
  Index,
} from 'typeorm';
import * as utils from 'src/utils';
import { Currency } from 'src/modules/currency/entity/currency.entity';

@Entity('currency_pair')
@Unique(['buy_currency_id', 'sell_currency_id'])
export class CurrencyPair {
  @PrimaryColumn({ type: 'varchar', length: 50 })
  unique_id: string;

  @BeforeInsert()
  generateUniqueId() {
    this.unique_id = utils.generateRandomId();
  }

  @Index()
  @Column({ type: 'varchar', length: 50 })
  buy_currency_id: string;

  @ManyToOne(() => Currency, { eager: true })
  @JoinColumn({ name: 'buy_currency_id', referencedColumnName: 'unique_id' })
  buy_currency: Currency;

  @Index()
  @Column({ type: 'varchar', length: 50 })
  sell_currency_id: string;

  @ManyToOne(() => Currency, { eager: true })
  @JoinColumn({ name: 'sell_currency_id', referencedColumnName: 'unique_id' })
  sell_currency: Currency;

  @Column()
  calculation_type: string;

  @Column({ type: 'varchar', length: 50, name: 'high_value_currency_id' })
  high_value_currency_id: string;

  @ManyToOne(() => Currency)
  @JoinColumn({ name: 'high_value_currency_id', referencedColumnName: 'unique_id' })
  high_value_currency: Currency;

  @Column({ default: true })
  is_active: boolean;

  @Column({ default: false })
  is_deleted: boolean;

  @CreateDateColumn({ name: 'created_at' })
  created_at: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updated_at: Date;
}
