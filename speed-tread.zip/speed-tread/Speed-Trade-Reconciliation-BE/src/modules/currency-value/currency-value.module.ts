import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { CurrencyValueService } from './currency-value.service';

@Module({
  imports: [HttpModule],
  providers: [CurrencyValueService],
  exports: [CurrencyValueService],
})
export class CurrencyValueModule {}
