import { Injectable, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

@Injectable()
export class CurrencyValueService {
  private readonly logger = new Logger(CurrencyValueService.name);
  private readonly apiUrl = 'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies';

  constructor(private readonly httpService: HttpService) {}

  /**
   * Determines which of the two currency codes has a higher value.
   * @param codeA The first currency code (e.g., 'USD').
   * @param codeB The second currency code (e.g., 'INR').
   * @returns The code of the currency with the higher value.
   */
  async getHigherValueCurrency(codeA: string, codeB: string): Promise<string> {
    if (codeA === codeB) {
      return codeA; // If currencies are the same, either one is fine.
    }

    const codeA_lower = codeA.toLowerCase();
    const codeB_lower = codeB.toLowerCase();

    try {
      const url = `${this.apiUrl}/${codeA_lower}.json`;
      const response = await firstValueFrom(this.httpService.get(url));

      const rate = response.data[codeA_lower]?.[codeB_lower];

      if (rate === undefined) {
        throw new Error(`Could not find exchange rate from ${codeA} to ${codeB}`);
      }

      // If 1 unit of codeA is worth more than 1 unit of codeB, codeA is higher.
      if (rate > 1) {
        return codeA;
      } else {
        return codeB;
      }
    } catch (error) {
      this.logger.error(`Failed to fetch currency value for ${codeA}/${codeB}`, error);
      // Fallback or error handling needed. For now, re-throwing.
      // A potential fallback could be to call the API with codeB as the base.
      throw new Error('Could not determine higher value currency due to an external API error.');
    }
  }
}
