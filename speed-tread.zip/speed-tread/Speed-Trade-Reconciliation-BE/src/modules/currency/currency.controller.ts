import { Controller, Post, Get, Patch, Param, Body, Put, Query } from '@nestjs/common';
import { CurrencyService } from './currency.service';
import { CreateCurrencyDto, UpdateCurrencyDto } from './dto/currency.dto';
import { UpdateCurrencyStatusDto } from './dto/update-currency-status.dto';
import { GetSellableCurrenciesDto } from './dto/get-sellable-currencies.dto';

@Controller('currencies')
export class CurrencyController {
  constructor(private readonly currencyService: CurrencyService) {}

  @Post()
  create(@Body() createCurrencyDto: CreateCurrencyDto) {
    return this.currencyService.createCurrency(createCurrencyDto);
  }

  @Put()
  update(@Body() updateCurrencyDto: UpdateCurrencyDto) {
    return this.currencyService.updateCurrency(updateCurrencyDto);
  }

  @Get('get-all')
  getAll(@Query('search') search?: string) {
    return this.currencyService.getAllCurrencies(search);
  }

  @Post('sellable-for')
  getSellableCurrencies(@Body() dto: GetSellableCurrenciesDto) {
    return this.currencyService.getSellableCurrencies(dto.settlement_currency);
  }

  @Put('status')
  updateCurrencyStatus(@Body() updateCurrencyStatusDto: UpdateCurrencyStatusDto) {
    return this.currencyService.updateCurrencyStatus(updateCurrencyStatusDto);
  }
}
