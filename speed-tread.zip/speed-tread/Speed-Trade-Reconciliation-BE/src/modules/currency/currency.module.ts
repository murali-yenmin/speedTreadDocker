import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { CurrencyService } from './currency.service';
import { CurrencyController } from './currency.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Currency } from './entity/currency.entity';
import { CurrencyPair } from '../currency-pair/entities/currency-pair.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Currency, CurrencyPair]), HttpModule],
  controllers: [CurrencyController],
  providers: [CurrencyService],
  exports: [CurrencyService],
})
export class CurrencyModule {}
