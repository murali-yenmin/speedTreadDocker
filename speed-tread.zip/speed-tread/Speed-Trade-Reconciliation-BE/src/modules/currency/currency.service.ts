import { HttpStatus, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Not, Repository } from 'typeorm';
import { Currency } from './entity/currency.entity';
import { CreateCurrencyDto, UpdateCurrencyDto } from './dto/currency.dto';
import { commonCatch, sendFailure, sendSuccess } from 'src/utils/response.utils';
import { Messages } from 'src/message-constants/message.constants';
import { FilterDto } from 'src/common/dtos/filter.dto';
import { Condition } from 'src/common/interfaces/app.interface';
import * as utils from 'src/utils';
import { UpdateCurrencyStatusDto } from './dto/update-currency-status.dto';
import { CurrencyPair } from '../currency-pair/entities/currency-pair.entity';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

@Injectable()
export class CurrencyService {
  private readonly logger = new Logger(CurrencyService.name);
  constructor(
    @InjectRepository(Currency)
    private readonly currencyRepository: Repository<Currency>,
    @InjectRepository(CurrencyPair)
    private readonly currencyPairRepository: Repository<CurrencyPair>,
    private readonly httpService: HttpService,
  ) {}

  // Create a new currency
  async createCurrency(createCurrencyDto: CreateCurrencyDto): Promise<object> {
    try {
      const currencyExists = await this.currencyRepository.findOne({ where: { code: createCurrencyDto.code } });
      if (currencyExists) {
        return sendFailure(Messages.CurrencyAlreadyExists, HttpStatus?.OK);
      }
      createCurrencyDto.code = createCurrencyDto.code?.toUpperCase();
      const currency = this.currencyRepository.create(createCurrencyDto);
      const savedCurrency = await this.currencyRepository.save(currency);
      return sendSuccess(Messages.CurrencyCreated, savedCurrency);
    } catch (error) {
      this.logger.error('Error creating currency', error);
      return commonCatch(error);
    }
  }

  // Find one currency by ID
  async findOne(query): Promise<object> {
    const currency = await this.currencyRepository.findOne(query);
    return currency;
  }

  // Update currency by ID
  async updateCurrency(updateCurrencyDto: UpdateCurrencyDto): Promise<object> {
    try {
      if (updateCurrencyDto?.code) {
        const currencyExists = await this.currencyRepository.findOne({
          where: { code: updateCurrencyDto.code, unique_id: Not(updateCurrencyDto.unique_id) },
        });
        if (currencyExists) {
          return sendFailure(Messages.CurrencyAlreadyExists, HttpStatus?.OK);
        }
      }
      const currency = await this.findOne({ where: { unique_id: updateCurrencyDto.unique_id } });
      updateCurrencyDto.code = updateCurrencyDto.code?.toUpperCase();

      Object.assign(currency, updateCurrencyDto);
      await this.currencyRepository.save(currency);
      const updatedCurrency = await this.findOne({
        where: { unique_id: updateCurrencyDto.unique_id },
        select: ['unique_id', 'name', 'code', 'is_active'],
      });
      return sendSuccess(Messages.CurrencyUpdated, updatedCurrency);
    } catch (error) {
      this.logger.error('Error updating currency', error);
      return commonCatch(error);
    }
  }

  async getAllCurrencies(search?: string): Promise<any> {
    try {
      const qb = this.currencyRepository
        .createQueryBuilder('currency')
        .select(['currency.unique_id', 'currency.name', 'currency.code', 'currency.is_active'])
        .orderBy(
          `
            CASE 
              WHEN currency.code REGEXP '^[A-Za-z]' THEN 0 
              ELSE 1 
            END
          `,
        )
        .addOrderBy('currency.code', 'ASC');

      // ✅ Apply search if provided
      if (search && search.trim() !== '') {
        qb.where('currency.name LIKE :search OR currency.code LIKE :search', { search: `%${search}%` });
      }

      const currenciesList = await qb.getMany();
      return sendSuccess(Messages.CurrenciesFetched, currenciesList);
    } catch (error) {
      this.logger.error('This error is from getAllCurrencies');
      this.logger.error(error);
      return commonCatch(error);
    }
  }

  async getSellableCurrencies(settlementCurrencyCode: string): Promise<any> {
    try {
      const settlementCurrency = await this.currencyRepository.findOne({ where: { code: settlementCurrencyCode } });
      if (!settlementCurrency) {
        return sendFailure(Messages.CurrencyNotExist, HttpStatus.NOT_FOUND);
      }

      const currencyPairs = await this.currencyPairRepository.find({
        where: { buy_currency_id: settlementCurrency.unique_id, is_deleted: false },
        relations: ['sell_currency'],
      });

      const sellableCurrencyCodes = currencyPairs.map((pair) => pair.sell_currency.code);

      if (!sellableCurrencyCodes.includes(settlementCurrencyCode)) {
        sellableCurrencyCodes.push(settlementCurrencyCode);
      }

      return sendSuccess('Sellable currencies fetched successfully', sellableCurrencyCodes);
    } catch (error) {
      this.logger.error('Error from getSellableCurrencies', error);
      return commonCatch(error);
    }
  }

  async updateCurrencyStatus(updateCurrencyStatusDto: UpdateCurrencyStatusDto): Promise<object> {
    try {
      const currency = await this.findOne({ where: { unique_id: updateCurrencyStatusDto.unique_id } });
      if (!currency) {
        return sendFailure(Messages.CurrencyNotExist, HttpStatus.OK);
      }
      await this.currencyRepository.update(
        { unique_id: updateCurrencyStatusDto.unique_id },
        { is_active: updateCurrencyStatusDto.is_active },
      );
      const updatedCurrency = await this.findOne({
        where: { unique_id: updateCurrencyStatusDto.unique_id },
        select: ['unique_id', 'name', 'code', 'is_active'],
      });
      return sendSuccess(Messages.CurrencyStatusUpdated, updatedCurrency);
    } catch (error) {
      this.logger.error('Error updating currency status', error);
      return commonCatch(error);
    }
  }
}
