import { PartialType } from '@nestjs/mapped-types';
import { IsBoolean, IsNotEmpty, IsOptional, IsString, Length } from 'class-validator';

export class CreateCurrencyDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsString()
  @IsNotEmpty()
  code: string;

  @IsBoolean()
  @IsOptional()
  is_active: boolean;
}

export class UpdateCurrencyDto extends PartialType(CreateCurrencyDto) {
  @IsString()
  @IsNotEmpty()
  unique_id: string;
}
