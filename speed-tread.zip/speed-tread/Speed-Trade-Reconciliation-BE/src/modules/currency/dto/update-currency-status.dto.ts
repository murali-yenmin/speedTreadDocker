import { IsBoolean, IsNotEmpty, IsString } from 'class-validator';

export class UpdateCurrencyStatusDto {
  @IsString()
  @IsNotEmpty()
  unique_id: string;

  @IsBoolean()
  @IsNotEmpty()
  is_active: boolean;
}
