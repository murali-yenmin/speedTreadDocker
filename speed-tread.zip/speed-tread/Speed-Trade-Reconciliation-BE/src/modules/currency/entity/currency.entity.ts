import {
  Entity,
  Column,
  PrimaryColumn,
  BeforeInsert,
  ManyToMany,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';
import * as utils from 'src/utils';
import { CustomerGroup } from 'src/modules/customer-group/entity/customer-group.entity';

@Entity('currency')
export class Currency {
  @PrimaryColumn({ type: 'varchar', length: 50 })
  unique_id: string;

  @BeforeInsert()
  generateUniqueId() {
    this.unique_id = utils.generateRandomId();
  }

  @Column({ type: 'varchar', length: 100 })
  name: string;
 
  @Index()
  @Column({ type: 'varchar', length: 10 })
  code: string;

  @Column({ default: true })
  is_active: boolean;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
