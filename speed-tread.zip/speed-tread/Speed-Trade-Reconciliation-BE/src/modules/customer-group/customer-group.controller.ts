import { Controller, Post, Get, Patch, Param, Body, Put, UseGuards, Query } from '@nestjs/common';
import { CustomerGroupService } from './customer-group.service';
import { FilterDto } from 'src/common/dtos/filter.dto';
import { CreateCustomerGroupDto, UpdateCustomerGroupDto } from './dto/customer-group.dto';
import { GetLoggedUser } from 'src/common/decorators/logged-admin.decorator';
import { LoggedAdmin } from 'src/common/interfaces/logged-user.interface';
import { AdminGuard } from 'src/common/guards/admin.guard';

@UseGuards(AdminGuard)
@Controller('groups')
export class CustomerGroupController {
  constructor(private readonly customerGroupService: CustomerGroupService) {}

  @Get()
  search(@Query('search') search?: string, @Query('limit') limit?: string) {
    return this.customerGroupService.search(search, limit);
  }

  @Post()
  create(@Body() createCustomerGroupDto: CreateCustomerGroupDto, @GetLoggedUser() loggedUser: LoggedAdmin) {
    return this.customerGroupService.createCustomerGroup(createCustomerGroupDto, loggedUser);
  }

  @Put()
  update(@Body() updateCustomerGroupDto: UpdateCustomerGroupDto, @GetLoggedUser() loggedUser: LoggedAdmin) {
    return this.customerGroupService.updateCustomerGroup(updateCustomerGroupDto, loggedUser);
  }

  @Post('get-all')
  getAll(@Body() filter: FilterDto, @GetLoggedUser() loggedUser: LoggedAdmin) {
    return this.customerGroupService.getAllCustomerGroups(filter, loggedUser);
  }

  @Post('order-view')
  getGroupView(@Body() filter: FilterDto, @GetLoggedUser() loggedUser: LoggedAdmin) {
    return this.customerGroupService.getGroupView(filter, loggedUser);
  }

  @Get(':id')
  getOrderGroupDetails(@Param('id') id: string, @GetLoggedUser() loggedUser: LoggedAdmin) {
    return this.customerGroupService.getOrderGroupDetails(id, loggedUser);
  }

  @Get('group-details/:id')
  getSingleCustomerGroupDetails(@Param('id') id: string, @GetLoggedUser() loggedUser: LoggedAdmin) {
    return this.customerGroupService.getSingleCustomerGroupDetails(id, loggedUser);
  }
}
