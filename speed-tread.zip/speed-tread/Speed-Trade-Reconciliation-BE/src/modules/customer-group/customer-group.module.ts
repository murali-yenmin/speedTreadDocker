import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CustomerGroup } from './entity/customer-group.entity';
import { CustomerGroupController } from './customer-group.controller';
import { CustomerGroupService } from './customer-group.service';
import { MediaSourceModule } from '../media-source/media-source.module';
import { ManagementUsers } from '../management-users/entities/management-user.entity';
import { ManagementUsersModule } from '../management-users/management-users.module';
import { TransactionModule } from '../transaction/transaction.module';
import { OrderTransactionService } from '../order/order-transaction.service';
import { OrderTransaction } from '../order/entities/order-transaction.entity';
import { Order } from '../order/entities/order.entity';
import { Currency } from '../currency/entity/currency.entity';
import { CurrencyPair } from '../currency-pair/entities/currency-pair.entity';
import { AccountsModule } from '../accounts/accounts.module';
import { OrderModule } from '../order/order.module';
import { OrderService } from '../order/order.service';
import { AccountsService } from '../accounts/accounts.service';
import { Account } from '../accounts/entities/account.entity';
import { CurrencyPairService } from '../currency-pair/currency-pair.service';
import { CurrencyValueService } from '../currency-value/currency-value.service';
import { CurrencyPairModule } from '../currency-pair/currency-pair.module';
import { HttpService } from '@nestjs/axios';
import { CurrencyOrderModule } from '../currency-order/currency-order.module';
import { CurrencyOrder } from '../currency-order/entities/currency-order.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      CustomerGroup,
      ManagementUsers,
      OrderTransaction,
      Order,
      Currency,
      CurrencyPair,
      Account,
      CurrencyOrder,
    ]),
    MediaSourceModule,
    ManagementUsersModule,
    TransactionModule,
    AccountsModule,
    OrderModule,
    CurrencyPairModule,
    CurrencyOrderModule,
  ],
  controllers: [CustomerGroupController],
  providers: [CustomerGroupService, OrderTransactionService, OrderService],
  exports: [CustomerGroupService],
})
export class CustomerGroupModule {}
