import { HttpStatus, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Not, Repository } from 'typeorm';
import { CustomerGroup } from './entity/customer-group.entity';
import { CreateCustomerGroupDto, UpdateCustomerGroupDto } from './dto/customer-group.dto';
import { commonCatch, sendFailure, sendSuccess } from 'src/utils/response.utils';
import { Messages } from 'src/message-constants/message.constants';
import { FilterDto } from 'src/common/dtos/filter.dto';
import { Condition } from 'src/common/interfaces/app.interface';
import * as utils from 'src/utils';
import { LoggedAdmin } from 'src/common/interfaces/logged-user.interface';
import { ManagementUsers } from '../management-users/entities/management-user.entity';
import { TransactionService } from '../transaction/transaction.service';
import moment from '../../utils/moment';
import { OrderTransactionService } from '../order/order-transaction.service';
import { CurrencyOrderService } from '../currency-order/currency-order.service';

import { Currency } from '../currency/entity/currency.entity';

@Injectable()
export class CustomerGroupService {
  private readonly logger = new Logger(CustomerGroupService.name);

  async search(search?: string, limit?: string): Promise<any> {
    try {
      const queryBuilder = this.customerGroupRepository
        .createQueryBuilder('cg')
        .select(['cg.unique_id', 'cg.group_id', 'cg.name', 'cg.settlement_currency', 'cg.is_active', 'cg.updated_at']);

      if (search) {
        queryBuilder.where('cg.group_id LIKE :search', { search: `%${search}%` });
      }

      if (limit) {
        queryBuilder.take(Number(limit));
      }

      const customerGroupsList = await queryBuilder.getMany();

      return sendSuccess(Messages.CustomerGroupsFetched, customerGroupsList);
    } catch (error) {
      this.logger.error('Error from search');
      this.logger.error(error);
      return commonCatch(error);
    }
  }

  constructor(
    @InjectRepository(CustomerGroup)
    private readonly customerGroupRepository: Repository<CustomerGroup>,
    @InjectRepository(ManagementUsers)
    private readonly managementUserRepository: Repository<ManagementUsers>,
    @InjectRepository(Currency)
    private readonly currencyRepository: Repository<Currency>,
    private readonly transactionService: TransactionService,
    private readonly orderTransactionService: OrderTransactionService,
    private readonly currencyOrderService: CurrencyOrderService,
  ) {}

  async createCustomerGroup(createCustomerGroupDto: CreateCustomerGroupDto, loggedUser: LoggedAdmin): Promise<any> {
    try {
      const { name, settlement_currency, is_favorite, group_id } = createCustomerGroupDto;

      const currency = await this.currencyRepository.findOne({ where: { code: settlement_currency } });
      if (!currency) {
        return sendFailure(Messages.CurrencyNotExist, HttpStatus.NOT_FOUND);
      }

      const existingGroup = await this.customerGroupRepository.findOne({
        where: [{ name: name?.toLowerCase() }, { group_id }],
      });

      if (existingGroup) {
        let errorField: { name?: string; group_id?: string } = {};
        if (existingGroup.name?.toLowerCase() === name?.toLowerCase()) {
          errorField = { name: 'Group name already exists' };
        } else if (existingGroup.group_id === group_id) {
          errorField = { group_id: 'Group ID already exists' };
        }
        if (errorField?.name || errorField?.group_id) {
          return sendFailure(Messages.CustomerGroupAlreadyExists, HttpStatus.OK, { errorField });
        }
      }

      const user = await this.managementUserRepository.findOne({
        where: { unique_id: loggedUser.unique_id },
      });

      const group = this.customerGroupRepository.create({
        name: name?.trim(),
        group_id: group_id?.trim(),
        settlement_currency: currency,
        created_by: { id: user.unique_id, name: user.user_name },
        updated_by: { id: user.unique_id, name: user.user_name },
      });

      const savedGroup = await this.customerGroupRepository.save(group);

      await this.currencyOrderService.createCurrencyOrderForGroup(savedGroup.unique_id, currency.unique_id);

      return sendSuccess(Messages.CustomerGroupUpdated, savedGroup);
    } catch (error) {
      this.logger.error('Error from createCustomerGroup', error);
      return commonCatch(error);
    }
  }

  // Find one customer group by ID
  async findOne(query): Promise<CustomerGroup | null> {
    const customerGroup = await this.customerGroupRepository.findOne(query);
    return customerGroup;
  }

  // Update customer group by ID
  async updateCustomerGroup(updateCustomerGroupDto: UpdateCustomerGroupDto, loggedUser: LoggedAdmin): Promise<any> {
    try {
      const { unique_id, name, is_favorite, settlement_currency, ...rest } = updateCustomerGroupDto;
      const customerGroup = await this.findOne({
        where: { unique_id },
      });
      if (!customerGroup) {
        return sendFailure(Messages.CustomerGroupNotFound, HttpStatus.NOT_FOUND);
      }

      if (is_favorite !== undefined) {
        const user = await this.managementUserRepository.findOne({
          where: { unique_id: loggedUser.unique_id },
        });
        if (user) {
          const isAlreadyStarred = user.starred_group.includes(unique_id);
          if (is_favorite && !isAlreadyStarred) {
            user.starred_group.push(unique_id);
          }
          if (!is_favorite && isAlreadyStarred) {
            user.starred_group = user.starred_group.filter((id) => id !== unique_id);
          }
          await this.managementUserRepository.save(user);
        }
      }

      if (name) {
        const existingGroup = await this.customerGroupRepository.findOne({
          where: { name, unique_id: Not(unique_id) },
        });

        if (existingGroup) {
          return sendFailure(Messages.CustomerGroupAlreadyExists, HttpStatus.OK);
        }
      }

      Object.assign(customerGroup, {
        name,
        updated_by: { id: loggedUser.unique_id, name: loggedUser.user_name },
      });
      const updatedCustomerGroup = await this.customerGroupRepository.save(customerGroup);

      return sendSuccess(Messages.CustomerGroupUpdated, updatedCustomerGroup);
    } catch (error) {
      this.logger.error('Error from updateCustomerGroup', error);
      return commonCatch(error);
    }
  }

  async getAllCustomerGroups(filter: FilterDto, loggedUser: LoggedAdmin): Promise<any> {
    try {
      let valueStatusFilter = null;
      if (filter?.query) {
        const valueStatusIndex = filter.query.findIndex((cond) => cond.fieldName === 'value_status');
        if (valueStatusIndex > -1) {
          valueStatusFilter = filter.query[valueStatusIndex].fieldString;
          // Remove the filter from the query array so it's not processed by the DB query
          filter.query.splice(valueStatusIndex, 1);
        }
      }
      // Base query
      const user = await this.managementUserRepository.findOne({
        where: { unique_id: loggedUser.unique_id },
      });
      const baseQuery = this.customerGroupRepository
        .createQueryBuilder('cg')
        .leftJoinAndSelect('cg.settlement_currency', 'settlement_currency')
        .select([
          'cg.unique_id',
          'cg.group_id',
          'cg.name',
          'settlement_currency.code',
          'cg.is_active',
          'cg.updated_at',
          'cg.created_at',
        ]);
      // Filters
      if (filter?.query) {
        const removed = filter.query.filter((cond) => cond.fieldName === 'is_favorite' && cond.fieldString === true);

        const newQuery = filter.query.filter(
          (cond) => !(cond.fieldName === 'is_favorite' && cond.fieldString === true),
        );
        let conditions = filter.query as Condition[];

        if (removed.length > 0) {
          conditions = newQuery as Condition[];

          baseQuery.where({ unique_id: In(user?.starred_group) });
        }
        if (conditions.length > 0) {
          const whereConditions = utils.buildMysqlQuery(conditions);

          baseQuery.andWhere(whereConditions);
        }
      }

      // Data query
      const queryBuilder = baseQuery.clone();

      // Sorting
      queryBuilder.orderBy(`cg.group_id`, 'ASC');

      // Execute
      const customerGroupsList = await queryBuilder.getMany();

      const groupIds = customerGroupsList.map((group) => group.unique_id);
      let allEnrichedCurrencyOrders = [];
      if (groupIds.length > 0) {
        const response = await this.currencyOrderService.getCurrencyOrdersWithValuesForGroups(groupIds, 'transaction');
        allEnrichedCurrencyOrders = response;
      }

      const enrichedCurrencyOrdersByGroupId = new Map<string, any[]>();
      allEnrichedCurrencyOrders.forEach((item) => {
        const groupId = item.group_id;
        if (!enrichedCurrencyOrdersByGroupId.has(groupId)) {
          enrichedCurrencyOrdersByGroupId.set(groupId, []);
        }
        enrichedCurrencyOrdersByGroupId.get(groupId).push(item);
      });

      // Enrich results
      const enrichedGroups = customerGroupsList.map((group) => {
        if (user?.starred_group.length > 0 && user.starred_group.includes(group.unique_id)) {
          group['is_favorite'] = true;
        }

        let currenciesForThisGroup = enrichedCurrencyOrdersByGroupId.get(group.unique_id) || [];

        let finalCurrencies = currenciesForThisGroup.map((item) => ({
          status: item.status,
          value: item.value,
          currency: item.currency,
          is_mismatch: item.is_mismatch,
          error: item.error,
          processing: item.processing,
          transferring: item.transferring,
          changes_required: item.changes_required,
        }));

        if (finalCurrencies.length === 0) {
          finalCurrencies.push({
            status: 'all_clear',
            value: 0.0,
            currency: group?.settlement_currency?.code,
            is_mismatch: false,
            error: 0,
            processing: 0,
            transferring: 0,
            changes_required: 0,
          });
        } else {
          const hasMatchingSettlementCurrency = finalCurrencies.some(
            (currency) => currency.currency === group?.settlement_currency?.code,
          );

          if (!hasMatchingSettlementCurrency) {
            finalCurrencies.push({
              status: 'all_clear',
              value: 0.0,
              currency: group?.settlement_currency.code,
              is_mismatch: false,
              error: 0,
              processing: 0,
              transferring: 0,
              changes_required: 0,
            });
          }
        }

        return {
          ...group,
          settlement_currency: group?.settlement_currency?.code,
          currencies: finalCurrencies,
        };
      });

      let filteredGroups = enrichedGroups;
      if (valueStatusFilter && valueStatusFilter !== 'all') {
        filteredGroups = enrichedGroups.filter((group) => {
          if (!group.currencies) return false;
          if (valueStatusFilter === 'not_tally') {
            return group.currencies.some((c) => c.is_mismatch === true);
          }
          return group.currencies.some((c) => c.status === valueStatusFilter);
        });
      }

      const totalCount = filteredGroups.length;

      let paginatedGroups = filteredGroups;
      if (filter?.cp && filter?.pl) {
        const skip = (filter.cp - 1) * filter.pl;
        paginatedGroups = filteredGroups.slice(skip, skip + filter.pl);
      }

      const resultGroups = paginatedGroups.map((group) => {
        if (valueStatusFilter && valueStatusFilter !== 'all') {
          let newCurrencies;
          if (valueStatusFilter === 'not_tally') {
            newCurrencies = group.currencies.filter((c) => c.is_mismatch === true);
          } else {
            // 'we_owe' or 'owe_us'
            newCurrencies = group.currencies.filter((c) => c.status === valueStatusFilter);
          }
          return { ...group, currencies: newCurrencies };
        }
        return group;
      });

      return sendSuccess(Messages.CustomerGroupsFetched, {
        customer_groups_list: resultGroups,
        total_count: totalCount,
      });
    } catch (error) {
      this.logger.error('Error from getAllCustomerGroups');
      this.logger.error(error);
      return commonCatch(error);
    }
  }

  async getGroupView(filter: FilterDto, loggedUser: LoggedAdmin): Promise<any> {
    try {
      let valueStatusFilter = null;
      if (filter?.query) {
        const valueStatusIndex = filter.query.findIndex((cond) => cond.fieldName === 'value_status');
        if (valueStatusIndex > -1) {
          valueStatusFilter = filter.query[valueStatusIndex].fieldString;
          // Remove the filter from the query array so it's not processed by the DB query
          filter.query.splice(valueStatusIndex, 1);
        }
      }
      // Base query
      const user = await this.managementUserRepository.findOne({
        where: { unique_id: loggedUser.unique_id },
      });
      const baseQuery = this.customerGroupRepository
        .createQueryBuilder('cg')
        .leftJoinAndSelect('cg.settlement_currency', 'settlement_currency')
        .select([
          'cg.unique_id',
          'cg.group_id',
          'cg.name',
          'settlement_currency.code',
          'cg.is_active',
          'cg.created_at',
        ]);
      // Filters
      if (filter?.query) {
        const removed = filter.query.filter((cond) => cond.fieldName === 'is_favorite' && cond.fieldString === true);

        const newQuery = filter.query.filter(
          (cond) => !(cond.fieldName === 'is_favorite' && cond.fieldString === true),
        );
        let conditions = filter.query as Condition[];

        if (removed.length > 0) {
          conditions = newQuery as Condition[];

          baseQuery.where({ unique_id: In(user?.starred_group) });
        }
        if (conditions.length > 0) {
          const whereConditions = utils.buildMysqlQuery(conditions);

          baseQuery.andWhere(whereConditions);
        }
      }
      // Data query
      const queryBuilder = baseQuery.clone();

      // Sorting
      queryBuilder.orderBy(`cg.group_id`, 'ASC');

      // Execute
      const customerGroupsList = await queryBuilder.getMany();

      const groupIds = customerGroupsList.map((group) => group.unique_id);
      let allEnrichedCurrencyOrders = [];
      if (groupIds.length > 0) {
        allEnrichedCurrencyOrders = await this.currencyOrderService.getCurrencyOrdersWithValuesForGroups(
          groupIds,
          'order',
        );
      }

      const enrichedCurrencyOrdersByGroupId = new Map<string, any[]>();
      allEnrichedCurrencyOrders.forEach((item) => {
        const groupId = item.group_id;
        if (!enrichedCurrencyOrdersByGroupId.has(groupId)) {
          enrichedCurrencyOrdersByGroupId.set(groupId, []);
        }
        enrichedCurrencyOrdersByGroupId.get(groupId).push(item);
      });

      // Enrich results
      const enrichedGroups = customerGroupsList.map((group) => {
        if (user?.starred_group.length > 0 && user.starred_group.includes(group.unique_id)) {
          group['is_favorite'] = true;
        }

        let currenciesForThisGroup = enrichedCurrencyOrdersByGroupId.get(group.unique_id) || [];

        let finalCurrencies = currenciesForThisGroup.map((item) => ({
          status: item.status,
          value: item.value,
          currency: item.currency,
          is_mismatch: item.is_mismatch,
          error: item.error,
          processing: item.processing,
          transferring: item.transferring,
          changes_required: item.changes_required,
        }));

        if (finalCurrencies.length === 0) {
          finalCurrencies.push({
            status: 'all_clear',
            value: 0.0,
            currency: group?.settlement_currency?.code,
            is_mismatch: false,
            error: 0,
            processing: 0,
            transferring: 0,
            changes_required: 0,
          });
        } else {
          const hasMatchingSettlementCurrency = finalCurrencies.some(
            (currency) => currency.currency === group?.settlement_currency?.code,
          );

          if (!hasMatchingSettlementCurrency) {
            finalCurrencies.push({
              status: 'all_clear',
              value: 0.0,
              currency: group?.settlement_currency.code,
              is_mismatch: false,
              error: 0,
              processing: 0,
              transferring: 0,
              changes_required: 0,
            });
          }
        }
        return {
          ...group,
          settlement_currency: group?.settlement_currency?.code,
          currencies: finalCurrencies,
        };
      });

      let filteredGroups = enrichedGroups;
      if (valueStatusFilter && valueStatusFilter !== 'all') {
        filteredGroups = enrichedGroups.filter((group) => {
          if (!group.currencies) return false;
          if (valueStatusFilter === 'not_tally') {
            return group.currencies.some((c) => c.is_mismatch === true);
          }
          return group.currencies.some((c) => c.status === valueStatusFilter);
        });
      }

      const totalCount = filteredGroups.length;

      let paginatedGroups = filteredGroups;
      if (filter?.cp && filter?.pl) {
        const skip = (filter.cp - 1) * filter.pl;
        paginatedGroups = filteredGroups.slice(skip, skip + filter.pl);
      }

      const resultGroups = paginatedGroups.map((group) => {
        if (valueStatusFilter && valueStatusFilter !== 'all') {
          let newCurrencies;
          if (valueStatusFilter === 'not_tally') {
            newCurrencies = group.currencies.filter((c) => c.is_mismatch === true);
          } else {
            // 'we_owe' or 'owe_us'
            newCurrencies = group.currencies.filter((c) => c.status === valueStatusFilter);
          }
          return { ...group, currencies: newCurrencies };
        }
        return group;
      });

      return sendSuccess(Messages.CustomerGroupsFetched, {
        customer_groups_list: resultGroups,
        total_count: totalCount,
      });
    } catch (error) {
      this.logger.error('Error from getGroupView');
      this.logger.error(error);
      return commonCatch(error);
    }
  }

  async getOrderGroupDetails(unique_id: string, loggedUser: LoggedAdmin): Promise<any> {
    try {
      const user = await this.managementUserRepository.findOne({
        where: { unique_id: loggedUser.unique_id },
      });

      const group = await this.customerGroupRepository.findOne({
        where: { unique_id },
        relations: ['settlement_currency'],
      });

      if (!group) {
        return sendFailure(Messages.CustomerGroupNotFound, HttpStatus.NOT_FOUND);
      }

      if (user?.starred_group.length > 0 && user.starred_group.includes(group.unique_id)) {
        group['is_favorite'] = true;
      }

      const transactions = await this.orderTransactionService.calculateAmountForGroup('notOwn', null, group.unique_id);

      const mismatchedCurrencies = await this.getMismatchedCurrencies(group.unique_id, null);

      const currenciesWithMismatch = transactions.map((t) => ({
        ...t,
        is_mismatch: mismatchedCurrencies.has(t.currency),
      }));

      if (currenciesWithMismatch.length === 0) {
        currenciesWithMismatch.push({
          status: 'all_clear',
          value: 0.0,
          currency: group?.settlement_currency.code,
          processing: 0,
          transferring: 0,
        });
      } else {
        const hasMatchingCurrency = currenciesWithMismatch.some(
          (currency) => currency.currency === group?.settlement_currency.code,
        );

        if (!hasMatchingCurrency) {
          currenciesWithMismatch.push({
            status: 'all_clear',
            value: 0.0,
            currency: group?.settlement_currency.code,
            processing: 0,
            transferring: 0,
          });
        }
      }

      const enrichedGroup = {
        ...group,
        settlement_currency: group?.settlement_currency?.code,
        currencies: currenciesWithMismatch,
      };

      return sendSuccess(Messages.CustomerGroupsFetched, enrichedGroup);
    } catch (error) {
      this.logger.error('Error from getGroupDetails');
      this.logger.error(error);
      return commonCatch(error);
    }
  }

  async getSingleCustomerGroupDetails(unique_id: string, loggedUser: LoggedAdmin): Promise<any> {
    try {
      const user = await this.managementUserRepository.findOne({
        where: { unique_id: loggedUser.unique_id },
      });

      const group = await this.customerGroupRepository.findOne({
        where: { unique_id },
        relations: ['settlement_currency'],
      });

      if (!group) {
        return sendFailure(Messages.CustomerGroupNotFound, HttpStatus.NOT_FOUND);
      }

      if (user?.starred_group.length > 0 && user.starred_group.includes(group.unique_id)) {
        group['is_favorite'] = true;
      }

      const transactions = await this.transactionService.calculateAmountForGroup(null, group.unique_id);
      const mismatchedCurrencies = await this.getMismatchedCurrencies(group.unique_id, null);
      const currenciesWithMismatch = transactions.map((t) => ({
        ...t,
        is_mismatch: mismatchedCurrencies.has(t.currency),
      }));
      if (currenciesWithMismatch.length === 0) {
        currenciesWithMismatch.push({
          status: 'all_clear',
          value: 0.0,
          currency: group?.settlement_currency?.code,
          processing: 0,
          transferring: 0,
        });
      } else {
        const hasMatchingCurrency = currenciesWithMismatch.some(
          (currency) => currency.currency === group?.settlement_currency?.code,
        );

        if (!hasMatchingCurrency) {
          currenciesWithMismatch.push({
            status: 'all_clear',
            value: 0.0,
            currency: group?.settlement_currency.code,
            processing: 0,
            transferring: 0,
          });
        }
      }

      const enrichedGroup = {
        ...group,
        settlement_currency: group?.settlement_currency?.code,
        currencies: currenciesWithMismatch,
      };

      return sendSuccess(Messages.CustomerGroupsFetched, enrichedGroup);
    } catch (error) {
      this.logger.error('Error from getSingleCustomerGroupDetails');
      this.logger.error(error);
      return commonCatch(error);
    }
  }

  private async getMismatchedCurrencies(groupId: string, currencyId: string | null): Promise<Set<string>> {
    const [transactionValues, orderTransactionValues] = await Promise.all([
      this.transactionService.calculateAmountForGroup(currencyId, groupId),
      this.orderTransactionService.calculateAmountForGroup('mismatch', currencyId, groupId),
    ]);

    const mismatchedCurrencies = new Set<string>();
    const transactionMap = new Map(transactionValues.map((t) => [t.currency, t]));
    const orderTransactionMap = new Map(orderTransactionValues.map((ot) => [ot.currency, ot]));
    const allCurrencies = new Set([...transactionMap.keys(), ...orderTransactionMap.keys()]);

    for (const currency of allCurrencies) {
      const transactionData = transactionMap.get(currency);
      const orderTransactionData = orderTransactionMap.get(currency);

      if (!transactionData && orderTransactionData) {
        if (!(orderTransactionData.value === 0 && orderTransactionData.overall_calculated_amount === 0)) {
          mismatchedCurrencies.add(currency);
        }
        if (orderTransactionData?.status === 'all_clear' || +orderTransactionData?.value?.toFixed(2) <= 0.05) {
          mismatchedCurrencies.delete(currency);
        }
      }
      // Case 2: Transaction has data, OrderTransaction has nothing (and not both zero)
      else if (transactionData && !orderTransactionData) {
        if (!(transactionData?.value === 0 && transactionData?.overall_calculated_amount === 0)) {
          mismatchedCurrencies.add(currency);
        }
        if (transactionData?.status === 'all_clear' || +transactionData?.value?.toFixed(2) <= 0.05) {
          mismatchedCurrencies.delete(currency);
        }
      } else if (transactionData && orderTransactionData) {
        if (
          transactionData.status !== orderTransactionData.status ||
          +Math.abs(+transactionData.value?.toFixed(2) - +orderTransactionData.value.toFixed(2))?.toFixed(2) > 0.05 // Math.abs(transactionData.overall_calculated_amount - orderTransactionData.overall_calculated_amount) > 0.05
        ) {
          mismatchedCurrencies.add(currency);
        }
        if (transactionData.status === 'all_clear' && orderTransactionData.status === 'all_clear') {
          mismatchedCurrencies.delete(currency);
        }
      }
    }

    return mismatchedCurrencies;
  }
}
