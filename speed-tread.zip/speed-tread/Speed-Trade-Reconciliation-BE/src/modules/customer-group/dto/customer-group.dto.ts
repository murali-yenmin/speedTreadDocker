import { PartialType } from '@nestjs/mapped-types';
import { IsArray, IsNotEmpty, IsString, IsBoolean, IsOptional } from 'class-validator';

export class CreateCustomerGroupDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsString()
  @IsNotEmpty()
  group_id: string;

  @IsString()
  @IsNotEmpty()
  settlement_currency: string;
  
  @IsBoolean()
  @IsOptional()
  is_favorite?: boolean;

  @IsString()
  @IsOptional()
  media_source_id?: string;
}

export class UpdateCustomerGroupDto extends PartialType(CreateCustomerGroupDto) {
  @IsString()
  @IsNotEmpty()
  unique_id: string;

  @IsBoolean()
  @IsOptional()
  is_active?: boolean;
}
