import {
  BeforeInsert,
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToMany,
  PrimaryColumn,
  UpdateDateColumn,
  ManyToOne,
} from 'typeorm';
import * as utils from 'src/utils';
import { Currency } from 'src/modules/currency/entity/currency.entity';
import { MediaSource } from 'src/modules/media-source/entities/media-source.entity';

@Entity('customer_groups')
export class CustomerGroup {
  @PrimaryColumn({ type: 'varchar', length: 50 })
  unique_id: string;

  @BeforeInsert()
  generateUniqueId() {
    this.unique_id = utils.generateRandomId();
  }

  @Column({ type: 'varchar', length: 50, unique: true })
  group_id: string;

  @Column({ type: 'varchar', length: 255, unique: true })
  name: string;

  // @Column({ type: 'varchar', length: 50 })
  // media_source_id: string;

  @Column({ type: 'varchar', length: 50 })
  settlement_currency_id: string;

  @ManyToOne(() => Currency, { eager: true })
  @JoinColumn({ name: 'settlement_currency_id', referencedColumnName: 'unique_id' })
  settlement_currency: Currency;

  // @JoinColumn({ name: 'media_source_id', referencedColumnName: 'unique_id' })
  // media_source: MediaSource;

  @Column({ type: 'boolean', default: false })
  is_favorite: boolean;

  @Column({ type: 'boolean', default: true })
  is_active: boolean;

  @CreateDateColumn({ type: 'timestamp' })
  created_at: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updated_at: Date;

  @Column('json', { nullable: true })
  created_by: {
    id: string;
    name: string;
  };

  @Column('json', { nullable: true })
  updated_by: {
    id: string;
    name: string;
  };
}
