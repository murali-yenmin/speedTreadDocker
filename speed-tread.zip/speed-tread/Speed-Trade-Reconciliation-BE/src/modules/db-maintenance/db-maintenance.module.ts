import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DbMaintenanceService } from './db-maintenance.service';

@Module({
  imports: [TypeOrmModule.forFeature([])],
  providers: [DbMaintenanceService],
  exports: [DbMaintenanceService],
})
export class DbMaintenanceModule {}
