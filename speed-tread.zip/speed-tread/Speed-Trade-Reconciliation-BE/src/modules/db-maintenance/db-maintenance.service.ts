import { Injectable, Logger } from '@nestjs/common';
import { DataSource } from 'typeorm';

@Injectable()
export class DbMaintenanceService {
  private readonly logger = new Logger(DbMaintenanceService.name);

  constructor(private readonly dataSource: DataSource) {}

  async fixTimestampColumns() {
    this.logger.log('Starting database timestamp column maintenance...');

    const columnsToAlter = [
      { table: 'orders', column: 'ordered_date' },
      { table: 'order_transactions', column: 'transferred_date' },
      { table: 'transactions', column: 'transferred_date' },
    ];

    for (const { table, column } of columnsToAlter) {
      try {
        const [columnInfo] = await this.dataSource.query(
          `SELECT IS_NULLABLE, COLUMN_DEFAULT FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
          [table, column],
        );

        if (columnInfo) {
          const needsAlteration = columnInfo.IS_NULLABLE === 'NO' || columnInfo.COLUMN_DEFAULT !== null;

          if (needsAlteration) {
            this.logger.log(`Altering column ${table}.${column}: setting to TIMESTAMP NULL and dropping default.`);
            await this.dataSource.query(`ALTER TABLE ?? MODIFY ?? TIMESTAMP NULL`, [table, column]);
            this.logger.log(`Successfully altered column ${table}.${column}.`);
          } else {
            this.logger.log(`Column ${table}.${column} is already in the desired state. No alteration needed.`);
          }
        } else {
          this.logger.warn(`Column ${table}.${column} not found in INFORMATION_SCHEMA. Skipping alteration.`);
        }
      } catch (error) {
        this.logger.error(`Error altering column ${table}.${column}: ${error.message}`);
      }
    }

    this.logger.log('Database timestamp column maintenance completed.');
    return { message: 'Timestamp columns maintenance completed' };
  }
}