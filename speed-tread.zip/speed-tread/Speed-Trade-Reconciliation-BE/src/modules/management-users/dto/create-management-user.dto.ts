import { IsArray, IsNotEmpty, IsOptional } from 'class-validator';

export class CreateManagementUserDto {
  @IsNotEmpty()
  user_name: string;

  @IsNotEmpty()
  email_address: string;

  @IsNotEmpty()
  role_id: string;

  @IsOptional()
  @IsArray()
  starred_group?: string[];
}
