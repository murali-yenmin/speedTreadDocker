import { IsBoolean, IsNotEmpty, IsString } from 'class-validator';

export class StarGroupDto {
  @IsString()
  @IsNotEmpty()
  customer_group_id: string;

  @IsBoolean()
  @IsNotEmpty()
  is_add: boolean;
}
