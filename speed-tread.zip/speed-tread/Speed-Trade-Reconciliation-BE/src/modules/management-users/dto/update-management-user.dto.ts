import { OmitType, PartialType } from '@nestjs/mapped-types';
import { CreateManagementUserDto } from './create-management-user.dto';
import { IsArray, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class UpdateManagementUserDto extends PartialType(CreateManagementUserDto) {
  @IsString()
  @IsNotEmpty()
  unique_id: string;

  @IsOptional()
  @IsArray()
  starred_group?: string[];
}
