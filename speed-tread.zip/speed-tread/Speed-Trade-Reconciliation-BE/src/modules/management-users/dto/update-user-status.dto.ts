import { IsBoolean, IsNotEmpty } from "class-validator";

export class UpdateUserStatusDto {
  @IsNotEmpty()
  unique_id: string;

  @IsBoolean()
  @IsNotEmpty()
  is_active: boolean;
}
