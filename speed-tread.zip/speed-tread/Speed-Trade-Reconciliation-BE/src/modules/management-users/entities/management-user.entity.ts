import { Role } from 'src/modules/roles/entity/roles.entity';
import {
  BeforeInsert,
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryColumn,
  UpdateDateColumn,
} from 'typeorm';
import * as utils from 'src/utils';

@Entity('management_users')
export class ManagementUsers {
  @PrimaryColumn({ type: 'varchar', length: 50 })
  unique_id: string;

  @BeforeInsert()
  generateUniqueId() {
    this.unique_id = utils?.generateRandomId();
  }

  @Column({ nullable: true })
  user_name: string;

  @Column({ nullable: true })
  email_address: string;

  @Column({ type: 'varchar', length: 50 }) // FK column
  role_unique_id: string;

  @ManyToOne(() => Role, { eager: true })
  @JoinColumn({ name: 'role_unique_id', referencedColumnName: 'unique_id' })
  role: Role;

  @Column({ nullable: true })
  password: string;

  @Column({ default: null, nullable: true })
  secret_key: string;

  @Column({ nullable: true })
  profile_img: string;

  @Column({ nullable: true })
  key_expires_at: Date;

  @Column({ default: true })
  is_active: boolean;

  @Column({ default: false })
  is_deleted: boolean;

  @Column('json', { nullable: false, default: () => "'[]'" })
  starred_group: string[];

  @Column('json', { nullable: true })
  created_by: {
    id: string;
    name: string;
  };

  @Column('json', { nullable: true })
  updated_by: {
    id: string;
    name: string;
  };

  @CreateDateColumn({ name: 'created_at' })
  created_at: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updated_at: Date;
}
