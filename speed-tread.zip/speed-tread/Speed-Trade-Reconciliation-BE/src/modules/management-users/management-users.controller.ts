import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards, Put } from '@nestjs/common';
import { ManagementUsersService } from './management-users.service';
import { CreateManagementUserDto } from './dto/create-management-user.dto';
import { UpdateManagementUserDto } from './dto/update-management-user.dto';
import { UpdateUserStatusDto } from './dto/update-user-status.dto';
import { FilterDto } from 'src/common/dtos/filter.dto';
import { GetLoggedUser } from 'src/common/decorators/logged-admin.decorator';
import { LoggedAdmin } from 'src/common/interfaces/logged-user.interface';
import { AdminGuard } from 'src/common/guards/admin.guard';
import { StarGroupDto } from './dto/star-group.dto';

@Controller('user')
export class ManagementUsersController {
  constructor(private readonly managementUsersService: ManagementUsersService) {}

  @Post()
  create(@Body() createManagementUserDto: CreateManagementUserDto, @GetLoggedUser() loggedUser: LoggedAdmin) {
    return this.managementUsersService.createManagementUser(createManagementUserDto, loggedUser);
  }

  @Post('get-all')
  findAll(@Body() filter: FilterDto) {
    return this.managementUsersService.getAllUsers(filter);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.managementUsersService.getUser(id);
  }

  @Put()
  update(@Body() updateManagementUserDto: UpdateManagementUserDto) {
    return this.managementUsersService.updateUser(updateManagementUserDto);
  }

  @Put('status')
  updateUserStatus(@Body() updateUserStatusDto: UpdateUserStatusDto) {
    return this.managementUsersService.updateUserStatus(updateUserStatusDto);
  }

  @Put('star-group')
  starGroup(@Body() starGroupDto: StarGroupDto, @GetLoggedUser() loggedUser: LoggedAdmin) {
    return this.managementUsersService.starGroup(starGroupDto, loggedUser);
  }

  // For Bulk Delete Users
  // @Delete()
  // deleteMultipleUsers(@Body() uniqueIds: string[]) {
  //   return this.managementUsersService.deleBulkUsers(uniqueIds['uniqueIds']);
  // }
}
