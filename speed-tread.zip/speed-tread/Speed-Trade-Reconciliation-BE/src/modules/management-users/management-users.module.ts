import { forwardRef, Module } from '@nestjs/common';
import { ManagementUsersService } from './management-users.service';
import { ManagementUsersController } from './management-users.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ManagementUsers } from './entities/management-user.entity';
import { RolesModule } from '../roles/roles.module';
import { AppModule } from 'src/app.module';
import { AppService } from 'src/app.service';
import { CustomerGroup } from '../customer-group/entity/customer-group.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([ManagementUsers, CustomerGroup]),
    RolesModule,
    forwardRef(() => AppModule),
  ],
  controllers: [ManagementUsersController],
  providers: [ManagementUsersService, AppService],
  exports: [ManagementUsersService],
})
export class ManagementUsersModule {}
