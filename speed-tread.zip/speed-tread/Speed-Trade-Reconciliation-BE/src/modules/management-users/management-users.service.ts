import { HttpStatus, Injectable, Logger } from '@nestjs/common';
import { CreateManagementUserDto } from './dto/create-management-user.dto';
import { UpdateManagementUserDto } from './dto/update-management-user.dto';
import { UpdateUserStatusDto } from './dto/update-user-status.dto';
import { commonCatch, sendFailure, sendSuccess } from 'src/utils/response.utils';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Not, Repository } from 'typeorm';
import { ManagementUsers } from './entities/management-user.entity';
import { Messages } from 'src/message-constants/message.constants';
import * as utils from '../../utils';
import { RolesService } from '../roles/roles.service';
import { FilterDto } from 'src/common/dtos/filter.dto';
import { Condition } from 'src/common/interfaces/app.interface';
import { LoggedAdmin } from 'src/common/interfaces/logged-user.interface';
import { AppService } from 'src/app.service';
import { ok } from 'assert';
import { EmailDescription } from 'src/constants/app.constant';
import { EmailSubject } from 'src/constants/email.constants';
import { StarGroupDto } from './dto/star-group.dto';
import { CustomerGroup } from '../customer-group/entity/customer-group.entity';

@Injectable()
export class ManagementUsersService {
  private logger = new Logger(ManagementUsersService.name);
  constructor(
    @InjectRepository(ManagementUsers)
    private readonly managementUserRepository: Repository<ManagementUsers>,
    @InjectRepository(CustomerGroup)
    private readonly customerGroupRepository: Repository<CustomerGroup>,
    private readonly rolesService: RolesService,
    private readonly appService: AppService,
  ) {}

  // common methods for user management
  async findOne(query: any): Promise<any> {
    if (query.where) {
      query.where.is_deleted = false;
    } else {
      query.where = { is_deleted: false };
    }
    return await this.managementUserRepository.findOne(query);
  }

  async update(criteria: any, data: Partial<ManagementUsers>): Promise<ManagementUsers | null> {
    await this.managementUserRepository.update(criteria, data);
    return await this.managementUserRepository.findOne({ where: criteria });
  }

  private async checkUserExists(email: string): Promise<ManagementUsers | null> {
    const user = await this.managementUserRepository.findOne({
      where: [{ email_address: email }],
    });
    return user;
  }

  //   Create a management user
  async createManagementUser(createManagementUserDto: CreateManagementUserDto, loggedUser: LoggedAdmin): Promise<any> {
    try {
      const userExists = await this.checkUserExists(createManagementUserDto.email_address);

      if (userExists?.email_address === createManagementUserDto.email_address) {
        return sendFailure(Messages.EmailAlreadyExists, HttpStatus?.OK);
      }
      // const password = 'Yenmin@123';
      const password = utils.generatePassword();
      const hashedPassword = await utils.createHashPwd(password);

      const user = this.managementUserRepository.create({
        user_name: createManagementUserDto.user_name,
        email_address: createManagementUserDto.email_address,
        password: hashedPassword,
        role_unique_id: createManagementUserDto.role_id,
        starred_group: createManagementUserDto.starred_group,
        created_by: {
          id: loggedUser?.unique_id,
          name: loggedUser?.user_name,
        },
        updated_by: {
          id: loggedUser?.unique_id,
          name: loggedUser?.user_name,
        },
      });

      await this.managementUserRepository.save(user);
      user['generatePassword'] = password;
      this.appService.sendWelcomeMail(user);
      if (user) {
        return sendSuccess(Messages.userCreated);
      } else if (!user) {
        return sendFailure(Messages.userCreateFailed, HttpStatus.OK);
      }
    } catch (error) {
      this.logger.error('Error from createManagementUser', error);
      return commonCatch(error);
    }
  }

  async getAllUsers(filter: FilterDto): Promise<any> {
    try {
      const queryBuilder = this.managementUserRepository.createQueryBuilder('user');
      queryBuilder.where('user.is_deleted = :is_deleted', { is_deleted: false });

      const totalCount = await queryBuilder.getCount();
      // Apply filters (WHERE)
      if (filter?.query) {
        const conditions = filter.query as Condition[];
        const whereConditions = utils.buildMysqlQuery(conditions);

        // Assuming buildMysqlQuery returns a valid TypeORM-compatible object
        queryBuilder.andWhere(whereConditions);
      }

      // Apply sorting
      let sortField = filter?.sort?.field ?? 'created_at';
      const sortOrder = filter?.sort?.value === 'asc' ? 'ASC' : 'DESC';
      const orderBy = utils.buildOrderBy('user', sortField, sortOrder);

      if (orderBy) {
        queryBuilder.addOrderBy(orderBy.field, orderBy.order);
      }

      // Pagination
      const skip = (filter?.cp - 1) * filter?.pl;
      queryBuilder.skip(skip).take(filter?.pl);

      queryBuilder.leftJoinAndSelect('user.role', 'role');

      // ✅ Select specific user fields
      queryBuilder.select([
        'user.unique_id',
        'user.user_name',
        'user.email_address',
        'user.is_active',
        'user.profile_img',
        'user.starred_group',
        'user.updated_at',
      ]);

      // ✅ Select specific role fields (otherwise you’ll get all columns)
      queryBuilder.addSelect(['role.unique_id', 'role.role_type']);

      // Execute query
      const usersList = await queryBuilder.getMany();

      return sendSuccess(Messages.GetAllAdmin, {
        users_list: usersList,
        total_count: totalCount,
      });
    } catch (error) {
      this.logger.error('Error from getAllUsers', error);
      return commonCatch(error);
    }
  }

  async getUser(id: string): Promise<object> {
    try {
      const user = await this.managementUserRepository
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.role', 'role')
        .select(['user.unique_id', 'user.user_name', 'user.email_address', 'user.starred_group'])
        .where('user.unique_id = :id', { id })
        .andWhere('user.is_deleted = :isDeleted', { isDeleted: false })
        .getOne();

      if (!user) {
        return sendFailure(Messages.UserNotFound);
      }
      return sendSuccess(Messages.UserFetched, user);
    } catch (error) {
      this.logger.error('Error fetching user', error);
      return commonCatch(error);
    }
  }

  async remove(id: string): Promise<any> {
    try {
      const user = await this.managementUserRepository.findOne({ where: { unique_id: id } });
      if (!user) {
        return sendFailure(Messages.UserNotFound);
      }
      await this.managementUserRepository.delete({ unique_id: id });
      return sendSuccess(Messages.userDeleted);
    } catch (error) {
      this.logger.error('Error from remove', error);
      return commonCatch(error);
    }
  }

  async updateUserStatus(updateUserStatusDto: UpdateUserStatusDto): Promise<any> {
    try {
      const user = await this.managementUserRepository.findOne({ where: { unique_id: updateUserStatusDto.unique_id } });
      if (!user) {
        return sendFailure(Messages.UserNotFound);
      }
      await this.managementUserRepository.update(
        { unique_id: updateUserStatusDto.unique_id },
        { is_active: updateUserStatusDto.is_active },
      );
      const updatedUser = await this.managementUserRepository
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.role', 'role')
        .select([
          'user.unique_id',
          'user.user_name',
          'user.email_address',
          'user.is_active',
          'role.unique_id',
          'role.role_type',
        ])
        .where('user.unique_id = :unique_id', { unique_id: updateUserStatusDto.unique_id })
        .getOne();

      // Attach role_type if role exists
      const responseUser = updatedUser
        ? {
            ...updatedUser,
            role_type: updatedUser.role?.role_type,
          }
        : null;
      return sendSuccess(Messages.userStatusUpdated, responseUser);
    } catch (error) {
      this.logger.error('Error from updateUserStatus', error);
      return commonCatch(error);
    }
  }

  async updateUser(updateManagementUserDto: UpdateManagementUserDto): Promise<any> {
    try {
      const user = await this.managementUserRepository.findOne({
        where: { unique_id: updateManagementUserDto.unique_id },
      });

      if (!user) {
        return sendFailure(Messages.UserNotFound, HttpStatus.OK);
      }

      // Check if email is being updated and if it's already taken
      if (updateManagementUserDto.email_address && user.email_address !== updateManagementUserDto.email_address) {
        const emailExists = await this.managementUserRepository.findOne({
          where: {
            email_address: updateManagementUserDto.email_address,
            unique_id: Not(updateManagementUserDto.unique_id),
          },
        });

        if (emailExists) {
          return sendFailure(Messages.EmailAlreadyExists, HttpStatus.OK);
        }
        //For future use
        // updateManagementUserDto['is_active'] = false;
        // const otp = utils.generateOTP();
        // const hashedOtp = await utils.createHashOtp(otp);
        // this.appService.sendForgotMail(
        //   { ...user, ...updateManagementUserDto, secret_key: hashedOtp },
        //   EmailDescription.RegeneratePasswordUsingLink,
        //   EmailSubject.RegeneratePassword,
        // );
      }

      const { unique_id, role_id, ...updateData } = updateManagementUserDto;

      if (role_id) {
        (updateData as any).role_unique_id = role_id;
      }

      // Update user
      await this.managementUserRepository.update({ unique_id: unique_id }, { ...updateData });

      const updatedUser = await this.managementUserRepository
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.role', 'role')
        .select([
          'user.unique_id',
          'user.user_name',
          'user.email_address',
          'user.is_active',
          'role.unique_id',
          'role.role_type',
        ])
        .where('user.unique_id = :unique_id', { unique_id: unique_id })
        .getOne();

      return sendSuccess(Messages.userUpdated, updatedUser);
    } catch (error) {
      this.logger.error('Error from updateUser', error);
      return commonCatch(error);
    }
  }

  async starGroup(starGroupDto: StarGroupDto, loggedUser: LoggedAdmin): Promise<any> {
    try {
      const { customer_group_id, is_add } = starGroupDto;
      const user = await this.managementUserRepository.findOne({
        where: { unique_id: loggedUser.unique_id },
      });

      if (!user) {
        return sendFailure(Messages.UserNotFound, HttpStatus.NOT_FOUND);
      }

      const group = await this.customerGroupRepository.findOne({
        where: { unique_id: customer_group_id },
      });

      if (!group) {
        return sendFailure(Messages.CustomerGroupNotFound, HttpStatus.NOT_FOUND);
      }

      let starredGroups = user.starred_group || [];

      if (is_add) {
        if (!starredGroups.includes(customer_group_id)) {
          starredGroups.push(customer_group_id);
        }
      } else {
        starredGroups = starredGroups.filter((groupId) => groupId !== customer_group_id);
      }

      user.starred_group = starredGroups;
      await this.managementUserRepository.save(user);

      return sendSuccess(Messages.userUpdated, user);
    } catch (error) {
      this.logger.error('Error from starGroup', error);
      return commonCatch(error);
    }
  }
  // For Bulk Delete Users
  // async deleBulkUsers(ids: string[]): Promise<any> {
  //   try {
  //     await this.managementUserRepository.delete({ role_unique_id: In(ids) });
  //     return sendSuccess(Messages.userDeleted);
  //   } catch (error) {
  //     this.logger.error('Error from deleBulkUsers', error);
  //     return commonCatch(error);
  //   }
  // }
}
