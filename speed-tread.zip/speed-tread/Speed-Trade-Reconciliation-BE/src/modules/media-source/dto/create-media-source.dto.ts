import { IsString, IsNotEmpty } from 'class-validator';

export class CreateMediaSourceDto {
  @IsString()
  @IsNotEmpty()
  label: string;
}
