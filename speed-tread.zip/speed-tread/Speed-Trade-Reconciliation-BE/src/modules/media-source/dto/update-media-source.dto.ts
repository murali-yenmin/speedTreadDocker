import { PartialType } from '@nestjs/mapped-types';
import { CreateMediaSourceDto } from './create-media-source.dto';
import { IsString, IsNotEmpty, IsOptional, IsBoolean } from 'class-validator';

export class UpdateMediaSourceDto extends PartialType(CreateMediaSourceDto) {
  @IsString()
  @IsNotEmpty()
  unique_id: string;

  @IsOptional()
  @IsBoolean()
  is_active?: boolean;
}
