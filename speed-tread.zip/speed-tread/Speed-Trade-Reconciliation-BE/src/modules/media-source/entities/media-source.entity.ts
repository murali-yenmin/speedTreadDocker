import { BeforeInsert, Column, CreateDateColumn, Entity, PrimaryColumn, UpdateDateColumn } from 'typeorm';
import * as utils from 'src/utils';

@Entity('media_sources')
export class MediaSource {
  @PrimaryColumn({ type: 'varchar', length: 50 })
  unique_id: string;

  @BeforeInsert()
  generateUniqueId() {
    this.unique_id = this.unique_id || utils.generateRandomId();
  }

  @Column({ type: 'varchar', length: 100 })
  label: string;

  @Column({ default: true })
  is_active: boolean;

  @Column({ default: false })
  is_deleted: boolean;

  @CreateDateColumn({ type: 'timestamp' })
  created_at: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updated_at: Date;
}
