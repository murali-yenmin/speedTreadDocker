import { Controller, Get, Post, Body, Patch, Param, Delete, Put } from '@nestjs/common';
import { MediaSourceService } from './media-source.service';
import { CreateMediaSourceDto } from './dto/create-media-source.dto';
import { UpdateMediaSourceDto } from './dto/update-media-source.dto';

@Controller('media-source')
export class MediaSourceController {
  constructor(private readonly mediaSourceService: MediaSourceService) {}

  @Post()
  create(@Body() createMediaSourceDto: CreateMediaSourceDto) {
    return this.mediaSourceService.create(createMediaSourceDto);
  }

  @Get()
  findAll() {
    return this.mediaSourceService.findAll();
  }

  @Get(':unique_id')
  findOne(@Param('unique_id') unique_id: string) {
    return this.mediaSourceService.findOne(unique_id);
  }

  @Put()
  update(@Body() updateMediaSourceDto: UpdateMediaSourceDto) {
    return this.mediaSourceService.update(updateMediaSourceDto);
  }

  @Delete(':unique_id')
  remove(@Param('unique_id') unique_id: string) {
    return this.mediaSourceService.remove(unique_id);
  }
}
