import { Module } from '@nestjs/common';
import { MediaSourceService } from './media-source.service';
import { MediaSourceController } from './media-source.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MediaSource } from './entities/media-source.entity';

@Module({
  imports: [TypeOrmModule.forFeature([MediaSource])],
  controllers: [MediaSourceController],
  providers: [MediaSourceService],
  exports: [MediaSourceService],
})
export class MediaSourceModule {}
