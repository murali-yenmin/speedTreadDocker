import { HttpStatus, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Raw, Repository } from 'typeorm';
import { MediaSource } from './entities/media-source.entity';
import { CreateMediaSourceDto } from './dto/create-media-source.dto';
import { UpdateMediaSourceDto } from './dto/update-media-source.dto';
import { commonCatch, sendFailure, sendSuccess } from 'src/utils/response.utils';
import { Messages } from 'src/message-constants/message.constants';

@Injectable()
export class MediaSourceService {
  private readonly logger = new Logger(MediaSourceService.name);

  constructor(
    @InjectRepository(MediaSource)
    private readonly mediaSourceRepository: Repository<MediaSource>,
  ) {}

  async create(dto: CreateMediaSourceDto): Promise<object> {
    try {
      const { label } = dto;
      const existingMediaSource = await this.mediaSourceRepository.findOne({
        where: { label: Raw((alias) => `LOWER(${alias}) = LOWER(:label)`, { label }) },
      });

      if (existingMediaSource) {
        return sendFailure(Messages.MediaSourceAlreadyExists, HttpStatus.OK);
      }

      const newMediaSource = this.mediaSourceRepository.create({
        label,
      });
      await this.mediaSourceRepository.save(newMediaSource);

      return sendSuccess(Messages.MediaSourceCreated, newMediaSource);
    } catch (error) {
      this.logger.error(`Failed to create media source: ${error.message}`);
      return commonCatch(error);
    }
  }

  async findAll(): Promise<object> {
    try {
      const mediaSources = await this.mediaSourceRepository.find({
        where: { is_deleted: false },
        order: { updated_at: 'DESC' }, // DESC = -1
      });

      return sendSuccess(Messages.MediaSourceFetched, mediaSources);
    } catch (error) {
      this.logger.error(`Failed to fetch media sources: ${error.message}`);
      return commonCatch(error);
    }
  }

  async findOne(unique_id: string): Promise<object> {
    try {
      const mediaSource = await this.mediaSourceRepository.findOne({ where: { unique_id, is_deleted: false } });
      if (!mediaSource) {
        return sendFailure(Messages.MediaSourceNotExist, HttpStatus.NOT_FOUND);
      }
      return sendSuccess(Messages.MediaSourceFetched, mediaSource);
    } catch (error) {
      this.logger.error(`Failed to fetch media source: ${error.message}`);
      return commonCatch(error);
    }
  }

  async update(dto: UpdateMediaSourceDto): Promise<object> {
    try {
      const { unique_id, label, ...updateData } = dto;
      const mediaSource = await this.mediaSourceRepository.findOne({ where: { unique_id, is_deleted: false } });

      if (!mediaSource) {
        return sendFailure(Messages.MediaSourceNotExist, HttpStatus.NOT_FOUND);
      }

      if (label) {
        const existingMediaSource = await this.mediaSourceRepository.findOne({
          where: { label: Raw((alias) => `LOWER(${alias}) = LOWER(:label)`, { label }), is_deleted: false },
        });

        if (existingMediaSource && existingMediaSource.unique_id !== unique_id) {
          return sendFailure(Messages.MediaSourceAlreadyExists, HttpStatus.BAD_REQUEST);
        }
        mediaSource.label = label;
      }

      Object.assign(mediaSource, updateData);
      await this.mediaSourceRepository.save(mediaSource);

      return sendSuccess(Messages.MediaSourceUpdated, mediaSource);
    } catch (error) {
      this.logger.error(`Failed to update media source: ${error.message}`);
      return commonCatch(error);
    }
  }

  async remove(unique_id: string): Promise<object> {
    try {
      const mediaSource = await this.mediaSourceRepository.findOne({ where: { unique_id, is_deleted: false } });

      if (!mediaSource) {
        return sendFailure(Messages.MediaSourceNotExist, HttpStatus.NOT_FOUND);
      }

      mediaSource.is_deleted = true;
      await this.mediaSourceRepository.save(mediaSource);

      return sendSuccess(Messages.MediaSourceDeleted, null);
    } catch (error) {
      this.logger.error(`Failed to delete media source: ${error.message}`);
      return commonCatch(error);
    }
  }
}
