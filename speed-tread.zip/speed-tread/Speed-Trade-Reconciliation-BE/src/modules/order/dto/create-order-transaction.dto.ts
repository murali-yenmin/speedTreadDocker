import { IsString, IsNotEmpty, IsNumber, IsOptional, ValidateIf, IsDate } from 'class-validator';
import { Type } from 'class-transformer';

export class CreateOrderTransactionDto {
  @IsString()
  @IsNotEmpty()
  order_id: string;

  @IsString()
  @IsNotEmpty()
  group_id: string;

  @IsString()
  @IsNotEmpty()
  transfer_by: string;

  @IsString()
  @IsNotEmpty()
  trading: string;

  @IsNumber()
  @IsNotEmpty()
  sell_value: number;

  @IsString()
  @IsNotEmpty()
  sell_currency: string;

  @IsString()
  @IsNotEmpty()
  settlement_currency: string;

  @IsNumber()
  @ValidateIf((o) => o.sell_currency !== o.settlement_currency)
  @IsNotEmpty()
  rate: number;

  @IsNumber()
  @IsOptional()
  fee: number;

  @IsString()
  @IsOptional()
  remarks?: string;

  @IsString()
  @IsOptional()
  account_id?: string;

  @IsString()
  @IsOptional()
  transferred_date?: string;
}
