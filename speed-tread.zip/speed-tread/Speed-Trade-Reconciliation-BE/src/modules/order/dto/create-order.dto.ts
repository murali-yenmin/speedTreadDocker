import {
  IsBoolean,
  IsOptional,
  IsArray,
  ValidateNested,
  ArrayMinSize,
  Validate,
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments,
} from 'class-validator';
import { Type } from 'class-transformer';
import { OrderDataDto } from './order-data.dto';

@ValidatorConstraint({ name: 'isMultiOrder', async: false })
export class IsMultiOrderConstraint implements ValidatorConstraintInterface {
  validate(data: OrderDataDto[], args: ValidationArguments) {
    const object = args.object as CreateOrderDto;
    if (object.is_multiOrder === false && data.length > 1) {
      return false;
    }
    return true;
  }

  defaultMessage(args: ValidationArguments) {
    return 'For single order creation, the data array must contain only one element.';
  }
}

export class CreateOrderDto {
  @IsBoolean()
  @IsOptional()
  is_multiOrder?: boolean = false;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => OrderDataDto) // crucial for nested validation
  data: OrderDataDto[];
}
