import { IsNotEmpty, IsString } from 'class-validator';

export class DateStatusDto {
  @IsString()
  @IsNotEmpty()
  group_id: string;

  @IsString()
  @IsNotEmpty()
  settlement_currency: string;
}
