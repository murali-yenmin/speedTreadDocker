import { IsArray, IsNotEmpty, IsString } from 'class-validator';

export class DeleteMultiOrderDto {
  @IsArray()
  @IsNotEmpty()
  @IsString({ each: true })
  ids: string[];
}
