import { 
  IsIn, 
  IsOptional, 
  IsString, 
  IsArray, 
  Validate, 
  ValidatorConstraint, 
  ValidatorConstraintInterface, 
  ValidationArguments, 
  IsNotEmpty
} from 'class-validator';

@ValidatorConstraint({ name: 'GroupOrCurrencyRequired', async: false })
export class GroupOrCurrencyRequired implements ValidatorConstraintInterface {
  validate(_: any, args: ValidationArguments) {
    const dto = args.object as any;

    // At least one must exist and must be a non-empty array
    return (
      (dto.group_id && dto.group_id.length > 0) ||
      (dto.currency_id && dto.currency_id.length > 0)
    );
  }

  defaultMessage(args: ValidationArguments) {
    return 'Either group_id or currency_id must be provided.';
  }
}

export class ListOrderGroupCurrencyDto {
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  group_id?: string[];

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  currency_id?: string[];

  // Custom validator
  @Validate(GroupOrCurrencyRequired)
  validateGroupOrCurrency: boolean;

  @IsString()
  @IsNotEmpty()
  day_filter: string;
}
