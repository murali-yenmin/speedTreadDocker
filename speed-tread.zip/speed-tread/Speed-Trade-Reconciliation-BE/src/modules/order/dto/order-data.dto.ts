import { IsString, IsNotEmpty, IsNumber, IsOptional, IsIn, ValidateIf, IsDate } from 'class-validator';
import { Type } from 'class-transformer';

export class OrderDataDto {
  @IsString()
  @IsNotEmpty()
  group_id: string;

  @IsString()
  @IsNotEmpty()
  account_id: string;

  @IsString()
  @IsNotEmpty()
  @IsIn(['we', 'customer'])
  order_by: string;

  @IsString()
  @IsNotEmpty()
  currency: string;

  @IsString()
  @IsNotEmpty()
  settlement_currency: string;

  @IsNumber()
  @IsNotEmpty()
  amount: number;

  @IsNumber()
  @IsOptional()
  @ValidateIf((o) => o.currency !== o.settlement_currency)
  rate: number;

  @IsNumber()
  @IsOptional()
  fee?: number;

  @IsString()
  @IsNotEmpty()
  trading: string;

  @IsString()
  @IsOptional()
  remarks?: string;

  @IsString()
  @IsOptional()
  ordered_date?: string;
}
