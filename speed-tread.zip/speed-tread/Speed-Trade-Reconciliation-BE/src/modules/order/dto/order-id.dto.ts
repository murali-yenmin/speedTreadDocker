import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class OrderIdDto {
  @IsString()
  @IsNotEmpty()
  order_id: string;
}

export class AmountCheckDto extends OrderIdDto {
  @IsString()
  @IsOptional()
  transaction_id?: string;
}
