import { PartialType } from '@nestjs/mapped-types';
import { CreateOrderTransactionDto } from './create-order-transaction.dto';
import { IsNotEmpty, IsString } from 'class-validator';

export class UpdateOrderTransactionDto extends PartialType(CreateOrderTransactionDto) {
  @IsString()
  @IsNotEmpty()
  unique_id: string;
}
