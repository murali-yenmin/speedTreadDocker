import {
  BeforeInsert,
  Column,
  CreateDateColumn,
  Entity,
  PrimaryColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';
import * as utils from 'src/utils';
import { Currency } from 'src/modules/currency/entity/currency.entity';
import { Order } from './order.entity';
import { Account } from 'src/modules/accounts/entities/account.entity';

@Entity('order_transactions')
export class OrderTransaction {
  @PrimaryColumn({ type: 'varchar', length: 50 })
  unique_id: string;

  @BeforeInsert()
  generateUniqueId() {
    this.unique_id = utils.generateTransactionId();
  }

  @Column({ type: 'varchar', length: 50, unique: true, nullable: true })
  transaction_id: string;

  @Index()
  @Column({ type: 'varchar', length: 50, nullable: true })
  order_id: string;

  @Column({ type: 'varchar', length: 50, nullable: true })
  group_id: string;

  @ManyToOne(() => Order, (order) => order.transactions)
  @JoinColumn({ name: 'order_id', referencedColumnName: 'unique_id' })
  order: Order;

  @Column({ type: 'varchar', length: 255, nullable: true })
  transfer_by: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  trading: string;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0, nullable: true })
  sell_value: number;

  @Column({ type: 'varchar', length: 50, nullable: true })
  sell_currency_id: string;

  @ManyToOne(() => Currency, { eager: true })
  @JoinColumn({ name: 'sell_currency_id', referencedColumnName: 'unique_id' })
  sell_currency: Currency;

  @Column({ type: 'varchar', length: 50, nullable: true })
  settlement_currency_id: string;

  @ManyToOne(() => Currency, { eager: true })
  @JoinColumn({
    name: 'settlement_currency_id',
    referencedColumnName: 'unique_id',
  })
  settlement_currency: Currency;

  @Column({ type: 'decimal', precision: 18, scale: 3, default: 0, nullable: true })
  rate: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0, nullable: true })
  fee: number;

  @Column({ type: 'varchar', length: 50 })
  account_id: string;

  @Column({ type: 'varchar', length: 50, nullable: true })
  settlement_date: string;

  @ManyToOne(() => Account, { eager: true })
  @JoinColumn({ name: 'account_id', referencedColumnName: 'unique_id' })
  account: Account;

  @Column({ type: 'text', nullable: true })
  remarks: string;

  @Column({
    type: 'datetime',
    default: () => 'CURRENT_TIMESTAMP', // auto insert on create
    nullable: false,
  })
  transferred_date: Date;

  @CreateDateColumn({ type: 'timestamp' })
  created_at: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updated_at: Date;

  @Column('json', { nullable: true })
  created_by: {
    id: string;
    name: string;
  };

  @Column('json', { nullable: true })
  updated_by: {
    id: string;
    name: string;
  };

  @Index()
  @Column({ type: 'boolean', default: false })
  is_deleted: boolean;
}
