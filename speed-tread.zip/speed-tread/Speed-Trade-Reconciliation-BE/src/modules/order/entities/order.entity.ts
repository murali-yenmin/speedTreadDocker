import {
  BeforeInsert,
  Column,
  CreateDateColumn,
  Entity,
  PrimaryColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  OneToMany,
  Index,
} from 'typeorm';
import * as utils from 'src/utils';
import { Currency } from 'src/modules/currency/entity/currency.entity';
import { CustomerGroup } from 'src/modules/customer-group/entity/customer-group.entity';
import { OrderTransaction } from './order-transaction.entity';
import { Account } from 'src/modules/accounts/entities/account.entity';

@Entity('orders')
export class Order {
  @PrimaryColumn({ type: 'varchar', length: 50 })
  unique_id: string;

  @BeforeInsert()
  generateUniqueId() {
    this.unique_id = utils.generateRandomId();
  }

  @Column({ type: 'varchar', length: 50, unique: true })
  order_id: string;

  @Index() // Added Index
  @Column({ type: 'varchar', length: 50, default: 'processing', nullable: true  })
  status: string;

  @Index() // Added Index
  @Column({ type: 'varchar', length: 50, nullable: true })
  group_id: string;

  @ManyToOne(() => CustomerGroup, { eager: true })
  @JoinColumn({ name: 'group_id', referencedColumnName: 'unique_id' })
  customer_group: CustomerGroup;

  @Index() // Added Index
  @Column({ type: 'varchar', length: 50, update: true, nullable: true })
  account_id: string;

  @ManyToOne(() => Account, { eager: true })
  @JoinColumn({ name: 'account_id', referencedColumnName: 'unique_id' })
  account: Account;

  @Column({ type: 'varchar', length: 50, nullable: true })
  order_by: string; // 'we' or 'customer'

  @Index() // Added Index
  @Column({ type: 'varchar', length: 50, nullable: true })
  currency_id: string;

  @ManyToOne(() => Currency, { eager: true })
  @JoinColumn({ name: 'currency_id', referencedColumnName: 'unique_id' })
  currency: Currency;

  @Index() // Added Index
  @Column({ type: 'varchar', length: 50, nullable: true })
  settlement_currency_id: string;

  @ManyToOne(() => Currency, { eager: true })
  @JoinColumn({
    name: 'settlement_currency_id',
    referencedColumnName: 'unique_id',
  })
  settlement_currency: Currency;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0, nullable: true })
  amount: number;

  @Column({ type: 'decimal', precision: 18, scale: 3, default: 0, nullable: true })
  rate: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0, nullable: true })
  fee: number;

  @Column({ type: 'varchar', length: 50, nullable: true })
  trading: string; // 'buy' or 'sell'

  @Column({ type: 'text', nullable: true })
  remarks: string;

  @Index() // Added Index
  @Column({
    type: 'datetime',
    default: () => 'CURRENT_TIMESTAMP', // auto insert on create
    nullable: false,
  })
  ordered_date: Date;

  @OneToMany(() => OrderTransaction, (transaction) => transaction.order)
  transactions: OrderTransaction[];

  @Column({ default: true })
  is_active: boolean;

  @Index() // Added Index
  @Column({ default: false })
  is_deleted: boolean;

  @CreateDateColumn({ name: 'created_at' })
  created_at: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updated_at: Date;

  @Column('json', { nullable: true })
  created_by: {
    id: string;
    name: string;
  };

  @Column('json', { nullable: true })
  updated_by: {
    id: string;
    name: string;
  };
}
