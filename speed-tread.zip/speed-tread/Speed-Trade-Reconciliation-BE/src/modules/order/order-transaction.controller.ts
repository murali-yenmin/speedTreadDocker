import { ListOrderGroupCurrencyDto } from './dto/list-order-group-currency.dto';
import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  UseGuards,
  Patch,
  Put,
  Delete,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { OrderTransactionService } from './order-transaction.service';
import { CreateOrderTransactionDto } from './dto/create-order-transaction.dto';
import { UpdateOrderTransactionDto } from './dto/update-order-transaction.dto';
import { AdminGuard } from 'src/common/guards/admin.guard';
import { get } from 'http';
import { GetLoggedUser } from 'src/common/decorators/logged-admin.decorator';
import { LoggedAdmin } from 'src/common/interfaces/logged-user.interface';
import { OrderService } from './order.service';
import { AmountCheckDto, OrderIdDto } from './dto/order-id.dto';

@UseGuards(AdminGuard)
@Controller('order-transaction')
export class OrderTransactionController {
  constructor(
    private readonly orderTransactionService: OrderTransactionService,
    private readonly orderService: OrderService,
  ) {}

  @Post('full-pay')
  getFullPayDetails(@Body() orderIdDto: OrderIdDto, @GetLoggedUser() loggedUser: LoggedAdmin) {
    return this.orderTransactionService.getFullPayDetails(orderIdDto.order_id, loggedUser);
  }

  @Post('remaining-balance')
  getRemainingBalance(@Body() getRemainingAmountDto: AmountCheckDto) {
    return this.orderTransactionService.getRemainingBalance(getRemainingAmountDto);
  }

  @Post()
  create(@Body() createOrderTransactionDto: CreateOrderTransactionDto, @GetLoggedUser() loggedUser: LoggedAdmin) {
    return this.orderTransactionService.create(createOrderTransactionDto, loggedUser);
  }

  @Put()
  update(@Body() updateOrderTransactionDto: UpdateOrderTransactionDto, @GetLoggedUser() loggedUser: LoggedAdmin) {
    return this.orderTransactionService.update(updateOrderTransactionDto, loggedUser);
  }

  @Delete(':id')
  delete(@Param('id') id: string) {
    return this.orderTransactionService.delete(id);
  }

  @Get('order-currencies/:groupId')
  getOrderCurrenciesByGroupId(@Param('groupId') groupId: string) {
    return this.orderService.getOrderSettlementCurrencies(groupId);
  }

  @Post('list-based-on-group-currency')
  getListBasedOnGroupCurrencies(@Body() dto: ListOrderGroupCurrencyDto) {
    return this.orderTransactionService.listBasedOnGroupCurrency(dto);
  }

  @Get('details/:id')
  getTransactionDetails(@Param('id') id: string) {
    return this.orderTransactionService.getTransactionDetails(id);
  }

  @Put('settlement-date/update-all')
  updateSettlementDate() {
    return this.orderTransactionService.updateSettlementDate();
  }
}
