import { Injectable, Logger, HttpStatus, Inject, forwardRef } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Like, Repository, Between, In, LessThanOrEqual } from 'typeorm';
import { OrderTransaction } from './entities/order-transaction.entity';
import { CreateOrderTransactionDto } from './dto/create-order-transaction.dto';
import { commonCatch, sendSuccess, sendFailure } from 'src/utils/response.utils';
import { Order } from './entities/order.entity';
import { LoggedAdmin } from 'src/common/interfaces/logged-user.interface';
import moment, { convertUTCToSingapore, settlementDate, settlementDateUpdate } from '../../utils/moment';
import { Currency } from '../currency/entity/currency.entity';
import { CurrencyPair } from '../currency-pair/entities/currency-pair.entity';
import { Messages } from 'src/message-constants/message.constants';
import { OrderService } from './order.service';
import { CurrencyPairService } from '../currency-pair/currency-pair.service';

import { UpdateOrderTransactionDto } from './dto/update-order-transaction.dto';
import { CustomerGroup } from '../customer-group/entity/customer-group.entity';
import { AccountsService } from '../accounts/accounts.service';
import { AmountCheckDto } from './dto/order-id.dto';
import { AppConfigService } from 'src/config/app-config/app-config.service';
import { ListOrderGroupCurrencyDto } from './dto/list-order-group-currency.dto';

@Injectable()
export class OrderTransactionService {
  private readonly logger = new Logger(OrderTransactionService.name);

  constructor(
    @InjectRepository(OrderTransaction)
    private readonly orderTransactionRepository: Repository<OrderTransaction>,
    @InjectRepository(Order)
    private readonly orderRepository: Repository<Order>,
    @InjectRepository(CustomerGroup)
    private readonly customerGroupRepository: Repository<CustomerGroup>,
    @InjectRepository(Currency)
    private readonly currencyRepository: Repository<Currency>,
    @InjectRepository(CurrencyPair)
    private readonly currencyPairRepository: Repository<CurrencyPair>,
    private readonly accountsService: AccountsService,
    @Inject(forwardRef(() => OrderService))
    private readonly orderService: OrderService,
    private readonly currencyPairService: CurrencyPairService,
    private readonly appConfig: AppConfigService,
  ) {}

  async create(createOrderTransactionDto: CreateOrderTransactionDto, loggedUser: LoggedAdmin): Promise<any> {
    try {
      const order = await this.orderRepository.findOne({
        where: { unique_id: createOrderTransactionDto.order_id, is_deleted: false },
        relations: ['customer_group'],
      });

      if (!order) {
        return sendFailure(Messages.OrderNotFound, HttpStatus.NOT_FOUND);
      }

      const today = moment().startOf('day');

      const sellCurrency = await this.currencyRepository.findOne({
        where: { code: createOrderTransactionDto.sell_currency },
      });

      const settlementCurrency = await this.currencyRepository.findOne({
        where: { code: createOrderTransactionDto.settlement_currency },
      });

      if (!sellCurrency || !settlementCurrency) {
        return sendFailure(Messages.CurrencyNotExist, HttpStatus.NOT_FOUND);
      }

      if (createOrderTransactionDto.sell_currency !== createOrderTransactionDto.settlement_currency) {
        const currencyPair = await this.currencyPairRepository.findOne({
          where: {
            buy_currency_id: settlementCurrency.unique_id,
            sell_currency_id: sellCurrency.unique_id,
            is_deleted: false,
          },
        });

        if (!currencyPair) {
          return sendFailure(Messages.CurrencyPairNotFound, HttpStatus.OK);
        }
      }

      const format = (order.ordered_date ? moment(order.ordered_date, 'DD-MM-YYYY') : moment()).format('DDMMYYYY');
      const prefix = `${order.customer_group.group_id}/${format}/${createOrderTransactionDto.settlement_currency}-TF`;

      const lastTransaction = await this.orderTransactionRepository.findOne({
        where: { transaction_id: Like(`${prefix}%`) },
        order: { transaction_id: 'DESC' },
      });

      let newId = 1;
      if (lastTransaction) {
        const lastId = parseInt(lastTransaction.transaction_id.split('-').pop().replace('TF', ''), 10);
        newId = lastId + 1;
      }

      const transaction_id = `${prefix}${newId.toString().padStart(3, '0')}`;
      const settlement_date = await settlementDate(
        moment(createOrderTransactionDto?.transferred_date).format('DD-MM-YYYY'),
      );

      const selectedDate = moment(createOrderTransactionDto.transferred_date);
      const currentTime = moment();

      const finalDateTime = selectedDate
        .hour(currentTime.hour())
        .minute(currentTime.minute())
        .second(currentTime.second())
        .millisecond(currentTime.millisecond())
        .toDate();

      // Build new transaction object
      const newTransactionData: any = {
        ...createOrderTransactionDto,
        sell_currency: sellCurrency,
        settlement_currency: settlementCurrency,
        account_id: order.account_id,
        transaction_id,
        order_id: order.unique_id,
        transferred_date: finalDateTime,
        settlement_date: settlement_date,
        created_by: { id: loggedUser.unique_id, name: loggedUser.user_name },
        updated_by: { id: loggedUser.unique_id, name: loggedUser.user_name },
      };

      // ✅ REMOVE rate if zero, null or undefined
      if (!createOrderTransactionDto.rate || Number(createOrderTransactionDto.rate) === 0) {
        delete newTransactionData.rate;
      }
      const orderCheck = await this.orderCalculationCheck(
        order?.unique_id,
        null,
        createOrderTransactionDto?.sell_value,
      );

      if (orderCheck?.lastTransaction && +orderCheck?.feePaid !== +order?.fee && !createOrderTransactionDto?.fee) {
        return sendFailure('Fee is required for this transaction.', HttpStatus.OK);
      }
      const calculatedFee = +orderCheck?.feePaid + +createOrderTransactionDto?.fee;

      if (createOrderTransactionDto?.fee && orderCheck?.lastTransaction && calculatedFee > +order?.fee) {
        return sendFailure('The fee amount exceeds the allowed fee for this order.', HttpStatus.OK);
      }

      if (createOrderTransactionDto?.fee && orderCheck?.lastTransaction && calculatedFee !== +order?.fee) {
        return sendFailure('The fee amount does not match the required fee for this order.', HttpStatus.OK);
      }

      const newTransaction = this.orderTransactionRepository.create(newTransactionData);
      const savedTransaction = await this.orderTransactionRepository.save(newTransaction);

      await this.orderService.recalculateOrderStatus(order.unique_id);

      return sendSuccess('Transaction created successfully', savedTransaction);
    } catch (error) {
      this.logger.error('Error creating transaction', error);
      return commonCatch(error);
    }
  }

  async calculateAmountForGroup(purpose: string, date: string, groupId: string, currency?: string): Promise<any[]> {
    try {
      const filterDate = date ? moment(date, 'DD-MM-YYYY') : moment();
      const endDate = filterDate.clone().endOf('day').toDate();

      const qb = this.orderRepository
        .createQueryBuilder('o')
        .leftJoin('o.transactions', 't', 't.transferred_date <= :endDate AND t.is_deleted = false', { endDate })
        .leftJoinAndSelect('o.currency', 'currency')
        .leftJoinAndSelect('o.settlement_currency', 'settlement_currency')
        .leftJoinAndSelect('t.sell_currency', 't_sell_currency')
        .leftJoinAndSelect('t.settlement_currency', 't_settlement_currency')
        .leftJoin(
          'currency_pair',
          'cp',
          'cp.buy_currency_id = o.settlement_currency_id AND cp.sell_currency_id = t.sell_currency_id',
        )
        .select('settlement_currency.code', 'currency')
        .addSelect('t_sell_currency.code', 't_sell_currency_code')
        .addSelect('t_settlement_currency.code', 't_settlement_currency_code')
        .addSelect(
          `
        SUM(
          CASE 
            WHEN t.transfer_by = 'customer' AND cp.calculation_type = 'multiply' THEN t.sell_value * t.rate
            WHEN t.transfer_by = 'customer' AND cp.calculation_type = 'divide' THEN t.sell_value / t.rate
            WHEN t.transfer_by = 'customer' AND cp.calculation_type IS NULL THEN t.sell_value
            ELSE 0
          END
        )
      `,
          'customer_value',
        )
        .addSelect(
          `
        SUM(
          CASE 
            WHEN t.transfer_by = 'we' AND cp.calculation_type = 'multiply' THEN t.sell_value * t.rate
            WHEN t.transfer_by = 'we' AND cp.calculation_type = 'divide' THEN t.sell_value / t.rate
            WHEN t.transfer_by = 'we' AND cp.calculation_type IS NULL THEN t.sell_value
            ELSE 0
          END
        )
      `,
          'we_value',
        )
        .addSelect(`SUM(CASE WHEN t.transfer_by = 'customer' THEN t.fee ELSE 0 END)`, 'weOweFees')
        .addSelect(`SUM(CASE WHEN t.transfer_by = 'we' THEN t.fee ELSE 0 END)`, 'oweUsFees')
        .addSelect(
          `
        COUNT(
          DISTINCT CASE
            WHEN o.status IN ('error') THEN o.unique_id
          END
        )
      `,
          'error',
        )
        .addSelect(
          `
        COUNT(
          DISTINCT CASE
            WHEN o.status IN ('processing') THEN o.unique_id
          END
        )
      `,
          'processing',
        )
        .addSelect(
          `
        COUNT(
          DISTINCT CASE
            WHEN o.status IN ('transferring') THEN o.unique_id
          END
        )
      `,
          'transferring',
        )
        .addSelect(
          `
        COUNT(
          DISTINCT CASE
            WHEN o.status IN ('processing','error','transferring') THEN o.unique_id
          END
        )
      `,
          'changes_required',
        )
        .where('o.group_id = :groupId', { groupId })
        .andWhere('o.is_deleted = :isDeleted', { isDeleted: false })
        .addOrderBy('o.created_at', 'ASC');

      if (currency) {
        qb.andWhere('settlement_currency.unique_id = :currency', { currency });
      }

      qb.groupBy('settlement_currency.code');

      // Fetch all relevant settlement currencies for the group within the date range
      const allRelevantSettlementCurrenciesQuery = this.orderRepository
        .createQueryBuilder('o')
        .leftJoin('o.currency', 'currency')
        .leftJoin('o.settlement_currency', 'settlement_currency')
        .select('DISTINCT settlement_currency.code', 'currency')
        .where('o.group_id = :groupId', { groupId })
        .addOrderBy('o.created_at', 'ASC')
        .andWhere('o.ordered_date <= :endDate', { endDate })
        .andWhere('o.is_deleted = :isDeleted', { isDeleted: false });

      if (currency) {
        allRelevantSettlementCurrenciesQuery.andWhere('settlement_currency.unique_id = :currency', { currency });
      }

      const allRelevantCurrencies = await allRelevantSettlementCurrenciesQuery.getRawMany();

      const allCurrencyCodes = new Set(allRelevantCurrencies.map((c) => c.currency));

      const queryResults = await qb.getRawMany();

      // Create a map for quick lookup of aggregated results
      const resultsMap = new Map<string, any>();
      queryResults.forEach((r) => resultsMap.set(r.currency, r));

      const finalProcessedResults: any[] = [];

      for (const currCode of allCurrencyCodes) {
        if (resultsMap.has(currCode)) {
          finalProcessedResults.push(resultsMap.get(currCode));
        } else {
          // No transactions for this currency, return 'all_clear' with default values
          finalProcessedResults.push({
            status: 'all_clear',
            value: 0,
            currency: currCode,
            error: 0, // Default to 0 changes required if no transactions
            processing: 0,
            transferring: 0,
            changes_required: 0,
          });
        }
      }

      if (!finalProcessedResults.length && !currency) {
        return [];
      }

      if (purpose === 'own') {
        if (finalProcessedResults.length === 0) {
          return [{ status: 'all_clear', value: 0, currency: currency }];
        }
        const obj = finalProcessedResults[0];
        let totalWeOwe = (obj.we_value ? +obj.we_value : 0) + (obj.oweUsFees ? +obj.oweUsFees : 0);
        let totalOweUs = (obj.customer_value ? +obj.customer_value : 0) + (obj.weOweFees ? +obj.weOweFees : 0);
        totalOweUs = +totalOweUs.toFixed(2);
        totalWeOwe = +totalWeOwe.toFixed(2);
        if (totalWeOwe > totalOweUs) {
          return [{ status: 'owe_us', value: +(totalWeOwe - totalOweUs).toFixed(2), currency: obj.currency }];
        } else if (totalOweUs > totalWeOwe) {
          return [{ status: 'we_owe', value: +(totalOweUs - totalWeOwe).toFixed(2), currency: obj.currency }];
        } else {
          return [{ status: 'all_clear', value: 0, currency: obj.currency }];
        }
      }
      if (purpose === 'mismatch') {
        return finalProcessedResults.map((obj) => {
          let totalWeOwe = (obj.we_value ? +obj.we_value : 0) + (obj.oweUsFees ? +obj.oweUsFees : 0);
          let totalOweUs = (obj.customer_value ? +obj.customer_value : 0) + (obj.weOweFees ? +obj.weOweFees : 0);
          totalOweUs = +totalOweUs.toFixed(2);
          totalWeOwe = +totalWeOwe.toFixed(2);

          if (totalWeOwe > totalOweUs) {
            return {
              status: 'owe_us',
              value: +(totalWeOwe - totalOweUs).toFixed(2),
              currency: obj.currency,
              overall_calculated_amount: totalOweUs + totalWeOwe,
            };
          } else if (totalOweUs > totalWeOwe) {
            return {
              status: 'we_owe',
              value: +(totalOweUs - totalWeOwe).toFixed(2),
              currency: obj.currency,
              overall_calculated_amount: totalOweUs + totalWeOwe,
            };
          } else {
            return {
              status: 'all_clear',
              value: 0,
              currency: obj.currency,
              overall_calculated_amount: totalOweUs + totalWeOwe,
            };
          }
        });
      }

      if (purpose === 'notOwn') {
        return finalProcessedResults.map((obj) => {
          const customerValue = obj.customer_value ? +obj.customer_value : 0;
          const weOweFees = obj.weOweFees ? +obj.weOweFees : 0;
          const weValue = obj.we_value ? +obj.we_value : 0;
          const oweUsFees = obj.oweUsFees ? +obj.oweUsFees : 0;
          const errorCount = obj.error ? +obj.error : 0;
          const processingCount = obj.processing ? +obj.processing : 0;
          const transferringCount = obj.transferring ? +obj.transferring : 0;
          const changesRequired = obj.changes_required ? +obj.changes_required : 0;

          let totalWeOwe = weValue + oweUsFees;
          let totalOweUs = customerValue + weOweFees;
          totalOweUs = +totalOweUs.toFixed(2);
          totalWeOwe = +totalWeOwe.toFixed(2);
          if (totalWeOwe > totalOweUs) {
            return {
              status: 'owe_us',
              value: +(totalWeOwe - totalOweUs).toFixed(2),
              currency: obj.currency,
              error: errorCount,
              processing: processingCount,
              transferring: transferringCount,
              changes_required: changesRequired,
            };
          } else if (totalOweUs > totalWeOwe) {
            return {
              status: 'we_owe',
              value: +(totalOweUs - totalWeOwe).toFixed(2),
              currency: obj.currency,
              error: errorCount,
              processing: processingCount,
              transferring: transferringCount,
              changes_required: changesRequired,
            };
          } else {
            return {
              status: 'all_clear',
              value: 0,
              currency: obj.currency,
              error: errorCount,
              processing: processingCount,
              transferring: transferringCount,
              changes_required: changesRequired,
            };
          }
        });
      }

      return [];
    } catch (error) {
      this.logger.error('Error from calculateAmountForGroup', error);
      return [];
    }
  }

  async calculateAmountForGroups(purpose: string, date: string, groupIds: string[], currency?: string): Promise<any[]> {
    try {
      const filterDate = date ? moment(date, 'DD-MM-YYYY') : moment();
      const endDate = filterDate.clone().endOf('day').toDate();

      const qb = this.orderRepository
        .createQueryBuilder('o')
        .leftJoin('o.transactions', 't', 't.transferred_date <= :endDate AND t.is_deleted = false', { endDate })
        .leftJoinAndSelect('o.currency', 'currency')
        .leftJoinAndSelect('o.settlement_currency', 'settlement_currency')
        .leftJoinAndSelect('t.sell_currency', 't_sell_currency')
        .leftJoinAndSelect('t.settlement_currency', 't_settlement_currency')
        .leftJoin(
          'currency_pair',
          'cp',
          'cp.buy_currency_id = o.settlement_currency_id AND cp.sell_currency_id = t.sell_currency_id',
        )
        .select('settlement_currency.code', 'currency')
        .addSelect('t_sell_currency.code', 't_sell_currency_code')
        .addSelect('t_settlement_currency.code', 't_settlement_currency_code')
        .addSelect('o.group_id', 'groupId') // Select group_id
        .addSelect(
          `
        SUM(
          CASE 
            WHEN t.transfer_by = 'customer' AND cp.calculation_type = 'multiply' THEN t.sell_value * t.rate
            WHEN t.transfer_by = 'customer' AND cp.calculation_type = 'divide' THEN t.sell_value / t.rate
            WHEN t.transfer_by = 'customer' AND cp.calculation_type IS NULL THEN t.sell_value
            ELSE 0
          END
        )
      `,
          'customer_value',
        )
        .addSelect(
          `
        SUM(
          CASE 
            WHEN t.transfer_by = 'we' AND cp.calculation_type = 'multiply' THEN t.sell_value * t.rate
            WHEN t.transfer_by = 'we' AND cp.calculation_type = 'divide' THEN t.sell_value / t.rate
            WHEN t.transfer_by = 'we' AND cp.calculation_type IS NULL THEN t.sell_value
            ELSE 0
          END
        )
      `,
          'we_value',
        )
        .addSelect(`SUM(CASE WHEN t.transfer_by = 'customer' THEN t.fee ELSE 0 END)`, 'weOweFees')
        .addSelect(`SUM(CASE WHEN t.transfer_by = 'we' THEN t.fee ELSE 0 END)`, 'oweUsFees')
        .addSelect(
          `
        COUNT(
          DISTINCT CASE
            WHEN o.status IN ('error') THEN o.unique_id
          END
        )
      `,
          'error',
        )
        .addSelect(
          `
        COUNT(
          DISTINCT CASE
            WHEN o.status IN ('processing') THEN o.unique_id
          END
        )
      `,
          'processing',
        )
        .addSelect(
          `
        COUNT(
          DISTINCT CASE
            WHEN o.status IN ('transferring') THEN o.unique_id
          END
        )
      `,
          'transferring',
        )
        .addSelect(
          `
        COUNT(
          DISTINCT CASE
            WHEN o.status IN ('processing','error','transferring') THEN o.unique_id
          END
        )
      `,
          'changes_required',
        )
        .where('o.group_id IN (:...groupIds)', { groupIds })
        .andWhere('o.is_deleted = :isDeleted', { isDeleted: false })
        .addOrderBy('o.created_at', 'ASC');

      if (currency) {
        qb.andWhere('settlement_currency.unique_id = :currency', { currency });
      }

      qb.groupBy('o.group_id, settlement_currency.code'); // Group by group_id and settlement_currency.code

      // Fetch all relevant settlement currencies for the groups within the date range
      const allRelevantSettlementCurrenciesQuery = this.orderRepository
        .createQueryBuilder('o')
        .leftJoin('o.currency', 'currency')
        .leftJoin('o.settlement_currency', 'settlement_currency')
        .select('settlement_currency.code', 'currency')
        .addSelect('o.group_id', 'groupId') // Select group_id
        .where('o.group_id IN (:...groupIds)', { groupIds })
        .addOrderBy('o.created_at', 'ASC')
        .andWhere('o.ordered_date <= :endDate', { endDate })
        .andWhere('o.is_deleted = :isDeleted', { isDeleted: false })
        .groupBy('o.group_id') // Group by group_id
        .addGroupBy('settlement_currency.code'); // Group by settlement_currency.code

      if (currency) {
        allRelevantSettlementCurrenciesQuery.andWhere('settlement_currency.unique_id = :currency', { currency });
      }

      const allRelevantCurrencies = await allRelevantSettlementCurrenciesQuery.getRawMany();

      // Map to store all unique currencies per group
      const groupCurrencyMap = new Map<string, Set<string>>();
      allRelevantCurrencies.forEach((item) => {
        if (!groupCurrencyMap.has(item.groupId)) {
          groupCurrencyMap.set(item.groupId, new Set<string>());
        }
        groupCurrencyMap.get(item.groupId).add(item.currency);
      });

      const queryResults = await qb.getRawMany();

      // Create a map for quick lookup of aggregated results per group and currency
      // Map<groupId, Map<currencyCode, calculationResult>>
      const resultsMap = new Map<string, Map<string, any>>();
      queryResults.forEach((r) => {
        if (!resultsMap.has(r.groupId)) {
          resultsMap.set(r.groupId, new Map<string, any>());
        }
        resultsMap.get(r.groupId).set(r.currency, r);
      });

      const finalProcessedResults: any[] = [];

      groupIds.forEach((groupId) => {
        const currenciesForGroup = groupCurrencyMap.get(groupId) || new Set<string>();
        currenciesForGroup.forEach((currCode) => {
          if (resultsMap.has(groupId) && resultsMap.get(groupId).has(currCode)) {
            finalProcessedResults.push({ ...resultsMap.get(groupId).get(currCode), groupId });
          } else {
            // No transactions for this currency in this group, return 'all_clear' with default values
            finalProcessedResults.push({
              status: 'all_clear',
              value: 0,
              currency: currCode,
              error: 0,
              processing: 0,
              transferring: 0,
              changes_required: 0,
              groupId: groupId,
            });
          }
        });
      });

      if (purpose === 'own') {
        // This logic needs to be adapted for multiple groups, or removed if 'own' purpose is only for single group
        // For now, returning empty array as it's unclear how 'own' would apply to multiple groups
        return [];
      }
      if (purpose === 'mismatch') {
        return finalProcessedResults.map((obj) => {
          let totalWeOwe = (obj.we_value ? +obj.we_value : 0) + (obj.oweUsFees ? +obj.oweUsFees : 0);
          let totalOweUs = (obj.customer_value ? +obj.customer_value : 0) + (obj.weOweFees ? +obj.weOweFees : 0);
          totalOweUs = +totalOweUs.toFixed(2);
          totalWeOwe = +totalWeOwe.toFixed(2);
          const errorCount = obj.error ? +obj.error : 0;
          const processingCount = obj.processing ? +obj.processing : 0;
          const transferringCount = obj.transferring ? +obj.transferring : 0;
          const changesRequired = obj.changes_required ? +obj.changes_required : 0;

          if (totalWeOwe > totalOweUs) {
            return {
              status: 'owe_us',
              value: +(totalWeOwe - totalOweUs).toFixed(2),
              currency: obj.currency,
              overall_calculated_amount: totalOweUs + totalWeOwe,
              groupId: obj.groupId,
              error: errorCount,
              processing: processingCount,
              transferring: transferringCount,
              changes_required: changesRequired,
            };
          } else if (totalOweUs > totalWeOwe) {
            return {
              status: 'we_owe',
              value: +(totalOweUs - totalWeOwe).toFixed(2),
              currency: obj.currency,
              overall_calculated_amount: totalOweUs + totalWeOwe,
              groupId: obj.groupId,
              error: errorCount,
              processing: processingCount,
              transferring: transferringCount,
              changes_required: changesRequired,
            };
          } else {
            return {
              status: 'all_clear',
              value: 0,
              currency: obj.currency,
              overall_calculated_amount: totalOweUs + totalWeOwe,
              groupId: obj.groupId,
              error: errorCount,
              processing: processingCount,
              transferring: transferringCount,
              changes_required: changesRequired,
            };
          }
        });
      }

      if (purpose === 'notOwn') {
        return finalProcessedResults.map((obj) => {
          const customerValue = obj.customer_value ? +obj.customer_value : 0;
          const weOweFees = obj.weOweFees ? +obj.weOweFees : 0;
          const weValue = obj.we_value ? +obj.we_value : 0;
          const oweUsFees = obj.oweUsFees ? +obj.oweUsFees : 0;
          const errorCount = obj.error ? +obj.error : 0;
          const processingCount = obj.processing ? +obj.processing : 0;
          const transferringCount = obj.transferring ? +obj.transferring : 0;
          const changesRequired = obj.changes_required ? +obj.changes_required : 0;

          let totalWeOwe = weValue + oweUsFees;
          let totalOweUs = customerValue + weOweFees;
          totalOweUs = +totalOweUs.toFixed(2);
          totalWeOwe = +totalWeOwe.toFixed(2);
          if (totalWeOwe > totalOweUs) {
            return {
              status: 'owe_us',
              value: +(totalWeOwe - totalOweUs).toFixed(2),
              currency: obj.currency,
              error: errorCount,
              processing: processingCount,
              transferring: transferringCount,
              changes_required: changesRequired,
              groupId: obj.groupId,
            };
          } else if (totalOweUs > totalWeOwe) {
            return {
              status: 'we_owe',
              value: +(totalOweUs - totalWeOwe).toFixed(2),
              currency: obj.currency,
              error: errorCount,
              processing: processingCount,
              transferring: transferringCount,
              changes_required: changesRequired,
              groupId: obj.groupId,
            };
          } else {
            return {
              status: 'all_clear',
              value: 0,
              currency: obj.currency,
              error: errorCount,
              processing: processingCount,
              transferring: transferringCount,
              changes_required: changesRequired,
              groupId: obj.groupId,
            };
          }
        });
      }

      return [];
    } catch (error) {
      this.logger.error('Error from calculateAmountForGroups', error);
      return [];
    }
  }

  public async calculateTotalTransferredAmountForGroup(
    date: string,
    groupId: string,
    currency?: string,
  ): Promise<any[]> {
    try {
      const filterDate = date ? moment(date, 'DD-MM-YYYY') : moment();
      const endDate = filterDate.clone().endOf('day').toDate();

      const qb = this.orderTransactionRepository
        .createQueryBuilder('order_transaction')
        .leftJoin(
          'currency',
          'sell_currency_entity',
          'sell_currency_entity.code = order_transaction.sell_currency.code',
        )
        .leftJoin(
          'currency',
          'settlement_currency_entity',
          'settlement_currency_entity.code = order_transaction.settlement_currency.code',
        )
        .leftJoin(
          'currency_pair',
          'cp',
          'cp.buy_currency_id = settlement_currency_entity.unique_id AND cp.sell_currency_id = sell_currency_entity.unique_id',
        )
        .select('order_transaction.settlement_currency.code', 'currency')
        .addSelect(
          `
        SUM(
          CASE
            WHEN order_transaction.sell_currency.code != order_transaction.settlement_currency.code
            THEN
              CASE
                WHEN cp.calculation_type = 'multiply' THEN order_transaction.sell_value * order_transaction.rate
                WHEN cp.calculation_type = 'divide' THEN order_transaction.sell_value / order_transaction.rate
                ELSE order_transaction.sell_value
              END
            ELSE order_transaction.sell_value
          END
          + order_transaction.fee
        )`,
          'value',
        )
        .where('order_transaction.group_id = :groupId', { groupId })
        .andWhere('order_transaction.is_deleted = :isDeleted', { isDeleted: false });

      if (date) {
        qb.andWhere('order_transaction.transferred_date <= :endDate', { endDate });
      }

      if (currency) {
        qb.andWhere('order_transaction.settlement_currency.code = :currency', { currency });
      }

      qb.groupBy('order_transaction.settlement_currency.code');

      const rawResults = await qb.getRawMany();

      return rawResults.map((row) => ({
        currency: row.currency,
        value: parseFloat((row.value || 0).toFixed(2)),
      }));
    } catch (error) {
      this.logger.error('Error from _calculateTotalTransferredAmountForGroup in OrderTransactionService', error);
      return [];
    }
  }

  async getGroupCurrencySummaryWithChanges(date: string, groupId: string, currency?: string): Promise<any> {
    try {
      const inputDate = moment(date, 'DD-MM-YYYY');

      const whereCondition: any = { group_id: groupId };
      const startDate = inputDate.clone().startOf('day').toDate();
      const endDate = inputDate.clone().endOf('day').toDate();
      whereCondition.created_at = Between(startDate, endDate);

      const orders = await this.orderRepository.find({
        where: whereCondition,
        relations: ['transactions'],
      });

      if (orders.length === 0) {
        return currency ? null : [];
      }

      const currencyCodes = new Set<string>();
      orders.forEach((order) => {
        currencyCodes.add(order.settlement_currency.code);
        order.transactions.forEach((t) => {
          currencyCodes.add(t.sell_currency.code);
          currencyCodes.add(t.settlement_currency.code);
        });
      });

      const currencyEntities = await this.currencyRepository.find({
        where: { code: In(Array.from(currencyCodes)) },
      });
      const currencyMap = new Map(currencyEntities.map((c) => [c.code, c]));

      const pairQueries = [];
      orders.forEach((order) => {
        order.transactions.forEach((t) => {
          if (t.sell_currency?.code !== t.settlement_currency?.code) {
            const sellCurrency = currencyMap.get(t.sell_currency.code);
            const settlementCurrency = currencyMap.get(t.settlement_currency.code);
            if (sellCurrency && settlementCurrency) {
              pairQueries.push({
                buy_currency_id: settlementCurrency.unique_id,
                sell_currency_id: sellCurrency.unique_id,
              });
            }
          }
        });
      });

      const currencyPairs =
        pairQueries.length > 0 ? await this.currencyPairRepository.find({ where: pairQueries }) : [];
      const currencyPairMap = new Map<string, any>();
      currencyPairs.forEach((cp) => {
        const key1 = `${cp.buy_currency_id}_${cp.sell_currency_id}`;
        currencyPairMap.set(key1, cp);
      });

      const currencyGroups = {};
      const changesRequiredCount = {};

      for (const order of orders) {
        if (order.status === 'processing' || order.status === 'error') {
          if (!changesRequiredCount[order.settlement_currency.code]) {
            changesRequiredCount[order.settlement_currency.code] = 0;
          }
          changesRequiredCount[order.settlement_currency.code]++;
        }
        if (!currencyGroups[order.settlement_currency.code]) {
          currencyGroups[order.settlement_currency.code] = { weOwe: 0, oweUs: 0 };
        }

        if (order.trading === 'buy') {
          currencyGroups[order.settlement_currency.code].oweUs += +order.amount;
        } else if (order.trading === 'sell') {
          currencyGroups[order.settlement_currency.code].weOwe += +order.amount;
        }

        for (const transaction of order.transactions) {
          let transactionValue = +transaction.sell_value;
          if (transaction.sell_currency.code !== transaction.settlement_currency.code) {
            const sellCurrency = currencyMap.get(transaction.sell_currency.code);
            const settlementCurrency = currencyMap.get(transaction.settlement_currency.code);

            if (sellCurrency && settlementCurrency) {
              const key1 = `${sellCurrency.unique_id}_${settlementCurrency.unique_id}`;
              const key2 = `${settlementCurrency.unique_id}_${sellCurrency.unique_id}`;
              const currencyPair = currencyPairMap.get(key1) || currencyPairMap.get(key2);

              if (currencyPair) {
                if (currencyPair.calculation_type === 'multiply') {
                  transactionValue = +transaction.sell_value * +transaction.rate;
                } else if (currencyPair.calculation_type === 'divide') {
                  transactionValue = +transaction.sell_value / +transaction.rate;
                }
              }
            }
          }

          if (!currencyGroups[transaction.settlement_currency.code]) {
            currencyGroups[transaction.settlement_currency.code] = { weOwe: 0, oweUs: 0 };
          }

          if (transaction.transfer_by === 'customer') {
            currencyGroups[transaction.settlement_currency.code].weOwe += transactionValue;
          } else if (transaction.transfer_by === 'we') {
            currencyGroups[transaction.settlement_currency.code].oweUs += transactionValue;
          }
        }
      }

      const targetCurrencies = currency ? [currency] : Object.keys(currencyGroups);

      const results = targetCurrencies
        .map((curr) => {
          if (!currencyGroups[curr]) return null;

          const { weOwe, oweUs } = currencyGroups[curr];
          const changes_required = changesRequiredCount[curr] || 0;
          if (weOwe > oweUs) {
            return {
              status: 'we_owe',
              value: parseFloat((weOwe - oweUs).toFixed(2)),
              currency: curr,
              changes_required,
            };
          } else if (oweUs > weOwe) {
            return {
              status: 'owe_us',
              value: parseFloat((oweUs - weOwe).toFixed(2)),
              currency: curr,
              changes_required,
            };
          } else if (curr) {
            return { status: 'all_clear', value: 0, currency: curr, changes_required };
          }
        })
        .filter(Boolean);

      if (currency) {
        return results.length > 0 ? results[0] : null;
      }
      return results;
    } catch (error) {
      this.logger.error('Error from getGroupCurrencySummary', error);
      return currency ? null : [];
    }
  }

  async getSellCurrencies(groupId: string, settlementCurrency: string): Promise<string[]> {
    try {
      const results = await this.orderTransactionRepository
        .createQueryBuilder('transaction')
        .leftJoin('transaction.sell_currency', 'sell_currency')
        .leftJoin('transaction.settlement_currency', 'settlement_currency')
        .select('DISTINCT sell_currency.code', 'sell_currency')
        .where('transaction.group_id = :groupId', { groupId })
        .andWhere('settlement_currency.code = :settlementCurrency', { settlementCurrency })
        .andWhere('transaction.is_deleted = :isDeleted', { isDeleted: false })
        .getRawMany();

      return results.map((r) => r.sell_currency);
    } catch (error) {
      this.logger.error('Error from getSellCurrencies', error);
      return [];
    }
  }

  async update(updateOrderTransactionDto: UpdateOrderTransactionDto, user: LoggedAdmin): Promise<any> {
    try {
      const { unique_id, order_id } = updateOrderTransactionDto;

      const orderTransactionData = await this.orderTransactionRepository.findOne({
        where: { unique_id: unique_id, is_deleted: false },
        relations: ['account', 'sell_currency', 'settlement_currency'],
      });

      if (!orderTransactionData) {
        return sendFailure('Transaction not found', HttpStatus.NOT_FOUND);
      }
      delete updateOrderTransactionDto?.transferred_date;

      const order = await this.orderRepository.findOne({
        where: { unique_id: order_id },
      });

      if (!order) {
        return sendFailure('Order not found', HttpStatus.NOT_FOUND);
      }

      const updateData: any = {};

      // Compare & update only changed fields
      if (orderTransactionData.transfer_by !== updateOrderTransactionDto.transfer_by) {
        updateData.account_id = updateOrderTransactionDto.account_id;
      }

      if (orderTransactionData.trading !== updateOrderTransactionDto.trading) {
        updateData.trading = updateOrderTransactionDto.trading;
      }

      if (orderTransactionData.sell_currency.code !== updateOrderTransactionDto.sell_currency) {
        const sellCurrency = await this.currencyRepository.findOne({
          where: { code: updateOrderTransactionDto.sell_currency },
        });
        if (!sellCurrency) return sendFailure(Messages.CurrencyNotExist, HttpStatus.NOT_FOUND);
        updateData.sell_currency_id = sellCurrency.unique_id;
      }

      if (orderTransactionData.settlement_currency.code !== updateOrderTransactionDto.settlement_currency) {
        const settlementCurrency = await this.currencyRepository.findOne({
          where: { code: updateOrderTransactionDto.settlement_currency },
        });
        if (!settlementCurrency) return sendFailure(Messages.CurrencyNotExist, HttpStatus.NOT_FOUND);
        updateData.settlement_currency_id = settlementCurrency.unique_id;
      }

      if (orderTransactionData.sell_value !== updateOrderTransactionDto?.sell_value) {
        updateData.sell_value = updateOrderTransactionDto.sell_value;
      }

      updateData.fee = updateOrderTransactionDto?.fee ? updateOrderTransactionDto?.fee : null;

      updateData.rate = updateOrderTransactionDto?.rate !== 0 ? updateOrderTransactionDto?.rate : null;

      if (orderTransactionData.remarks !== updateOrderTransactionDto?.remarks) {
        updateData.remarks = updateOrderTransactionDto.remarks;
      }

      // If no change, return success without update
      if (Object.keys(updateData).length === 0) {
        return sendSuccess('No changes detected', orderTransactionData);
      }
      const orderCheck = await this.orderCalculationCheck(
        order?.unique_id,
        updateOrderTransactionDto?.unique_id,
        updateOrderTransactionDto?.sell_value,
      );
      if (orderCheck?.lastTransaction && +orderCheck?.feePaid !== +order?.fee && !updateOrderTransactionDto?.fee) {
        return sendFailure('Fee is required for this transaction.', HttpStatus.OK);
      }
      const calculatedFee = +orderCheck?.feePaid + +updateOrderTransactionDto?.fee;

      if (updateOrderTransactionDto?.fee && orderCheck?.lastTransaction && calculatedFee > +order?.fee) {
        return sendFailure('The fee amount exceeds the allowed fee for this order.', HttpStatus.OK);
      }

      if (updateOrderTransactionDto?.fee && orderCheck?.lastTransaction && calculatedFee !== +order?.fee) {
        return sendFailure('The fee amount does not match the required fee for this order.', HttpStatus.OK);
      }

      // Update DB
      await this.orderTransactionRepository.update({ unique_id }, updateData);

      await this.orderRepository.update(
        { unique_id: order_id },
        { updated_by: { id: user.unique_id, name: user.user_name } },
      );
      // Recalculate order
      await this.orderService.recalculateOrderStatus(orderTransactionData?.order_id);

      return sendSuccess('Order transaction updated successfully');
    } catch (error) {
      this.logger.error('Error updating order', error);
      return commonCatch(error);
    }
  }

  async getFullPayDetails(orderId: string, loggedUser: LoggedAdmin): Promise<any> {
    try {
      const order = await this.orderRepository
        .createQueryBuilder('order')
        .leftJoinAndSelect('order.customer_group', 'customer_group')
        .leftJoinAndSelect('order.currency', 'currency')
        .leftJoinAndSelect('order.settlement_currency', 'settlement_currency')
        .leftJoinAndSelect('order.transactions', 'transactions', 'transactions.is_deleted = :isDeleted', {
          isDeleted: false,
        })
        .leftJoinAndSelect('transactions.sell_currency', 'transaction_sell_currency')
        .leftJoinAndSelect('transactions.settlement_currency', 'transaction_settlement_currency')
        .where('order.unique_id = :orderId', { orderId })
        .andWhere('order.is_deleted = false')
        .getOne();

      if (!order) {
        return sendFailure(Messages.OrderNotFound, HttpStatus.OK);
      }

      if (order.status !== 'processing' && order.status !== 'transferring') {
        return sendFailure('Full pay not allowed for this order ', HttpStatus.OK);
      }

      // Calculate what has already been paid
      const totalPrincipalPaid = order.transactions.reduce((sum, transaction) => sum + +transaction.sell_value, 0);
      const totalFeePaid = order.transactions.reduce((sum, transaction) => sum + (+transaction.fee || 0), 0);

      // Calculate what is remaining
      const remainingPrincipal = +order.amount - totalPrincipalPaid;
      const remainingFee = (+order.fee || 0) - totalFeePaid;

      if (remainingPrincipal <= 0 && remainingFee <= 0) {
        return sendFailure('Order is already fully paid.', HttpStatus.OK);
      }

      let weTransactionDto;
      let customerTransactionDto;
      let rateForConversion;
      if (order.currency && order.settlement_currency) {
        weTransactionDto = {
          sell_value: remainingPrincipal > 0 ? remainingPrincipal : 0, // Ensure sell_value is not negative
          sell_currency: order.currency.code,
        };
        customerTransactionDto = {
          sell_value: remainingPrincipal > 0 ? remainingPrincipal : 0, // Ensure sell_value is not negative
          sell_currency: order.currency.code,
        };
      } else {
        rateForConversion = order.rate;
      }
      let settlement_date = settlementDate(moment(order?.ordered_date)?.format('DD-MM-YYYY'));
      const selectedDate = moment(order?.ordered_date, 'DD-MM-YYYY');
      const currentTime = moment();

      const finalDateTime = selectedDate
        .hour(currentTime.hour())
        .minute(currentTime.minute())
        .second(currentTime.second())
        .millisecond(currentTime.millisecond())
        .toDate();
      const baseTransactionDetails = {
        order_id: order?.unique_id,
        group_id: order?.group_id,
        trading: order?.trading?.toLowerCase() === 'buy' ? 'sell' : order?.trading,
        settlement_currency_id: order?.settlement_currency_id,
        sell_currency_id: order?.currency_id,
        rate: order?.rate,
        fee: remainingFee > 0 ? remainingFee : 0, // Use remaining fee
        account_id: order?.account_id,
        transferred_date: finalDateTime,
        settlement_date: settlement_date,
        created_by: { id: loggedUser?.unique_id, name: loggedUser?.user_name },
        updated_by: { id: loggedUser?.unique_id, name: loggedUser?.user_name },
      };

      const today = moment(order?.ordered_date || moment().startOf('day'));
      const format = today.format('DDMMYYYY');
      const prefix = `${order.customer_group.group_id}/${format}/${order.settlement_currency.code}-TF`;

      const lastTransaction = await this.orderTransactionRepository.findOne({
        where: { transaction_id: Like(`${prefix}%`) },
        order: { transaction_id: 'DESC' },
      });

      let lastId = 0;
      if (lastTransaction) {
        lastId = parseInt(lastTransaction.transaction_id.split('-').pop().replace('TF', ''), 10);
      }
      let partyType: string;
      if (order.order_by === 'we') {
        partyType = order?.trading === 'transfer' || order?.trading === 'adjustment' ? order?.order_by : 'customer';
        const customerTransactionId = `${prefix}${(lastId + 1).toString().padStart(3, '0')}`;
        const customerTransaction = this.orderTransactionRepository.create({
          ...baseTransactionDetails,
          ...customerTransactionDto,
          transfer_by: partyType,
          transaction_id: customerTransactionId,
        });
        await this.orderTransactionRepository.save(customerTransaction);
      } else if (order.order_by === 'customer') {
        partyType = order?.trading === 'transfer' || order?.trading === 'adjustment' ? order?.order_by : 'we';

        const weTransactionId = `${prefix}${(lastId + 1).toString().padStart(3, '0')}`;
        const weTransaction = this.orderTransactionRepository.create({
          ...baseTransactionDetails,
          ...weTransactionDto,
          transfer_by: partyType,
          transaction_id: weTransactionId,
        });
        await this.orderTransactionRepository.save(weTransaction);
      }

      await this.orderService.recalculateOrderStatus(order.unique_id);

      return sendSuccess('Transaction created successfully', null);
    } catch (error) {
      this.logger.error('Error processing full pay', error);
      return commonCatch(error);
    }
  }

  async delete(id: string): Promise<any> {
    try {
      const transaction = await this.orderTransactionRepository.findOne({ where: { unique_id: id } });
      if (!transaction) {
        return sendFailure(Messages.TransactionNotFound, HttpStatus.NOT_FOUND);
      }

      await this.orderTransactionRepository.update({ unique_id: id }, { is_deleted: true });
      await this.orderService.recalculateOrderStatus(transaction.order_id);
      return sendSuccess(Messages.TransactionDeleted, null);
    } catch (error) {
      this.logger.error('Error from delete transaction', error);
      return commonCatch(error);
    }
  }

  async getRemainingBalance(amountCheckDto: AmountCheckDto): Promise<any> {
    try {
      const { order_id, transaction_id } = amountCheckDto;

      // Fetch order and related transactions
      const order = await this.orderRepository
        .createQueryBuilder('order')
        .leftJoinAndSelect('order.transactions', 'transactions', 'transactions.is_deleted = :isDeleted', {
          isDeleted: false,
        })
        .where('order.unique_id = :order_id', { order_id })
        .andWhere('order.is_deleted = false')
        .getOne();

      if (!order) return sendFailure(Messages.OrderNotFound, HttpStatus.NOT_FOUND);

      // Exclude current transaction if provided
      const transactions = transaction_id
        ? order.transactions.filter((t) => t.unique_id !== transaction_id)
        : order.transactions;

      // Calculate already paid values
      const totalPrincipalPaid = transactions.reduce((sum, t) => sum + +t.sell_value, 0);
      const totalFeePaid = transactions.reduce((sum, t) => sum + (+t.fee || 0), 0);

      const result = {
        order_amount: +order?.amount,
        order_fee: +order?.fee,
        transaction_amount: totalPrincipalPaid,
        transaction_fee: totalFeePaid,
      };

      return sendSuccess('Remaining balance retrieved successfully', result);
    } catch (error) {
      this.logger.error('Error getting remaining balance', error);
      return commonCatch(error);
    }
  }
  async getTransactionDetails(id: string): Promise<any> {
    try {
      const transaction = await this.orderTransactionRepository
        .createQueryBuilder('transaction')
        .leftJoin('transaction.account', 'transaction_account')
        .leftJoin('transaction.sell_currency', 'sell_currency')
        .leftJoin('transaction.settlement_currency', 'settlement_currency')
        .leftJoin(
          'currency_pair',
          'cp',
          'cp.sell_currency_id = transaction.sell_currency_id AND cp.buy_currency_id = transaction.settlement_currency_id',
        )
        .where('transaction.unique_id = :id', { id })
        .andWhere('transaction.is_deleted = :isDeleted', { isDeleted: false })
        .select([
          'transaction.unique_id as unique_id',
          'transaction.transaction_id as transaction_id',
          'transaction.order_id as order_id',
          'transaction.group_id as group_id',
          'transaction.transfer_by as transfer_by',
          'transaction.sell_value as sell_value',
          'sell_currency.code as sell_currency',
          'settlement_currency.code as settlement_currency',
          'transaction.rate as rate',
          'transaction.fee as fee',
          'transaction.trading as trading',
          'transaction.remarks as remarks',
          'transaction.updated_at as updated_at',
          'transaction.transferred_date as transferred_date',
          'transaction.created_at as created_at',
          'transaction_account.unique_id as account_unique_id',
          'transaction_account.name as account_name',
          `ROUND(
            CASE
              WHEN sell_currency.code = settlement_currency.code THEN transaction.sell_value
              ELSE
                CASE
                  WHEN cp.calculation_type = 'multiply' THEN transaction.sell_value * transaction.rate
                  WHEN cp.calculation_type = 'divide' THEN transaction.sell_value / transaction.rate
                  ELSE transaction.sell_value
                END
            END, 2
          ) as calculated_amount`,
        ])
        .getRawOne();

      if (!transaction) {
        return sendFailure(Messages.TransactionNotFound, HttpStatus.NOT_FOUND);
      }

      const formattedTransaction = {
        ...transaction,
        account: {
          unique_id: transaction.account_unique_id,
          name: transaction.account_name,
        },
      };

      return sendSuccess(Messages.TransactionDetailsFetched, formattedTransaction);
    } catch (error) {
      this.logger.error(`Error from getTransactionDetails with id: ${id}`);
      this.logger.error(error);
      return commonCatch(error);
    }
  }

  async orderCalculationCheck(order_id, transaction_id?: string, amount?: number) {
    const orderCheck = await this.orderRepository
      .createQueryBuilder('order')
      .leftJoinAndSelect('order.transactions', 'transactions', 'transactions.is_deleted = :isDeleted', {
        isDeleted: false,
      })
      .where('order.unique_id = :order_id', { order_id })
      .andWhere('order.is_deleted = false')
      .getOne();

    // Exclude current transaction if provided
    const transactions = transaction_id
      ? orderCheck.transactions.filter((t) => t.unique_id !== transaction_id)
      : orderCheck.transactions;

    // Calculate already paid values
    const totalPrincipalPaid = transactions.reduce((sum, t) => sum + +t.sell_value, 0);
    const totalFeePaid = transactions.reduce((sum, t) => sum + (+t.fee || 0), 0);
    let lastTransaction = +totalPrincipalPaid + +amount >= +orderCheck?.amount ? true : false;
    return {
      lastTransaction: lastTransaction,
      feePaid: totalFeePaid,
    };
  }

  async listBasedOnGroupCurrency(listDto: ListOrderGroupCurrencyDto): Promise<any> {
    try {
      let startDate, endDate;
      const tz = await this.appConfig.applicationDefaults.timezone;
      let day: string;
      if (listDto?.day_filter) {
        const settlement_date = settlementDate(listDto.day_filter);

        const selectedDate = moment.tz(settlement_date, 'DD-MM-YYYY', tz);
        if (selectedDate.isSame(moment.tz(tz), 'day')) {
          day = 'today';
        } else {
          day = 'yesterday';
        }
        // Start: selected day at 6:00 AM
        startDate = selectedDate.clone().hour(6).minute(0).second(0).millisecond(0).toDate();

        // End: next day at 5:30 AM
        endDate = selectedDate.clone().add(1, 'day').hour(5).minute(30).second(0).millisecond(0).toDate();
      }

      const result = await this.calculateAmountForOrderGroupByDateRange(
        listDto?.day_filter,
        listDto?.group_id,
        listDto?.currency_id,
      );
      const finalResult = {
        grouped_currency: result,
        day: day,
        start_date: convertUTCToSingapore(startDate),
        end_date: convertUTCToSingapore(endDate),
      };
      return sendSuccess('Group with currency calculation fetched successfully', finalResult);
    } catch (error) {
      this.logger.error('Error from listBasedOnGroupCurrency', error);
      return commonCatch(error);
    }
  }

  async calculateAmountForOrderGroupByDateRange(
    settlement_date: string,
    groupId?: string | string[],
    currencyId?: string | string[],
  ): Promise<any[]> {
    try {
      const query = this.orderTransactionRepository
        .createQueryBuilder('order_transaction')
        .leftJoin('customer_groups', 'grp', 'grp.unique_id = order_transaction.group_id')
        .leftJoin('order_transaction.sell_currency', 'sell_currency')
        .leftJoin('order_transaction.settlement_currency', 'settlement_currency')
        // ❌ removed currency_pair join completely

        .select('grp.unique_id', 'group_unique_id')
        .addSelect('grp.group_id', 'group_code')
        .addSelect('grp.name', 'group_name')

        /* use SELL CURRENCY instead of SETTLEMENT */
        .addSelect('sell_currency.code', 'sell_currency_code')
        .addSelect('sell_currency.unique_id', 'sell_currency_id')

        /* ======================== AMOUNTS ======================== */

        // transfer_by = we → oweUs
        .addSelect(
          `
        SUM(
          CASE WHEN order_transaction.transfer_by = 'we'
            THEN order_transaction.sell_value
            ELSE 0
          END
        )
        `,
          'oweUs',
        )
        // transfer_by = customer → weOwe
        .addSelect(
          `
        SUM(
          CASE WHEN order_transaction.transfer_by = 'customer'
            THEN order_transaction.sell_value
            ELSE 0
          END
        )
        `,
          'weOwe',
        )

        // fees separately
        .addSelect(
          `SUM(CASE WHEN order_transaction.transfer_by = 'we' THEN order_transaction.fee ELSE 0 END)`,
          'oweUsFees',
        )
        .addSelect(
          `SUM(CASE WHEN order_transaction.transfer_by = 'customer' THEN order_transaction.fee ELSE 0 END)`,
          'weOweFees',
        )

        /* ======================== RAW TOTALS (unchanged) ======================== */

        .addSelect(`SUM(order_transaction.sell_value)`, 'beforeConversionSellValue')
        .addSelect(`SUM(order_transaction.fee)`, 'beforeConversionFee')
        .addSelect(`SUM(order_transaction.sell_value + order_transaction.fee)`, 'beforeConversionTotal')

        .andWhere('order_transaction.is_deleted = :isDeleted', { isDeleted: false })
        .andWhere('order_transaction.settlement_date = :settlement_date', { settlement_date })
        .andWhere('order_transaction.trading != :tradeType', { tradeType: 'adjustment' });

      /* ======================== GROUP FILTER ======================== */
      if (groupId) {
        if (Array.isArray(groupId)) {
          query.andWhere('order_transaction.group_id IN (:...groupIds)', { groupIds: groupId });
        } else {
          query.andWhere('order_transaction.group_id = :groupId', { groupId });
        }
      }

      /* ======================== CURRENCY FILTER (USE SELL CURRENCY) ======================== */
      if (currencyId) {
        if (Array.isArray(currencyId)) {
          query.andWhere('sell_currency.unique_id IN (:...currencyIds)', { currencyIds: currencyId });
        } else {
          query.andWhere('sell_currency.unique_id = :currencyId', { currencyId });
        }
      }

      /* ======================== GROUPING (USE SELL CURRENCY) ======================== */
      query.groupBy('grp.unique_id').addGroupBy('sell_currency.code');

      const rawResults = await query.getRawMany();
      const groupedResult: Record<string, any> = {};

      rawResults.forEach((row) => {
        const groupKey = row.group_unique_id;

        if (!groupedResult[groupKey]) {
          groupedResult[groupKey] = {
            group_unique_id: row.group_unique_id,
            group_code: row.group_code,
            group_name: row.group_name,
            currencies: [],
          };
        }

        const weOwe = +row.weOwe;
        const oweUs = +row.oweUs;
        const weOweFees = +row.weOweFees;
        const oweUsFees = +row.oweUsFees;

        /* ======================== CALCULATIONS ======================== */
        const totalWeOwe = +(weOwe + weOweFees).toFixed(2);
        const totalOweUs = +(oweUs + oweUsFees).toFixed(2);
        const grandTotal = +(totalWeOwe + totalOweUs).toFixed(2);

        const beforeConversionSellValue = +row.beforeConversionSellValue;
        const beforeConversionFee = +row.beforeConversionFee;
        const beforeConversionTotal = +row.beforeConversionTotal;

        groupedResult[groupKey].currencies.push({
          settlement_currency_id: row.sell_currency_id,
          settlement_currency_code: row.sell_currency_code,

          weOwe: +weOwe.toFixed(2),
          oweUs: +oweUs.toFixed(2),
          weOweFees: +weOweFees.toFixed(2),
          oweUsFees: +oweUsFees.toFixed(2),

          totalWeOwe,
          totalOweUs,
          grandTotal,

          sell_value: +(weOwe + oweUs).toFixed(2),
          fee: +(weOweFees + oweUsFees).toFixed(2),

          beforeConversionSellValue: +beforeConversionSellValue.toFixed(2),
          beforeConversionFee: +beforeConversionFee.toFixed(2),
          beforeConversionTotal: +beforeConversionTotal.toFixed(2),
        });
      });

      return Object.values(groupedResult);
    } catch (error) {
      this.logger.error('Error from calculateAmountForOrderGroupByDateRange', error);
      return [];
    }
  }

  async updateSettlementDate(): Promise<any> {
    try {
      const transactions = await this.orderTransactionRepository.find({
        where: { is_deleted: false },
      });

      const updatedTransactions = [];
      for (const transaction of transactions) {
        if (transaction.transferred_date) {
          const settlement_date = settlementDateUpdate(transaction.transferred_date);
          if (transaction.settlement_date !== settlement_date) {
            transaction.settlement_date = settlement_date;
            updatedTransactions.push(this.orderTransactionRepository.save(transaction));
          }
        }
      }
      await Promise.all(updatedTransactions);
      return sendSuccess(Messages.TransactionsUpdated, {
        updated_count: updatedTransactions.length,
      });
    } catch (error) {
      this.logger.error('Error from updateSettlementDate in OrderTransactionService', error);
      return commonCatch(error);
    }
  }
}
