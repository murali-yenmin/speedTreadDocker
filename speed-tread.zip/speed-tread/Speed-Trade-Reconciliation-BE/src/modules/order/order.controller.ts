import { Controller, Get, Post, Body, Put, Param, UseGuards, Delete, Query } from '@nestjs/common';
import { OrderService } from './order.service';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderDto } from './dto/update-order.dto';
import { AdminGuard } from 'src/common/guards/admin.guard';
import { GetLoggedUser } from 'src/common/decorators/logged-admin.decorator';
import { LoggedAdmin } from 'src/common/interfaces/logged-user.interface';
import { FilterDto } from 'src/common/dtos/filter.dto';
import { CumulativeCurrencyDto } from './dto/cumulative-currency.dto';
import { OrderStatus } from 'src/constants/app.constant';
import { sendSuccess } from 'src/utils/response.utils';
import { DateStatusDto } from './dto/date-status.dto';
import { DeleteMultiOrderDto } from './dto/delete-multi-order.dto';

@UseGuards(AdminGuard)
@Controller('order')
export class OrderController {
  constructor(private readonly orderService: OrderService) {}

  @Get('status')
  getOrderStatus(): { message: string; data: any } {
    return sendSuccess("Order's status has been fetched successfully", [
      OrderStatus.Processing,
      OrderStatus.Transferring,
      OrderStatus.Error,
      OrderStatus.Completed,
    ]);
  }

  @Post('date-status')
  getDateStatus(@Body() query: DateStatusDto) {
    return this.orderService.getDateStatus(query);
  }

  @Post()
  create(@Body() createOrderDto: CreateOrderDto, @GetLoggedUser() user: LoggedAdmin) {
    return this.orderService.create(createOrderDto, user);
  }

  @Post('get-all')
  getAll(@Body() filter: FilterDto) {
    return this.orderService.getAll(filter, 'order');
  }

  @Post('get-all-report')
  getAllReport(@Body() filter: FilterDto) {
    return this.orderService.getAll(filter, 'report');
  }

  @Post('cumulative-currencies')
  getCumulativeCurrencies(@Body() dto: CumulativeCurrencyDto) {
    return this.orderService.getCumulativeCurrencies(dto);
  }

  @Put()
  update(@Body() updateOrderDto: UpdateOrderDto, @GetLoggedUser() user: LoggedAdmin) {
    return this.orderService.update(updateOrderDto, user);
  }

  @Post('/multi')
  deleteMulti(@Body() deleteMultiOrderDto: DeleteMultiOrderDto) {
    return this.orderService.deleteMulti(deleteMultiOrderDto.ids);
  }

  @Delete(':id')
  delete(@Param('id') id: string) {
    return this.orderService.delete(id);
  }

  @Get('details/:id')
  getOrderDetails(@Param('id') id: string) {
    return this.orderService.getOrderDetails(id);
  }
}
