import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Order } from './entities/order.entity';
import { OrderTransaction } from './entities/order-transaction.entity';
import { OrderController } from './order.controller';
import { OrderService } from './order.service';
import { OrderTransactionController } from './order-transaction.controller';
import { OrderTransactionService } from './order-transaction.service';
import { ManagementUsersModule } from '../management-users/management-users.module';
import { AccountsModule } from '../accounts/accounts.module';
import { CustomerGroup } from '../customer-group/entity/customer-group.entity';
import { Currency } from '../currency/entity/currency.entity';
import { CurrencyPair } from '../currency-pair/entities/currency-pair.entity';
import { Account } from '../accounts/entities/account.entity';
import { CurrencyPairModule } from '../currency-pair/currency-pair.module';
import { CurrencyOrder } from '../currency-order/entities/currency-order.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Order, OrderTransaction, CustomerGroup, Currency, CurrencyPair, Account, CurrencyOrder]),
    ManagementUsersModule,
    AccountsModule,
    CurrencyPairModule,
  ],
  controllers: [OrderController, OrderTransactionController],
  providers: [OrderService, OrderTransactionService],
  exports: [OrderService, OrderTransactionService],
})
export class OrderModule {}
