import { Injectable, Logger, HttpStatus, Inject, forwardRef } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Condition, Repository, Like, Not, In } from 'typeorm';
import { Order } from './entities/order.entity';
import { OrderTransaction } from './entities/order-transaction.entity';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderDto } from './dto/update-order.dto';
import { commonCatch, sendSuccess, sendFailure } from 'src/utils/response.utils';
import { LoggedAdmin } from 'src/common/interfaces/logged-user.interface';
import moment from '../../utils/moment';
import { CustomerGroup } from '../customer-group/entity/customer-group.entity';
import { Currency } from '../currency/entity/currency.entity';
import { CurrencyPair } from '../currency-pair/entities/currency-pair.entity';
import { CurrencyPairService } from '../currency-pair/currency-pair.service';
import { Messages } from 'src/message-constants/message.constants';
import * as utils from 'src/utils';
import { FilterDto } from 'src/common/dtos/filter.dto';
import { OrderTransactionService } from './order-transaction.service';
import { AccountsService } from '../accounts/accounts.service';
import { Account } from '../accounts/entities/account.entity';
import { OrderStatus, Status } from 'src/constants/app.constant';
import { CurrencyOrder } from '../currency-order/entities/currency-order.entity';
import { DateStatusDto } from './dto/date-status.dto';

@Injectable()
export class OrderService {
  private readonly logger = new Logger(OrderService.name);

  constructor(
    @InjectRepository(Order)
    private readonly orderRepository: Repository<Order>,
    @InjectRepository(CustomerGroup)
    private readonly customerGroupRepository: Repository<CustomerGroup>,
    @InjectRepository(Currency)
    private readonly currencyRepository: Repository<Currency>,
    @InjectRepository(CurrencyPair)
    private readonly currencyPairRepository: Repository<CurrencyPair>,
    @Inject(forwardRef(() => OrderTransactionService))
    private readonly orderTransactionService: OrderTransactionService,
    @InjectRepository(OrderTransaction)
    private readonly orderTransactionRepository: Repository<OrderTransaction>,
    @InjectRepository(Account)
    private readonly accountRepository: Repository<Account>,
    private readonly accountsService: AccountsService,
    private readonly currencyPairService: CurrencyPairService,
    @InjectRepository(CurrencyOrder)
    private readonly currencyOrderRepository: Repository<CurrencyOrder>,
  ) {}

  async getDateStatus(query: DateStatusDto): Promise<any> {
    try {
      const { group_id, settlement_currency } = query;

      const thirtyDaysAgo = moment().subtract(30, 'days').startOf('day').toDate();
      const today = moment().endOf('day').toDate();

      const results = await this.orderRepository
        .createQueryBuilder('order')
        .leftJoin('order.settlement_currency', 'settlement_currency')
        .select("DATE_FORMAT(order.ordered_date, '%d-%m-%Y')", 'date')
        .where('order.group_id = :groupId', { groupId: group_id })
        .andWhere('order.is_deleted = :status', { status: false })
        .andWhere('settlement_currency.code = :settlementCurrency', { settlementCurrency: settlement_currency })
        .andWhere('order.status IN (:...statuses)', {
          statuses: [OrderStatus.Processing, OrderStatus.Transferring, OrderStatus.Error],
        })
        .andWhere('order.ordered_date BETWEEN :thirtyDaysAgo AND :today', {
          thirtyDaysAgo,
          today,
        })
        .groupBy('date')
        .orderBy('date', 'ASC')
        .getRawMany();

      const dates = results.map((r) => r.date);
      return sendSuccess('Date status fetched successfully', dates);
    } catch (error) {
      this.logger.error('Error fetching date status', error);
      return commonCatch(error);
    }
  }
  async create(createOrderDto: CreateOrderDto, user: LoggedAdmin): Promise<any> {
    try {
      const createdOrders = [];

      for (const orderData of createOrderDto.data) {
        const group = await this.customerGroupRepository.findOne({
          where: { unique_id: orderData.group_id },
        });
        if (!group) {
          return sendFailure(Messages.CustomerGroupNotFound, HttpStatus.OK);
        }

        let account_id = null;
        if (orderData.account_id) {
          const account = await this.accountsService.resolveAccountId(orderData.account_id);
          account_id = account.unique_id;
        }

        const currency = await this.currencyRepository.findOne({ where: { code: orderData.currency } });
        const settlement_currency = await this.currencyRepository.findOne({
          where: { code: orderData.settlement_currency },
        });

        if (!currency || !settlement_currency) {
          return sendFailure(Messages.CurrencyNotExist, HttpStatus.NOT_FOUND);
        }

        if (orderData.currency !== orderData.settlement_currency) {
          let currencyPair = await this.currencyPairRepository.findOne({
            where: {
              buy_currency_id: currency.unique_id,
              sell_currency_id: settlement_currency.unique_id,
              is_deleted: false,
            },
          });

          if (!currencyPair) {
            return sendFailure(Messages.CurrencyPairNotFound, HttpStatus.OK);
          }
        }

        const today = (orderData.ordered_date ? moment(orderData.ordered_date, 'DD-MM-YYYY') : moment()).format(
          'DDMMYYYY',
        );
        const prefix = `${group.group_id}/${today}/${orderData.settlement_currency}-OD`;

        const lastOrder = await this.orderRepository.findOne({
          where: { order_id: Like(`${prefix}%`) },
          order: { order_id: 'DESC' },
        });

        let newId = 1;
        if (lastOrder) {
          const lastId = parseInt(lastOrder.order_id.split('-').pop().replace('OD', ''), 10);
          newId = lastId + 1;
        }
        const selectedDate = moment(orderData.ordered_date, 'DD-MM-YYYY');
        const currentTime = moment();

        const finalDateTime = selectedDate
          .hour(currentTime.hour())
          .minute(currentTime.minute())
          .second(currentTime.second())
          .millisecond(currentTime.millisecond())
          .toDate();
        const newOrderId = `${prefix}${newId.toString().padStart(3, '0')}`;
        const order = this.orderRepository.create({
          ...orderData,
          currency,
          settlement_currency,
          account_id,
          rate: orderData?.rate,
          order_id: newOrderId,
          status: 'processing',
          ordered_date: finalDateTime,
          created_by: {
            id: user.unique_id,
            name: user.user_name,
          },
          updated_by: {
            id: user.unique_id,
            name: user.user_name,
          },
        });
        const savedOrder = await this.orderRepository.save(order);
        if (orderData?.trading === 'adjustment') {
          await this.orderTransactionService.getFullPayDetails(savedOrder.unique_id, user);
        }
        const reloadedOrder = await this.orderRepository.findOne({
          where: { unique_id: savedOrder.unique_id },
          relations: ['account'],
        });
        createdOrders.push(reloadedOrder);
      }

      if (createOrderDto.is_multiOrder) {
        const group = await this.customerGroupRepository.findOne({
          where: { unique_id: createOrderDto.data[0]?.group_id },
        });
        if (createdOrders.length === 0) {
          return sendSuccess(Messages.OrderMultiOrderCreated, { group: {}, currencies: [] });
        }

        const groupedByCurrency = createdOrders.reduce((acc, order) => {
          const currency = order.currency?.code;
          if (!acc[currency]) {
            acc[currency] = {
              total_amount: 0,
              orders: [],
            };
          }
          acc[currency].orders.push({
            order_id: order.order_id,
            amount: order.amount,
            account_name: order.account?.name,
            remarks: order.remarks,
            rate: order.rate,
            ordered_date: order.ordered_date,
            currency: order.currency?.code,
            settlement_currency: order.settlement_currency?.code,
            order_by: order.order_by,
          });
          acc[currency].total_amount += Number(order.amount);
          return acc;
        }, {});

        const currencies = Object.keys(groupedByCurrency)
          .sort()
          .map((currencyCode) => ({
            currency: currencyCode,
            total_amount: String(groupedByCurrency[currencyCode].total_amount),
            orders: groupedByCurrency[currencyCode].orders,
          }));
        const response = {
          group: {
            name: group?.name,
            group_id: group?.group_id,
          },
          currencies: currencies,
        };
        return sendSuccess(Messages.OrderMultiOrderCreated, response);
      } else {
        return sendSuccess(Messages.OrderCreated, createdOrders[0]);
      }
    } catch (error) {
      this.logger.error('Error creating order(s)', error);
      return commonCatch(error);
    }
  }

  async getAll(filter: FilterDto, purpose: string): Promise<any> {
    try {
      const moment = require('moment-timezone'); // make sure you have moment-timezone installed
      const baseQuery = this.orderRepository
        .createQueryBuilder('order')
        .leftJoinAndSelect('order.customer_group', 'customer_group')
        .leftJoinAndSelect('order.account', 'account')
        .leftJoinAndSelect('order.currency', 'currency')
        .leftJoinAndSelect('order.settlement_currency', 'settlement_currency')
        .leftJoinAndSelect('order.transactions', 'transactions', 'transactions.is_deleted = :isDeletedTransaction', {
          isDeletedTransaction: false,
        })
        .leftJoinAndSelect('transactions.sell_currency', 'transaction_sell_currency')
        .leftJoinAndSelect('transactions.settlement_currency', 'transaction_settlement_currency')
        .where('order.is_deleted = :isDeleted', { isDeleted: false });

      if (filter?.from_date && filter?.to_date) {
        const startDate = moment(filter.from_date, 'DD-MM-YYYY').startOf('day').toDate();
        const endDate = moment(filter.to_date, 'DD-MM-YYYY').endOf('day').toDate();
        baseQuery.andWhere('order.ordered_date BETWEEN :startDate AND :endDate', { startDate, endDate });
      }

      let groupId, settlementCurrency, orderStatus, settlementCurrencyCode, sellCurrency;
      if (filter?.query.length > 0) {
        const conditions = filter.query as Condition<any>[];
        const groupCondition = conditions.find((c) => c.fieldName === 'group_id');

        if (groupCondition) {
          groupId = groupCondition.fieldString;
        }
        const currencyCondition = conditions.find((c) => c.fieldName === 'settlement_currency');
        if (currencyCondition) {
          settlementCurrencyCode = currencyCondition.fieldString;
          if (Array.isArray(currencyCondition.fieldString)) {
            const currencies = await this.currencyRepository.find({
              where: { code: In(currencyCondition.fieldString) },
            });
            if (currencies.length > 0) {
              settlementCurrency = currencies.map((c) => c.unique_id);
              const currencyConditionIndex = conditions.findIndex((c) => c.fieldName === 'settlement_currency');
              conditions[currencyConditionIndex].fieldString = settlementCurrency;
              conditions[currencyConditionIndex].fieldName = 'settlement_currency_id';
            }
          } else {
            const currency = await this.currencyRepository.findOne({ where: { code: currencyCondition.fieldString } });
            if (currency) {
              settlementCurrency = currency.unique_id;
              const currencyConditionIndex = conditions.findIndex((c) => c.fieldName === 'settlement_currency');
              conditions[currencyConditionIndex].fieldString = settlementCurrency;
              conditions[currencyConditionIndex].fieldName = 'settlement_currency_id';
            }
          }
        }
        const sellCurrencyCondition = conditions.find((c) => c.fieldName === 'currency');
        if (sellCurrencyCondition) {
          if (Array.isArray(sellCurrencyCondition.fieldString)) {
            const currencies = await this.currencyRepository.find({
              where: { code: In(sellCurrencyCondition.fieldString) },
            });
            if (currencies.length > 0) {
              const currencyIds = currencies.map((c) => c.unique_id);
              const currencyConditionIndex = conditions.findIndex((c) => c.fieldName === 'currency');
              conditions[currencyConditionIndex].fieldString = currencyIds;
              conditions[currencyConditionIndex].fieldName = 'currency_id';
            }
          } else {
            const currency = await this.currencyRepository.findOne({
              where: { code: sellCurrencyCondition.fieldString },
            });
            if (currency) {
              sellCurrency = currency.unique_id;
              const currencyConditionIndex = conditions.findIndex((c) => c.fieldName === 'currency');
              conditions[currencyConditionIndex].fieldString = sellCurrency;
              conditions[currencyConditionIndex].fieldName = 'currency_id';
            }
          }
        }
        const statusConditionIndex = conditions.findIndex((c) => c.fieldName === 'status');
        if (statusConditionIndex > -1) {
          orderStatus = conditions[statusConditionIndex].fieldString;
          conditions.splice(statusConditionIndex, 1);
        }
        const whereConditions = utils.buildMysqlQuery(conditions);
        baseQuery.andWhere(whereConditions);
      }

      // --- START: New logic for status counts ---
      const statusCountQuery = baseQuery.clone();
      const statusCountsPromises = Object.values(OrderStatus).map(async (status) => {
        const q = statusCountQuery.clone().andWhere('order.status = :status', { status });
        const count = await q.getCount();
        return { label: status, value: count };
      });

      let counts = await Promise.all(statusCountsPromises);

      // if (purpose === 'report') {
      //   counts = counts.filter((c) => c.label !== OrderStatus.Completed);
      // }
      // --- END: New logic for status counts ---

      if (purpose === 'report') {
        if (!orderStatus) {
          const reportStatuses = [
            OrderStatus.Error,
            OrderStatus.Transferring,
            OrderStatus.Processing,
            OrderStatus.Completed,
          ];
          baseQuery.andWhere('order.status IN (:...status)', { status: reportStatuses });
        } else if (orderStatus) {
          baseQuery.andWhere('order.status = :status', { status: orderStatus });
        }
      } else if (orderStatus) {
        baseQuery.andWhere('order.status = :status', { status: orderStatus });
      }

      const totalCount = await baseQuery.clone().getCount();

      let overall_calculation;

      if (groupId) {
        overall_calculation = await this.orderTransactionService.calculateAmountForGroup(
          'own',
          null,
          groupId,
          settlementCurrency,
        );
      }

      baseQuery.addOrderBy('order.created_at', 'ASC');
      baseQuery.addOrderBy('transactions.created_at', 'ASC');

      const orders = await baseQuery.getMany();

      let ordersWithCalculation = [];
      if (orders.length > 0) {
        // --- Optimization Start ---

        // 1. Collect all unique currency codes from all orders and transactions
        const currencyCodes = new Set<string>();
        orders.forEach((order) => {
          currencyCodes.add(order?.currency?.code);
          currencyCodes.add(order?.settlement_currency?.code);
          order.transactions.forEach((t) => {
            currencyCodes.add(t?.sell_currency?.code);
            currencyCodes.add(t?.settlement_currency?.code);
          });
        });

        // 2. Fetch all relevant Currency entities in one go
        const currencyEntities = await this.currencyRepository.find({
          where: { code: In(Array.from(currencyCodes)) },
        });
        const currencyMap = new Map(currencyEntities.map((c) => [c.code, c]));

        // 3. Collect all currency pairs to query
        const pairQueries = new Set<string>();
        orders.forEach((order) => {
          if (order.currency.code !== order.settlement_currency.code) {
            const sellCurrency = currencyMap.get(order.currency.code);
            const settlementCurrency = currencyMap.get(order.settlement_currency.code);
            if (sellCurrency && settlementCurrency) {
              pairQueries.add(`${settlementCurrency.unique_id}_${sellCurrency.unique_id}`);
            }
          }
          order.transactions.forEach((t) => {
            if (t.sell_currency.code !== t.settlement_currency.code) {
              const sellCurrency = currencyMap.get(t.sell_currency.code);
              const settlementCurrency = currencyMap.get(t.settlement_currency.code);
              if (sellCurrency && settlementCurrency) {
                pairQueries.add(`${settlementCurrency.unique_id}_${sellCurrency.unique_id}`);
              }
            }
          });
        });

        // 4. Fetch all relevant CurrencyPair entities
        const pairsToFetch = Array.from(pairQueries).map((p) => {
          const [buy_currency_id, sell_currency_id] = p.split('_');
          return { buy_currency_id, sell_currency_id };
        });

        const currencyPairs =
          pairsToFetch.length > 0 ? await this.currencyPairRepository.find({ where: pairsToFetch }) : [];
        const currencyPairMap = new Map(currencyPairs.map((p) => [`${p.buy_currency_id}_${p.sell_currency_id}`, p]));

        // 5. Create a reusable calculation function
        const calculateAmount = (sellCode: string, settlementCode: string, amount: number, rate: number) => {
          if (sellCode === settlementCode) {
            return +amount;
          }
          const sellCurrency = currencyMap.get(sellCode);
          const settlementCurrency = currencyMap.get(settlementCode);
          if (!sellCurrency || !settlementCurrency) return +amount;

          const currencyPair = currencyPairMap.get(`${settlementCurrency.unique_id}_${sellCurrency.unique_id}`);
          if (!currencyPair) return +amount;

          if (currencyPair.calculation_type === 'multiply') {
            return +amount * +rate;
          } else if (currencyPair.calculation_type === 'divide') {
            return +amount / +rate;
          }
          return +amount;
        };

        // --- Optimization End ---

        ordersWithCalculation = orders.map((order) => {
          const orderAmount = calculateAmount(
            order.currency.code,
            order.settlement_currency.code,
            order.amount,
            order.rate,
          );
          const totalOrderAmount = orderAmount + +order?.fee;
          let totalTransactionValue = 0;
          let we = 0;
          let cus = 0;
          let weFees = 0;
          let cusFees = 0;
          let totalVal = 0;
          let totalSellValue = 0;

          for (const transaction of order.transactions) {
            totalSellValue += +transaction.sell_value;
            const sellCurrencyCode = transaction.sell_currency.code;
            const settlementCurrencyCode = transaction.settlement_currency.code;
            const transactionValue = calculateAmount(
              sellCurrencyCode,
              settlementCurrencyCode,
              transaction?.sell_value,
              transaction?.rate,
            );
            if (transaction?.sell_currency !== order?.settlement_currency) {
              transaction['calculated_amount'] = transactionValue;
            }
            transaction['settlement_currency'] = transaction?.settlement_currency?.code as any;
            transaction['sell_currency'] = transaction?.sell_currency?.code as any;

            we += transactionValue;
            weFees += +transaction?.fee || 0;
            totalTransactionValue += transactionValue;
          }
          let calculationStatus;

          let base = 0;
          let fees = 0;
          let flip = false;

          if (order?.order_by === 'we') {
            base = +we;
            fees = +weFees;
          } else if (order?.order_by === 'customer') {
            base = +we;
            fees = +weFees;
            flip = true; // reverse owe_us / we_owe logic
          }

          const totalWithFees = +(base + fees).toFixed(2);
          if (totalWithFees === 0) {
            if (order?.order_by === 'we') {
              calculationStatus = 'by_customer';
            } else {
              calculationStatus = 'by_us';
            }
            totalVal = +totalOrderAmount;
          } else if (totalOrderAmount === totalWithFees) {
            calculationStatus = 'all_clear';
            totalVal = 0;
          } else {
            const diff = +Math.abs(totalOrderAmount - totalWithFees).toFixed(2);
            const isOrderGreater = totalOrderAmount > totalWithFees;

            if (flip) {
              calculationStatus = isOrderGreater ? 'by_us' : 'by_customer';
            } else {
              calculationStatus = isOrderGreater ? 'by_customer' : 'by_us';
            }

            totalVal = diff;
          }

          const truncateToTwo = (num: number) => Math.floor(num * 100) / 100;
          let transferPercent =
            totalOrderAmount > 0 ? ((+totalTransactionValue + +weFees) / totalOrderAmount) * 100 : 0;
          transferPercent = truncateToTwo(transferPercent);

          const rounded = Number.isInteger(transferPercent) ? transferPercent : Number(transferPercent.toFixed(2));

          const pendingAmount = +order?.amount - +totalSellValue;
          let calculation = {
            status: calculationStatus,
            value: totalVal,
            currency: order.settlement_currency.code,
            transferred_amount: totalSellValue,
            pending_amount: Math.abs(+pendingAmount.toFixed(2)),
          };
          const { currency, settlement_currency, ...rest } = order;
          return {
            ...rest,
            currency: currency.code,
            settlement_currency: settlement_currency.code,
            calculation: calculation,
            transfer_percent: rounded,
          };
        });
      }

      const groupedOrders = ordersWithCalculation.reduce((acc, order) => {
        const date = moment(order.ordered_date).format('DD-MM-YYYY');
        if (!acc[date]) {
          acc[date] = [];
        }
        acc[date].push(order);
        return acc;
      }, {});

      let formattedOrders = [];
      if (filter?.from_date && filter?.to_date) {
        const startDate = moment(filter.from_date, 'DD-MM-YYYY');
        const endDate = moment(filter.to_date, 'DD-MM-YYYY');
        for (let m = startDate; m.isSameOrBefore(endDate); m.add(1, 'days')) {
          const date = m.format('DD-MM-YYYY');
          formattedOrders.push({
            date,
            orders: groupedOrders[date] || [],
          });
        }
      } else {
        formattedOrders = Object.keys(groupedOrders).map((date) => ({
          date,
          orders: groupedOrders[date],
        }));
      }

      formattedOrders.sort((a, b) => moment(b.date, 'DD-MM-YYYY').diff(moment(a.date, 'DD-MM-YYYY')));

      return sendSuccess('Orders fetched successfully', {
        orders: formattedOrders,
        totalCount,
        statuses: counts,
        overall_calculation: overall_calculation ? overall_calculation[0] : null,
      });
    } catch (error) {
      this.logger.error('Error fetching orders', error);
      return commonCatch(error);
    }
  }

  async update(updateOrderDto: UpdateOrderDto, user: LoggedAdmin): Promise<any> {
    try {
      const order = await this.orderRepository.findOne({
        where: { unique_id: updateOrderDto.unique_id, is_deleted: false },
        relations: ['account'],
      });
      if (!order) {
        return sendFailure('Order not found', HttpStatus.NOT_FOUND);
      }
      delete updateOrderDto?.ordered_date;

      const payload = { ...updateOrderDto };

      // ✅ Resolve account id if passed
      if (payload.account_id) {
        const account = await this.accountsService.resolveAccountId(payload.account_id);
        payload.account_id = account.unique_id;
      }
      // ✅ Handle currency & settlement currency update
      if (payload.currency || payload.settlement_currency) {
        const currency = payload.currency
          ? await this.currencyRepository.findOne({ where: { code: payload.currency } })
          : order.currency;
        const settlement_currency = payload.settlement_currency
          ? await this.currencyRepository.findOne({ where: { code: payload.settlement_currency } })
          : order.settlement_currency;

        if (!currency || !settlement_currency) {
          return sendFailure(Messages.CurrencyNotExist, HttpStatus.NOT_FOUND);
        }

        if (currency.code !== settlement_currency.code) {
          const trading = payload.trading || order.trading;
          let currencyPair;
          currencyPair = await this.currencyPairRepository.findOne({
            where: {
              buy_currency_id: settlement_currency.unique_id,
              sell_currency_id: currency.unique_id,
              is_deleted: false,
            },
          });

          if (!currencyPair) {
            return sendFailure(Messages.CurrencyPairNotFound, HttpStatus.OK);
          }
        }

        order.currency = currency;
        order.settlement_currency = settlement_currency;
        if (payload.currency) delete payload.currency;
        if (payload.settlement_currency) delete payload.settlement_currency;
      }

      // ✅ Merge
      for (const key in payload) {
        if (payload.hasOwnProperty(key)) {
          order[key] = payload[key];
        }
      }

      // ✅ ACTUAL FIX BELOW 👇
      if (payload.account_id) {
        const acc = await this.accountRepository.findOne({
          where: { unique_id: payload.account_id },
        });
        if (!acc) {
          return sendFailure('Account not found', HttpStatus.BAD_REQUEST);
        }
        order.account = acc; // ← Only this updates relation
      }

      // ✅ updated_by
      order.updated_by = { id: user.unique_id, name: user.user_name };

      // ✅ Save
      const updatedOrder = await this.orderRepository.save(order);

      // ✅ Update child transactions if needed
      if (payload.hasOwnProperty('account_id')) {
        await this.orderTransactionRepository.update(
          { order_id: updatedOrder.unique_id },
          { account_id: updatedOrder.account_id },
        );
      }

      await this.recalculateOrderStatus(updatedOrder.unique_id);

      const reloadedOrder = await this.orderRepository.findOne({
        where: { unique_id: updatedOrder.unique_id },
      });

      return sendSuccess('Order updated successfully', reloadedOrder);
    } catch (error) {
      this.logger.error('Error updating order', error);
      return commonCatch(error);
    }
  }

  async getCumulativeCurrencies(dto: any): Promise<any> {
    try {
      const currencies = await this.orderTransactionService.getSellCurrencies(dto.group_id, dto.settlement_currency);
      return sendSuccess('Cumulative currencies fetched successfully', currencies);
    } catch (error) {
      this.logger.error('Error from getCumulativeCurrencies', error);
      return commonCatch(error);
    }
  }

  async getOrderSettlementCurrencies(groupId: string): Promise<any> {
    try {
      const results = await this.currencyOrderRepository.find({
        where: { group_id: groupId },
        order: { order: 'ASC' },
        relations: ['currency'],
      });
      const currencies = results.map((r) => {
        return r.currency?.code;
      });
      return sendSuccess('Order settlement currencies fetched successfully', currencies);
    } catch (error) {
      this.logger.error('Error from getOrderSettlementCurrencies', error);
      return commonCatch(error);
    }
  }

  async updateOrderStatus(orderId: string, status: string): Promise<Order | null> {
    try {
      const order = await this.orderRepository.findOne({ where: { unique_id: orderId } });

      if (!order) {
        return null; // Order not found
      }

      order.status = status;
      await this.orderRepository.save(order);

      return order; // Return the updated order
    } catch (error) {
      this.logger.error(`Error updating order status for order ID: ${orderId}`, error);
      return null; // Return null on error
    }
  }

  async recalculateOrderStatus(orderId: string): Promise<void> {
    try {
      const order = await this.orderRepository.findOne({
        where: { unique_id: orderId },
        relations: ['customer_group'],
      });
      if (!order) return this.logger.warn(`Order ${orderId} not found.`);

      const transactions = await this.orderTransactionRepository.find({
        where: { order_id: orderId, is_deleted: false },
      });

      if (!transactions.length) {
        await this.orderRepository.update({ unique_id: orderId }, { status: 'processing' });
        return;
      }

      let orderAmount = await this.currencyPairService.calculateAmountInSettlementCurrency(
        order.currency.code,
        order.settlement_currency.code,
        order.amount,
        order.rate,
      );

      let orderTotal = +order?.fee + +orderAmount;

      let totalTransfer = 0,
        totalFee = 0;

      for (const t of transactions) {
        const value = await this.currencyPairService.calculateAmountInSettlementCurrency(
          t.sell_currency.code,
          t.settlement_currency.code,
          t.sell_value,
          t.rate,
        );
        totalTransfer += value;
        totalFee += +t.fee;
      }

      const total = +totalTransfer + +totalFee;

      const errors = +total?.toFixed(2) > +orderTotal?.toFixed(2);

      let newStatus = 'transferring';
      if (errors) newStatus = 'error';
      else if (+total?.toFixed(2) > 0 && +orderTotal?.toFixed(2) > 0 && +total?.toFixed(2) === +orderTotal?.toFixed(2))
        newStatus = 'completed';

      await this.orderRepository.update({ unique_id: orderId }, { status: newStatus });
    } catch (error) {
      this.logger.error(`Error recalculating order status for order ID: ${orderId}`, error);
    }
  }

  async getOrderDetails(id: string): Promise<any> {
    try {
      const order = await this.orderRepository
        .createQueryBuilder('order')
        .leftJoinAndSelect('order.customer_group', 'customer_group')
        .leftJoinAndSelect('order.account', 'account')
        .leftJoinAndSelect('order.currency', 'currency')
        .leftJoinAndSelect('order.settlement_currency', 'settlement_currency')
        .leftJoinAndSelect('order.transactions', 'transactions', 'transactions.is_deleted = :isDeletedTransaction', {
          isDeletedTransaction: false,
        })
        .leftJoinAndSelect('transactions.sell_currency', 'transaction_sell_currency')
        .leftJoinAndSelect('transactions.settlement_currency', 'transaction_settlement_currency')
        .where('order.unique_id = :id', { id })
        .andWhere('order.is_deleted = :isDeleted', { isDeleted: false })
        .getOne();

      if (!order) {
        return sendFailure(Messages.OrderNotFound, HttpStatus.NOT_FOUND);
      }

      const currencyCodes = new Set<string>();
      currencyCodes.add(order.currency.code);
      currencyCodes.add(order.settlement_currency.code);
      order.transactions.forEach((t) => {
        currencyCodes.add(t.sell_currency.code);
        currencyCodes.add(t.settlement_currency.code);
      });

      const currencyEntities = await this.currencyRepository.find({
        where: { code: In(Array.from(currencyCodes)) },
      });
      const currencyMap = new Map(currencyEntities.map((c) => [c.code, c]));

      const pairQueries = new Set<string>();
      if (order.currency.code !== order.settlement_currency.code) {
        const sellCurrency = currencyMap.get(order.currency.code);
        const settlementCurrency = currencyMap.get(order.settlement_currency.code);
        if (sellCurrency && settlementCurrency) {
          pairQueries.add(`${settlementCurrency.unique_id}_${sellCurrency.unique_id}`);
        }
      }
      order.transactions.forEach((t) => {
        if (t.sell_currency.code !== t.settlement_currency.code) {
          const sellCurrency = currencyMap.get(t.sell_currency.code);
          const settlementCurrency = currencyMap.get(t.settlement_currency.code);
          if (sellCurrency && settlementCurrency) {
            pairQueries.add(`${settlementCurrency.unique_id}_${sellCurrency.unique_id}`);
          }
        }
      });

      const pairsToFetch = Array.from(pairQueries).map((p) => {
        const [buy_currency_id, sell_currency_id] = p.split('_');
        return { buy_currency_id, sell_currency_id };
      });

      const currencyPairs =
        pairsToFetch.length > 0 ? await this.currencyPairRepository.find({ where: pairsToFetch }) : [];
      const currencyPairMap = new Map(currencyPairs.map((p) => [`${p.buy_currency_id}_${p.sell_currency_id}`, p]));

      const calculateAmount = (sellCode: string, settlementCode: string, amount: number, rate: number) => {
        if (sellCode === settlementCode) {
          return +amount;
        }
        const sellCurrency = currencyMap.get(sellCode);
        const settlementCurrency = currencyMap.get(settlementCode);
        if (!sellCurrency || !settlementCurrency) return +amount;

        const currencyPair = currencyPairMap.get(`${settlementCurrency.unique_id}_${sellCurrency.unique_id}`);
        if (!currencyPair) return +amount;

        if (currencyPair.calculation_type === 'multiply') {
          return +amount * +rate;
        } else if (currencyPair.calculation_type === 'divide') {
          return +amount / +rate;
        }
        return +amount;
      };

      const orderAmount = calculateAmount(
        order.currency.code,
        order.settlement_currency.code,
        order.amount,
        order.rate,
      );

      let totalTransactionValue = 0;
      let we = 0;
      let weFees = 0;
      let totalVal = 0;

      for (const transaction of order.transactions) {
        const sellCurrencyCode = transaction.sell_currency.code;
        const settlementCurrencyCode = transaction.settlement_currency.code;
        const transactionValue = calculateAmount(
          sellCurrencyCode,
          settlementCurrencyCode,
          transaction?.sell_value,
          transaction?.rate,
        );

        if (transaction?.sell_currency !== order?.settlement_currency) {
          transaction['calculated_amount'] = transactionValue;
        }
        transaction['settlement_currency'] = transaction?.settlement_currency?.code as any;
        transaction['sell_currency'] = transaction?.sell_currency?.code as any;

        we += transactionValue;
        weFees += +transaction?.fee || 0;
        totalTransactionValue += transactionValue;
      }
      let calculationStatus;

      let base = 0;
      let fees = 0;
      let flip = false;

      if (order?.order_by === 'we') {
        base = +we;
        fees = +weFees;
      } else if (order?.order_by === 'customer') {
        base = +we;
        fees = +weFees;
        flip = true; // reverse owe_us / we_owe logic
      }

      const totalWithFees = +(base + fees).toFixed(2);
      if (totalWithFees === 0) {
        if (order?.order_by === 'we') {
          calculationStatus = 'by_customer';
        } else {
          calculationStatus = 'by_us';
        }
        totalVal = +orderAmount;
      } else if (orderAmount === totalWithFees) {
        calculationStatus = 'all_clear';
        totalVal = 0;
      } else {
        const diff = +Math.abs(orderAmount - totalWithFees).toFixed(2);
        const isOrderGreater = orderAmount > totalWithFees;

        if (flip) {
          calculationStatus = isOrderGreater ? 'by_us' : 'by_customer';
        } else {
          calculationStatus = isOrderGreater ? 'by_customer' : 'by_us';
        }

        totalVal = diff;
      }
      const truncateToTwo = (num: number) => Math.floor(num * 100) / 100;

      let transferPercent = orderAmount > 0 ? ((+totalTransactionValue + +weFees) / orderAmount) * 100 : 0;
      transferPercent = truncateToTwo(transferPercent);

      const rounded = Number.isInteger(transferPercent) ? transferPercent : Number(transferPercent.toFixed(2));
      let calculation = {
        status: calculationStatus,
        value: totalVal,
        currency: order.settlement_currency.code,
      };
      const { currency, settlement_currency, ...rest } = order;
      const orderWithCalculation = {
        ...rest,
        currency: currency.code,
        settlement_currency: settlement_currency.code,
        calculation: calculation,
        transfer_percent: rounded,
      };

      return sendSuccess('Order details fetched successfully', orderWithCalculation);
    } catch (error) {
      this.logger.error('Error fetching order details', error);
      return commonCatch(error);
    }
  }

  async delete(id: string): Promise<any> {
    try {
      const order = await this.orderRepository.findOne({ where: { unique_id: id } });
      if (!order) {
        return sendFailure(Messages.OrderNotFound, HttpStatus.NOT_FOUND);
      }

      await this.orderRepository.update({ unique_id: id }, { is_deleted: true });
      await this.orderTransactionRepository.update({ order_id: id }, { is_deleted: true });

      return sendSuccess(Messages.OrderDeleted, null);
    } catch (error) {
      this.logger.error('Error from delete order', error);
      return commonCatch(error);
    }
  }

  async deleteMulti(ids: string[]): Promise<any> {
    try {
      if (!ids || ids.length === 0) {
        return sendFailure(Messages.OrderNotFound, HttpStatus.OK);
      }

      const orderResult = await this.orderRepository.update({ unique_id: In(ids) }, { is_deleted: true });

      if (orderResult.affected === 0) {
        return sendFailure(Messages.OrderNotFound, HttpStatus.OK);
      }

      await this.orderTransactionRepository.update({ order_id: In(ids) }, { is_deleted: true });

      return sendSuccess(Messages.OrdersDeleted);
    } catch (error) {
      this.logger.error('Error from delete multi order', error);
      return commonCatch(error);
    }
  }
}
