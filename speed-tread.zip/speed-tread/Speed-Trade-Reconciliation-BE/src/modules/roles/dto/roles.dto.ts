// src/roles/dto/create-role.dto.ts
import { PartialType } from '@nestjs/mapped-types';
import { IsNotEmpty, IsString, IsOptional, IsBoolean } from 'class-validator';

export class CreateRoleDto {
  @IsString()
  @IsNotEmpty()
  role_type: string;

  @IsString()
  @IsOptional()
  description: string;

  @IsString()
  @IsOptional()
  access: string;
}

export class UpdateRoleDto extends PartialType(CreateRoleDto) {
  @IsString()
  @IsNotEmpty()
  unique_id: string;
}
