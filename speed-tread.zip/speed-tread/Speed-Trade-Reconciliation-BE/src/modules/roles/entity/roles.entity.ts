import { BeforeInsert, Column, CreateDateColumn, Entity, PrimaryColumn, UpdateDateColumn } from 'typeorm';
import * as utils from 'src/utils';

@Entity('roles')
export class Role {
  @PrimaryColumn({ type: 'varchar', length: 50 })
  unique_id: string;

  @BeforeInsert()
  generateUniqueId() {
    this.unique_id = this.unique_id || utils.generateRandomId();
  }

  @Column({ unique: true })
  role_type: string; // e.g. Admin, Manager, User

  @Column({ nullable: true, default: '' })
  description: string;

  @Column({ type: 'text', nullable: true, default: '' })
  access: string; // you can store JSON or comma-separated values

  @Column({ default: true })
  is_active: boolean;

  @Column({ default: false })
  is_deleted: boolean;

  @CreateDateColumn({ name: 'created_at' })
  created_at: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updated_at: Date;
}
