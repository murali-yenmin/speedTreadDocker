// src/roles/roles.controller.ts
import { Controller, Get, Post, Put, Delete, Param, Body, ParseIntPipe } from '@nestjs/common';
import { RolesService } from './roles.service';
import { CreateRoleDto, UpdateRoleDto } from './dto/roles.dto';

@Controller('roles')
export class RolesController {
  constructor(private readonly rolesService: RolesService) {}

  @Get()
  findAll() {
    return this.rolesService.findAll();
  }

  @Post()
  create(@Body() dto: CreateRoleDto) {
    return this.rolesService.create(dto);
  }

  @Put()
  update(@Body() dto: UpdateRoleDto) {
    return this.rolesService.update(dto);
  }


  // For Bulk Delete Roles
  // @Delete()
  // deleteMultipleRoles(@Body() uniqueIds: string[]) {
  //   return this.rolesService.deleteBulkRoles(uniqueIds['uniqueIds']);
  // }
}
