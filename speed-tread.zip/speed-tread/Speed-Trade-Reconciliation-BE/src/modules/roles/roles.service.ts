// src/roles/roles.service.ts
import { HttpStatus, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { Role } from './entity/roles.entity';
import { CreateRoleDto, UpdateRoleDto } from './dto/roles.dto';
import { commonCatch, sendFailure, sendSuccess } from 'src/utils/response.utils';
import { Messages } from 'src/message-constants/message.constants';
import { generateRandomId } from 'src/utils';

@Injectable()
export class RolesService {
  private readonly logger = new Logger(RolesService.name);
  constructor(
    @InjectRepository(Role)
    private readonly roleRepo: Repository<Role>,
  ) {}

  //   Common Reusable Functions
  async findOneByQuery(query): Promise<object> {
    return this.roleRepo.findOne(query);
  }

  //  API functions

  // Find all roles For dropdown without pagination
  async findAll(): Promise<object> {
    try {
      const roles = await this.roleRepo.find({
        select: ['unique_id', 'role_type'],
      });
      return sendSuccess(Messages.RolesFetched, roles);
    } catch (error) {
      this.logger.error(`Failed to fetch roles: ${error.message}`);
      return commonCatch(error);
    }
  }

  //   Create a role
  async create(dto: CreateRoleDto): Promise<object> {
    try {
      const roleExists = await this.roleRepo.findOne({ where: { role_type: dto.role_type?.toLowerCase() } });
      if (roleExists) {
        return sendFailure(Messages.RolesAlreadyExists, HttpStatus.OK);
      }
      const role = this.roleRepo.create(dto);

      await this.roleRepo.save(role);
      return sendSuccess(Messages.RolesCreated, role);
    } catch (error) {
      this.logger.error(`Failed to create role: ${error.message}`);
      return commonCatch(error);
    }
  }

  //   Update a role
  async update(dto: UpdateRoleDto): Promise<object> {
    try {
      const role = await this.findOneByQuery({ where: { unique_id: dto.unique_id } });
      delete dto?.unique_id;
      Object.assign(role, dto);
      await this.roleRepo.save(role);
      return sendSuccess(Messages.RolesUpdated, role);
    } catch (error) {
      this.logger.error(`Failed to update role with ID ${dto.unique_id}: ${error.message}`);
      return commonCatch(error);
    }
  }

  // For Bulk Delete Roles
  // async deleteBulkRoles(ids: string[]): Promise<any> {
  //   try {
  //     await this.roleRepo.delete({ unique_id: In(ids) });
  //     return sendSuccess("roles deleted");
  //   } catch (error) {
  //     this.logger.error('Error from deleteBulkRoles', error);
  //     return commonCatch(error);
  //   }
  // }
}
