import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class CalculateAmountDto {
  @IsOptional()
  @IsString()
  date: string;

  @IsNotEmpty()
  @IsString()
  group_id: string;

  @IsNotEmpty()
  @IsString()
  currency: string;
}
