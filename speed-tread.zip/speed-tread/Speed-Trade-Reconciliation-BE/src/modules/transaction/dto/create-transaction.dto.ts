import { IsString, IsNotEmpty, IsNumber, IsOptional, ValidateIf, IsDate } from 'class-validator';
import { Type } from 'class-transformer';

export class CreateTransactionDto {
  @IsString()
  @IsNotEmpty()
  group_id: string;

  @IsString()
  @IsNotEmpty()
  transfer_by: string;

  @IsNumber()
  @IsNotEmpty()
  sell_value: number;

  @IsString()
  @IsNotEmpty()
  sell_currency: string;

  @IsString()
  @IsNotEmpty()
  settlement_currency: string;

  @IsString()
  @IsNotEmpty()
  trading: string;

  @IsNumber()
  @ValidateIf((o) => o.sell_currency !== o.settlement_currency)
  @IsNotEmpty()
  rate: number;

  @IsString()
  @IsNotEmpty()
  account_id: string;

  @IsString()
  @IsOptional()
  remarks?: string;

  @IsNumber()
  @IsOptional()
  fee: number;

  @IsString()
  @IsOptional()
  transferred_date: string;
}
