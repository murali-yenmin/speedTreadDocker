import { IsArray, IsNotEmpty, IsString } from 'class-validator';

export class DeleteMultiTransactionDto {
  @IsArray()
  @IsNotEmpty()
  @IsString({ each: true })
  ids: string[];
}
