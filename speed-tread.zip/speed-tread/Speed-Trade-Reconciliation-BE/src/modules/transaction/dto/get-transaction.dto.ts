// import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class GetTransactionDto {
  // @ApiProperty()
  @IsString()
  @IsNotEmpty()
  group_id: string;

  // @ApiProperty()
  @IsString()
  @IsNotEmpty()
  settlement_currency: string;
}
