import {
  BeforeInsert,
  Column,
  CreateDateColumn,
  Entity,
  PrimaryColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import * as utils from 'src/utils';
import { Currency } from 'src/modules/currency/entity/currency.entity';
import { CustomerGroup } from 'src/modules/customer-group/entity/customer-group.entity';
import { Account } from 'src/modules/accounts/entities/account.entity';

@Entity('transactions')
export class Transaction {
  @PrimaryColumn({ type: 'varchar', length: 50 })
  unique_id: string;

  @BeforeInsert()
  generateUniqueId() {
    this.unique_id = utils.generateRandomId();
  }

  @Column({ type: 'varchar', length: 50, unique: true })
  transaction_id: string;

  @Column({ type: 'varchar', length: 50, nullable: true })
  group_id: string;

  @ManyToOne(() => CustomerGroup, { eager: true })
  @JoinColumn({ name: 'group_id', referencedColumnName: 'unique_id' })
  customer_group: CustomerGroup;

  @Column({ type: 'varchar', length: 255, nullable: true })
  trading: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  transfer_by: string;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0, nullable: true })
  sell_value: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0, nullable: true })
  fee: number;

  @Column({ type: 'varchar', length: 50, nullable: true })
  sell_currency_id: string;

  @ManyToOne(() => Currency, { eager: true })
  @JoinColumn({ name: 'sell_currency_id', referencedColumnName: 'unique_id' })
  sell_currency: Currency;

  @Column({ type: 'varchar', length: 50, nullable: true })
  settlement_currency_id: string;

  @ManyToOne(() => Currency, { eager: true })
  @JoinColumn({
    name: 'settlement_currency_id',
    referencedColumnName: 'unique_id',
  })
  settlement_currency: Currency;

  @Column({ type: 'decimal', precision: 18, scale: 3, default: 0, nullable: true })
  rate: number;

  @Column({ type: 'varchar', length: 50, nullable: true })
  account_id: string;
  
  @Column({ type: 'varchar', length: 50, nullable: true })
  settlement_date: string;

  @ManyToOne(() => Account, { eager: true })
  @JoinColumn({ name: 'account_id', referencedColumnName: 'unique_id' })
  account: Account;

  @Column({ type: 'text', nullable: true })
  remarks: string;

  @Column({
    type: 'datetime',
    default: () => 'CURRENT_TIMESTAMP', // auto insert on create
    nullable: false,
  })
  transferred_date: Date;

  @CreateDateColumn({ type: 'timestamp' })
  created_at: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updated_at: Date;

  @Column('json', { nullable: true })
  created_by: {
    id: string;
    name: string;
  };

  @Column('json', { nullable: true })
  updated_by: {
    id: string;
    name: string;
  };

  @Column({ type: 'boolean', default: false })
  is_deleted: boolean;
}
