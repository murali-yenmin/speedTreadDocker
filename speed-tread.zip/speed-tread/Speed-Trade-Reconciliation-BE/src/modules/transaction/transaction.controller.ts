import { Controller, Get, Post, Body, Param, Delete, Put, UseGuards } from '@nestjs/common';
import { TransactionService } from './transaction.service';
import { CreateTransactionDto } from './dto/create-transaction.dto';
import { UpdateTransactionDto } from './dto/update-transaction.dto';
import { GetLoggedUser } from 'src/common/decorators/logged-admin.decorator';
import { LoggedAdmin } from 'src/common/interfaces/logged-user.interface';
import { AdminGuard } from 'src/common/guards/admin.guard';
import { FilterDto } from 'src/common/dtos/filter.dto';
import { CalculateAmountDto } from './dto/calculate-amount.dto';
import { CumulativeCurrencyDto } from './dto/cumulative-currency.dto';
import { CreateMultiTransactionDto } from './dto/create-multi-transaction.dto';
import { ListGroupCurrencyDto } from '../customer-group/dto/list-group-currency.dto';
import { GetTransactionDto } from './dto/get-transaction.dto';
import { DeleteMultiTransactionDto } from './dto/delete-multi-transaction.dto';
@UseGuards(AdminGuard)
@Controller('transaction')
export class TransactionController {
  constructor(private readonly transactionService: TransactionService) {}

  @Post()
  create(@Body() createTransactionDto: CreateTransactionDto, @GetLoggedUser() user: LoggedAdmin) {
    return this.transactionService.create(createTransactionDto, user, false);
  }

  @Post('/multi')
  createMulti(@Body() createMultiTransactionDto: CreateMultiTransactionDto, @GetLoggedUser() user: LoggedAdmin) {
    return this.transactionService.createMulti(createMultiTransactionDto, user);
  }

  @Post('/settlement')
  createNew(@Body() createTransactionDto: CreateTransactionDto, @GetLoggedUser() user: LoggedAdmin) {
    return this.transactionService.create(createTransactionDto, user, true);
  }

  @Post('get-all')
  getAll(@Body() filter: FilterDto) {
    return this.transactionService.getAllTransactions(filter);
  }

  @Post('overall-amount')
  calculateAmount(@Body() calculateAmountDto: CalculateAmountDto) {
    return this.transactionService.calculateAmount(calculateAmountDto);
  }

  @Post('cumulative-currencies')
  getCumulativeCurrencies(@Body() dto: CumulativeCurrencyDto) {
    return this.transactionService.getCumulativeCurrencies(dto);
  }

  @Get('details/:id')
  getTransactionDetails(@Param('id') id: string) {
    return this.transactionService.getTransactionDetails(id);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.transactionService.findOne(+id);
  }

  @Put()
  update(@Body() updateTransactionDto: UpdateTransactionDto, @GetLoggedUser() user: LoggedAdmin) {
    return this.transactionService.update(updateTransactionDto.unique_id, updateTransactionDto, user);
  }

  @Put('/multi')
  deleteMulti(@Body() deleteMultiTransactionDto: DeleteMultiTransactionDto) {
    return this.transactionService.deleteMulti(deleteMultiTransactionDto.ids);
  }

  @Delete(':id')
  delete(@Param('id') id: string) {
    return this.transactionService.delete(id);
  }

  @Get('currencies/:groupId')
  getTransactionCurrenciesByGroupId(@Param('groupId') groupId: string) {
    return this.transactionService.getTransactionCurrenciesByGroupId(groupId);
  }

  @Post('list-group-calculation')
  GetListBasedOnGroupCurrencies(@Body() dto: ListGroupCurrencyDto) {
    return this.transactionService.listBasedOnGroupCurrency(dto);
  }

  @Put('settlement-date/update-all')
  updateSettlementDate() {
    return this.transactionService.updateSettlementDate();
  }

  @Post('group-currency')
  getTransactionsByGroupAndCurrency(@Body() getTransactionDto: GetTransactionDto) {
    return this.transactionService.getTransactionsByGroupAndCurrency(getTransactionDto);
  }
}
