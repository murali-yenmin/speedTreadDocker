import { forwardRef, Module } from '@nestjs/common';
import { TransactionService } from './transaction.service';
import { TransactionController } from './transaction.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Transaction } from './entities/transaction.entity';
import { ManagementUsersModule } from '../management-users/management-users.module';
import { Currency } from '../currency/entity/currency.entity';
import { CurrencyPair } from '../currency-pair/entities/currency-pair.entity';
import { ManagementUsers } from '../management-users/entities/management-user.entity';
import { CustomerGroup } from '../customer-group/entity/customer-group.entity';
import { AccountsModule } from '../accounts/accounts.module';
import { Account } from '../accounts/entities/account.entity';
import { CurrencyPairModule } from '../currency-pair/currency-pair.module';
import { CurrencyOrderModule } from '../currency-order/currency-order.module';
import { CurrencyOrder } from '../currency-order/entities/currency-order.entity';
import { CurrencyModule } from '../currency/currency.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Transaction,
      Currency,
      CurrencyPair,
      ManagementUsers,
      CustomerGroup,
      Account,
      CurrencyOrder,
    ]),
    ManagementUsersModule,
    AccountsModule,
    CurrencyPairModule,
    CurrencyModule,
  ],
  controllers: [TransactionController],
  providers: [TransactionService],
  exports: [TransactionService],
})
export class TransactionModule {}
