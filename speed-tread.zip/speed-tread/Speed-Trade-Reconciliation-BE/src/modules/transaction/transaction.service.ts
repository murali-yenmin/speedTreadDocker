import { CalculateAmountDto } from './dto/calculate-amount.dto';
import { CumulativeCurrencyDto } from './dto/cumulative-currency.dto';
import { HttpStatus, Injectable, Logger, HttpException } from '@nestjs/common';
import { CreateTransactionDto } from './dto/create-transaction.dto';
import { UpdateTransactionDto } from './dto/update-transaction.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Transaction } from './entities/transaction.entity';
import { Between, Repository, Like, In } from 'typeorm';
import { LoggedAdmin } from 'src/common/interfaces/logged-user.interface';
import { commonCatch, sendFailure, sendSuccess } from 'src/utils/response.utils';
import { Messages } from 'src/message-constants/message.constants';
import { FilterDto } from 'src/common/dtos/filter.dto';
import { Condition } from 'src/common/interfaces/app.interface';
import * as utils from 'src/utils';
import moment, { convertUTCToSingapore, settlementDate, settlementDateUpdate } from '../../utils/moment';
import { CustomerGroup } from '../customer-group/entity/customer-group.entity';
import { ManagementUsers } from '../management-users/entities/management-user.entity';
import { Errors } from 'src/message-constants/error.constants';
import { Currency } from '../currency/entity/currency.entity';
import { CurrencyPair } from '../currency-pair/entities/currency-pair.entity';
import { AccountsService } from '../accounts/accounts.service';
import { CurrencyPairService } from '../currency-pair/currency-pair.service';
import { Account } from '../accounts/entities/account.entity';
import { CurrencyOrder } from '../currency-order/entities/currency-order.entity';
import { CreateMultiTransactionDto } from './dto/create-multi-transaction.dto';
import { ListGroupCurrencyDto } from '../customer-group/dto/list-group-currency.dto';
import { AppConfigService } from 'src/config/app-config/app-config.service';
import { CurrencyService } from '../currency/currency.service';
import { GetTransactionDto } from './dto/get-transaction.dto';

@Injectable()
export class TransactionService {
  private logger = new Logger(TransactionService.name);
  constructor(
    @InjectRepository(Transaction)
    private readonly transactionRepository: Repository<Transaction>,
    @InjectRepository(CustomerGroup)
    private readonly customerGroupRepository: Repository<CustomerGroup>,
    @InjectRepository(Currency)
    private readonly currencyRepository: Repository<Currency>,
    @InjectRepository(CurrencyOrder)
    private readonly currencyOrderRepository: Repository<CurrencyOrder>,
    @InjectRepository(CurrencyPair)
    private readonly currencyPairRepository: Repository<CurrencyPair>,
    private readonly accountsService: AccountsService,
    private readonly currencyPairService: CurrencyPairService,
    private readonly appConfig: AppConfigService,
    private readonly currencyService: CurrencyService,
  ) {}

  async create(createTransactionDto: CreateTransactionDto, user: LoggedAdmin, isNew: boolean): Promise<any> {
    try {
      const group = await this.customerGroupRepository.findOne({
        where: { unique_id: createTransactionDto.group_id },
      });
      if (!group) {
        return sendFailure(Messages.CustomerGroupNotFound, HttpStatus.NOT_FOUND);
      }

      let rate = createTransactionDto?.rate;
      const sellCurrency = await this.currencyRepository.findOne({
        where: { code: createTransactionDto.sell_currency },
      });
      const settlementCurrency = await this.currencyRepository.findOne({
        where: { code: createTransactionDto.settlement_currency },
      });

      if (!sellCurrency || !settlementCurrency) {
        return sendFailure(Messages.CurrencyNotExist, HttpStatus.NOT_FOUND);
      }

      if (createTransactionDto.sell_currency !== createTransactionDto.settlement_currency) {
        if (!rate) {
          return sendFailure(Errors.CurrencyPairRateNotConfigured, HttpStatus.BAD_REQUEST);
        }
        const currencyPair = await this.currencyPairRepository.findOne({
          where: {
            buy_currency_id: settlementCurrency.unique_id,
            sell_currency_id: sellCurrency.unique_id,
            is_deleted: false,
          },
        });
        if (!currencyPair) {
          return sendFailure(Messages?.CurrencyPairNotFound, HttpStatus?.OK);
        }
        // Validate currency pair existence using the common function's underlying logic
        // We don't need the returned value here, just the validation side effect (warnings/errors)
      }

      const today = (
        createTransactionDto.transferred_date ? moment(createTransactionDto.transferred_date, 'DD-MM-YYYY') : moment()
      ).format('DDMMYYYY');
      const prefix = `${group.group_id}/${today}/${createTransactionDto.settlement_currency}-TF`;

      const lastTransaction = await this.transactionRepository.findOne({
        where: { transaction_id: Like(`${prefix}%`) },
        order: { transaction_id: 'DESC' },
      });

      let newId = 1;
      if (lastTransaction) {
        const lastId = parseInt(lastTransaction.transaction_id.split('-').pop().replace('TF', ''), 10);
        newId = lastId + 1;
      }

      const account = await this.accountsService.resolveAccountId(createTransactionDto.account_id);

      const transaction_id = `${prefix}${newId.toString().padStart(3, '0')}`;
      const selectedDate = moment(createTransactionDto.transferred_date, 'DD-MM-YYYY');
      const currentTime = moment();

      const finalDateTime = selectedDate
        .hour(currentTime.hour())
        .minute(currentTime.minute())
        .second(currentTime.second())
        .millisecond(currentTime.millisecond())
        .toDate();

      let settlement_date = settlementDate(createTransactionDto?.transferred_date);
      const transaction = this.transactionRepository.create({
        group_id: createTransactionDto.group_id,
        transfer_by: createTransactionDto.transfer_by,
        sell_value: createTransactionDto.sell_value,
        trading: createTransactionDto.trading,
        remarks: createTransactionDto.remarks,
        fee: createTransactionDto.fee,
        sell_currency_id: sellCurrency?.unique_id,
        settlement_currency_id: settlementCurrency?.unique_id,
        account_id: account?.unique_id,
        transaction_id,
        rate,
        transferred_date: finalDateTime,
        settlement_date: settlement_date,
        created_by: {
          id: user.unique_id,
          name: user.user_name,
        },
        updated_by: {
          id: user.unique_id,
          name: user.user_name,
        },
      });
      const savedTransaction = await this.transactionRepository.save(transaction);

      return sendSuccess(Messages.TransactionCreated, savedTransaction);
    } catch (error) {
      this.logger.error('Error from create transaction', error);
      return commonCatch(error);
    }
  }

  async createMulti(createMultiTransactionDto: CreateMultiTransactionDto, user: LoggedAdmin): Promise<any> {
    const results = [];
    const prefixMap = new Map<string, number>();

    for (const createTransactionDto of createMultiTransactionDto.transactions) {
      try {
        const group = await this.customerGroupRepository.findOne({
          where: { unique_id: createTransactionDto.group_id },
        });
        if (!group) {
          results.push(
            sendFailure(
              `${Messages.CustomerGroupNotFound} for group_id: ${createTransactionDto.group_id}`,
              HttpStatus.NOT_FOUND,
            ),
          );
          continue;
        }

        let rate = createTransactionDto?.rate;
        const sellCurrency = await this.currencyRepository.findOne({
          where: { code: createTransactionDto.sell_currency },
        });
        const settlementCurrency = await this.currencyRepository.findOne({
          where: { code: createTransactionDto.settlement_currency },
        });

        if (!sellCurrency || !settlementCurrency) {
          results.push(
            sendFailure(
              `${Messages.CurrencyNotExist} for sell_currency: ${createTransactionDto.sell_currency} or settlement_currency: ${createTransactionDto.settlement_currency}`,
              HttpStatus.NOT_FOUND,
            ),
          );
          continue;
        }

        if (createTransactionDto.sell_currency !== createTransactionDto.settlement_currency) {
          if (!rate) {
            results.push(sendFailure(Errors.CurrencyPairRateNotConfigured, HttpStatus.BAD_REQUEST));
            continue;
          }
          const currencyPair = await this.currencyPairRepository.findOne({
            where: {
              buy_currency_id: settlementCurrency.unique_id,
              sell_currency_id: sellCurrency.unique_id,
              is_deleted: false,
            },
          });
          if (!currencyPair) {
            results.push(
              sendFailure(
                `${Messages.CurrencyPairNotFound} for ${createTransactionDto.sell_currency}-${createTransactionDto.settlement_currency}`,
                HttpStatus.OK,
              ),
            );
            continue;
          }
        }

        const today = (
          createTransactionDto.transferred_date ? moment(createTransactionDto.transferred_date, 'DD-MM-YYYY') : moment()
        ).format('DDMMYYYY');
        const prefix = `${group.group_id}/${today}/${createTransactionDto.settlement_currency}-TF`;

        if (!prefixMap.has(prefix)) {
          const lastTransaction = await this.transactionRepository.findOne({
            where: { transaction_id: Like(`${prefix}%`) },
            order: { transaction_id: 'DESC' },
          });

          let newId = 1;
          if (lastTransaction) {
            const lastId = parseInt(lastTransaction.transaction_id.split('-').pop().replace('TF', ''), 10);
            newId = lastId + 1;
          }
          prefixMap.set(prefix, newId);
        }

        const newId = prefixMap.get(prefix);
        prefixMap.set(prefix, newId + 1);

        const account = await this.accountsService.resolveAccountId(createTransactionDto.account_id);

        const transaction_id = `${prefix}${newId.toString().padStart(3, '0')}`;
        const selectedDate = moment(createTransactionDto.transferred_date, 'DD-MM-YYYY');
        const currentTime = moment();

        const finalDateTime = selectedDate
          .hour(currentTime.hour())
          .minute(currentTime.minute())
          .second(currentTime.second())
          .millisecond(currentTime.millisecond())
          .toDate();
        const settlement_date = settlementDate(createTransactionDto?.transferred_date);
        const transaction = this.transactionRepository.create({
          group_id: createTransactionDto.group_id,
          transfer_by: createTransactionDto.transfer_by,
          sell_value: createTransactionDto.sell_value,
          trading: createTransactionDto.trading,
          remarks: createTransactionDto.remarks,
          fee: createTransactionDto.fee,
          sell_currency_id: sellCurrency?.unique_id,
          settlement_currency_id: settlementCurrency?.unique_id,
          account_id: account?.unique_id,
          transaction_id,
          rate,
          transferred_date: finalDateTime,
          settlement_date: settlement_date,
          created_by: {
            id: user.unique_id,
            name: user.user_name,
          },
          updated_by: {
            id: user.unique_id,
            name: user.user_name,
          },
        });
        const savedTransaction = await this.transactionRepository.save(transaction);
        results.push(sendSuccess(Messages.TransactionCreated, savedTransaction));
      } catch (error) {
        this.logger.error(`Error processing transaction: ${JSON.stringify(createTransactionDto)}`, error);
        results.push(sendFailure(`Failed to process transaction: ${error.message}`, HttpStatus.INTERNAL_SERVER_ERROR));
      }
    }
    return sendSuccess('Multi-transaction creation process finished.', results);
  }

  async getAllTransactions(filter: FilterDto): Promise<any> {
    try {
      const baseQuery = this.transactionRepository
        .createQueryBuilder('transaction')
        .leftJoin('transaction.account', 'transaction_account')
        .leftJoin('transaction.sell_currency', 'sell_currency')
        .leftJoin('transaction.settlement_currency', 'settlement_currency')
        .leftJoin(
          'currency_pair',
          'cp',
          'cp.sell_currency_id = transaction.sell_currency_id AND cp.buy_currency_id = transaction.settlement_currency_id',
        )
        .where('transaction.is_deleted = :isDeleted', { isDeleted: false });

      /** -------------------------------
       *  Date Range Filter
       * --------------------------------*/
      if (filter?.from_date && filter?.to_date) {
        const startDate = moment(filter.from_date, 'DD-MM-YYYY').startOf('day').toDate();
        const endDate = moment(filter.to_date, 'DD-MM-YYYY').endOf('day').toDate();

        baseQuery.andWhere('transaction.transferred_date BETWEEN :start AND :end', {
          start: startDate,
          end: endDate,
        });
      }

      /** -------------------------------
       *  Dynamic Filters (Query Conditions)
       * --------------------------------*/
      if (filter?.query?.length > 0) {
        const conditions = filter.query as Condition[];

        /** Settlement Currency Filter */
        const settlementCondition = conditions.find((c) => c.fieldName === 'settlement_currency');
        if (settlementCondition) {
          if (Array.isArray(settlementCondition.fieldString)) {
            const currencies = await this.currencyRepository.find({
              where: { code: In(settlementCondition.fieldString) },
            });

            if (currencies.length > 0) {
              settlementCondition.fieldString = currencies.map((c) => c.unique_id) as any;
              settlementCondition.fieldName = 'settlement_currency_id';
            }
          } else {
            const currency = await this.currencyRepository.findOne({
              where: { code: settlementCondition.fieldString },
            });

            if (currency) {
              settlementCondition.fieldString = currency.unique_id;
              settlementCondition.fieldName = 'settlement_currency_id';
            }
          }
        }

        /** Sell Currency Filter */
        const sellCondition = conditions.find((c) => c.fieldName === 'sell_currency');
        if (sellCondition) {
          if (Array.isArray(sellCondition.fieldString)) {
            const currencies = await this.currencyRepository.find({
              where: { code: In(sellCondition.fieldString) },
            });

            if (currencies.length > 0) {
              sellCondition.fieldString = currencies.map((c) => c.unique_id) as any;
              sellCondition.fieldName = 'sell_currency_id';
            }
          } else {
            const currency = await this.currencyRepository.findOne({
              where: { code: sellCondition.fieldString },
            });

            if (currency) {
              sellCondition.fieldString = currency.unique_id;
              sellCondition.fieldName = 'sell_currency_id';
            }
          }
        }

        const whereConditions = utils.buildMysqlQuery(conditions);
        baseQuery.andWhere(whereConditions);
      }

      /** -------------------------------
       *  Count Total Records
       * --------------------------------*/
      const totalCountResult = await baseQuery.clone().select('COUNT(transaction.unique_id)', 'total').getRawOne();

      const totalCount = totalCountResult?.total ?? 0;

      /** -------------------------------
       *  Calculate Overall Amount
       * --------------------------------*/
      const overallAmountResult = await baseQuery
        .clone()
        .select(
          `SUM(
          CASE
            WHEN transaction.sell_currency_id = transaction.settlement_currency_id THEN transaction.sell_value
            ELSE
              CASE
                WHEN cp.calculation_type = 'multiply' THEN transaction.sell_value * transaction.rate
                WHEN cp.calculation_type = 'divide' THEN transaction.sell_value / transaction.rate
                ELSE transaction.sell_value
              END
          END + transaction.fee
        ) AS overall_calculated_amount`,
        )
        .getRawOne();

      const overall_calculated_amount = parseFloat(overallAmountResult?.overall_calculated_amount ?? 0).toFixed(2);

      /** -------------------------------
       *  Sorting
       * --------------------------------*/
      const sortField = filter?.sort?.field || 'created_at';
      const sortOrder = filter?.sort?.value === 'desc' ? 'DESC' : 'ASC';
      baseQuery.orderBy(`transaction.${sortField}`, sortOrder);

      /** -------------------------------
       *  Pagination
       * --------------------------------*/
      const page = filter?.cp || 1;
      const limit = filter?.pl || 10;
      const skip = (page - 1) * limit;

      baseQuery.skip(skip).take(limit);

      /** -------------------------------
       *  Select Fields
       * --------------------------------*/
      const transactions = await baseQuery
        .select([
          'transaction.unique_id AS unique_id',
          'transaction.transaction_id AS transaction_id',
          'transaction.group_id AS group_id',
          'transaction.transfer_by AS transfer_by',
          'transaction.sell_value AS sell_value',
          'sell_currency.code AS sell_currency',
          'settlement_currency.code AS settlement_currency',
          'transaction.rate AS rate',
          'transaction.fee AS fee',
          'transaction.trading AS trading',
          'transaction.remarks AS remarks',
          'transaction.updated_at AS updated_at',
          'transaction.transferred_date AS transferred_date',
          'transaction.created_at AS created_at',

          'transaction_account.unique_id AS account_unique_id',
          'transaction_account.name AS account_name',

          `ROUND(
          CASE
            WHEN sell_currency.code = settlement_currency.code THEN transaction.sell_value
            ELSE
              CASE
                WHEN cp.calculation_type = 'multiply' THEN transaction.sell_value * transaction.rate
                WHEN cp.calculation_type = 'divide' THEN transaction.sell_value / transaction.rate
                ELSE transaction.sell_value
              END
          END, 2
        ) AS calculated_amount`,
        ])
        .getRawMany();

      /** -------------------------------
       *  Group by Date
       * --------------------------------*/
      const groupedTransactions = transactions.reduce((acc, t) => {
        const date = moment(t.transferred_date).format('DD-MM-YYYY');
        if (!acc[date]) acc[date] = [];

        acc[date].push({
          ...t,
          account: {
            unique_id: t.account_unique_id,
            name: t.account_name,
          },
        });

        return acc;
      }, {});

      /** -------------------------------
       *  Date Ordering for Final Output
       * --------------------------------*/
      const finalFormattedTransactions = [];

      if (filter?.from_date && filter?.to_date) {
        const startDate = moment(filter.from_date, 'DD-MM-YYYY');
        const endDate = moment(filter.to_date, 'DD-MM-YYYY');

        for (let m = endDate; m.isSameOrAfter(startDate); m.subtract(1, 'days')) {
          const date = m.format('DD-MM-YYYY');
          finalFormattedTransactions.push({
            date,
            transactions: groupedTransactions[date] || [],
          });
        }
      } else {
        Object.keys(groupedTransactions)
          .sort((a, b) => moment(b, 'DD-MM-YYYY').diff(moment(a, 'DD-MM-YYYY')))
          .forEach((date) => {
            finalFormattedTransactions.push({
              date,
              transactions: groupedTransactions[date],
            });
          });
      }

      /** -------------------------------
       *  Return Final Response
       * --------------------------------*/
      return sendSuccess(Messages.TransactionsFetched, {
        transactions: finalFormattedTransactions,
        total_count: totalCount,
        overall_calculated_amount,
      });
    } catch (error) {
      this.logger.error(`Error from getAllTransactions with filter: ${JSON.stringify(filter)}`);
      this.logger.error(error);
      return commonCatch(error);
    }
  }

  async calculateAmount(calculateAmountDto: CalculateAmountDto): Promise<any> {
    try {
      const { date, group_id, currency } = calculateAmountDto;

      // Since this is not group-specific, we can reuse the function with null groupId
      const results = await this.calculateAmountForGroup(null, group_id, currency);

      // results will be an array with 0 or 1 element because currency is single
      if (!results || results.length === 0) {
        return sendSuccess(Messages.TransactionCalculated, {
          status: 'all_clear',
          value: 0,
          currency,
        });
      }

      const res = results[0];

      return sendSuccess(Messages.TransactionCalculated, {
        status: res.status,
        value: res.value,
        currency: res.currency,
      });
    } catch (error) {
      this.logger.error(`Error from calculateAmount with dto: ${JSON.stringify(calculateAmountDto)}`);
      this.logger.error(error);
      return commonCatch(error);
    }
  }

  findOne(id: number) {
    return `This action returns a #${id} transaction`;
  }

  async getTransactionDetails(id: string): Promise<any> {
    try {
      const transaction = await this.transactionRepository
        .createQueryBuilder('transaction')
        .leftJoin('transaction.account', 'transaction_account')
        .leftJoin('transaction.sell_currency', 'sell_currency')
        .leftJoin('transaction.settlement_currency', 'settlement_currency')
        .leftJoin(
          'currency_pair',
          'cp',
          'cp.sell_currency_id = transaction.sell_currency_id AND cp.buy_currency_id = transaction.settlement_currency_id',
        )
        .where('transaction.unique_id = :id', { id })
        .select([
          'transaction.unique_id as unique_id',
          'transaction.transaction_id as transaction_id',
          'transaction.group_id as group_id',
          'transaction.transfer_by as transfer_by',
          'transaction.sell_value as sell_value',
          'sell_currency.code as sell_currency',
          'settlement_currency.code as settlement_currency',
          'transaction.rate as rate',
          'transaction.fee as fee',
          'transaction.trading as trading',
          'transaction.remarks as remarks',
          'transaction.updated_at as updated_at',
          'transaction.transferred_date as transferred_date',
          'transaction.created_at as created_at',
          'transaction_account.unique_id as account_unique_id', // Account unique_id
          'transaction_account.name as account_name', // Account name
          `ROUND(
      CASE
        WHEN sell_currency.code = settlement_currency.code THEN transaction.sell_value
        ELSE
          CASE
            WHEN cp.calculation_type = 'multiply' THEN transaction.sell_value * transaction.rate
            WHEN cp.calculation_type = 'divide' THEN transaction.sell_value / transaction.rate
            ELSE transaction.sell_value
          END
      END, 2
    ) as calculated_amount`,
        ])
        .getRawOne();

      if (!transaction) {
        return sendFailure(Messages.TransactionNotFound, HttpStatus.NOT_FOUND);
      }

      const formattedTransaction = {
        ...transaction,
        account: {
          unique_id: transaction.account_unique_id,
          name: transaction.account_name,
        },
      };

      return sendSuccess(Messages.TransactionDetailsFetched, formattedTransaction);
    } catch (error) {
      this.logger.error(`Error from getTransactionDetails with id: ${id}`);
      this.logger.error(error);
      return commonCatch(error);
    }
  }

  async update(id: string, updateTransactionDto: UpdateTransactionDto, user: LoggedAdmin): Promise<any> {
    try {
      const transaction = await this.transactionRepository.findOne({ where: { unique_id: id, is_deleted: false } });
      if (!transaction) {
        return sendFailure(Messages.TransactionNotFound, HttpStatus.OK);
      }
      delete updateTransactionDto?.transferred_date;
      if (updateTransactionDto.account_id) {
        const account = await this.accountsService.resolveAccountId(updateTransactionDto.account_id);
        if (!account) {
          return sendFailure('Account not found', HttpStatus.BAD_REQUEST);
        }
        transaction.account_id = account.unique_id;
        transaction.account = account;
      }

      let currentSellCurrencyCode = transaction.sell_currency?.code;
      let currentSettlementCurrencyCode = transaction.settlement_currency?.code;
      let newRate = transaction.rate;

      if (updateTransactionDto.sell_currency) {
        const sellCurrency = await this.currencyRepository.findOne({
          where: { code: updateTransactionDto.sell_currency },
        });
        if (!sellCurrency) {
          return sendFailure(Messages.CurrencyNotExist, HttpStatus.NOT_FOUND);
        }
        transaction.sell_currency_id = sellCurrency.unique_id;
        transaction.sell_currency = sellCurrency;
        currentSellCurrencyCode = sellCurrency.code;
      }

      if (updateTransactionDto.settlement_currency) {
        const settlementCurrency = await this.currencyRepository.findOne({
          where: { code: updateTransactionDto.settlement_currency },
        });
        if (!settlementCurrency) {
          return sendFailure(Messages.CurrencyNotExist, HttpStatus.NOT_FOUND);
        }
        transaction.settlement_currency_id = settlementCurrency.unique_id;
        transaction.settlement_currency = settlementCurrency;
        currentSettlementCurrencyCode = settlementCurrency.code;
      }

      if (currentSellCurrencyCode !== currentSettlementCurrencyCode) {
        if (updateTransactionDto.rate === undefined && transaction.rate === undefined) {
          return sendFailure(Errors.CurrencyPairRateNotConfigured, HttpStatus.BAD_REQUEST);
        }
        newRate = updateTransactionDto.rate !== undefined ? updateTransactionDto.rate : transaction.rate;
        await this.currencyPairService.calculateAmountInSettlementCurrency(
          currentSellCurrencyCode,
          currentSettlementCurrencyCode,
          1, // dummy amount
          newRate,
        );
      }

      const { unique_id, sell_currency, settlement_currency, account_id, ...restOfDto } = updateTransactionDto;

      Object.assign(transaction, {
        ...restOfDto,
        rate: newRate,
        updated_by: {
          id: user.unique_id,
          name: user.user_name,
        },
      });

      const updatedTransaction = await this.transactionRepository.save(transaction);
      if (updatedTransaction?.sell_currency?.code !== updatedTransaction?.settlement_currency?.code) {
        updatedTransaction['calculated_amount'] = +updatedTransaction?.sell_value * +updatedTransaction?.rate;
      } else {
        updatedTransaction['calculated_amount'] = null;
      }
      return sendSuccess(Messages.TransactionUpdated, updatedTransaction);
    } catch (error) {
      this.logger.error('Error from update transaction', error);
      return commonCatch(error);
    }
  }

  async getCumulativeCurrencies(dto: CumulativeCurrencyDto): Promise<any> {
    try {
      const results = await this.transactionRepository
        .createQueryBuilder('transaction')
        .leftJoin('transaction.sell_currency', 'sell_currency')
        .leftJoin('transaction.settlement_currency', 'settlement_currency')
        .select('DISTINCT sell_currency.code', 'sell_currency')
        .where('transaction.group_id = :groupId', { groupId: dto.group_id })
        .andWhere('settlement_currency.code = :settlementCurrency', {
          settlementCurrency: dto.settlement_currency,
        })
        .andWhere('transaction.is_deleted = :isDeleted', { isDeleted: false })
        .getRawMany();

      return sendSuccess(
        'Cumulative currencies fetched successfully',
        results.map((r) => r.sell_currency),
      );
    } catch (error) {
      this.logger.error('Error from getCumulativeCurrencies', error);
      return commonCatch(error);
    }
  }

  async newCalculateAmountFromGroup(groupIds: string[], date: string | null): Promise<any[]> {
    try {
      const filterDate = date ? moment(date, 'DD-MM-YYYY') : moment();
      const endDate = filterDate.clone().endOf('day').toDate();

      const query = this.transactionRepository
        .createQueryBuilder('transaction')
        .leftJoin('transaction.sell_currency', 'sell_currency')
        .leftJoin('transaction.settlement_currency', 'settlement_currency')
        .leftJoin(
          'currency_pair',
          'pair',
          'pair.buy_currency_id = settlement_currency.unique_id AND pair.sell_currency_id = sell_currency.unique_id',
        )
        .select('settlement_currency.code', 'currency')
        .addSelect('transaction.group_id', 'groupId') // Add group_id to the select clause
        .addSelect(
          `
            SUM(
              CASE
                WHEN transaction.transfer_by = 'we'
                THEN (
                  CASE
                    WHEN sell_currency.code != settlement_currency.code
                    THEN
                      CASE
                        WHEN pair.calculation_type = 'multiply' THEN transaction.sell_value * transaction.rate
                        WHEN pair.calculation_type = 'divide' THEN transaction.sell_value / transaction.rate
                        ELSE transaction.sell_value
                      END
                    ELSE transaction.sell_value
                  END
                )
                ELSE 0
              END
            )`,
          'oweUs',
        )
        .addSelect(
          `
            SUM(
              CASE
                WHEN transaction.transfer_by = 'customer'
                THEN (
                  CASE
                    WHEN sell_currency.code != settlement_currency.code
                    THEN
                      CASE
                        WHEN pair.calculation_type = 'multiply' THEN transaction.sell_value * transaction.rate
                        WHEN pair.calculation_type = 'divide' THEN transaction.sell_value / transaction.rate
                        ELSE transaction.sell_value
                      END
                    ELSE transaction.sell_value
                  END
                )
                ELSE 0
              END
            )`,
          'weOwe',
        )
        .addSelect(
          `
            SUM(
              CASE
                WHEN transaction.transfer_by = 'we'
                THEN transaction.fee
                ELSE 0
              END
            )`,
          'oweUsFees',
        )
        .addSelect(
          `
            SUM(
              CASE
                WHEN transaction.transfer_by = 'customer'
                THEN transaction.fee
                ELSE 0
              END
            )`,
          'weOweFees',
        )
        .where('transaction.group_id IN (:...groupIds)', { groupIds }) // Use IN clause for multiple group IDs
        .andWhere('transaction.is_deleted = :isDeleted', { isDeleted: false })
        .addOrderBy('transaction.created_at', 'ASC');

      if (date) {
        query.andWhere('transaction.transferred_date <= :endDate', { endDate });
      }

      // Group by group_id first, then by settlement_currency.code
      query.groupBy('transaction.group_id').addGroupBy('settlement_currency.code');

      const rawResults = await query.getRawMany();

      return rawResults.map((row) => {
        const weOwe: number = +row.weOwe;
        const oweUs: number = +row.oweUs;
        const weOweFees: number = +row.weOweFees;
        const oweUsFees: number = +row.oweUsFees;

        const totalWeOwe = parseFloat((weOwe + weOweFees).toFixed(2));
        const totalOweUs = parseFloat((oweUs + oweUsFees).toFixed(2));

        let status: string;
        let value: number;

        if (totalWeOwe > totalOweUs) {
          status = 'we_owe';
          value = parseFloat((totalWeOwe - totalOweUs).toFixed(2));
        } else if (totalOweUs > totalWeOwe) {
          status = 'owe_us';
          value = parseFloat((totalOweUs - totalWeOwe).toFixed(2));
        } else {
          status = 'all_clear';
          value = 0.0;
        }

        return {
          groupId: row.groupId, // Include groupId in the result
          status: status,
          value: value,
          currency: row.currency,
          overall_calculated_amount: totalOweUs + totalWeOwe,
        };
      });
    } catch (error) {
      this.logger.error('Error from newCalculateAmountFromGroup', error);
      return [];
    }
  }

  remove(id: number) {
    return `This action removes a #${id} transaction`;
  }

  async updateSettlementDate(): Promise<any> {
    try {
      const transactions = await this.transactionRepository.find({
        where: { is_deleted: false },
      });

      const updatedTransactions = [];
      for (const transaction of transactions) {
        if (transaction.transferred_date) {
          const settlement_date = settlementDateUpdate(transaction.transferred_date);
          if (transaction.settlement_date !== settlement_date) {
            transaction.settlement_date = settlement_date;
            updatedTransactions.push(this.transactionRepository.save(transaction));
          }
        }
      }
      await Promise.all(updatedTransactions);
      return sendSuccess(Messages.TransactionsUpdated, {
        updated_count: updatedTransactions.length,
      });
    } catch (error) {
      this.logger.error('Error from updateSettlementDate', error);
      return commonCatch(error);
    }
  }

  async delete(id: string): Promise<any> {
    try {
      const transaction = await this.transactionRepository.findOne({ where: { unique_id: id } });
      if (!transaction) {
        return sendFailure(Messages.TransactionNotFound, HttpStatus.NOT_FOUND);
      }

      await this.transactionRepository.update({ unique_id: id }, { is_deleted: true });

      return sendSuccess(Messages.TransactionDeleted, null);
    } catch (error) {
      this.logger.error('Error from delete transaction', error);
      return commonCatch(error);
    }
  }

  async deleteMulti(ids: string[]): Promise<any> {
    try {
      if (!ids || ids.length === 0) {
        return sendFailure(Messages.TransactionNotFound, HttpStatus.BAD_REQUEST);
      }

      const result = await this.transactionRepository.update({ unique_id: In(ids) }, { is_deleted: true });

      if (result.affected === 0) {
        return sendFailure(Messages.TransactionNotFound, HttpStatus.NOT_FOUND);
      }

      return sendSuccess(Messages.TransactionsDeleted, null);
    } catch (error) {
      this.logger.error('Error from delete multi transaction', error);
      return commonCatch(error);
    }
  }

  async getTransactionCurrenciesByGroupId(groupId: string): Promise<any> {
    try {
      const results = await this.currencyOrderRepository.find({
        where: { group_id: groupId },
        order: { order: 'ASC' },
        relations: ['currency'],
      });
      const currencies = results.map((r) => {
        return r.currency?.code;
      });
      return sendSuccess('Transaction currencies fetched successfully', currencies);
    } catch (error) {
      this.logger.error('Error from getTransactionCurrenciesByGroupId', error);
      return commonCatch(error);
    }
  }

  async calculateAmountForGroup(date: string, groupId: string, currency?: string): Promise<any[]> {
    try {
      const filterDate = date ? moment(date, 'DD-MM-YYYY') : moment();

      const endDate = filterDate.clone().endOf('day').toDate();

      const query = this.transactionRepository

        .createQueryBuilder('transaction')

        .leftJoin('transaction.sell_currency', 'sell_currency')

        .leftJoin('transaction.settlement_currency', 'settlement_currency')

        .leftJoin(
          'currency_pair',
          'pair',
          'pair.buy_currency_id = settlement_currency.unique_id AND pair.sell_currency_id = sell_currency.unique_id',
        )

        .select('settlement_currency.code', 'currency')

        .addSelect(
          `
            SUM(
              CASE
                WHEN transaction.transfer_by = 'we'
                THEN (

                  CASE

                    WHEN sell_currency.code != settlement_currency.code

                    THEN

                      CASE

                        WHEN pair.calculation_type = 'multiply' THEN transaction.sell_value * transaction.rate

                        WHEN pair.calculation_type = 'divide' THEN transaction.sell_value / transaction.rate

                        ELSE transaction.sell_value

                      END

                    ELSE transaction.sell_value

                  END

                )

                ELSE 0

              END

            )`,

          'oweUs',
        )

        .addSelect(
          `

            SUM(

              CASE

                WHEN transaction.transfer_by = 'customer'

                THEN (

                  CASE

                    WHEN sell_currency.code != settlement_currency.code

                    THEN

                      CASE

                        WHEN pair.calculation_type = 'multiply' THEN transaction.sell_value * transaction.rate

                        WHEN pair.calculation_type = 'divide' THEN transaction.sell_value / transaction.rate

                        ELSE transaction.sell_value

                      END

                    ELSE transaction.sell_value

                  END

                )

                ELSE 0

              END

            )`,

          'weOwe',
        )

        .addSelect(
          `

            SUM(

              CASE

                WHEN transaction.transfer_by = 'we'

                THEN transaction.fee

                ELSE 0

              END

            )`,

          'oweUsFees',
        )

        .addSelect(
          `

            SUM(

              CASE

                WHEN transaction.transfer_by = 'customer'

                THEN transaction.fee

                ELSE 0

              END

            )`,

          'weOweFees',
        )

        .where('transaction.group_id = :groupId', { groupId })

        .andWhere('transaction.is_deleted = :isDeleted', { isDeleted: false })

        .addOrderBy('transaction.created_at', 'ASC');

      if (date) {
        query.andWhere('transaction.transferred_date <= :endDate', { endDate });
      }

      if (currency) {
        query.andWhere('settlement_currency.code = :currency', { currency });
      }

      query.groupBy('settlement_currency.code');

      const rawResults = await query.getRawMany();

      return rawResults.map((row) => {
        const weOwe: number = +row.weOwe;

        const oweUs: number = +row.oweUs;

        const weOweFees: number = +row.weOweFees;

        const oweUsFees: number = +row.oweUsFees;

        const totalWeOwe = parseFloat((weOwe + weOweFees).toFixed(2));

        const totalOweUs = parseFloat((oweUs + oweUsFees).toFixed(2));

        if (totalWeOwe > totalOweUs) {
          return {
            status: 'we_owe',

            value: parseFloat((totalWeOwe - totalOweUs).toFixed(2)),

            currency: row.currency,

            overall_calculated_amount: totalOweUs + totalWeOwe,
          };
        } else if (totalOweUs > totalWeOwe) {
          return {
            status: 'owe_us',

            value: parseFloat((totalOweUs - totalWeOwe).toFixed(2)),

            currency: row.currency,

            overall_calculated_amount: totalOweUs + totalWeOwe,
          };
        } else {
          return {
            status: 'all_clear',

            value: 0.0,

            currency: row.currency,

            overall_calculated_amount: totalOweUs + totalWeOwe,
          };
        }
      });
    } catch (error) {
      this.logger.error('Error from calculateAmountForGroup', error);
    }
  }

  async listBasedOnGroupCurrency(listDto: ListGroupCurrencyDto): Promise<any> {
    try {
      let startDate, endDate;
      const tz = await this.appConfig.applicationDefaults.timezone;
      let day: string;
      if (listDto?.day_filter) {
        const settlement_date = settlementDate(listDto.day_filter);
        const selectedDate = moment.tz(settlement_date, 'DD-MM-YYYY', tz);
        if (selectedDate.isSame(moment.tz(tz), 'day')) {
          day = 'today';
        } else {
          day = 'yesterday';
        }
        startDate = selectedDate.hour(6).minute(0).second(0).millisecond(0).toDate();
        endDate = selectedDate.add(1, 'day').hour(5).minute(30).second(0).millisecond(0).toDate();
      }

      const result = await this.calculateAmountForGroupByDateRange(
        listDto?.day_filter,
        listDto?.group_id,
        listDto?.currency_id,
      );
      const finalResult = {
        grouped_currency: result,
        day: day,
        start_date: convertUTCToSingapore(startDate),
        end_date: convertUTCToSingapore(endDate),
      };
      return sendSuccess('Group with currency calculation fetched successfully', finalResult);
      // return sendSuccess('Group with currency calculation fetched successfully', finalResult);
    } catch (error) {
      this.logger.error('Error from listBasedOnGroupCurrency', error);
      return commonCatch(error);
    }
  }

  async calculateAmountForGroupByDateRange(
    settlement_date: string,
    groupId?: string | string[],
    currencyId?: string | string[],
  ): Promise<any[]> {
    try {
      const query = this.transactionRepository
        .createQueryBuilder('order_transaction')
        .leftJoin('customer_groups', 'grp', 'grp.unique_id = order_transaction.group_id')
        .leftJoin('order_transaction.sell_currency', 'sell_currency')
        .leftJoin('order_transaction.settlement_currency', 'settlement_currency')
        // ❌ removed currency_pair join completely

        .select('grp.unique_id', 'group_unique_id')
        .addSelect('grp.group_id', 'group_code')
        .addSelect('grp.name', 'group_name')

        /* use SELL CURRENCY instead of SETTLEMENT */
        .addSelect('sell_currency.code', 'sell_currency_code')
        .addSelect('sell_currency.unique_id', 'sell_currency_id')

        /* ======================== AMOUNTS ======================== */

        // transfer_by = we → oweUs
        .addSelect(
          `
        SUM(
          CASE WHEN order_transaction.transfer_by = 'we'
            THEN order_transaction.sell_value
            ELSE 0
          END
        )
        `,
          'oweUs',
        )
        // transfer_by = customer → weOwe
        .addSelect(
          `
        SUM(
          CASE WHEN order_transaction.transfer_by = 'customer'
            THEN order_transaction.sell_value
            ELSE 0
          END
        )
        `,
          'weOwe',
        )

        // fees separately
        .addSelect(
          `SUM(CASE WHEN order_transaction.transfer_by = 'we' THEN order_transaction.fee ELSE 0 END)`,
          'oweUsFees',
        )
        .addSelect(
          `SUM(CASE WHEN order_transaction.transfer_by = 'customer' THEN order_transaction.fee ELSE 0 END)`,
          'weOweFees',
        )

        /* ======================== RAW TOTALS (unchanged) ======================== */

        .addSelect(`SUM(order_transaction.sell_value)`, 'beforeConversionSellValue')
        .addSelect(`SUM(order_transaction.fee)`, 'beforeConversionFee')
        .addSelect(`SUM(order_transaction.sell_value + order_transaction.fee)`, 'beforeConversionTotal')

        .andWhere('order_transaction.is_deleted = :isDeleted', { isDeleted: false })
        .andWhere('order_transaction.settlement_date = :settlement_date', { settlement_date })
        .andWhere('order_transaction.trading != :tradeType', { tradeType: 'adjustment' });

      /* ======================== GROUP FILTER ======================== */
      if (groupId) {
        if (Array.isArray(groupId)) {
          query.andWhere('order_transaction.group_id IN (:...groupIds)', { groupIds: groupId });
        } else {
          query.andWhere('order_transaction.group_id = :groupId', { groupId });
        }
      }

      /* ======================== CURRENCY FILTER (USE SELL CURRENCY) ======================== */
      if (currencyId) {
        if (Array.isArray(currencyId)) {
          query.andWhere('sell_currency.unique_id IN (:...currencyIds)', { currencyIds: currencyId });
        } else {
          query.andWhere('sell_currency.unique_id = :currencyId', { currencyId });
        }
      }

      /* ======================== GROUPING (USE SELL CURRENCY) ======================== */
      query.groupBy('grp.unique_id').addGroupBy('sell_currency.code');

      const rawResults = await query.getRawMany();
      const groupedResult: Record<string, any> = {};

      rawResults.forEach((row) => {
        const groupKey = row.group_unique_id;

        if (!groupedResult[groupKey]) {
          groupedResult[groupKey] = {
            group_unique_id: row.group_unique_id,
            group_code: row.group_code,
            group_name: row.group_name,
            currencies: [],
          };
        }

        const weOwe = +row.weOwe;
        const oweUs = +row.oweUs;
        const weOweFees = +row.weOweFees;
        const oweUsFees = +row.oweUsFees;

        /* ======================== CALCULATIONS ======================== */
        const totalWeOwe = +(weOwe + weOweFees).toFixed(2);
        const totalOweUs = +(oweUs + oweUsFees).toFixed(2);
        const grandTotal = +(totalWeOwe + totalOweUs).toFixed(2);

        const beforeConversionSellValue = +row.beforeConversionSellValue;
        const beforeConversionFee = +row.beforeConversionFee;
        const beforeConversionTotal = +row.beforeConversionTotal;

        groupedResult[groupKey].currencies.push({
          settlement_currency_id: row.sell_currency_id,
          settlement_currency_code: row.sell_currency_code,

          weOwe: +weOwe.toFixed(2),
          oweUs: +oweUs.toFixed(2),
          weOweFees: +weOweFees.toFixed(2),
          oweUsFees: +oweUsFees.toFixed(2),

          totalWeOwe,
          totalOweUs,
          grandTotal,

          sell_value: +(weOwe + oweUs).toFixed(2),
          fee: +(weOweFees + oweUsFees).toFixed(2),

          beforeConversionSellValue: +beforeConversionSellValue.toFixed(2),
          beforeConversionFee: +beforeConversionFee.toFixed(2),
          beforeConversionTotal: +beforeConversionTotal.toFixed(2),
        });
      });

      return Object.values(groupedResult);
    } catch (error) {
      this.logger.error('Error from calculateAmountForOrderGroupByDateRange', error);
      return [];
    }
  }

  async calculateAmountForGroupListing(date: any, groupId: string, currency?: string): Promise<any[]> {
    try {
      const endDate = date;

      const query = this.transactionRepository
        .createQueryBuilder('transaction')
        .leftJoin('transaction.sell_currency', 'sell_currency')
        .leftJoin('transaction.settlement_currency', 'settlement_currency')
        .leftJoin(
          'currency_pair',
          'pair',
          'pair.buy_currency_id = settlement_currency.unique_id AND pair.sell_currency_id = sell_currency.unique_id',
        )
        .select('settlement_currency.code', 'currency')

        .addSelect(
          `
        SUM(
          CASE
            WHEN transaction.transfer_by = 'we'
            THEN (
              CASE
                WHEN sell_currency.code != settlement_currency.code
                THEN
                  CASE
                    WHEN pair.calculation_type = 'multiply' THEN transaction.sell_value * transaction.rate
                    WHEN pair.calculation_type = 'divide' THEN transaction.sell_value / transaction.rate
                    ELSE transaction.sell_value
                  END
                ELSE transaction.sell_value
              END
            )
            ELSE 0
          END
        )`,
          'oweUs',
        )

        .addSelect(
          `
        SUM(
          CASE
            WHEN transaction.transfer_by = 'customer'
            THEN (
              CASE
                WHEN sell_currency.code != settlement_currency.code
                THEN
                  CASE
                    WHEN pair.calculation_type = 'multiply' THEN transaction.sell_value * transaction.rate
                    WHEN pair.calculation_type = 'divide' THEN transaction.sell_value / transaction.rate
                    ELSE transaction.sell_value
                  END
                ELSE transaction.sell_value
              END
            )
            ELSE 0
          END
        )`,
          'weOwe',
        )

        .addSelect(
          `
        SUM(
          CASE
            WHEN transaction.transfer_by = 'we'
            THEN transaction.fee
            ELSE 0
          END
        )`,
          'oweUsFees',
        )

        .addSelect(
          `
        SUM(
          CASE
            WHEN transaction.transfer_by = 'customer'
            THEN transaction.fee
            ELSE 0
          END
        )`,
          'weOweFees',
        )

        .where('transaction.group_id = :groupId', { groupId })
        .andWhere('transaction.is_deleted = :isDeleted', { isDeleted: false })

        .andWhere('transaction.transferred_date <= :endDate', { endDate });

      if (currency) {
        query.andWhere('settlement_currency.code = :currency', { currency });
      }

      query.groupBy('settlement_currency.code');
      query.addOrderBy('transaction.created_at', 'ASC');

      const rawResults = await query.getRawMany();

      return rawResults.map((row) => {
        const weOwe = +row.weOwe;
        const oweUs = +row.oweUs;
        const weOweFees = +row.weOweFees;
        const oweUsFees = +row.oweUsFees;

        const totalWeOwe = parseFloat((weOwe + weOweFees).toFixed(2));
        const totalOweUs = parseFloat((oweUs + oweUsFees).toFixed(2));

        if (totalWeOwe > totalOweUs) {
          return {
            status: 'we_owe',
            value: parseFloat((totalWeOwe - totalOweUs).toFixed(2)),
            currency: row.currency,
            overall_calculated_amount: totalOweUs + totalWeOwe,
          };
        } else if (totalOweUs > totalWeOwe) {
          return {
            status: 'owe_us',
            value: parseFloat((totalOweUs - totalWeOwe).toFixed(2)),
            currency: row.currency,
            overall_calculated_amount: totalOweUs + totalWeOwe,
          };
        } else {
          return {
            status: 'all_clear',
            value: 0.0,
            currency: row.currency,
            overall_calculated_amount: totalOweUs + totalWeOwe,
          };
        }
      });
    } catch (error) {
      this.logger.error('Error from calculateAmountForGroup', error);
    }
  }

  async getTransactionsByGroupAndCurrency(getTransactionDto: GetTransactionDto): Promise<object> {
    try {
      const currency: any = await this.currencyService.findOne({
        where: { code: getTransactionDto.settlement_currency },
      });

      if (!currency) {
        return sendFailure(Messages.CurrencyNotExist, HttpStatus.NOT_FOUND);
      }

      const current_day_summary = await this.calculateAmountForGroup(
        null,
        getTransactionDto?.group_id,
        getTransactionDto?.settlement_currency,
      );

      let now = moment().format('DD-MM-YYYY');
      const settlement_date = settlementDate(now);
      // Today time ranges
      // const todayStart = now.clone().hour(10).minute(0).second(0).millisecond(0);
      // const todayEnd = now.clone().add(1, 'day').hour(9).minute(30).second(0).millisecond(0);

      // // Yesterday time ranges
      // const yesterdayStart = now.clone().subtract(1, 'day').hour(10).minute(0).second(0).millisecond(0);
      // const yesterdayEnd = now.clone().hour(9).minute(30).second(0).millisecond(0);

      // let transactionListStartDate: Date;
      // let transactionListEndDate: Date;

      // // If current time > today's 10:00 AM → use today range
      // if (now.isBetween(todayStart, todayEnd)) {
      //   transactionListStartDate = todayStart.toDate();
      //   transactionListEndDate = todayEnd.toDate();
      // }
      // // Else → use yesterday range
      // else {
      //   transactionListStartDate = yesterdayStart.toDate();
      //   transactionListEndDate = yesterdayEnd.toDate();
      // }
      const previous = moment(settlement_date, 'DD-MM-YYYY').hour(5).minute(30).second(0).millisecond(0).toDate();

      const previous_day_summary = await this.calculateAmountForGroupListing(
        previous,
        getTransactionDto?.group_id,
        getTransactionDto?.settlement_currency,
      );

      const baseQuery = this.transactionRepository
        .createQueryBuilder('transaction')
        .leftJoin('transaction.account', 'transaction_account')
        .leftJoin('transaction.sell_currency', 'sell_currency')
        .leftJoin('transaction.settlement_currency', 'settlement_currency')
        .leftJoin(
          'currency_pair',
          'cp',
          'cp.sell_currency_id = transaction.sell_currency_id AND cp.buy_currency_id = transaction.settlement_currency_id',
        )
        .where('transaction.group_id = :groupId', { groupId: getTransactionDto.group_id })
        .andWhere('transaction.settlement_currency_id = :currencyId', { currencyId: currency.unique_id })
        .andWhere('transaction.settlement_date = :endDate', {
          endDate: settlement_date,
        })
        .andWhere('transaction.is_deleted = :isDeleted', { isDeleted: false });

      const transactions = await baseQuery
        .select([
          'transaction.unique_id AS unique_id',
          'transaction.transaction_id AS transaction_id',
          'transaction.group_id AS group_id',
          'transaction.transfer_by AS transfer_by',
          'transaction.sell_value AS sell_value',
          'transaction.settlement_date AS settlement_date',
          'sell_currency.code AS sell_currency',
          'settlement_currency.code AS settlement_currency',
          'transaction.rate AS rate',
          'transaction.fee AS fee',
          'transaction.trading AS trading',
          'transaction.remarks AS remarks',
          'transaction.updated_at AS updated_at',
          'transaction.transferred_date AS transferred_date',
          'transaction.created_at AS created_at',
          'transaction_account.unique_id AS account_unique_id',
          'transaction_account.name AS account_name',

          // ⭐ UPDATED CALCULATED AMOUNT WITH FEE ADDED
          `ROUND(
      (
        CASE
          WHEN sell_currency.code = settlement_currency.code THEN transaction.sell_value
          ELSE
            CASE
              WHEN cp.calculation_type = 'multiply' THEN transaction.sell_value * transaction.rate
              WHEN cp.calculation_type = 'divide' THEN transaction.sell_value / transaction.rate
              ELSE transaction.sell_value
            END
        END
        + transaction.fee
      ),
      2
    ) AS calculated_amount`,
        ])
        .orderBy('transaction.created_at', 'ASC')
        .getRawMany();

      let running_balance = previous_day_summary[0]?.value || 0;
      let running_status: 'we_owe' | 'owe_us' | 'all_clear' = previous_day_summary[0]?.status || 'all_clear';

      const processedTransactions = transactions.map((t) => {
        const { newAmount, newStatus } = this.calculateRunningBalance(
          running_balance,
          running_status,
          +t.calculated_amount,
          t.transfer_by,
        );

        running_balance = +newAmount;
        running_status = newStatus;

        return {
          ...t,
          running_balance: running_balance,
          running_status: newStatus,
          account: {
            unique_id: t.account_unique_id,
            name: t.account_name,
          },
        };
      });

      return sendSuccess(Messages.TransactionsFetched, {
        summary_till_yesterday: previous_day_summary[0] || {
          status: 'all_clear',
          value: 0,
          currency: getTransactionDto.settlement_currency,
        },
        transactions: processedTransactions,
        summary_today: current_day_summary[0] || {
          status: 'all_clear',
          value: 0,
          currency: getTransactionDto.settlement_currency,
        },
      });
    } catch (error) {
      this.logger.error('Error fetching transactions', error);
      return commonCatch(error);
    }
  }

  private calculateRunningBalance(
    previous_amount: number,
    previous_status: 'we_owe' | 'owe_us' | 'all_clear',
    calculated_amount: number,
    transferBy: 'we' | 'customer',
  ): { newAmount: number; newStatus: 'we_owe' | 'owe_us' | 'all_clear' } {
    let newAmount: number;
    let newStatus: 'we_owe' | 'owe_us' | 'all_clear';

    // Rule 1: If previous_status = "we_owe"
    if (previous_status === 'we_owe') {
      if (transferBy === 'customer') {
        newAmount = +previous_amount + +calculated_amount;
        newStatus = 'we_owe';
      } else {
        // transferBy = "we"
        newAmount = +previous_amount - +calculated_amount;
        if (newAmount > 0) {
          newStatus = 'we_owe';
        } else if (newAmount === 0) {
          newStatus = 'all_clear';
        } else {
          // newAmount < 0
          newStatus = 'owe_us';
          newAmount = +Math.abs(+newAmount);
        }
      }
    }
    // Rule 2: If previous_status = "owe_us"
    else if (previous_status === 'owe_us') {
      if (transferBy === 'we') {
        newAmount = +previous_amount + +calculated_amount;
        newStatus = 'owe_us';
      } else {
        // transferBy = "customer"
        newAmount = +previous_amount - +calculated_amount;
        if (newAmount > 0) {
          newStatus = 'owe_us';
        } else if (newAmount === 0) {
          newStatus = 'all_clear';
        } else {
          // newAmount < 0
          newStatus = 'we_owe';
          newAmount = +Math.abs(+newAmount);
        }
      }
    }
    // Rule 3: If previous_status = "all_clear"
    else {
      // previous_status === "all_clear"
      if (transferBy === 'we') {
        newAmount = +calculated_amount;
        newStatus = 'owe_us';
      } else {
        // transferBy = "customer"
        newAmount = +calculated_amount;
        newStatus = 'we_owe';
      }
    }

    // Ensure newAmount is always positive or zero, as negative is handled by status
    newAmount = +newAmount?.toFixed(2);
    if (newAmount < 0) {
      newAmount = +Math.abs(+newAmount);
    }

    return { newAmount, newStatus };
  }
}
