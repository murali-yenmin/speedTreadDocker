import axios, { AxiosResponse } from 'axios';
import requestIp from 'request-ip';
import { Request } from 'express';

interface APIResponse {
  status: number;
  data?: any;
}

export async function requestApi(
  url: string,
  method: string,
  body?: any,
  headers: object = { 'Content-Type': 'application/json' },
): Promise<APIResponse> {
  try {
    const response = await axios.request<AxiosResponse>({ url, method, data: body, headers: headers });
    return { status: response.status, data: response.data };
  } catch (error) {
    return { status: 500 };
  }
}

export function getRequestIp(request: Request): string {
  const req = request as any;

  let ip: string =
    req.headers['cf-connecting-ip'] ||
    requestIp.getClientIp(req) ||
    request.headers['x-forwarded-for'] ||
    request.headers['X-Forwarded-For'] ||
    request.headers['X-Real-IP'] ||
    request.headers['x-real-ip'] ||
    req?.ip ||
    req?.raw?.connection?.remoteAddress ||
    req?.raw?.socket?.remoteAddress ||
    undefined;
  if (ip && ip.split(',').length > 0) ip = ip.split(',')[0];

  return ip;
}
