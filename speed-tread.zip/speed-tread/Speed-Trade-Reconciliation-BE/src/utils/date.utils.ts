import * as moment from 'moment-timezone';
import { Mode } from 'src/constants/app.constant';
import { EmailSubject, EmailTemplates, EmailVariables } from 'src/constants/email.constants';

export function addMinutes(minutes: number): Date {
  return moment().tz(process.env.DEFAULT_TIMEZONE).add(minutes, 'm').toDate();
}

export function addDays(days: number): Date {
  return moment().tz(process.env.DEFAULT_TIMEZONE).add(days, 'days').toDate();
}

export function getTimeStamp(minutes: number, type: moment.unitOfTime.DurationConstructor): number {
  return moment().tz(process.env.DEFAULT_TIMEZONE).add(minutes, type).unix();
}

export const buildDateFilter = (years?: number[] | number, months?: number[]): Record<string, any> => {
  const filter: any = {};

  const yearList = Array.isArray(years) ? years : years ? [years] : [];

  if (yearList.length > 0 && Array.isArray(months) && months.length > 0) {
    const dateFilters = yearList.flatMap((year) =>
      months.map((month: number) => {
        const start = moment
          .utc({ year, month: month - 1 })
          .startOf('month')
          .toDate();
        const end = moment
          .utc({ year, month: month - 1 })
          .endOf('month')
          .toDate();
        return { paid_date: { $gte: start, $lte: end } };
      }),
    );
    filter.$or = dateFilters;
  } else if (yearList.length > 0) {
    const dateFilters = yearList.map((year) => {
      const start = moment.utc({ year }).startOf('year').toDate();
      const end = moment.utc({ year }).endOf('year').toDate();
      return { paid_date: { $gte: start, $lte: end } };
    });
    filter.$or = dateFilters;
  }

  return filter;
};
interface DateRange {
  fromDate: string;
  toDate: string;
  field: string;
}

export function dateRangeFilter({ fromDate, toDate, field }: DateRange) {
  return {
    [field]: {
      $gte: moment.utc(fromDate, 'YYYY-MM-DD').startOf('day').toDate(),
      $lte: moment.utc(toDate, 'YYYY-MM-DD').endOf('day').toDate(),
    },
  };
}

export function isCardExpiredYesterday(month: number, year: number): { value: boolean; date } {
  const expiryDate = moment(`${year}-${month}`, 'YYYY-MM').endOf('month');
  const yesterday = moment().subtract(1, 'day').startOf('day');
  return { value: expiryDate.isSame(yesterday, 'day'), date: expiryDate };
}
