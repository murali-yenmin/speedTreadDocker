import { IsNotEmpty, IsNumber, IsDateString, ValidateIf } from 'class-validator';

export class DashboardFilterDto {
  @ValidateIf((o) => !o.start_date && !o.end_date)
  @IsNotEmpty()
  days: 'last_12_months' | string;

  @ValidateIf((o) => !o.days)
  @IsNotEmpty()
  @IsDateString()
  start_date: string;

  @ValidateIf((o) => !o.days)
  @IsNotEmpty()
  @IsDateString()
  end_date: string;
}
