export const sendWelcomeEmail = (user, mailService, generatePassword) => {
  const url = process.env.SITE_URL;
  return mailService.sendMail({
    from: `"${process.env.APP_NAME}" <${process.env.EMAIL_ADDRESS}>`,
    to: user?.email_address,
    subject: `Welcome to ${process.env.APP_NAME} – Your Account Has Been Created`,
    text: `Welcome to ${process.env.APP_NAME}`,
    html: `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="color-scheme" content="light" />
    <meta name="supported-color-schemes" content="light" />
    <link
      href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600;700&display=swap"
      rel="stylesheet"
    />
    <title>Legaligence Onboard</title>
    <style>
      body {
        margin: 0;
        font-family: "Montserrat";
        padding: 0;
      }
      .main-table {
        max-width: 650px !important;
        margin: 0 auto;
        padding: 0;
      }

      .sub-table {
        max-width: 530px !important;
        margin: 0 auto;
        padding: 0;
      }

      @media only screen and (max-width: 480px) {
        .main-table {
          max-width: 650px !important;
          margin: 0 auto;
          padding: 0;
        }
      }
    </style>
  </head>

  <body style="margin: 0; padding: 0; background: #f7f7f7">
    <table
      align="center"
      border="0"
      cellspacing="0"
      cellpadding="0"
      class="main-table"
    >
      <tr>
        <td style="background-color: #ffffff">
          <table align="center" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td>
                <table
                  style="
                    width: 650px;
                    margin: 0 auto;
                    padding: 32px 0px;
                    border-bottom: 1px solid black;
                  "
                >
                  <tr align="center">
                    <td>
                      <img
                        src="${process.env.SITE_URL}/images/logo.png"
                        alt="Logo"
                        style="text-align: center"
                      />
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr valign="top">
              <td align="center">
                <p
                  style="
                    font-family: Montserrat, Helvetica, sans-serif;
                    font-size: 18px;
                    font-weight: 400;
                    color: #393939;
                    margin: 0px;
                    line-height: 22px;
                    text-align: center;
                    padding-top: 32px;
                  "
                >
                  Hi
                  <span style="color: #b34350; font-weight: bold"
                    >${user.user_name ?? 'Guest'},</span
                  >
                </p>
              </td>
            </tr>
          </table>
          <table
            align="center"
            border="0"
            cellspacing="0"
            cellpadding="0"
            class="sub-table"
          >
            <tr align="center">
              <td>
                <table style="width: 530px; margin: 0 auto">
                  <tr>
                    <td>
                      <p
                        style="
                          font-family: Montserrat, Helvetica, sans-serif;
                          font-size: 16px;
                          font-weight: 400;
                          color: #393939;
                          margin-top: 16px;
                          margin-bottom: 32px;
                          line-height: 22px;
                          text-align: center;
                        "
                      >
                        Welcome to Speed Trade Reconciliation. Use your credentials to log in and get started with managing trades and reconciliations.
                      </p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td>  <table
                  align="center"
                  width="100%"
                  cellpadding="0"
                  cellspacing="0"
                >
                  <tr>
                    <td align="center">
                      <table
                        width="500"
                        cellpadding="20"
                        cellspacing="0"
                        bgcolor="#e97e86ff"
                        style="
                          border-radius: 10px;
                          text-align: left;
                          font-family: Arial, sans-serif;
                          font-size: 16px;
                          color: #333;
                          background-color: #e5e5e5;
                          line-height: 1.6;
                        "
                      >
                        <tr>
                          <td style="text-align: left">
                            <p style="color: #000000">
                              <strong>Email:</strong> ${user?.email_address}
                            </p>
                            <p style="color: #000000">
                              <strong>Password:</strong> ${generatePassword}
                            </p>
                             <p style="color: #554f4f; font-size: 14px;">
                             Please make sure to change your password after your first login for security reasons.
                            </p>
                          </td>
                        </tr>

                      </table>
                    </td>
                  </tr>
                </table></td>
            </tr>
            <tr>
              <td>
                <p
                  style="
                    font-size: 16px;
                    font-weight: 400;
                    color: #5a3d2b;
                    margin: 32px 0px;
                    line-height: 22px;
                    text-align: center;
                  "
                >
                  Thanks,<br />
                  <span style="color: #9a252d; font-weight: bold"
                    >${process.env.APP_NAME} Team</span
                  >
                </p>
              </td>
            </tr>
            <tr>
              <td>
                <table
                  style="
                    width: 650px;
                    margin: 0 auto;
                    padding: 16px 0px;
                    background-color: #9a252d;
                  "
                  align="center"
                >
                  <tr>
                    <td>
                      <table
                        width="500"
                        align="center"
                        style="table-layout: fixed; font-size: 12px"
                      >
                        <tr valign="middle">
                          <td width="33%" style="line-height: 16px">
                            <a
                              href="tel:${process.env.CONTACT_PHONE}"
                              style="
                                font-family: Montserrat, Helvetica, sans-serif;
                                font-size: 14px;
                                font-weight: 500;
                                color: #a3a3a3;
                                text-decoration: none;
                              "
                            >
                              ${process.env.CONTACT_PHONE}
                            </a>
                          </td>
                          <td width="33%" style="line-height: 16px">
                            <a
                              href="${process.env.SITE_URL}"
                              target="_blank"
                              style="
                                font-family: Montserrat, Helvetica, sans-serif;
                                font-size: 14px;
                                font-weight: 500;
                                color: #a3a3a3;
                                text-decoration: none;
                              "
                            >
                              ${process.env.SITE_URL}
                            </a>
                          </td>
                          <td width="33%" style="line-height: 16px">
                            <a
                              href="mailto:${process.env.CONTACT_EMAIL}"
                              style="
                                font-family: Montserrat, Helvetica, sans-serif;
                                font-size: 14px;
                                font-weight: 500;
                                color: #a3a3a3;
                                text-decoration: none;
                              "
                            >
                              ${process.env.CONTACT_EMAIL}
                            </a>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="border-width: 0">
          <table
            style="
              border-width: 0;
              width: 100%;
              min-width: 100%;
              background-color: #242424;
              color: #fffffe;
            "
            cellpadding="0"
            cellspacing="0"
            role="none"
          >
            <tr>
              <td
                style="
                  border-width: 0;
                  padding: 16px 0;
                  text-align: center;
                  font-size: 12px;
                "
              >
                © 2025 Speed Trade Reconciliation. All rights reserved.
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>
`,
  });
};
