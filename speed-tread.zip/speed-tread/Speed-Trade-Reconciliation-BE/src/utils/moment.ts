import * as moment from 'moment-timezone';
moment.tz.setDefault('Asia/Singapore');
export default moment;

export function convertUTCToSingapore(dateString: string) {
  return moment.utc(dateString).tz('Asia/Singapore').format('YYYY-MM-DD HH:mm:ss');
}

export function settlementDate(transferred_date) {
  let settlement_date;
  // Parse transferred date and get today's date in Asia/Singapore timezone
  const transferred = moment(transferred_date, 'DD-MM-YYYY').tz('Asia/Singapore');

  const today = moment().tz('Asia/Singapore');
  const todayDateOnly = moment().tz('Asia/Singapore').startOf('day');
  // Get current time
  const currentHour = today.hour();
  const currentMinute = today.minute();
  // Check if transferred date === today date
  if (transferred.isSame(todayDateOnly, 'day')) {
    if (currentHour < 5 || (currentHour === 5 && currentMinute <= 30)) {
      // settlement date = yesterday date
      settlement_date = today.subtract(1, 'day').format('DD-MM-YYYY');
    } else {
      settlement_date = today.format('DD-MM-YYYY');
    }
  }
  // Check if transferred date < today date
  else if (transferred.isBefore(todayDateOnly, 'day')) {
    // If difference is more than 1 day, settlement date = transferred date
    settlement_date = transferred.format('DD-MM-YYYY');
  }

  // transferred date > today date
  else {
    settlement_date = transferred.format('DD-MM-YYYY');
  }
  return settlement_date;
}

export function settlementDateUpdate(transferred_date) {
  const transferred = moment.tz(transferred_date, 'YYYY-MM-DD HH:mm', 'Asia/Singapore');
  const hour = transferred.hour();
  const minute = transferred.minute();

  // Between 00:00 and 05:30 → previous date
  if (hour < 5 || (hour === 5 && minute <= 30)) {
    return transferred.clone().subtract(1, 'day').format('DD-MM-YYYY');
  }

  // Otherwise, same date
  return transferred.format('DD-MM-YYYY');

  // Business window
}

// export function settlementDate(transferred_date) {
//   let settlement_date;

//   // Force current time to behave like 05-12-2025 01:30 SG time
//   const now = moment.tz('05-12-2025 01:30', 'DD-MM-YYYY HH:mm', 'Asia/Singapore');

//   const transferred = moment.tz(transferred_date, 'DD-MM-YYYY', 'Asia/Singapore');
//   const todayDateOnly = now.clone().startOf('day');

//   const currentHour = now.hour();
//   const currentMinute = now.minute();

//   // If transferred date == today
//   if (transferred.isSame(todayDateOnly, 'day')) {
//     if (currentHour < 5 || (currentHour === 5 && currentMinute <= 30)) {
//       // settlement = yesterday
//       settlement_date = now.clone().subtract(1, 'day').format('DD-MM-YYYY');
//     } else {
//       settlement_date = now.format('DD-MM-YYYY');
//     }
//   }
//   // If transferred date < today
//   else if (transferred.isBefore(todayDateOnly, 'day')) {
//     settlement_date = transferred.format('DD-MM-YYYY');
//   }
//   // transferred date > today
//   else {
//     settlement_date = transferred.format('DD-MM-YYYY');
//   }

//   return settlement_date;
// }
