import { IsNotEmpty, IsOptional } from 'class-validator';
export class paginationDto {
  @IsNotEmpty()
  currentPage: number;

  @IsNotEmpty()
  pageSize: number;

  @IsOptional()
  sort: Record<string, any>;

  @IsOptional()
  filter: FilterObject[];
}

interface FilterObject {
  key: string;
  value: any;
}
