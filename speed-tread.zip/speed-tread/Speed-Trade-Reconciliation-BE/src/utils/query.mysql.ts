import { ILike, FindOptionsWhere, In } from 'typeorm';

interface Condition {
  operation: string; // "%" or "eq"
  fieldName: string; // column name
  fieldString: string; // value
}

export function buildMysqlQuery<T>(conditions: Condition[]): FindOptionsWhere<T> | FindOptionsWhere<T>[] {
  const andConditions: FindOptionsWhere<T> = {};
  const orConditions: FindOptionsWhere<T>[] = [];

  conditions.forEach((cond) => {
    const { operation, fieldName, fieldString } = cond;

    if (operation === '%') {
      // LIKE query
      orConditions.push({ [fieldName]: ILike(`%${fieldString}%`) } as FindOptionsWhere<T>);
    } else if (operation === 'eq') {
      // Exact match or IN query if fieldString is an array
      if (Array.isArray(fieldString)) {
        andConditions[fieldName] = In(fieldString) as any;
      } else {
        andConditions[fieldName] = fieldString as any;
      }
    }
  });

  if (orConditions.length > 0) {
    // TypeORM supports OR conditions via `where: [ {}, {} ]`
    return [...orConditions.map((c) => ({ ...andConditions, ...c }))];
  }

  return andConditions;
}

export function buildOrderBy(
  alias: string,
  sortField?: string,
  sortOrder: 'ASC' | 'DESC' = 'ASC'
): { field: string; order: 'ASC' | 'DESC' } | undefined {
  if (!sortField) return undefined;

  // If FE already sends with alias (e.g. "user.updated_at"), keep it
  const field = sortField.includes('.') ? sortField : `${alias}.${sortField}`;

  return { field, order: sortOrder };
}
