import { HttpStatus } from '@nestjs/common';
import { Errors } from 'src/message-constants/error.constants';

interface ApiResponse<T> {
  status: boolean;
  statusCode: number;
  message: string;
  data: T | null;
  error: T | null | string;
  args: null | Record<string, string>;
}

export function sendSuccess<T>(
  message: string,
  data?: T,
  statusCode: number = HttpStatus.OK,
  args: Record<string, string> = undefined,
): ApiResponse<T> {
  return {
    status: true,
    statusCode,
    message,
    data,
    error: undefined,
    args,
  };
}

export function sendFailure<T>(
  message: string,
  statusCode: number = HttpStatus.UNPROCESSABLE_ENTITY,
  data?: T,
  error?: T,
  args: Record<string, string> = undefined,
): ApiResponse<T> {
  return {
    status: false,
    statusCode,
    message,
    data: data ?? null,
    error: error ?? 'Unprocessable Entity',
    args,
  };
}

export const commonCatch = (error: any) => {
  return sendFailure(
    error.message ? error.message : Errors?.InternalServerError,
    error.message ? HttpStatus.BAD_REQUEST : HttpStatus.INTERNAL_SERVER_ERROR,
  );
};
