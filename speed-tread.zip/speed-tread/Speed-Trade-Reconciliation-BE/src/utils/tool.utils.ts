import * as dotenv from 'dotenv';
import { customAlphabet } from 'nanoid';
import * as crypto from 'crypto';
import * as argon2 from 'argon2';
import { I18nService } from 'nestjs-i18n';
import * as CryptoJS from 'crypto-js';
import { AppConfigService } from 'src/config/app-config/app-config.service';
import { ConfigService } from '@nestjs/config';

// Dynamically determine environment
const ENV_FILE = `.env.${process.env.NODE_ENV || 'local'}`;

dotenv.config({ path: ENV_FILE });

const SECRET_KEY = process.env.JWT_CONSTANT;

const nanoid = customAlphabet('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', 12);

export function generateRandomId() {
  return nanoid();
}

export const generatePassword = () => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  // ensure password has at least one uppercase, one lowercase, one number
  const required = [
    String.fromCharCode(65 + Math.floor(Math.random() * 26)), // Uppercase
    String.fromCharCode(97 + Math.floor(Math.random() * 26)), // Lowercase
    Math.floor(Math.random() * 10).toString(), // Number
  ];

  const remaining = Array.from({ length: 5 }, () => chars[Math.floor(Math.random() * chars.length)]);

  return [...required, ...remaining].sort(() => Math.random() - 0.5).join('');
};

export function generatePasswordExpiry(input: number) {
  const futureDate = new Date();
  futureDate.setDate(futureDate.getDate() + input);
  return futureDate;
}

export async function createHashPwd(password: string): Promise<string> {
  return await argon2.hash(password, {
    type: argon2.argon2id, // Recommended type for security
    memoryCost: 65536, // 64MB of memory (higher = more secure)
    timeCost: 3, // Number of iterations
    parallelism: 2, // Threads for hashing
  });
}

export async function decryptCryptoPwd(password: string): Promise<any> {
  if (password && SECRET_KEY) {
    const decrypt = await CryptoJS.AES.decrypt(password, SECRET_KEY).toString(CryptoJS.enc.Utf8);
    return decrypt;
  }
  return '';
}

export function createHashOtp(input: string) {
  return crypto.createHash('sha256').update(input).digest('hex');
}

export async function verifyHashPwd(password: string, hashedPassword: string): Promise<boolean> {
  return await argon2.verify(hashedPassword, password);
}

export function generateOTP() {
  const id = customAlphabet('0123456789', 6);
  return id();
}

export function removeUnderscore(message: string) {
  return message?.replace('_', ' ')?.replace(/^\w/, (value: string) => value?.toUpperCase());
}

export function getTranslatedMessage(
  i18n: I18nService,
  message: string | { key: string; args: Record<string, string> },
  language: string,
): string {
  if (typeof message === 'string') return i18n.translate(`${message}`, { lang: language });
  return i18n.translate(`${message.key}`, { lang: language, args: message.args });
}

export function formatNumber(num: number) {
  if (num >= 1_000_000_000_000) {
    return (num / 1_000_000_000_000).toFixed(1).replace(/\.0$/, '') + 'T'; // Trillion
  }
  if (num >= 1_000_000_000) {
    return (num / 1_000_000_000).toFixed(1).replace(/\.0$/, '') + 'B'; // Billion
  }
  if (num >= 1_000_000) {
    return (num / 1_000_000).toFixed(1).replace(/\.0$/, '') + 'M'; // Million
  }
  if (num >= 1_000) {
    return (num / 1_000).toFixed(1).replace(/\.0$/, '') + 'K'; // Thousand
  }
  return num.toString();
}

export function generateTransactionId() {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const digits = '0123456789';

  // Generate 2 random digits
  let randomDigits = '';
  for (let i = 0; i < 2; i++) {
    randomDigits += digits[Math.floor(Math.random() * digits.length)];
  }

  // Generate 4 random letters
  let randomLetters = '';
  for (let i = 0; i < 4; i++) {
    randomLetters += letters[Math.floor(Math.random() * letters.length)];
  }

  return `TST${randomDigits}${randomLetters}`;
}
