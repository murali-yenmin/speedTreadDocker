import React from 'react';
import AppRoutes from './router';
import { useTranslation } from 'react-i18next';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import ErrorModal from './components/Modal/ErrorModal';

function App() {
  const { t, i18n } = useTranslation();

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
  };

  return (
    <div className="App">
      <AppRoutes />
      <ToastContainer position="bottom-right" />
      <ErrorModal />
    </div>
  );
}

export default App;
