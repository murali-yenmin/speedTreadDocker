import React from 'react';

interface IconProps {
  color?: string;
  className?: string;
}

const LockIconComponent: React.FC<IconProps> = ({
  color = '#102A57', // Default color
  className = '',
}) => {
  return (
    <svg
      className={className}
      width="17"
      height="19"
      viewBox="0 0 17 19"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M2.55 9.35C2.08056 9.35 1.7 9.73056 1.7 10.2V16.15C1.7 16.6194 2.08056 17 2.55 17H14.45C14.9194 17 15.3 16.6194 15.3 16.15V10.2C15.3 9.73056 14.9194 9.35 14.45 9.35H2.55ZM0 10.2C0 8.79167 1.14167 7.65 2.55 7.65H14.45C15.8583 7.65 17 8.79167 17 10.2V16.15C17 17.5583 15.8583 18.7 14.45 18.7H2.55C1.14167 18.7 0 17.5583 0 16.15V10.2Z"
        fill={color}
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M8.5 1.7C7.59826 1.7 6.73346 2.05821 6.09584 2.69584C5.45821 3.33346 5.1 4.19826 5.1 5.1V8.5C5.1 8.96944 4.71944 9.35 4.25 9.35C3.78056 9.35 3.4 8.96944 3.4 8.5V5.1C3.4 3.7474 3.93732 2.45019 4.89376 1.49376C5.85019 0.53732 7.1474 0 8.5 0C9.8526 0 11.1498 0.53732 12.1062 1.49376C13.0627 2.45019 13.6 3.7474 13.6 5.1V8.5C13.6 8.96944 13.2194 9.35 12.75 9.35C12.2806 9.35 11.9 8.96944 11.9 8.5V5.1C11.9 4.19826 11.5418 3.33346 10.9042 2.69584C10.2665 2.05821 9.40174 1.7 8.5 1.7Z"
        fill={color}
      />
    </svg>
  );
};

export default LockIconComponent;
