import React, { useState } from 'react';
import { ReactComponent as ChevronDownIcon } from '../assets/svg/ChevronDownIcon.svg';
import { AccordionProps } from '../interfaces/components';
import MobileChevron from './Images/MobileChevron';
import MobileChevronDown from './Images/MobileChevronDown';
import { CheckBoxInput } from './formFields/CheckBoxInput';

const Accordion: React.FC<AccordionProps> = ({
  header,
  children,
  className,
  isSelectMode = false,
  onSelect,
  checked = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className={`relative shadow-md ${className}`}>
      <div
        className="flex items-center justify-between p-4 cursor-pointer mid-range-sm:pb-8 mid-range-lg:pb-8 mid-range:pb-8"
        onClick={() => !isSelectMode && setIsOpen(!isOpen)}
      >
        <div className="flex items-center gap-4 flex-grow">
          {isSelectMode ? (
            <CheckBoxInput
              checked={checked}
              onChange={() => onSelect && onSelect()}
            />
          ) : (
            <ChevronDownIcon
              className={`h-6 w-6 transition-transform ${isOpen ? 'rotate-180' : ''} hidden md_lg:block`}
            />
          )}
          <div className="flex-grow">{header}</div>
        </div>
      </div>

      {isOpen && <div className="p-4 border-t border-gray-200">{children}</div>}
      <div
        className={`mobile-chevronIcon absolute right-0 left-0 bottom-0 transition-transform block mid-range-sm:block mid-range-sm:flex mid-range-sm:justify-center mid-range-sm:align-center md_lg:hidden rounded-b-[20px]`}
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? <MobileChevron /> : <MobileChevronDown />}
      </div>
    </div>
  );
};

export default Accordion;
