import React from 'react';

interface AddButtonDottedProps {
  onClick: (event: React.MouseEvent<HTMLButtonElement>) => void;
  fullWidth?: boolean;
  title?: string;
}

export const AddButtonDotted = ({
  onClick,
  fullWidth = true,
  title,
}: AddButtonDottedProps) => {
  const widthClass = fullWidth ? 'w-full' : 'w-full md:w-[115px]';

  return (
    <button
      className={`group border-2 border-dashed border-gray-300 rounded-lg ${widthClass} flex justify-center items-center h-[49px] flex-shrink-0 hover:bg-blue-50 hover:border-blue-700`}
      onClick={(e) => {
        e.stopPropagation();
        onClick(e);
      }}
      title={title}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-6 w-6 text-gray-400 group-hover:text-blue-700"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M12 6v6m0 0v6m0-6h6m-6 0H6"
        />
      </svg>
    </button>
  );
};
