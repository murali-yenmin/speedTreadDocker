import React from 'react';
import { AccountName } from '../../store/interfaces/accountName';
import StyledUl from '../common/StyledUl';
import StyledLi from '../common/StyledLi';

interface AccountNameDropdownProps {
  items: AccountName[];
  selectedItem: AccountName | null;
  onSelectItem: (item: AccountName) => void;
  setShowAccountNameDropdown: (show: boolean) => void;
}

const AccountNameDropdown: React.FC<AccountNameDropdownProps> = ({
  items,
  selectedItem,
  onSelectItem,
  setShowAccountNameDropdown,
}) => {
  return (
    <div className="absolute z-10 w-full pt-1">
      <StyledUl parentFocus={() => setShowAccountNameDropdown(true)}>
        {items.map((item) => (
          <StyledLi
            key={item.unique_id}
            selected={selectedItem?.unique_id === item.unique_id}
            onClick={() => {
              onSelectItem(item);
            }}
          >
            {item.name}
          </StyledLi>
        ))}
      </StyledUl>
    </div>
  );
};

export default AccountNameDropdown;
