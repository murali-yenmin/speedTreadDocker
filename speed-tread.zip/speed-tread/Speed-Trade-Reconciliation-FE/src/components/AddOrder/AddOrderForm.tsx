import React from 'react';
import {
  SubmitHandler,
  UseFormReturn,
} from 'react-hook-form';
import { AddOrderFormValues } from '../../interfaces/order';

interface AddOrderFormProps {
  children: React.ReactNode;
  onSubmit: SubmitHandler<AddOrderFormValues>;
  form: UseFormReturn<AddOrderFormValues>;
}

const AddOrderForm: React.FC<AddOrderFormProps> = ({
  children,
  onSubmit,
  form,
}) => {
  const { handleSubmit } = form;

  return (
    <form
      autoComplete="off"
      id="add-order-form"
      onSubmit={handleSubmit(onSubmit)}
    >
      {children}
    </form>
  );
};

export default AddOrderForm;
