import React from 'react';
import {
  UseFormReturn,
  useFieldArray,
} from 'react-hook-form';
import { AddOrderFormValues } from '../../interfaces/order';
import FormattedInput from '../formFields/FormattedInput';
import Dropdown from '../formFields/Dropdown';
import Input from '../formFields/Input';
import TextArea from '../formFields/TextArea';
import AmountInput from '../formFields/AmountInput';
import PlusIcon from '../Images/PlusIcon';
import MinusIcon from '../Images/MinusIcon';
import { AccountName } from '../../store/interfaces/accountName';
import AccountNameDropdown from './AccountNameDropdown';

interface MultiOrderFormProps {
  form: UseFormReturn<AddOrderFormValues>;
  pairedCurrencies: string[];
  accountNameRefs: React.MutableRefObject<(HTMLDivElement | null)[]>;
  handleMultiAccountNameChange: (value: string, index: number) => void;
  showMultiAccountNameDropdown: number | null;
  setShowMultiAccountNameDropdown: (index: number | null) => void;
  items: AccountName[];
  selectedItems: (AccountName | null)[];
  setSelectedItems: (items: (AccountName | null)[]) => void;
  scrollContainerRef: React.RefObject<HTMLDivElement | null>;
}

const MultiOrderForm: React.FC<MultiOrderFormProps> = ({
  form,
  pairedCurrencies,
  accountNameRefs,
  handleMultiAccountNameChange,
  showMultiAccountNameDropdown,
  setShowMultiAccountNameDropdown,
  items,
  selectedItems,
  setSelectedItems,
  scrollContainerRef,
}) => {
  const {
    control,
    watch,
    setValue,
    clearErrors,
  } = form;

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'orders',
  });

  const watchedOrders = watch('orders');
  const watchedSettlementCurrency = watch('settlementCurrency');
  const orderType = watch('orderType');

  const handleAddOrder = () => {
    append({
      amount: undefined,
      currency: watchedSettlementCurrency || '',
      rate: undefined,
      accountName: '',
      remarks: '',
      fee: undefined,
    });
  };

  return (
    <div className="p-4 border rounded-lg space-y-4 ">
      <div className="hidden md:grid md:grid-cols-[160px_120px_100px_1fr_150px_1fr_60px] gap-2">
        <div className="font-medium text-gray-700">Amount</div>
        <div className="font-medium text-gray-700">Currency</div>
        <div className="font-medium text-gray-700">Rate</div>
        <div className="font-medium text-gray-700">Account Name</div>
        <div className="font-medium text-gray-700">Fees</div>
        <div className="font-medium text-gray-700">Remarks (Optional)</div>
        <div></div>
      </div>
      {fields.map((field, index) => {
        const orderCurrency = watchedOrders[index]?.currency;
        const isRateDisabled = watchedSettlementCurrency === orderCurrency;

        return (
          <div
            key={field.id}
            className="grid grid-cols-1 md:grid-cols-[160px_120px_100px_1fr_150px_1fr_60px] gap-2"
          >
            <div>
              <label className="md:hidden font-medium text-gray-700">
                Amount
              </label>
              <AmountInput
                name={`orders.${index}.amount`}
                control={control}
                placeholder="Amount"
                decimalPlaces={2}
                maxDigits={10}
              />
            </div>
            <div>
              <label className="md:hidden font-medium text-gray-700">
                Currency
              </label>
              <Dropdown
                name={`orders.${index}.currency`}
                label=""
                control={control}
                options={
                  watchedSettlementCurrency
                    ? pairedCurrencies?.map((c) => ({
                        label: c,
                        value: c,
                      })) || []
                    : []
                }
                onChange={() => {
                  setValue(`orders.${index}.rate`, undefined);
                }}
              />
            </div>
            <div>
              <label className="md:hidden font-medium text-gray-700">
                Rate
              </label>
              <FormattedInput
                name={`orders.${index}.rate`}
                control={control}
                placeholder="Rate"
                decimalPlaces={3}
                disabled={isRateDisabled}
              />
            </div>
            <div
              ref={(el) => {
                if (el) accountNameRefs.current[index] = el;
              }}
              className="relative"
            >
              <label className="md:hidden font-medium text-gray-700">
                Account Name
              </label>
              <Input
                name={`orders.${index}.accountName` as any}
                control={control}
                label=""
                type="text"
                placeholder="Account Name"
                onChange={(value) => handleMultiAccountNameChange(value, index)}
                onFocus={() => {
                  setShowMultiAccountNameDropdown(index);
                }}
                maxLength={50}
              />
              {items &&
                items?.length > 0 &&
                showMultiAccountNameDropdown === index && (
                  <AccountNameDropdown
                    items={items}
                    selectedItem={selectedItems[index]}
                    onSelectItem={(item) => {
                      setValue(`orders.${index}.accountName`, item.name);
                      const newSelectedItems = [...selectedItems];
                      newSelectedItems[index] = item;
                      setSelectedItems(newSelectedItems);
                      setShowMultiAccountNameDropdown(null);
                      clearErrors(`orders.${index}.accountName`);
                    }}
                    setShowAccountNameDropdown={() =>
                      setShowMultiAccountNameDropdown(index)
                    }
                  />
                )}
            </div>
            {orderType !== 'adjustment' && (
              <div>
                <label className="md:hidden font-medium text-gray-700">
                  Fees (Optional)
                </label>
                <FormattedInput
                  label=""
                  name={`orders.${index}.fee`}
                  control={control}
                  placeholder="Enter Fee"
                  decimalPlaces={2}
                />
              </div>
            )}
            <div>
              <label className="md:hidden font-medium text-gray-700">
                Remarks (Optional)
              </label>
              <TextArea
                name={`orders.${index}.remarks` as any}
                control={control}
                label=""
                rows={1}
                placeholder="Enter Remarks"
                maxLength={150}
              />
            </div>
            {fields.length > 0 && (
              <div className="flex items-start">
                {index === fields.length - 1 ? (
                  <button
                    title="Add"
                    type="button"
                    onClick={() => {
                      handleAddOrder();
                      setTimeout(() => {
                        if (scrollContainerRef.current) {
                          scrollContainerRef.current.scrollTo({
                            top: scrollContainerRef.current.scrollHeight,
                            behavior: 'smooth',
                          });
                        }
                      }, 100);
                    }}
                    className="py-2 px-3 bg-primary-blue text-white rounded-md hover:bg-royal-purple"
                  >
                    <PlusIcon className="h-6 w-6" />
                  </button>
                ) : (
                  <button
                    title="Delete"
                    type="button"
                    onClick={() => remove(index)}
                    className="py-2 px-3 bg-initialsBg rounded-md hover:bg-initialsBg-600"
                  >
                    <MinusIcon className="h-6 w-6" />
                  </button>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default MultiOrderForm;
