import React from 'react';
import { UseFormReturn, FieldArrayWithId } from 'react-hook-form';
import { AddOrderFormValues } from '../../interfaces/order';
import FormattedInput from '../formFields/FormattedInput';
import Dropdown from '../formFields/Dropdown';
import Input from '../formFields/Input';
import TextArea from '../formFields/TextArea';
import AmountInput from '../formFields/AmountInput';
import { AccountName } from '../../store/interfaces/accountName';
import AccountNameDropdown from './AccountNameDropdown';

interface SingleOrderFormProps {
  form: UseFormReturn<AddOrderFormValues>;
  pairedCurrencies: string[];
  accountNameRef: React.RefObject<HTMLDivElement | null>;
  handleAccountNameChange: (value: string) => void;
  showAccountNameDropdown: boolean;
  setShowAccountNameDropdown: (show: boolean) => void;
  items: AccountName[];
  selectedItem: AccountName | null;
  setSelectedItem: (item: AccountName | null) => void;
  fields: FieldArrayWithId<AddOrderFormValues, 'orders', 'id'>[];
}

const SingleOrderForm: React.FC<SingleOrderFormProps> = ({
  form,
  pairedCurrencies,
  accountNameRef,
  handleAccountNameChange,
  showAccountNameDropdown,
  setShowAccountNameDropdown,
  items,
  selectedItem,
  setSelectedItem,
  fields,
}) => {
  const {
    control,
    watch,
    setValue,
    clearErrors,
  } = form;

  const watchedOrders = watch('orders');
  const watchedSettlementCurrency = watch('settlementCurrency');
  const orderType = watch('orderType');

  return (
    <div className="px-4 py-6 border rounded-lg">
      {fields.map((field, index) => {
        const orderCurrency = watchedOrders[index]?.currency;
        const isRateDisabled = watchedSettlementCurrency === orderCurrency;
        const gridTemplateColumns =
          watchedOrders.length > 1
            ? 'grid-cols-[1fr_148px_95px_auto]'
            : 'grid-cols-1 xs:grid-cols-[2fr_1fr_1fr]';

        return (
          <div
            key={field.id}
            className={`grid gap-4 items-baseline ${gridTemplateColumns}`}
          >
            <div>
              <AmountInput
                name={`orders.${index}.amount`}
                control={control}
                placeholder="Amount"
                decimalPlaces={2}
                maxDigits={10}
              />
            </div>
            <div>
              <Dropdown
                name={`orders.${index}.currency`}
                label=""
                control={control}
                options={
                  watchedSettlementCurrency
                    ? pairedCurrencies?.map((c) => ({
                        label: c,
                        value: c,
                      })) || []
                    : []
                }
                onChange={() => {
                  setValue(`orders.${index}.rate`, undefined);
                }}
              />
            </div>
            <div>
              <FormattedInput
                name={`orders.${index}.rate`}
                control={control}
                placeholder="Rate"
                decimalPlaces={3}
                disabled={isRateDisabled}
              />
            </div>
          </div>
        );
      })}
      <div ref={accountNameRef} className="relative my-4">
        <Input
          name={`accountName` as any}
          control={control}
          label="Account Name"
          type="text"
          placeholder="Account Name"
          onChange={handleAccountNameChange}
          onFocus={() => {
            setShowAccountNameDropdown(true);
          }}
          maxLength={50}
        />
        {items && items?.length > 0 && showAccountNameDropdown && (
          <AccountNameDropdown
            items={items}
            selectedItem={selectedItem}
            onSelectItem={(item) => {
              setValue('accountName', item.name);
              setSelectedItem(item);
              setShowAccountNameDropdown(false);
              clearErrors('accountName');
            }}
            setShowAccountNameDropdown={setShowAccountNameDropdown}
          />
        )}
      </div>
      {orderType !== 'adjustment' && (
        <div className="mb-2">
          <FormattedInput
            label="Fee (Optional)"
            name="fee"
            control={control}
            placeholder="Enter Fee"
            decimalPlaces={2}
          />
        </div>
      )}
      <div>
        <TextArea
          name="remarks"
          control={control}
          label="Remarks (Optional)"
          rows={1}
          placeholder="Enter Remarks"
          maxLength={150}
        />
      </div>
    </div>
  );
};

export default SingleOrderForm;
