import React from 'react';
import { SubmitHandler, UseFormReturn } from 'react-hook-form';
import { AddTransactionFormData } from '../../interfaces/components';

interface AddTransactionFormProps {
  children: React.ReactNode;
  onSubmit: SubmitHandler<AddTransactionFormData>;
  form: UseFormReturn<AddTransactionFormData>;
}

const AddTransactionForm: React.FC<AddTransactionFormProps> = ({
  children,
  onSubmit,
  form,
}) => {
  const { handleSubmit } = form;

  return (
    <form
      autoComplete="off"
      id="add-transaction-form" // handle unique id
      onSubmit={handleSubmit(onSubmit)}
    >
      {children}
    </form>
  );
};

export default AddTransactionForm;
