import React from 'react';
import { FieldArrayWithId, FieldValues, UseFormReturn } from 'react-hook-form';
import { AddTransactionFormData } from '../../interfaces/components';
import { DropdownOption } from '../../interfaces/formfields';
import { AccountName } from '../../store/interfaces/accountName';
import AmountInput from '../formFields/AmountInput';
import SelectDropdown from '../formFields/SelectDropdown';
import FormattedInput from '../formFields/FormattedInput';
import Input from '../formFields/Input';
import StyledUl from '../common/StyledUl';
import StyledLi from '../common/StyledLi';
import TextArea from '../formFields/TextArea';

interface SingleTransactionFormProps<T extends FieldValues> {
  form: UseFormReturn<AddTransactionFormData>;
  pairedCurrencies: DropdownOption[];
  handleCurrencyChange: (selectedOption: DropdownOption) => void;
  showRateField: boolean;
  accountNameRef: React.RefObject<HTMLDivElement | null>;
  handleAccountNameChange: (value: string) => void;
  showAccountNameDropdown: boolean;
  setShowAccountNameDropdown: (show: boolean) => void;
  items: AccountName[];
  selectedItem: AccountName | null;
  setSelectedItem: (item: AccountName | null) => void;
  isEditMode: boolean;
  fields: FieldArrayWithId<AddTransactionFormData, 'orders', 'id'>[];
}

const SingleTransactionForm = <T extends FieldValues>({
  form,
  pairedCurrencies,
  handleCurrencyChange,
  showRateField,
  accountNameRef,
  handleAccountNameChange,
  showAccountNameDropdown,
  setShowAccountNameDropdown,
  items,
  selectedItem,
  setSelectedItem,
  fields,
  isEditMode,
}: SingleTransactionFormProps<T>) => {
  const {
    control,
    watch,
    setValue,
    clearErrors,
    formState: { errors },
  } = form;

  const watchedCurrency = watch('currency');
  const watchedOrders = watch('orders');
  const watchedSettlementCurrency = watch('settlementCurrency');
  const gridTemplateColumns =
    watchedOrders && watchedOrders.length > 1
      ? 'grid-cols-[1fr_148px_95px_auto]'
      : 'grid-cols-1 xs:grid-cols-[2fr_1fr_1fr]';

  return (
    <div className="px-4 py-6 border rounded-lg">
      <div
        className={`grid gap-4 items-baseline ${isEditMode ? 'grid-cols-1' : gridTemplateColumns}`}
      >
        <div>
          <AmountInput
            label=""
            name="sell"
            control={control}
            placeholder="Amount"
            decimalPlaces={2}
            maxDigits={10}
            prefix={isEditMode && watchedCurrency}
          />
        </div>
        {!isEditMode && (
          <>
            <div>
              <SelectDropdown
                label=""
                options={pairedCurrencies}
                value={
                  pairedCurrencies.find((c) => c.value === watchedCurrency) ||
                  null
                }
                onChange={(selectedOption) =>
                  handleCurrencyChange(selectedOption as DropdownOption)
                }
                error={errors.currency?.message}
                customPadding="1px"
              />
            </div>
          </>
        )}
        {(!isEditMode || watchedCurrency !== watchedSettlementCurrency) && (
          <FormattedInput
            label={isEditMode ? 'Rate' : ''}
            name="rate"
            control={control}
            placeholder="Rate"
            decimalPlaces={3}
            disabled={!showRateField}
          />
        )}
      </div>
      <div ref={accountNameRef} className="relative space-y-4 mt-4">
        <Input
          label="Account Name"
          name="account"
          control={control}
          placeholder="Enter Account Name"
          onChange={handleAccountNameChange}
          onFocus={() => {
            setShowAccountNameDropdown(true);
          }}
          maxLength={50}
        />
        {items && items?.length > 0 && showAccountNameDropdown && (
          <div className="absolute z-10 w-full pt-1">
            <StyledUl parentFocus={() => setShowAccountNameDropdown(true)}>
              {items.map((item) => (
                <StyledLi
                  key={item.unique_id}
                  selected={selectedItem?.unique_id === item.unique_id}
                  onClick={() => {
                    setValue('account', item.name);
                    setSelectedItem(item);
                    setShowAccountNameDropdown(false);
                    clearErrors('account');
                  }}
                >
                  {item.name}
                </StyledLi>
              ))}
            </StyledUl>
          </div>
        )}
        <FormattedInput
          label="Fee (Optional)"
          name="fee"
          control={control}
          placeholder="Enter Fee"
          decimalPlaces={2}
        />
        <TextArea
          label="Remarks (Optional)"
          name="remarks"
          control={control}
          placeholder="Enter Remarks"
          maxLength={150}
        />
      </div>
    </div>
  );
};

export default SingleTransactionForm;
