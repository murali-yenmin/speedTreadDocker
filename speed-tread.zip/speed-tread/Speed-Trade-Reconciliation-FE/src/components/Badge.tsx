import React from 'react';
import { BadgeProps } from '../interfaces/components';

const Badge: React.FC<BadgeProps> = ({ children, color = 'gray' }) => {
  let bgColorClass = '';
  let textColorClass = '';

  switch (color) {
    case 'gray':
      bgColorClass = 'bg-gray-200';
      textColorClass = 'text-gray-800';
      break;
    case 'green':
      bgColorClass = 'bg-green-100';
      textColorClass = 'text-green-800';
      break;
    case 'red':
      bgColorClass = 'bg-red-100';
      textColorClass = 'text-red-800';
      break;
    default:
      bgColorClass = 'bg-gray-200';
      textColorClass = 'text-gray-800';
  }

  return (
    <span
      className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${bgColorClass} ${textColorClass}`}
    >
      {children}
    </span>
  );
};

export default Badge;
