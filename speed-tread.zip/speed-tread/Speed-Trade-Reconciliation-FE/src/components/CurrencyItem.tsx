import React, { useState } from 'react';
import AddTransactionModal from './Modal/AddTransactionModal';
import AddOrderModal from './Modal/AddOrderModal';
import SliderModal from './Modal/SliderModal';
import TransactionSliderContent from './TransactionSliderContent';
import OrderSlider from './OrderSlider';
import { useAppDispatch } from '../store/store';
import { resetGetAllTransactions } from '../store/slices/transaction/getAllTransactionsSlice';
import { resetAmountOverview } from '../store/slices/transaction/amountOverviewSlice';
import moment from 'moment';
import { defaultDateFormat } from './formFields/DateRangeInput';
import { CurrencyItemProps } from '../interfaces/components';
import CurrencyViewer from './CurrencyViewer';

const CurrencyItem: React.FC<CurrencyItemProps> = ({
  currency,
  groupId,
  groupName,
  group_uniqueId,
  sliderType,
  onDataUpdate,
  is_favorite,
}) => {
  const dispatch = useAppDispatch();

  const [isAddTransactionModalOpen, setIsAddTransactionModalOpen] =
    useState(false);
  const [isAddOrderModalOpen, setIsAddOrderModalOpen] = useState(false);
  const [isSliderOpen, setIsSliderOpen] = useState(false);
  const [hasUpdated, setHasUpdated] = useState(false);

  const handleOpenModal = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (sliderType === 'order') {
      setIsAddOrderModalOpen(true);
    } else {
      setIsAddTransactionModalOpen(true);
    }
  };

  const handleCloseAddTransactionModal = () => {
    setIsAddTransactionModalOpen(false);
  };

  const handleAddTransactionSuccess = () => {
    if (onDataUpdate) {
      onDataUpdate();
    }
    setIsAddTransactionModalOpen(false);
  };

  const handleCloseAddOrderModal = () => {
    setIsAddOrderModalOpen(false);
  };

  const handleOpenSlider = () => {
    setIsSliderOpen(true);
  };

  const handleCloseSlider = () => {
    setIsSliderOpen(false);
    if (sliderType === 'transaction') {
      dispatch(resetGetAllTransactions());
      dispatch(resetAmountOverview());
    }
    if (hasUpdated) {
      if (onDataUpdate) {
        onDataUpdate();
      }
      setHasUpdated(false); // Reset after update
    }
  };

  return (
    <>
      <CurrencyViewer
        currency={currency}
        addOpt={true}
        handleOpenModal={handleOpenModal}
        handleOpenSlider={handleOpenSlider}
        showCount={true}
        sliderType={sliderType}
      />
      {isAddTransactionModalOpen && (
        <AddTransactionModal
          isOpen={isAddTransactionModalOpen}
          onClose={handleCloseAddTransactionModal}
          onSuccess={handleAddTransactionSuccess}
          id={groupId}
          name={groupName}
          settlementCurrency={currency.currency}
          group_uniqueId={group_uniqueId}
        />
      )}
      {isAddOrderModalOpen && (
        <AddOrderModal
          isOpen={isAddOrderModalOpen}
          onClose={handleCloseAddOrderModal}
          onOrderAdded={onDataUpdate}
          groupId={groupId}
          groupName={groupName}
          settlementCurrency={currency.currency}
          group_uniqueId={group_uniqueId}
          selectedDate={moment().format(defaultDateFormat)}
        />
      )}
      <SliderModal
        showCloseIcon={false}
        isOpen={isSliderOpen}
        onClose={handleCloseSlider}
      >
        {isSliderOpen && sliderType === 'transaction' && (
          <TransactionSliderContent
            group_uniqueId={group_uniqueId}
            groupId={groupId}
            groupName={groupName}
            settlementCurrency={currency.currency}
            onClose={handleCloseSlider}
            onUpdate={() => {
              setHasUpdated(true);
              onDataUpdate?.();
            }}
            is_favorite={is_favorite}
          />
        )}
        {isSliderOpen && sliderType === 'order' && (
          <OrderSlider
            groupId={groupId}
            groupName={groupName}
            settlementCurrency={currency.currency}
            onClose={handleCloseSlider}
            currency={currency}
            group_uniqueId={group_uniqueId}
            onUpdate={() => {
              setHasUpdated(true);
              onDataUpdate?.();
            }}
            is_favorite={is_favorite}
          />
        )}
      </SliderModal>
    </>
  );
};

export default CurrencyItem;
