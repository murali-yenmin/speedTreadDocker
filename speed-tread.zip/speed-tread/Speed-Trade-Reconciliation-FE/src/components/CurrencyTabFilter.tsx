import React from 'react';
import useMediaQuery from '../hooks/useMediaQuery';
import SelectDropdown from './formFields/SelectDropdown';

interface CurrencyTabFilterProps {
  currencies: string[];
  selectedCurrency: string;
  onCurrencyChange: (currency: string) => void;
  loading?: boolean; // Add loading prop
}

const CurrencyTabFilter: React.FC<CurrencyTabFilterProps> = ({
  currencies,
  selectedCurrency,
  onCurrencyChange,
  loading, // Destructure loading prop
}) => {
  const isMobile = useMediaQuery('(max-width: 767px)');
  const isTablet = useMediaQuery('(min-width: 768px) and (max-width: 1023px)');

  let visibleCount = currencies.length;
  if (isMobile) {
    visibleCount = 2;
  } else if (isTablet) {
    visibleCount = 4;
  }

  if (loading) {
    return (
      <div className="flex flex-wrap gap-2 animate-pulse">
        {[...Array(5)].map((_, index) => (
          <div key={index} className="h-10 w-20 bg-gray-300 rounded-md"></div>
        ))}
      </div>
    );
  }

  if (currencies.length > visibleCount) {
    const visibleCurrencies = currencies.slice(0, visibleCount);
    const dropdownCurrencies = currencies.slice(visibleCount);
    const isDropdownCurrencySelected =
      dropdownCurrencies.includes(selectedCurrency);

    const dropdownOptions = dropdownCurrencies.map((currency) => ({
      value: currency,
      label: currency,
    }));

    return (
      <div className="flex flex-wrap gap-2">
        {visibleCurrencies.map((currency) => (
          <button
            key={currency}
            onClick={() => onCurrencyChange(currency)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
              selectedCurrency === currency
                ? 'bg-primary-blue text-white shadow-sm'
                : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
            }`}
          >
            {currency}
          </button>
        ))}
        <div
          className={`select-currency w-[90px] ${
            isDropdownCurrencySelected
              ? 'bg-primary-blue'
              : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
          }`}
        >
          <SelectDropdown
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 w-[auto] p-[0!important] bg-[transparent] ${
              isDropdownCurrencySelected
                ? 'text-[white!important] shadow-sm select-value-white'
                : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
            }`}
            value={
              isDropdownCurrencySelected
                ? dropdownOptions.find(
                    (option) => option.value === selectedCurrency,
                  ) || null // Explicitly set to null if not found
                : null
            }
            onChange={(selectedOption) => {
              if (selectedOption && 'value' in selectedOption) {
                onCurrencyChange(selectedOption.value as string);
              }
            }}
            options={dropdownOptions}
            placeholder="More"
            customPadding="1px"
          />
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-wrap gap-2">
      {currencies.map((currency) => (
        <button
          key={currency}
          onClick={() => onCurrencyChange(currency)}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
            selectedCurrency === currency
              ? 'bg-primary-blue text-white shadow-sm'
              : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
          }`}
        >
          {currency}
        </button>
      ))}
    </div>
  );
};

export default CurrencyTabFilter;
