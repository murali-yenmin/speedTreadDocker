import React from 'react';

const CurrencyTabFilterSkeleton: React.FC = () => {
  return (
    <div className="flex flex-wrap gap-2 animate-pulse">
      {[...Array(5)].map((_, index) => (
        <div key={index} className="h-10 w-20 bg-gray-300 rounded-md"></div>
      ))}
    </div>
  );
};

export default CurrencyTabFilterSkeleton;
