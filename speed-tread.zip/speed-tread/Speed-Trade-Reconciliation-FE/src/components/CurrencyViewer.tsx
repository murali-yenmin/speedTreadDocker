import { CurrencyItemProps } from '../interfaces/components';
import { Currency } from '../interfaces/currency';
import {
  formatAmount,
  formatAmountWithSuperscript,
} from '../utils/numberUtils';
import PlusIcon from './Images/PlusIcon';
import SmallCountBox from './SmallCountBox';

interface CurrencyViewerProps {
  handleOpenSlider?: () => void;
  currency: Currency;
  sliderType?: CurrencyItemProps['sliderType'];
  handleOpenModal?: (data?: any) => void;
  showCount?: boolean;
  addOpt?: boolean;
  cursorPointer?: boolean;
  processing?: string;
  transferring?: string;
  error?: string;
}
function CurrencyViewer({
  handleOpenSlider,
  currency,
  handleOpenModal,
  sliderType,
  showCount = true,
  addOpt = false,
  cursorPointer = true,
}: CurrencyViewerProps) {
  const getTypeText = (currency: any) => {
    switch (currency.status) {
      case 'we_owe':
        return 'We Owe';
      case 'owe_us':
        return 'Owe Us';
      case 'all_clear':
        return 'All Clear';
      default:
        return '';
    }
  };

  const getCurrencyStatusColors = (currency: any) => {
    switch (currency.status) {
      case 'we_owe':
        return {
          divBg: 'bg-strong-red',
          currencyBg: 'bg-strong-red',
          currencyText: 'text-white',
        };
      case 'owe_us':
        return {
          divBg: 'bg-strong-green',
          currencyBg: 'bg-strong-green',
          currencyText: 'text-white',
        };
      case 'all_clear':
        return {
          divBg: 'bg-primary-blue',
          currencyBg: 'bg-light-blue',
          currencyText: 'text-dark-grey-blue',
        };
      default:
        return {
          divBg: 'bg-gray-300',
          currencyBg: 'bg-gray-100',
          currencyText: 'text-gray-500',
        };
    }
  };

  const { divBg, currencyBg, currencyText } = getCurrencyStatusColors(currency);
  return (
    <>
      <div
        className={`relative flex items-center justify-between space-x-2 p-[12px] rounded-lg border border-gray-200 w-full md:min-w-[264px] h-[50px] transition-all duration-200 ease-in-out ${currency.is_mismatch ? 'bg-light-red' : 'bg-white'} ${cursorPointer && 'cursor-pointer hover:border-primary-blue hover:shadow-md'} hover:z-10`}
        onClick={handleOpenSlider}
      >
        <div
          className={`absolute w-1 h-8 ${divBg} rounded-lg`}
          style={{ left: '-3px' }}
        ></div>
        <div className="flex items-center gap-3 ml-[0px!important]">
          <div
            className={`${currencyBg} ${currencyText} rounded-md px-2 py-1 text-sm font-semibold ml-0`}
            style={{ marginRight: '0 !important' }}
          >
            {currency.currency}
          </div>
          <div className="flex flex-col text-sm">
            <div className={`text-xs text-gray-500`}>
              {' '}
              {getTypeText(currency)}
            </div>
            <div
              className={`text-sm font-bold ${
                currency.status === 'we_owe'
                  ? 'text-strong-red'
                  : currency.status === 'owe_us'
                    ? 'text-strong-green'
                    : 'text-black'
              }`}
            >
              {currency.status === 'we_owe' && '('}
              {currency.status === 'all_clear'
                ? '-'
                : currency.value
                  ? formatAmountWithSuperscript(formatAmount(currency.value))
                  : '-'}
              {currency.status === 'we_owe' && ')'}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {showCount && (
            <>
              {Number(currency.changes_required) > 0 && (
                <SmallCountBox
                  count={Number(currency.changes_required)}
                  processing={currency.processing}
                  transferring={currency.transferring}
                  error={currency.error}
                />
              )}
            </>
          )}
          {addOpt && (
            <button
              className="bg-primary-blue text-white rounded-[8px] h-8 w-8 flex items-center justify-center hover:bg-royal-purple"
              onClick={handleOpenModal}
              title={
                sliderType === 'transaction'
                  ? 'Add Transaction'
                  : sliderType === 'order'
                    ? 'Add Order'
                    : 'Add New'
              }
            >
              <PlusIcon width="16px" height="16px" />
            </button>
          )}
        </div>
      </div>
    </>
  );
}

export default CurrencyViewer;
