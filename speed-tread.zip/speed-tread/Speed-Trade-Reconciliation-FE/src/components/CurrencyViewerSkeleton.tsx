function CurrencyViewerSkeleton() {
  return (
    <div className="relative flex animate-pulse items-center justify-between space-x-2 p-[12px] rounded-lg border border-gray-200 w-full md:min-w-[264px] h-[50px] bg-white">
      <div
        className="absolute w-1 h-8 bg-gray-200 rounded-lg"
        style={{ left: '-3px' }}
      ></div>
      <div className="flex items-center gap-3 ml-[0px!important]">
        <div
          className="bg-gray-200 rounded-md h-[28px] w-[50px]"
          style={{ marginRight: '0 !important' }}
        ></div>
        <div className="flex flex-col text-sm space-y-1">
          <div className="h-3 w-12 bg-gray-200 rounded"></div>
          <div className="h-4 w-16 bg-gray-200 rounded"></div>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <div className="h-5 w-5 bg-gray-200 rounded-full"></div>
        <div className="h-8 w-8 bg-gray-200 rounded-[8px]"></div>
      </div>
    </div>
  );
}

export default CurrencyViewerSkeleton;
