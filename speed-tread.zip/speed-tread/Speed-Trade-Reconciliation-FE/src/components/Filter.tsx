import React, {
  useState,
  useRef,
  useEffect,
  useImperativeHandle,
  forwardRef,
  SetStateAction,
  Dispatch,
} from 'react';
import { ReactComponent as FilterIcon } from '../assets/svg/FilterIcon.svg';
import { ReactComponent as ResetIcon } from '../assets/svg/ResetIcon.svg';
import { CheckBoxInput } from './formFields/CheckBoxInput';
import useOutsideClick from '../utils/outsideClick';
import { FilterOption } from '../interfaces/filter';

type FilterState = Record<string, string[]>;

interface FilterProps {
  filtersData: Record<string, FilterOption[]>;
  handleExport: (
    e: {
      operation: string;
      fieldName: string;
      fieldString: string | string[];
    }[],
  ) => void;
  active?: boolean;
  setFilterActive?: Dispatch<SetStateAction<boolean>>;
}

const pageConst = {
  filterActive: 'primary-orange', // Assuming this maps to a primary color
  filterDeActive: 'primary-grey', // Assuming this maps to a grey color
};

const Filter = forwardRef(
  (
    { filtersData, handleExport, active = false, setFilterActive }: FilterProps,
    ref,
  ) => {
    const [isDropdownOpen, setDropdownOpen] = useState<boolean>(false);
    const [tempFilters, setTempFilters] = useState<FilterState>({});
    const [dropdownStyle, setDropdownStyle] = useState<React.CSSProperties>({});

    const buttonRef = useRef<HTMLButtonElement>(null);
    const iconRef = useRef<HTMLDivElement>(null);
    const dropdownRef = useRef<HTMLDivElement>(null);

    const toggleDropdown = () => {
      setDropdownOpen((prev) => {
        const newState = !prev;

        if (newState && buttonRef.current && dropdownRef.current) {
          const button = buttonRef.current;
          const spacing = 8;

          const buttonRect = button.getBoundingClientRect();
          const dropdownRect = dropdownRef.current.getBoundingClientRect();

          // Position the dropdown below the button, aligned to the left
          const top = buttonRect.bottom + spacing;
          const left = buttonRect.right - dropdownRect.width;
          const finalLeft = left < 0 ? 0 : left;

          setDropdownStyle({
            position: 'fixed',
            top: `${top}px`,
            left: `${finalLeft}px`,
            zIndex: 1000,
          });
        }

        return newState;
      });
    };

    const resetFilters = () => {
      if (iconRef.current && !iconRef.current.classList.contains('spin-slow')) {
        iconRef.current.classList.add('spin-slow');
      }
      setTempFilters({});
      setFilterActive?.(false);
      setTimeout(() => {
        if (iconRef.current) {
          iconRef.current.classList.remove('spin-slow');
        }
      }, 800);
    };

    const applyFilters = () => {
      setDropdownOpen(false);
      const groupedFilters: Record<
        string,
        { operation: string; fieldName: string; fieldString: string[] }
      > = {};

      Object.entries(tempFilters).forEach(([category, values]) => {
        if (values.length > 0) {
          values.forEach((value) => {
            const originalOption = filtersData[category]?.find(
              (opt) => opt.value === value,
            );
            const fieldStringValue = originalOption
              ? originalOption.value
              : value;
            const fieldName = originalOption ? originalOption.fieldName : '';
            const operation = 'eq'; // Assuming operation is always "eq" for now

            if (!groupedFilters[fieldName]) {
              groupedFilters[fieldName] = {
                operation: operation,
                fieldName: fieldName,
                fieldString: [],
              };
            }
            groupedFilters[fieldName].fieldString.push(fieldStringValue);
          });
        }
      });
      handleExport(Object.values(groupedFilters));
    };

    const handleCheckboxChange = (category: string, optionValue: string) => {
      setTempFilters((prev) => {
        const prevOptions = prev[category] || [];
        return {
          ...prev,
          [category]: prevOptions.includes(optionValue)
            ? prevOptions.filter((item) => item !== optionValue)
            : [...prevOptions, optionValue],
        };
      });
    };

    const getAppliedFilterCount = (): number =>
      Object.values(tempFilters).reduce((acc, arr) => acc + arr.length, 0);

    useImperativeHandle(ref, () => ({
      resetFilters,
    }));

    useOutsideClick(dropdownRef, () => setDropdownOpen(false));

    return (
      <div
        className={`filter-btn flex items-center justify-center h-full`}
        style={{ position: 'relative' }}
      >
        <button
          ref={buttonRef}
          onClick={toggleDropdown}
          title="Filter options"
          className="p-2 bg-gray-100 rounded-md"
        >
          <FilterIcon
            color={`${active ? pageConst.filterActive : pageConst.filterDeActive}`}
          />
        </button>

        {isDropdownOpen && (
          <div
            className="dropdown-panel absolute w-52 bg-white z-10 rounded-2xl shadow-md flex flex-col top-0 right-0"
            ref={dropdownRef}
            style={dropdownStyle}
          >
            <div className="dropdown-header p-4 border-b border-gray-200 flex items-center justify-between">
              <div className="dropdown-title flex items-center justify-center">
                <h4 className="text-base font-medium text-gray-800 m-0">
                  Filter
                </h4>
                <span className="ml-3 w-6 h-6 bg-gray-200 text-base font-medium text-gray-800 flex items-center justify-center rounded-lg">
                  {getAppliedFilterCount()}
                </span>
              </div>
              <button
                className="reset-btn bg-none border-none cursor-pointer flex items-center justify-center p-0"
                onClick={resetFilters}
                title="Refresh"
              >
                <div ref={iconRef} className="flex items-center justify-center">
                  <ResetIcon className="text-grey-300" />
                </div>
              </button>
            </div>

            <div className="dropdown-body p-4 max-h-72 overflow-y-auto">
              {Object.entries(filtersData).map(([category, options]) => (
                <div
                  key={category}
                  className="filter-group p-4 bg-gray-100 rounded-2xl last:mb-0 mb-4"
                >
                  <h6 className="text-base font-medium text-gray-800 mb-4 capitalize">
                    {category}
                  </h6>
                  <div>
                    {options.map((option: FilterOption) => (
                      <label
                        key={option.value}
                        className={`option-list flex items-center capitalize cursor-pointer text-sm font-normal text-gray-700 last:mb-0 mb-2 ${(tempFilters[category] || []).includes(option.value) ? 'text-gray-900' : ''}`}
                      >
                        <CheckBoxInput
                          checked={(tempFilters[category] || []).includes(
                            option.value,
                          )}
                          onChange={() =>
                            handleCheckboxChange(category, option.value)
                          }
                        />
                        {<span className="ml-2">{option.label}</span>}
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="dropdown-footer p-4 border-t border-gray-200 flex gap-2">
              <button
                onClick={() => setDropdownOpen(false)}
                className="flex-1 py-2 text-sm font-medium h-auto m-0 text-center border border-gray-300 text-gray-700 bg-white rounded-md"
              >
                Cancel
              </button>
              <button
                onClick={applyFilters}
                className="flex-1 py-2 text-sm font-medium h-auto m-0 text-center border-0 text-white bg-primary-blue rounded-md"
              >
                Apply
              </button>
            </div>
          </div>
        )}
      </div>
    );
  },
);

export default Filter;
