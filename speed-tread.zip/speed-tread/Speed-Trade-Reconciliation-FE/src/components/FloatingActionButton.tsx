import React from 'react';
import PlusIcon from './Images/PlusIcon';

interface FloatingActionButtonProps {
  onClick: () => void;
  title?: string;
  sliderType?: 'transaction' | 'order';
}

const FloatingActionButton: React.FC<FloatingActionButtonProps> = ({
  onClick,
  title,
  sliderType,
}) => {
  const buttonTitle = (() => {
    if (sliderType === 'transaction') {
      return 'Add Transaction';
    } else if (sliderType === 'order') {
      return 'Add New Order';
    }
    return title || 'Add New';
  })();

  return (
    <button
      className="absolute bottom-8 right-8 bg-primary-blue text-white rounded-full h-[56px] w-[56px] flex items-center justify-center shadow-lg hover:bg-royal-purple"
      onClick={onClick}
      title={buttonTitle}
    >
      <PlusIcon width="24px" height="24px" />
    </button>
  );
};

export default FloatingActionButton;
