import React, { useState } from 'react';
import CurrencyItem from './CurrencyItem';
import FavoriteIcon from './FavoriteIcon';
import { AddButtonDotted } from './AddButtonDotted';
import AddTransactionModal from './Modal/AddTransactionModal';
import AddOrderModal from './Modal/AddOrderModal';
import ThreeDotDropdown from './ThreeDotDropdown';
import AddGroupModal from './Modal/AddGroupModal';
import TextTooltip from './TextTooltip';
import { Currency } from '../interfaces/currency';
import { useAppDispatch, useAppSelector } from '../store/store';
import { currencyReorderThunk, updateGroupThunk } from '../store/thunks/groups';
import { GroupCardProps } from '../interfaces/components';
import { updateFavorite } from '../store/slices/groups/getAllGroupsSlice';
import { updateFavoriteInOrderGroup } from '../store/slices/groups/orderGroupGetAllSlice';
import { useHorizontalScroll } from '../hooks/HorizontalScroll';
import { groupMoreOption } from '../constants/dropdowns';
import ReOrderItem from './Modal/ReOrderItem';
import CurrencyViewer from './CurrencyViewer';
import moment from 'moment';
import { defaultDateFormat } from './formFields/DateRangeInput';

const GroupCard: React.FC<GroupCardProps> = ({
  group,
  sliderType,
  onDataUpdate,
}) => {
  const dispatch = useAppDispatch();
  const scrollPercent = useHorizontalScroll('my-scroll-div' + group.unique_id);

  const [isAddTransactionModalOpen, setIsAddTransactionModalOpen] =
    useState(false);
  const [isAddOrderModalOpen, setIsAddOrderModalOpen] = useState(false);
  const [isAddGroupModalOpen, setIsAddGroupModalOpen] = useState(false);
  const [isReorderModalOpen, setIsReorderModalOpen] = useState(false);

  const handleOpenModal = (e?: React.MouseEvent<HTMLButtonElement>) => {
    e?.stopPropagation();
    if (sliderType === 'order') {
      setIsAddOrderModalOpen(true);
    } else {
      setIsAddTransactionModalOpen(true);
    }
  };

  const handleCloseAddTransactionModal = () => {
    setIsAddTransactionModalOpen(false);
  };

  const handleAddTransactionSuccess = () => {
    if (onDataUpdate) {
      onDataUpdate();
    }
    setIsAddTransactionModalOpen(false);
  };

  const handleCloseAddOrderModal = () => {
    setIsAddOrderModalOpen(false);
  };

  const handleThreeDotAction = (action: string) => {
    if (action === 'edit') {
      setIsAddGroupModalOpen(true);
    } else if (action === 'add') {
      handleOpenModal();
    } else if (action === 'reorder') {
      openReorderModel();
    }
  };

  const handleFavoriteToggle = () => {
    const payload = {
      unique_id: group.unique_id,
      is_favorite: !group.is_favorite,
    };
    if (sliderType === 'transaction') {
      dispatch(updateFavorite(payload));
    } else {
      dispatch(updateFavoriteInOrderGroup(payload));
    }
    dispatch(
      updateGroupThunk({
        payload: {
          unique_id: group.unique_id,
          name: group.name,
          is_favorite: !group.is_favorite,
        },
        callbackAfterSuccess: () => {
          if (onDataUpdate) {
            onDataUpdate();
          }
        },
        callbackAfterFailure: () => {
          const payload = {
            unique_id: group.unique_id,
            is_favorite: group.is_favorite,
          };
          if (sliderType === 'transaction') {
            dispatch(updateFavorite(payload));
          } else {
            dispatch(updateFavoriteInOrderGroup(payload));
          }
        },
      }),
    );
  };

  const openReorderModel = () => {
    setIsReorderModalOpen(true);
  };
  const closeReorderModel = () => {
    setIsReorderModalOpen(false);
  };

  const handleReorder = (reorderedItems: any[]) => {
    const orderData = reorderedItems?.map((item: Currency, index: number) => ({
      currency_id: item.currency_id ?? '', // Or any other unique identifier
      order: index + 1,
    }));

    let payload = {
      orders: orderData,
      group_id: group.unique_id,
    };

    dispatch(
      currencyReorderThunk({
        payload,
        callbackAfterSuccess: reorderSideEffect,
      }),
    );
  };

  const reorderSideEffect = () => {
    closeReorderModel();
    onDataUpdate && onDataUpdate();
  };

  return (
    <>
      <div className="bg-white rounded-lg shadow-md p-4 flex flex-col md:flex-row md:items-center md:justify-between w-full relative mb-4 border border-border-dark-grey">
        <div className="flex flex-col md:flex-row gap-4 flex-grow min-w-0 w-full">
          <div className="w-full md:w-[200px] flex-shrink-0">
            <div className="flex items-center space-x-2">
              <div
                className={`rounded-md px-2 py-1 text-sm font-semibold ${group.is_favorite ? 'bg-bright-orange text-white' : 'bg-gray-100 text-gray-800'}`}
              >
                {group.group_id}
              </div>
              <div className="cursor-pointer">
                <FavoriteIcon
                  isFavorite={group.is_favorite}
                  onClick={handleFavoriteToggle}
                  hoverEffect
                  width="w-[18px]"
                  height="h-[18px]"
                />
              </div>
            </div>
            <TextTooltip text={group.name} wrapperClassName="w-full">
              <div className="text-lg font-bold text-gray-800 mt-1 overflow-hidden text-ellipsis whitespace-nowrap">
                {group.name}
              </div>
            </TextTooltip>
          </div>
          <div
            className={`currency-list flex flex-col-reverse md:flex-row md:items-center flex-1 w-full gap-[30px] overflow-y-auto relative ${scrollPercent < 90 ? 'after:absolute after:right-0 after:top-0 after:w-[110px] after:h-full after:bg-gradient-to-r after:from-white/0 after:to-white/100' : ''} `}
          >
            {/* 
            Don't delete
            ToDo: Temporally hide
            <AddButtonDotted
              onClick={handleOpenModal}
              fullWidth={false}
              sliderType={sliderType}
            />
             */}

            <div
              className={`pr-[40px] my-scroll-div ${group.unique_id} flex flex-col md:flex-row md:items-center gap-[30px] overflow-x-auto scrollbar-hide scroll-smooth md:flex-nowrap pl-1 relative  
             `}
            >
              {group.currencies?.map((currency: Currency, index: number) => (
                <div className={`flex-shrink-0`} key={index}>
                  <CurrencyItem
                    currency={currency}
                    groupId={group.group_id}
                    groupName={group.name}
                    group_uniqueId={group.unique_id}
                    sliderType={sliderType}
                    onDataUpdate={onDataUpdate}
                    is_favorite={group.is_favorite}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
        <div
          className="absolute top-4 right-4 z-10 md:relative md:top-auto md:right-auto md:z-auto md:order-last ml-4"
          onClick={(e) => e.stopPropagation()} // Prevent any parent click handlers
        >
          <ThreeDotDropdown
            items={groupMoreOption(sliderType)}
            onAction={handleThreeDotAction}
          />
        </div>
      </div>
      {isAddTransactionModalOpen && (
        <AddTransactionModal
          isOpen={isAddTransactionModalOpen}
          onClose={handleCloseAddTransactionModal}
          onSuccess={handleAddTransactionSuccess}
          id={group.group_id}
          name={group.name}
          group_uniqueId={group.unique_id}
          settlementCurrency={group.settlement_currency}
          showSettlementCurrency={true}
        />
      )}
      {isAddOrderModalOpen && (
        <AddOrderModal
          isOpen={isAddOrderModalOpen}
          onClose={handleCloseAddOrderModal}
          onOrderAdded={onDataUpdate}
          groupId={group.group_id}
          groupName={group.name}
          group_uniqueId={group.unique_id}
          selectedDate={moment().format(defaultDateFormat)}
        />
      )}
      {isAddGroupModalOpen && (
        <AddGroupModal
          isOpen={isAddGroupModalOpen}
          onClose={() => setIsAddGroupModalOpen(false)}
          groupId={group.unique_id}
          onDataUpdate={onDataUpdate}
          context={sliderType}
        />
      )}
      {isReorderModalOpen && (
        <ReOrderItem
          isOpen={isReorderModalOpen}
          onClose={closeReorderModel}
          title="Edit Currency"
          cancelButtonText="Cancel"
          confirmButtonText="Update"
          groupId={group.unique_id}
          keyExtractor={(item: Currency) => item.currency}
          onConfirm={handleReorder}
        >
          {(currencyItem: Currency) => {
            return (
              <CurrencyViewer currency={currencyItem} cursorPointer={false} />
            );
          }}
        </ReOrderItem>
      )}
    </>
  );
};

export default GroupCard;
