import React from 'react';

const GroupCardListSkeleton: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-md p-4 flex flex-col md:flex-row md:items-center md:justify-between w-full relative mb-4 animate-pulse border border-border-dark-grey">
      <div className="flex flex-col md:flex-row gap-4 flex-grow min-w-0 w-full">
        <div className="w-full md:w-[200px] flex-shrink-0">
          <div className="flex items-center space-x-2">
            <div className="h-6 w-16 bg-gray-300 rounded"></div>
            <div className="h-6 w-6 bg-gray-300 rounded-full"></div>
          </div>
          <div className="h-4 w-3/4 bg-gray-300 rounded mt-2"></div>
        </div>
        <div className="flex flex-col-reverse md:flex-row md:items-center flex-1 w-full gap-[30px] overflow-y-auto">
          <div className="h-8 w-8 bg-gray-300 rounded-full"></div>
          <div className="flex flex-col md:flex-row md:items-center gap-[30px] md:overflow-x-auto md:flex-nowrap pl-1">
            <div className="h-12 w-40 bg-gray-300 rounded-lg flex-shrink-0"></div>
            <div className="h-12 w-40 bg-gray-300 rounded-lg flex-shrink-0"></div>
            <div className="h-12 w-40 bg-gray-300 rounded-lg flex-shrink-0"></div>
          </div>
        </div>
      </div>
      <div className="absolute top-4 right-4 z-10 md:relative md:top-auto md:right-auto md:z-auto md:order-last ml-4">
        <div className="h-6 w-6 bg-gray-300 rounded-full"></div>
      </div>
    </div>
  );
};

export default GroupCardListSkeleton;
