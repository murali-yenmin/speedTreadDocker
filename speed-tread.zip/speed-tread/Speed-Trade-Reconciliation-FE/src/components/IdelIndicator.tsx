import { useEffect, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';

interface IdleTimerProps {
  idleTime?: number;
  popupWaitTime?: number;
  onLogout: () => void;
}

export function useIdleTimer({
  idleTime = 2 * 60 * 1000,
  popupWaitTime = 30 * 1000,
  onLogout,
}: IdleTimerProps) {
  const { pathname } = useLocation();

  const disableRoutes = [
    '/login',
    '/forgot-password',
    '/reset',
    '/reset-password/:token',
  ];

  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const [showPopup, setShowPopup] = useState(false);
  const [secondsRemaining, setSecondsRemaining] = useState(
    popupWaitTime / 1000,
  );

  const events = ['mousemove', 'keydown', 'click', 'scroll'];

  const removeEventListeners = () => {
    events.forEach((e) => window.removeEventListener(e, eventHandler));
  };

  const addEventListeners = () => {
    events.forEach((e) => window.addEventListener(e, eventHandler));
  };

  const eventHandler = () => {
    if (!showPopup) resetTimers();
  };

  const startCountdown = () => {
    clearInterval(intervalRef.current!);
    setSecondsRemaining(popupWaitTime / 1000);

    intervalRef.current = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(intervalRef.current!);
          onLogout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const resetTimers = () => {
    if (disableRoutes.includes(pathname)) {
      clearTimeout(timeoutRef.current!);
      clearInterval(intervalRef.current!);
      setShowPopup(false);
      return;
    }

    clearTimeout(timeoutRef.current!);
    clearInterval(intervalRef.current!);

    setShowPopup(false);

    timeoutRef.current = setTimeout(() => {
      setShowPopup(true);
      removeEventListeners(); // STOP tracking inputs when popup displayed
      startCountdown();
    }, idleTime);
  };

  const stayActive = () => {
    setShowPopup(false);
    addEventListeners();
    resetTimers();
  };

  useEffect(() => {
    if (!disableRoutes.includes(pathname)) {
      addEventListeners();
      resetTimers();
    }

    return () => {
      removeEventListeners();
      clearTimeout(timeoutRef.current!);
      clearInterval(intervalRef.current!);
    };
  }, [pathname]);

  return { showPopup, stayActive, secondsRemaining };
}
