import React from 'react';
import Slider from 'react-slick';

interface Slide {
  image?: string;
  icon?: React.ReactNode;
  title: string;
  subtitle: string;
  highlightedTitle?: string;
}

interface ImageSliderProps {
  slides: Slide[];
}

const ImageSlider: React.FC<ImageSliderProps> = ({ slides }) => {
  const settings = {
    dots: true,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 4000,
    speed: 600,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    appendDots: (dots: React.ReactNode) => (
      <div className="absolute bottom-4 w-full">
        <ul className="flex justify-center">{dots}</ul>
      </div>
    ),
    customPaging: () => (
      <div className="h-2 w-2 bg-gray-400 rounded-full"></div>
    ),
  };

  return (
    <Slider {...settings} className="w-full h-full">
      {slides.map((slide, idx) => (
        <div
          key={idx}
          className="relative flex flex-col items-center justify-center h-full"
        >
          {/* Render icon if provided, else fallback to image */}
          {slide.icon ? (
            <div className="flex justify-center">{slide.icon}</div>
          ) : (
            slide.image && (
              <img
                src={slide.image}
                alt={`Slide ${idx}`}
                className="w-full max-h-full object-contain"
              />
            )
          )}
          {/* Text Section */}
          <div className="text-center text-gray-800 px-4 flex-grow flex flex-col justify-center">
            <h1 className="text-4xl font-bold">
              {slide.title}{' '}
              {slide.highlightedTitle && (
                <>
                  <br />
                  <span className="font-extrabold">
                    {slide.highlightedTitle}
                  </span>
                </>
              )}
            </h1>
            <h2 className="text-xl font-medium mt-2">{slide.subtitle}</h2>
          </div>
        </div>
      ))}
    </Slider>
  );
};

export default ImageSlider;
