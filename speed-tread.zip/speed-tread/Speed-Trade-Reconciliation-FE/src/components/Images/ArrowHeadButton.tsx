import React from 'react';
import ArrowHead from './ArrowHead';

interface ArrowHeadButtonProps {
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'tertiary';
  active?: boolean;
  small?: boolean;
  rotate?: boolean;
  needCursor?: boolean;
}

const ArrowHeadButton: React.FC<ArrowHeadButtonProps> = ({
  onClick,
  variant = 'primary',
  small = false,
  active = false,
  rotate,
  needCursor = true,
}) => {
  const bgColor =
    active || variant === 'primary'
      ? 'bg-primary-blue'
      : variant === 'secondary'
        ? 'bg-light-grey'
        : 'bg-white border border-primary-blue';
  const rotation = rotate ? 'transform rotate-180' : '';

  return (
    <button
      type="button"
      onClick={onClick}
      className={`${needCursor ? 'cursor-pointer' : 'cursor-default'} ${small ? 'w-[21px] h-[21px]' : 'w-[29px] h-[29px]'} ${bgColor} rounded-full flex items-center justify-center ${rotation}`}
    >
      <ArrowHead
        fill={!active ? 'text-primary-blue' : 'text-white'}
        small={small}
      />
    </button>
  );
};

export default ArrowHeadButton;
