const CheckIcon = () => (
  <svg
    width="16"
    height="13"
    viewBox="0 0 16 13"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M0.703125 5.66675L5.75868 10.6667L10.2309 5.66675L14.7031 0.666748"
      stroke="white"
      strokeWidth="2"
    />
  </svg>
);

export default CheckIcon;
