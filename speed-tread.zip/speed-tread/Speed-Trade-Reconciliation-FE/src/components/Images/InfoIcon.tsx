import React from 'react';

interface InfoIconProps {
  className?: string;
}

const InfoIcon: React.FC<InfoIconProps> = ({ className }) => {
  return (
    <svg
      className={className}
      width="16"
      height="16"
      viewBox="0 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g clipPath="url(#clip0_304_499)">
        <path
          d="M13.9995 8C13.9995 4.68632 11.3132 2.00004 7.99951 2C4.6858 2 1.99951 4.68629 1.99951 8C1.99956 11.3137 4.68583 14 7.99951 14C11.3132 14 13.9995 11.3136 13.9995 8ZM15.3328 8C15.3327 12.05 12.0495 15.3332 7.99951 15.3333C3.94945 15.3333 0.666059 12.0501 0.666016 8C0.666016 3.94991 3.94942 0.666504 7.99951 0.666504C12.0496 0.666548 15.3328 3.94994 15.3328 8Z"
          fill="currentColor"
        />
        <path
          d="M7.33268 10.6667V7.99992C7.33268 7.63173 7.63124 7.33317 7.99943 7.33317C8.36762 7.33317 8.66618 7.63173 8.66618 7.99992V10.6667C8.66613 11.0348 8.36759 11.3332 7.99943 11.3332C7.63127 11.3332 7.33273 11.0348 7.33268 10.6667Z"
          fill="currentColor"
        />
        <path
          d="M8.00602 4.6665C8.37421 4.6665 8.67277 4.96506 8.67277 5.33325C8.67277 5.70144 8.37421 6 8.00602 6H7.99943C7.63124 6 7.33268 5.70144 7.33268 5.33325C7.33268 4.96506 7.63124 4.6665 7.99943 4.6665H8.00602Z"
          fill="currentColor"
        />
      </g>
      <defs>
        <clipPath id="clip0_304_499">
          <rect width="16" height="16" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
};

export default InfoIcon;
