interface MinusIconProps {
  width?: string;
  height?: string;
  className?: string;
}

const MinusIcon: React.FC<MinusIconProps> = ({
  width = '24px',
  height = '24px',
  className = '',
}) => (
  <svg
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    width={width}
    height={height}
    className={className}
  >
    <path
      d="M3.29102 7.90039H12.5072"
      stroke="currentColor"
      stroke-width="2.10656"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
);

export default MinusIcon;
