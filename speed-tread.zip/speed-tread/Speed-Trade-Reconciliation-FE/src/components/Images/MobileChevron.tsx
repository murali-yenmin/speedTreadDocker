const MobileChevron = () => {
  return (
    <>
      <svg
        width="13"
        height="6"
        viewBox="0 0 13 6"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M6.49512 -6.55671e-07L12.9903 5.25L-7.2974e-05 5.25L6.49512 -6.55671e-07Z"
          fill="#8F8F8F"
        />
      </svg>
    </>
  );
};

export default MobileChevron;
