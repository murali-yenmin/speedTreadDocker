const MobileChevronDown = () => {
  return (
    <>
      <svg
        width="13"
        height="6"
        viewBox="0 0 13 6"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M6.49512 5.25L12.9903 2.69824e-07L-7.2974e-05 -8.65831e-07L6.49512 5.25Z"
          fill="#8F8F8F"
        />
      </svg>
    </>
  );
};

export default MobileChevronDown;
