import React from 'react';

interface PlusIconProps {
  width?: string;
  height?: string;
  className?: string;
}

const PlusIcon: React.FC<PlusIconProps> = ({
  width = '24px',
  height = '24px',
  className = '',
}) => (
  <svg
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    width={width}
    height={height}
    className={className}
  >
    <path
      d="M3.29102 7.90039H12.5072"
      stroke="white"
      strokeWidth="2.10656"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M7.90039 3.29102V12.5072"
      stroke="white"
      strokeWidth="2.10656"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export default PlusIcon;
