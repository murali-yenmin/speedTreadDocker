const SortIcon = () => {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M4 18L8 14H6V6H4V14H2L6 18H4ZM10 10H22V12H10V10ZM10 6H18V8H10V6ZM10 14H16V16H10V14Z"
        fill="currentColor"
      />
    </svg>
  );
};

export default SortIcon;
