import React from 'react';
import { LoaderProps } from '../interfaces/components';

const Loader: React.FC<LoaderProps> = ({ dotColor = 'bg-white' }) => {
  return (
    <div className="flex items-center justify-center space-x-1">
      {[...Array(5)].map((_, index) => (
        <div
          key={index}
          className={`w-2 h-2 ${dotColor} rounded-full animate-dot-pulse`}
          style={{ animationDelay: `${index * 0.1}s` }}
        ></div>
      ))}
    </div>
  );
};

export default Loader;
