import React from 'react';

interface ManagementDashboardCardProps {
  title: string;
  icon: React.ReactNode;
  buttons: {
    text: string;
    onClick: () => void;
  }[];
}

const ManagementDashboardCard: React.FC<ManagementDashboardCardProps> = ({
  title,
  icon,
  buttons,
}) => {
  return (
    <div className="bg-white rounded-lg p-4 sm:p-6 border border-border-light-grey w-full">
      <div className="mb-[14px] text-black">{icon}</div>
      <h3 className="text-rich-black font-bold text-xl sm:text-[22px] leading-normal sm:leading-[40px] mb-[14px]">
        {title}
      </h3>
      <div className="flex flex-col space-y-[10px]">
        {buttons.map((button, index) => (
          <button
            key={index}
            onClick={button.onClick}
            className="bg-quaternary-grey hover:bg-gray-200 text-primary-blue font-semibold text-[16px] py-2 px-4 rounded-lg transition-colors duration-300 w-full md:max-w-max"
          >
            {button.text}
          </button>
        ))}
      </div>
    </div>
  );
};

export default ManagementDashboardCard;