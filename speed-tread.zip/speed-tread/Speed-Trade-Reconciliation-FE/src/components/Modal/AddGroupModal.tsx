import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import Modal from './Modal';
import Input from '../formFields/Input';
import Dropdown from '../formFields/Dropdown';
import Button from '../formFields/Button';
import {
  AddGroupModalProps,
  AddGroupFormData,
} from '../../interfaces/components';
import { useAppDispatch, useAppSelector } from '../../store/store';
import {
  addGroupThunk,
  updateGroupThunk,
  getOrderGroupByIdThunk,
  getTransactionGroupByIdThunk,
} from '../../store/thunks/groups';
import { groupSchema } from '../../validations/group';
import { resetGetOrderGroupById } from '../../store/slices/groups/getOrderGroupByIdSlice';
import { resetGetTransactionGroupById } from '../../store/slices/groups/getTransactionGroupByIdSlice';

const AddGroupModal: React.FC<AddGroupModalProps> = ({
  isOpen,
  onClose,
  groupId,
  onDataUpdate,
  context,
}) => {
  const dispatch = useAppDispatch();

  const { data: group, isLoading: groupLoading } = useAppSelector((state) =>
    context === 'order'
      ? state.getOrderGroupByIdReducer
      : state.getTransactionGroupByIdReducer,
  );

  const addGroupLoader = useAppSelector(
    (state) => state.addGroupReducer.loading,
  );
  const updateGroupLoader = useAppSelector(
    (state) => state.updateGroupReducer.loading,
  );

  const isLoading = addGroupLoader || updateGroupLoader;

  const currencies = useAppSelector(
    (state) =>
      state.getAllCurrenciesReducer.data?.map((item) => ({
        label: item?.code,
        value: item?.code,
      })) || [],
  );

  const {
    control,
    handleSubmit,
    reset,
    setError,
    setValue,
    formState: { errors },
  } = useForm<AddGroupFormData>({
    resolver: yupResolver(groupSchema),
    defaultValues: {
      name: '',
      settlement_currency: '',
      group_id: '',
    },
  });

  const getGroupNumber = (groupId: string) => {
    return (groupId.match(/\d+/) || [''])[0];
  };

  useEffect(() => {
    if (groupId && context) {
      if (context === 'order') {
        dispatch(getOrderGroupByIdThunk({ payload: { id: groupId } }));
      } else {
        dispatch(getTransactionGroupByIdThunk({ payload: { id: groupId } }));
      }
    }
  }, [groupId, context, dispatch]);

  useEffect(() => {
    if (isOpen) {
      if (group) {
        reset({
          name: group.name,
          settlement_currency: group.settlement_currency,
          group_id: getGroupNumber(group.group_id),
        });
      } else {
        reset({
          name: '',
          settlement_currency: '',
          group_id: '',
        });
      }
    }
  }, [group, reset, isOpen]);

  const handleClose = () => {
    reset();
    onClose();
    dispatch(resetGetOrderGroupById());
    dispatch(resetGetTransactionGroupById());
  };

  const onSubmit = (data: AddGroupFormData) => {
    const callbackAfterSuccess = () => {
      handleClose();
      if (onDataUpdate) {
        onDataUpdate();
      }
    };

    if (group) {
      // Edit existing group
      const payload: {
        unique_id: string;
        name: string;
        settlement_currency?: string;
      } = {
        unique_id: group.unique_id,
        name: data.name,
      };

      if (data.settlement_currency) {
        payload.settlement_currency = data.settlement_currency;
      }

      dispatch(
        updateGroupThunk({
          payload: { ...payload, unique_id: group.unique_id },
          callbackAfterSuccess,
          callbackAfterFailure: (fields) => {
            if (fields?.name)
              setError('name', { type: 'custom', message: fields?.name });
            if (fields?.group_id)
              setError('group_id', {
                type: 'custom',
                message: fields?.group_id,
              });
          },
        }),
      );
    } else {
      // Add new group
      if (!data.settlement_currency) {
        // This should not happen if validation is working correctly
        return;
      }
      dispatch(
        addGroupThunk({
          payload: {
            name: data.name,
            settlement_currency: data.settlement_currency,
            group_id: `ST${data.group_id}`,
          },
          callbackAfterSuccess,
          callbackAfterFailure: (fields) => {
            if (fields?.name)
              setError('name', { type: 'custom', message: fields?.name });
            if (fields?.group_id)
              setError('group_id', {
                type: 'custom',
                message: fields?.group_id,
              });
          },
        }),
      );
    }
  };

  const formatGroupNo = (value: string) => {
    if (!value) {
      return '';
    }
    if (value.length < 3) {
      return value.padStart(3, '0');
    }
    return value;
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      title={group ? 'Edit Group' : 'New Group'}
      loader={groupLoading}
    > 
      <form onSubmit={handleSubmit(onSubmit)} autoComplete="off">
        <div className="space-y-4 mt-4">
          <div className="grid grid-cols-1 xs:grid-cols-[1.05fr_3fr] gap-4">
            <Input
              label="Group ID"
              name="group_id"
              placeholder="Enter Group ID"
              control={control}
              prefix="ST"
              type="number"
              disabled={!!group}
              maxLength={3}
              className="min-w-[155px]"
              onBlur={(e) => {
                const formattedValue = formatGroupNo(e.target.value);
                if (formattedValue !== e.target.value) {
                  setValue('group_id', formattedValue, {
                    shouldValidate: true,
                  });
                }
              }}
            />
            <Input
              label="Group Name"
              name="name"
              placeholder="Enter Group Name"
              control={control}
              maxLength={150}
            />
          </div>
          {!groupId && (
            <Dropdown
              label="Settlement Currency"
              name="settlement_currency"
              options={currencies}
              placeholder="Select Settlement Currency"
              control={control}
              disabled={!!group}
            />
          )}
        </div>
        <div className="flex justify-end gap-4 mt-6">
          <Button
            type="button"
            onClick={handleClose}
            variant="secondary"
            fullWidth={false}
            className="h-11"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            variant="primary"
            fullWidth={false}
            isLoading={isLoading}
            className="h-11 min-w-[89px]"
          >
            {group ? 'Save' : 'Create'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};

export default AddGroupModal;
