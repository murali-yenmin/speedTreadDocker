import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  useForm,
  Controller,
  SubmitHandler,
  Resolver,
  useFieldArray,
} from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import Modal from './Modal';
import Dropdown from '../formFields/Dropdown';
import ToggleButton from '../formFields/ToggleButton';
import ButtonGroup from '../formFields/ButtonGroup';
import { AddOrderModalProps, OrderSummary } from '../../interfaces/components';
import { AddOrderFormValues } from '../../interfaces/order';
import { AccountName } from '../../store/interfaces/accountName';
import { useAppSelector, RootState, useAppDispatch } from '../../store/store';
import { addOrderFormSchema } from '../../validations/order';
import { addOrderThunk } from '../../store/thunks/order';
import { getPairedCurrenciesThunk } from '../../store/thunks/pairedCurrencies';
import Button from '../formFields/Button';
import { ADD_ORDER_MODAL } from '../../constants/dropdowns';
import { getAccountNamesThunk } from '../../store/thunks/accountName';
import { resetAccountNames } from '../../store/slices/accountNameSlice';
import OrderSummaryModal from './OrderSummaryModal';
import useOutsideClick from '../../utils/outsideClick';
import InfoIcon from '../Images/InfoIcon';
import RadioGroup from '../formFields/RadioGroup';
import AddOrderForm from '../AddOrder/AddOrderForm';
import SingleOrderForm from '../AddOrder/SingleOrderForm';
import MultiOrderForm from '../AddOrder/MultiOrderForm';

const AddOrderModal: React.FC<AddOrderModalProps> = ({
  isOpen,
  onClose,
  settlementCurrency,
  group_uniqueId,
  onOrderAdded,
  selectedDate,
}) => {
  const dispatch = useAppDispatch();
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const { accountNames } = useAppSelector((state) => state.accountNameReducer);

  const [selectedItem, setSelectedItem] = useState<AccountName | null>(null);
  const [selectedItems, setSelectedItems] = useState<(AccountName | null)[]>(
    [],
  );
  const [showAccountNameDropdown, setShowAccountNameDropdown] = useState(false);
  const [showMultiAccountNameDropdown, setShowMultiAccountNameDropdown] =
    useState<number | null>(null);
  const [isSummaryModalOpen, setIsSummaryModalOpen] = useState(false);
  const [orderSummaryData, setOrderSummaryData] = useState<OrderSummary | null>(
    null,
  );

  const items: AccountName[] = accountNames;
  const { loading: addOrderLoading } = useAppSelector(
    (state: RootState) => state.addOrderReducer,
  );
  const handleAccountNameChange = useCallback(
    (value: string) => {
      if (value) {
        dispatch(getAccountNamesThunk(value));
        return;
      }
      dispatch(resetAccountNames());
      return;
    },
    [dispatch],
  );

  const handleMultiAccountNameChange = useCallback(
    (value: string, index: number) => {
      if (value) {
        setShowMultiAccountNameDropdown(index);
        dispatch(getAccountNamesThunk(value));
      }
    },
    [dispatch],
  );

  const form = useForm<AddOrderFormValues>({
    resolver: yupResolver(
      addOrderFormSchema(settlementCurrency),
    ) as unknown as Resolver<AddOrderFormValues>,
    defaultValues: {
      isMultiOrder: false,
      orderFor: 'we',
      orderType: 'buy',
      settlementCurrency: settlementCurrency || '',
      fee: undefined,
      accountName: '',
      remarks: '',
      orders: [
        {
          amount: undefined,
          currency: settlementCurrency || '',
          rate: undefined,
          accountName: '',
          remarks: '',
          fee: undefined,
        },
      ],
    },
  });

  const {
    control,
    watch,
    reset,
    getValues,
    setValue,
    setError,
    clearErrors,
    trigger,
    formState: { errors },
  } = form;

  const { fields } = useFieldArray({
    control,
    name: 'orders',
  });

  const isMultiOrder = watch('isMultiOrder');
  const watchedSettlementCurrency = watch('settlementCurrency');

  useEffect(() => {
    reset({
      isMultiOrder,
      orderFor: 'we',
      orderType: 'buy',
      settlementCurrency: settlementCurrency || '',
      fee: undefined,
      accountName: '',
      remarks: '',
      orders: [
        {
          amount: undefined,
          currency: settlementCurrency || '',
          rate: undefined,
          accountName: '',
          remarks: '',
          fee: undefined,
        },
      ],
    });
    clearErrors();
    trigger('orders.0.rate');
  }, [isMultiOrder, reset, settlementCurrency, clearErrors]);

  useEffect(() => {
    if (isOpen && watchedSettlementCurrency) {
      dispatch(
        getPairedCurrenciesThunk({
          settlement_currency: watchedSettlementCurrency,
        }),
      );
      const currentOrders = getValues('orders');
      const updatedOrders = currentOrders.map((order) => ({
        ...order,
        currency: watchedSettlementCurrency,
        rate: undefined,
      }));
      setValue('orders', updatedOrders);
    }
  }, [isOpen, watchedSettlementCurrency, dispatch, getValues, setValue]);

  const currencies = useAppSelector(
    (state: RootState) =>
      state.getAllCurrenciesReducer.data?.map(
        (item: { name: string; code: string }) => ({
          label: item?.code,
          value: item?.code,
        }),
      ) || [],
  );

  const pairedCurrencies = useAppSelector(
    (state: RootState) => state.pairedCurrenciesReducer.data,
  );

  const handleClose = () => {
    reset();
    setShowMultiAccountNameDropdown(null);
    setShowAccountNameDropdown(false);
    setSelectedItem(null);
    setSelectedItems([]);
    onClose();
  };

  const onSubmit: SubmitHandler<AddOrderFormValues> = (data) => {
    clearErrors();
    let hasError = false;
    data.orders.forEach((order, index) => {
      if (
        data.settlementCurrency !== order.currency &&
        (!order.rate || order.rate <= 0)
      ) {
        setError(`orders.${index}.rate` as const, {
          type: 'manual',
          message: 'Rate is required',
        });
        hasError = true;
      }
    });

    if (hasError) {
      return;
    }

    const transformedData = {
      is_multiOrder: data?.isMultiOrder,
      data: data.orders.map((order) => ({
        group_id: group_uniqueId,
        order_by: data?.orderFor,
        currency: order?.currency,
        settlement_currency: data?.settlementCurrency,
        amount: order?.amount,
        rate: order?.rate,
        trading: data?.orderType,
        remarks: data.isMultiOrder ? order?.remarks : data?.remarks,
        fee:
          data?.orderType !== 'adjustment'
            ? data.fee
              ? Number(data.fee)
              : undefined
            : undefined,
        account_id: data.isMultiOrder
          ? order?.accountName
          : selectedItem?.unique_id
            ? selectedItem?.unique_id
            : data?.accountName,
        ordered_date: selectedDate,
      })),
    };

    dispatch(
      addOrderThunk({
        payload: transformedData,
        callbackAfterSuccess: (summaryData: OrderSummary) => {
          handleClose();
          if (onOrderAdded) {
            onOrderAdded();
          }
        },
      }),
    );
  };

  const accountNameRef = useRef<HTMLDivElement>(null);
  const accountNameRefs = useRef<(HTMLDivElement | null)[]>([]);

  useOutsideClick(accountNameRef, () => setShowAccountNameDropdown(false));
  useOutsideClick(
    { current: accountNameRefs.current[showMultiAccountNameDropdown ?? -1] },
    () => {
      setShowMultiAccountNameDropdown(null);
    },
  );

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={handleClose}
        className={`min-w-[80%] sm:[min-width:unset] ${
          isMultiOrder ? 'md:max-w-[1151px] max-w-[80%]' : ''
        }`}
        preventOutsideClick
      >
        <div className="flex flex-col max-h-[80vh]">
          <div className="pb-6 border-b">
            <h2 className="text-lg font-bold">{'Add Order'}</h2>
          </div>
          <div
            className="flex-grow overflow-y-auto pb-6 pt-6"
            ref={scrollContainerRef}
            style={{ maxHeight: 'calc(80vh - 150px)' }}
          >
            <AddOrderForm onSubmit={onSubmit} form={form}>
              <div className="space-y-4">
                {!settlementCurrency && (
                  <div>
                    <Dropdown
                      label="Settlement Currency"
                      name="settlementCurrency"
                      options={currencies}
                      placeholder="Select Settlement Currency"
                      control={control}
                    />
                  </div>
                )}
                <div
                  className={`${
                    isMultiOrder ? 'flex gap-6 mid-range:flex-col' : ''
                  }`}
                >
                  <div
                    className={`${
                      isMultiOrder
                        ? 'w-[50%] mid-range:w-[100%]'
                        : 'w-full mb-4'
                    } flex items-center justify-between border rounded-lg p-3`}
                  >
                    <label>Multi Order?</label>
                    <Controller
                      name="isMultiOrder"
                      control={control}
                      render={({ field }) => (
                        <ToggleButton
                          {...field}
                          checked={field.value}
                          id="isMultiOrder"
                        />
                      )}
                    />
                  </div>
                  <div
                    className={`${
                      isMultiOrder ? 'w-[50%] mid-range:w-[100%]' : 'w-full'
                    }`}
                  >
                    <Controller
                      name="orderFor"
                      control={control}
                      render={({ field }) => (
                        <ButtonGroup
                          {...field}
                          options={[
                            { label: 'We', value: 'we' },
                            { label: 'Customer', value: 'customer' },
                          ]}
                        />
                      )}
                    />
                  </div>
                </div>
                <div
                  className={`${isMultiOrder ? 'flex gap-2 items-center' : ''}`}
                >
                  <div className={`${isMultiOrder ? '' : 'w-full'}`}>
                    <RadioGroup
                      name="orderType"
                      control={control}
                      options={
                        isMultiOrder
                          ? ADD_ORDER_MODAL?.filter(
                              (item) => item.value === 'buy',
                            )
                          : ADD_ORDER_MODAL
                      }
                      customClassName={`gap-x-[15px] grid   ${
                        isMultiOrder
                          ? 'xs:grid-cols-[1fr]'
                          : 'xs:grid-cols-[1fr_1fr_1fr] gap-y-[10px]'
                      }`}
                      childClassName="border rounded-[8px] py-[10px] px-[17px]"
                    />
                  </div>

                  <div
                    className={`flex justify-start items-start gap-2 transition-all duration-500 ease-in-out ${
                      isMultiOrder ? 'opacity-100' : 'opacity-0 hidden'
                    }`}
                    title="Information"
                  >
                    <span className="min-h-4 min-w-4">
                      <InfoIcon />
                    </span>
                    <p className="text-gray-400 leading-4">
                      Adjustment and Transfer options are not applicable for
                      multiple orders.
                    </p>
                  </div>

                  <div
                    className={`${
                      fields?.length > 1 ? 'w-[119px]' : 'w-[87px]'
                    }`}
                  ></div>
                </div>
                {isMultiOrder ? (
                  <MultiOrderForm
                    form={form}
                    pairedCurrencies={pairedCurrencies || []}
                    accountNameRefs={accountNameRefs}
                    handleMultiAccountNameChange={handleMultiAccountNameChange}
                    showMultiAccountNameDropdown={showMultiAccountNameDropdown}
                    setShowMultiAccountNameDropdown={
                      setShowMultiAccountNameDropdown
                    }
                    items={items}
                    selectedItems={selectedItems}
                    setSelectedItems={setSelectedItems}
                    scrollContainerRef={scrollContainerRef}
                  />
                ) : (
                  <SingleOrderForm
                    form={form}
                    pairedCurrencies={pairedCurrencies || []}
                    accountNameRef={accountNameRef}
                    handleAccountNameChange={handleAccountNameChange}
                    showAccountNameDropdown={showAccountNameDropdown}
                    setShowAccountNameDropdown={setShowAccountNameDropdown}
                    items={items}
                    selectedItem={selectedItem}
                    setSelectedItem={setSelectedItem}
                    fields={fields}
                  />
                )}
              </div>
            </AddOrderForm>
          </div>
          <div className="flex justify-end gap-4">
            <Button
              type="button"
              variant="secondary"
              onClick={handleClose}
              fullWidth={false}
              className={`h-[56px!important] ${
                isMultiOrder ? 'max-w-[250px] w-full' : 'w-[50%]'
              }`}
            >
              Cancel
            </Button>
            <Button
              isLoading={addOrderLoading}
              type="submit"
              form="add-order-form"
              fullWidth={false}
              className={`h-[56px!important] ${
                isMultiOrder ? 'max-w-[250px] w-full' : 'w-[50%]'
              }`}
            >
              Save
            </Button>
          </div>
        </div>
      </Modal>
      {orderSummaryData && (
        <OrderSummaryModal
          isOpen={isSummaryModalOpen}
          onClose={() => {
            setIsSummaryModalOpen(false);
            setOrderSummaryData(null);
            handleClose();
            if (onOrderAdded) {
              onOrderAdded();
            }
          }}
          orderSummary={orderSummaryData}
        />
      )}
    </>
  );
};

export default AddOrderModal;
