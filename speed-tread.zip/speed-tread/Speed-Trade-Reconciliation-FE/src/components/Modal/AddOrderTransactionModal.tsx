import React, { useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import Modal from './Modal';
import FormattedInput from '../formFields/FormattedInput';
import Dropdown from '../formFields/Dropdown';
import Button from '../formFields/Button';
import TextArea from '../formFields/TextArea';
import {
  AddOrderTransactionFormData,
  AddOrderTransactionModalProps,
} from '../../interfaces/components';
import { addOrderTransactionFormSchema } from '../../validations/orderTransaction';
import { useAppDispatch, useAppSelector } from '../../store/store';
import {
  addOrderTransactionThunk,
  editOrderTransactionThunk,
  getAddTransRemindBalThunk,
  getOrderTransactionByIdThunk,
} from '../../store/thunks/orderTransaction';
import {
  AddOrderTransactionPayload,
  EditOrderTransactionPayload,
} from '../../store/interfaces/orderTransaction';
import { getPairedCurrenciesThunk } from '../../store/thunks/pairedCurrencies';
import { DropdownOption } from '../../interfaces/formfields';
import moment from 'moment-timezone';
import { defaultDateFormat } from '../formFields/DateRangeInput';
import AmountInput from '../formFields/AmountInput';
import { clearRemindBal } from '../../store/slices/orderTransaction/orderRemainingBalSlice';
import { resetGetOrderTransactionById } from '../../store/slices/orderTransaction/getOrderTransactionByIdSlice';
import WarningMessage from '../WarningMessage';

const AddOrderTransactionModal: React.FC<AddOrderTransactionModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  settlementCurrency = '',
  group_uniqueId,
  transactionId,
  order_uniqueId,
  selectedDate,
  sellCurrency = '',
  order_by,
  trading = '',
  rate, // Add this line
}) => {
  const dispatch = useAppDispatch();
  const isEditMode = !!transactionId;

  const { data: transaction, isLoading: transactionLoading } = useAppSelector(
    (state) => state.getOrderTransactionByIdReducer,
  );

  const currencies = useAppSelector(
    (state) =>
      state.getAllCurrenciesReducer.data?.map((item) => ({
        label: item?.code,
        value: item?.code,
      })) || [],
  );
  const addLoader = useAppSelector(
    (state) => state.addOrderTransactionReducer.loading,
  );
  const editLoader = useAppSelector(
    (state) => state.editOrderTransactionReducer.loading,
  );
  const remainBal = useAppSelector(
    (state) => state.orderRemainingBalanceReducer.data,
  );
  const remainBalLoading = useAppSelector(
    (state) => state.orderRemainingBalanceReducer.loading,
  );

  const [callOnce, setCallOnce] = useState<boolean>(false);

  const {
    control,
    handleSubmit,
    formState: { errors },
    watch,
    reset,
    setValue,
    clearErrors,
    setError,
  } = useForm({
    resolver: yupResolver(addOrderTransactionFormSchema()),
    defaultValues: {
      settlementCurrency: settlementCurrency || '',
      type:
        trading === 'transfer'
          ? order_by
          : order_by === 'we'
            ? 'customer'
            : 'we',
      sell: undefined,
      trading: trading === 'buy' ? 'sell' : trading,
      currency: sellCurrency || '',
      rate: rate?.toString() || '', // Use the passed rate prop
      remarks: '',
      fee: undefined,
    },
  });

  useEffect(() => {
    if (isEditMode && transactionId) {
      dispatch(
        getOrderTransactionByIdThunk({ payload: { id: transactionId } }),
      );
    }
  }, [isEditMode, transactionId, dispatch]);

  useEffect(() => {
    if (isEditMode && transaction) {
      reset({
        settlementCurrency: settlementCurrency || '',
        type: transaction.transfer_by,
        sell: (transaction.sell_value as unknown as number) || undefined,
        trading: transaction.trading,
        currency: transaction.sell_currency,
        rate: transaction.rate || undefined,
        remarks: transaction.remarks,
        fee:
          transaction.fee && Number(transaction.fee) !== 0
            ? Number(transaction.fee)
            : undefined,
      });
    }
  }, [isEditMode, transaction, reset, settlementCurrency]);

  useEffect(() => {
    if (isOpen && settlementCurrency) {
      dispatch(
        getPairedCurrenciesThunk({
          settlement_currency: settlementCurrency,
        }),
      );
      setValue('settlementCurrency', settlementCurrency);
    }
  }, [isOpen, settlementCurrency, dispatch, setValue]);

  const handleClose = () => {
    reset();
    onClose();
    dispatch(resetGetOrderTransactionById());
  };

  const watchedCurrency = watch('currency');
  const watchedSell = watch('sell');
  const watchedSettlementCurrency = watch('settlementCurrency');
  const watchedFee = watch('fee');

  const showRateField = useMemo(() => {
    return (
      watchedSettlementCurrency && watchedSettlementCurrency !== watchedCurrency
    );
  }, [watchedCurrency, watchedSettlementCurrency]);

  const onSubmit = (data: AddOrderTransactionFormData) => {
    const today = moment().format("DD-MM-YYYY");

    const payload: AddOrderTransactionPayload | EditOrderTransactionPayload = {
      order_id: order_uniqueId,
      group_id: group_uniqueId || transaction?.group_id || '',
      transfer_by: data.type,
      sell_value: Number(data.sell),
      sell_currency: data.currency || '',
      settlement_currency: watchedSettlementCurrency,
      trading: data.trading,
      remarks: data.remarks || '',
      rate: data?.rate ? Number(data.rate) : undefined,
      fee: data?.fee ? Number(data.fee) : undefined,
      ...(!isEditMode ? { transferred_date: selectedDate || today } : {}),
    } as AddOrderTransactionPayload | EditOrderTransactionPayload;

    if (isEditMode && transaction) {
      (payload as EditOrderTransactionPayload).unique_id =
        transaction.unique_id;
      dispatch(
        editOrderTransactionThunk({
          payload: payload as EditOrderTransactionPayload,
          callbackAfterSuccess: onSuccess,
        }),
      );
    } else {
      dispatch(
        addOrderTransactionThunk({
          payload: payload as AddOrderTransactionPayload,
          callbackAfterSuccess: onSuccess,
        }),
      );
    }
  };

  const handleSettlementCurrencyChange = (val: DropdownOption) => {
    const option = val as DropdownOption;
    dispatch(
      getPairedCurrenciesThunk({
        settlement_currency: option?.value?.toString() || '',
      }),
    );
    setValue('currency', option?.value?.toString());
    setValue('rate', '');
  };

  useEffect(() => {
    return () => {
      dispatch(clearRemindBal());
      dispatch(resetGetOrderTransactionById());
    };
  }, []);

  useEffect(() => {
    // Clear our specific errors if the fee input is empty, to avoid sticky messages.
    if (
      (typeof watchedFee === 'undefined' || watchedFee === null) &&
      (errors.fee?.type === 'manual_fee' || errors.fee?.type === 'exact_fee')
    ) {
      clearErrors('fee');
    }

    if (remainBal) {
      let effectiveTransactionAmount = remainBal.transaction_amount || 0;
      let effectiveTransactionFee = remainBal.transaction_fee || 0;

      const remainingAmount = calculateRemaining(
        remainBal.order_amount,
        effectiveTransactionAmount,
      );
      const remainingFee = calculateRemaining(
        remainBal.order_fee,
        effectiveTransactionFee,
      );

      if (isEditMode) {
        const isCompletingTransaction =
          (Number(watchedSell) >= remainingAmount && remainingAmount > 0) ||
          remainingAmount < 0;

        const shouldEnforceExactFee =
          isCompletingTransaction && remainingFee > 0;

        // Case 1: Completing transaction AND fee is not yet paid -> requires the exact fee.
        if (shouldEnforceExactFee) {
          if (Number(watchedFee) !== remainingFee) {
            setError('fee', {
              type: 'exact_fee',
              message: `Please enter the exact remaining fee of ${watchedCurrency} ${remainingFee.toFixed(
                2,
              )} to complete order.`,
            });
          } else {
            if (errors.fee?.type === 'exact_fee') {
              clearErrors('fee');
            }
          }
        }
        // Case 2: All other scenarios
        else {
          // First, clear any lingering "exact_fee" error from a previous state.
          if (errors.fee?.type === 'exact_fee') {
            clearErrors('fee');
          }

          const maxAllowedFee = Math.max(0, remainingFee);
          // Now, check the "max fee" rule.
          if (watchedFee && Number(watchedFee) > maxAllowedFee) {
            setError('fee', {
              type: 'manual_fee',
              message: `Fee cannot be more than remaining fee of ${watchedCurrency} ${maxAllowedFee.toFixed(
                2,
              )}.`,
            });
          } else {
            if (errors.fee?.type === 'manual_fee') {
              clearErrors('fee');
            }
          }
        }
      }
      if (remainBal && !isEditMode) {
        const isCompletingTransaction =
          Number(watchedSell) >= remainingAmount && remainingAmount > 0;

        const shouldEnforceExactFee =
          isCompletingTransaction && remainingFee > 0;

        // Case 1: Completing transaction AND fee is not yet paid -> requires the exact fee.
        if (shouldEnforceExactFee) {
          if (Number(watchedFee) !== remainingFee) {
            setError('fee', {
              type: 'exact_fee',
              message: `Please enter the exact remaining fee of ${watchedCurrency} ${remainingFee.toFixed(
                2,
              )} to complete order.`,
            });
          } else {
            if (errors.fee?.type === 'exact_fee') {
              clearErrors('fee');
            }
          }
        }
        // Case 2: All other scenarios
        else {
          // First, clear any lingering "exact_fee" error from a previous state.
          if (errors.fee?.type === 'exact_fee') {
            clearErrors('fee');
          }

          const maxAllowedFee = Math.max(0, remainingFee);
          // Now, check the "max fee" rule.
          if (watchedFee && Number(watchedFee) > maxAllowedFee) {
            setError('fee', {
              type: 'manual_fee',
              message: `Fee cannot be more than remaining fee of ${watchedCurrency} ${maxAllowedFee.toFixed(
                2,
              )}.`,
            });
          } else {
            if (errors.fee?.type === 'manual_fee') {
              clearErrors('fee');
            }
          }
        }
      }
    }
  }, [
    watchedSell,
    watchedFee,
    remainBal,
    setError,
    clearErrors,
    watchedCurrency,
    isEditMode,
    transaction,
    remainBalLoading,
  ]);

  useEffect(() => {
    if (callOnce) return;
    if (watchedSell && callOnce === false) {
      setCallOnce(true);
    }
    handleRemindAmtAndFee();
  }, [transaction?.unique_id]);

  const handleRemindAmtAndFee = async () => {
    if (transaction?.unique_id) {
      await dispatch(
        getAddTransRemindBalThunk({
          payload: {
            order_id: order_uniqueId,
            transaction_id: transaction?.unique_id || '',
          },
        }),
      );

      return;
    } else if (!isEditMode) {
      await dispatch(
        getAddTransRemindBalThunk({
          payload: {
            order_id: order_uniqueId,
            transaction_id: '',
          },
        }),
      );
    }
  };

  const calculateRemaining = (total?: number, used?: number): number => {
    const result = (total || 0) - (used || 0);
    return Math.round(result * 100) / 100;
  };

  const showFee = (): boolean => {
    const isSameFee = remainBal?.order_fee === remainBal?.transaction_fee;
    if (!isEditMode) {
      return !isSameFee; // show only if fees differ
    }
    // In edit mode, show if fee is changed or watchedFee is truthy
    return Boolean(watchedFee || !isSameFee);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      className="min-w-[80%] sm:[min-width:unset]"
      loader={transactionLoading || remainBalLoading}
    >
      <div className="flex flex-col max-h-[80vh]">
        <div className="border-b pb-4">
          <h2 className="text-lg font-bold">
            {isEditMode ? 'Edit Transaction' : 'Add Transaction'}
          </h2>
        </div>
        <div
          className="flex-grow overflow-y-auto py-4"
          style={{ maxHeight: 'calc(80vh - 150px)' }}
        >
          <form
            onSubmit={handleSubmit(onSubmit as any)}
            id="add-order-transaction-form"
            autoComplete="off"
          >
            <div className="space-y-4">
              {!settlementCurrency && (
                <div>
                  <Dropdown
                    label="Settlement Currency"
                    name="settlementCurrency"
                    options={currencies}
                    placeholder="Select Settlement Currency"
                    control={control}
                    onChange={(val) =>
                      handleSettlementCurrencyChange(val as DropdownOption)
                    }
                  />
                </div>
              )}
              <div className="flex gap-4">
                <div className="w-full">
                  <AmountInput
                    label=""
                    name="sell"
                    control={control}
                    placeholder="0.00"
                    decimalPlaces={2}
                    prefix={watchedCurrency}
                    maxDigits={10}
                  />
                  <WarningMessage
                    visible={
                      !!(
                        remainBal &&
                        watchedSell &&
                        Number(watchedSell) >
                          calculateRemaining(
                            remainBal.order_amount,
                            remainBal.transaction_amount,
                          )
                      )
                    }
                    message="Please check this amount. It’s overpaid."
                  />
                </div>
              </div>
              {showRateField && (
                <FormattedInput
                  label="Rate"
                  name="rate"
                  control={control}
                  placeholder="0.000"
                  decimalPlaces={3}
                  disabled={!!rate} // Make it read-only if rate is provided
                />
              )}
              {showFee() && (
                <FormattedInput
                  label="Fee (Optional)"
                  name="fee"
                  control={control}
                  placeholder="Enter Fee"
                  decimalPlaces={2}
                />
              )}
              <TextArea
                label="Remarks (Optional)"
                name="remarks"
                control={control}
                placeholder="Enter Remarks"
                maxLength={150}
              />
            </div>
          </form>
        </div>
        <div className="flex justify-end gap-4 pt-6 border-t">
          <Button
            type="button"
            onClick={handleClose}
            variant="secondary"
            fullWidth={false}
            className="h-[56px!important] w-[50%]"
          >
            Cancel
          </Button>
          <Button
            disabled={Object.keys(errors).length > 0}
            isLoading={isEditMode ? editLoader : addLoader}
            type="submit"
            form="add-order-transaction-form"
            variant="primary"
            fullWidth={false}
            className="h-[56px!important] w-[50%]"
          >
            {isEditMode ? 'Update' : 'Save'}
          </Button>
        </div>
      </div>
    </Modal>
  );
};

export default AddOrderTransactionModal;
