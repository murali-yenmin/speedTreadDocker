import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  useForm,
  Controller,
  SubmitHandler,
  useFieldArray,
} from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import Modal from './Modal';
import Button from '../formFields/Button';
import ButtonGroup from '../formFields/ButtonGroup';
import RadioGroup from '../formFields/RadioGroup';
import {
  AddTransactionFormData,
  AddTransactionModalProps,
} from '../../interfaces/components';
import { addTransactionFormSchema } from '../../validations/transaction';
import {
  ALL_DATA_FOR_ADD_TRANSACTION_MODAL,
  SELL_DATA_FOR_ADD_TRANSACTION_MODAL,
  TRANSFER_BY_DROPDOWN_ITEMS,
} from '../../constants/dropdowns';
import { useAppDispatch, useAppSelector } from '../../store/store';
import {
  addBulkTransactionThunk,
  addTransactionThunk,
  editTransactionThunk,
  getTransactionByIdThunk,
} from '../../store/thunks/transaction';
import { getPairedCurrenciesThunk } from '../../store/thunks/pairedCurrencies';
import {
  AddTransactionPayload,
  EditTransactionPayload,
} from '../../store/interfaces/transaction';
import { DropdownOption } from '../../interfaces/formfields';
import { AccountName } from '../../store/interfaces/accountName';
import { getAccountNamesThunk } from '../../store/thunks/accountName';
import { resetAccountNames } from '../../store/slices/accountNameSlice';
import moment from 'moment-timezone';
import { defaultDateFormat } from '../formFields/DateRangeInput';
import useOutsideClick from '../../utils/outsideClick';
import Dropdown from '../formFields/Dropdown';
import { resetGetTransactionById } from '../../store/slices/transaction/getTransactionByIdSlice';
import AddTransactionForm from '../AddTransaction/AddTransactionForm';
import ToggleButton from '../formFields/ToggleButton';
import InfoIcon from '../Images/InfoIcon';
import MultiTransactionForm from '../AddTransaction/MultiTransactionForm';
import SingleTransactionForm from '../AddTransaction/SingleTransactionForm';
import { getOrderAndTransactionDate } from '../../utils/timeFormatter';

const AddTransactionModal: React.FC<AddTransactionModalProps> = ({
  isOpen,
  onClose,
  id,
  name,
  settlementCurrency,
  group_uniqueId,
  transactionId,
  onSuccess,
  showSettlementCurrency = false,
  selectedDate,
}) => {
  const dispatch = useAppDispatch();
  const isEditMode = !!transactionId;
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const {
    data: transaction,
    isLoading: transactionLoading,
    error,
  } = useAppSelector((state) => state.getTransactionByIdReducer);
  const currencies = useAppSelector(
    (state) =>
      state.getAllCurrenciesReducer.data?.map((item) => ({
        label: item?.code,
        value: item?.code,
      })) || [],
  );
  const addLoader = useAppSelector(
    (state) => state.addTransactionReducer.loading,
  );
  const addBulkLoader = useAppSelector(
    (state) => state.addBulkTransactionReducer.loading,
  );
  const editLoader = useAppSelector(
    (state) => state.editTransactionReducer.loading,
  );
  const pairedCurrencies = useAppSelector(
    (state) =>
      state.pairedCurrenciesReducer.data?.map((c) => ({
        label: c,
        value: c,
      })) || [],
  );
  const pairedCurrency = useAppSelector(
    (state) => state.pairedCurrenciesReducer.data,
  );

  const { accountNames } = useAppSelector((state) => state.accountNameReducer);
  const items: AccountName[] = accountNames;

  const [selectedItem, setSelectedItem] = useState<AccountName | null>(null);
  const [showAccountNameDropdown, setShowAccountNameDropdown] = useState(false);
  const [showMultiAccountNameDropdown, setShowMultiAccountNameDropdown] =
    useState<number | null>(null);
  const [selectedItems, setSelectedItems] = useState<(AccountName | null)[]>(
    [],
  );

  const form = useForm({
    resolver: yupResolver(addTransactionFormSchema(settlementCurrency)),
    defaultValues: {
      isMultiOrder: false,
      settlementCurrency: settlementCurrency || '',
      type: 'we',
      sell: undefined,
      trading: 'sell', // Set default to 'sell'
      fee: undefined,
      orders: [
        {
          amount: undefined,
          currency: settlementCurrency || '',
          rate: undefined,
          accountName: '',
          remarks: '',
        },
      ],
    },
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
    watch,
    reset,
    setValue,
    clearErrors,
    getValues,
    setError,
  } = form;

  const isMultiOrder = watch('isMultiOrder');
  const watchedCurrency = watch('currency');
  const watchedSettlementCurrency = watch('settlementCurrency');

  useEffect(() => {
    if (isEditMode && transactionId) {
      dispatch(getTransactionByIdThunk({ payload: { id: transactionId } }));
    }
  }, [isEditMode, transactionId, dispatch]);

  useEffect(() => {
    // This block now ONLY handles populating the form in edit mode.
    if (isEditMode && transaction) {
      reset({
        settlementCurrency: settlementCurrency || '',
        type: transaction.transfer_by,
        account: transaction?.account?.name,
        sell: transaction.sell_value as unknown as number,
        currency: transaction.sell_currency,
        rate: transaction.rate || undefined,
        remarks: transaction.remarks,
        fee: Number(transaction.fee) || undefined,
        isMultiOrder: false,
      });
      setValue('trading', transaction?.trading?.toLowerCase());
    }
  }, [isEditMode, transaction, reset, setValue, settlementCurrency]);

  useEffect(() => {
    reset({
      isMultiOrder,
      settlementCurrency: settlementCurrency || '',
      type: 'we',
      sell: undefined,
      trading: 'sell',
      fee: undefined,
      orders: [
        {
          amount: undefined,
          currency: settlementCurrency || '',
          rate: undefined,
          accountName: '',
          remarks: '',
        },
      ],
    });
    clearErrors();
  }, [isMultiOrder, reset, settlementCurrency, clearErrors]);

  useEffect(() => {
    if (isOpen && settlementCurrency) {
      dispatch(
        getPairedCurrenciesThunk({
          settlement_currency: settlementCurrency,
        }),
      );
      setValue('settlementCurrency', settlementCurrency);
      setValue('currency', settlementCurrency);
      const currentOrders = getValues('orders');
      const updatedOrders = currentOrders?.map((order) => ({
        ...order,
        currency: settlementCurrency,
        rate: undefined,
      }));
      setValue('orders', updatedOrders);
    }
  }, [isOpen, settlementCurrency, dispatch, setValue]);

  const handleClose = () => {
    reset();
    setSelectedItem(null);
    onClose();
    dispatch(resetGetTransactionById());
  };

  const showRateField = useMemo(() => {
    return Boolean(
      watchedSettlementCurrency &&
        watchedSettlementCurrency !== watchedCurrency,
    );
  }, [watchedCurrency, watchedSettlementCurrency]);

  const { fields } = useFieldArray({
    control,
    name: 'orders',
  });

  const onSubmit: SubmitHandler<AddTransactionFormData> = (data) => {
    clearErrors();
    let hasError = false;
    if (data.isMultiOrder) {
      data?.orders?.forEach((order, index) => {
        if (
          data.settlementCurrency !== order.currency &&
          (!order.rate || order.rate <= 0)
        ) {
          setError(`orders.${index}.rate` as const, {
            type: 'manual',
            message: 'Rate is required',
          });
          hasError = true;
        }
      });
    }
    
    if (hasError) {
      return;
    }
    
    const today = moment().format("DD-MM-YYYY");
    if (data.isMultiOrder) {
      if (!data?.orders?.length) return;

      const transactions: AddTransactionPayload[] =
        data?.orders?.map((order, index) => ({
          account_id:
            selectedItems[index]?.unique_id ?? order?.accountName ?? '',
          fee: order?.fee ? Number(order?.fee) : 0,
          group_id: group_uniqueId ?? transaction?.group_id ?? '',
          rate: order.rate ?? 0,
          remarks: order.remarks ?? '',
          sell_currency: order.currency,
          sell_value: order.amount ?? 0,
          settlement_currency: data.settlementCurrency,
          trading: data.trading,
          transfer_by: data.type,
          transferred_date: selectedDate || today as string,
        })) ?? [];

      dispatch(
        addBulkTransactionThunk({
          payload: { transactions },
          callbackAfterSuccess: onSuccess,
        }),
      );
      return;
    } else {
      // Single transaction logic
      const payload: AddTransactionPayload | EditTransactionPayload = {
        group_id: group_uniqueId || transaction?.group_id || '',
        transfer_by: data.type,
        sell_value: Number(data.sell),
        trading: data.trading,
        sell_currency: data.currency || '',
        settlement_currency: watchedSettlementCurrency,
        account_id: selectedItem?.unique_id || data.account,
        remarks: data?.remarks ?? '',
        rate: data?.rate ? Number(data.rate) : 0,
        fee: data?.fee ? Number(data.fee) : 0,
        ...(!isEditMode ? { transferred_date: selectedDate || today } : {}),
      } as AddTransactionPayload | EditTransactionPayload;

      if (isEditMode && transaction) {
        (payload as EditTransactionPayload).unique_id = transaction.unique_id;
        dispatch(
          editTransactionThunk({
            payload: payload as EditTransactionPayload,
            callbackAfterSuccess: onSuccess,
          }),
        );
      } else {
        dispatch(
          addTransactionThunk({
            payload: payload as AddTransactionPayload,
            callbackAfterSuccess: onSuccess,
          }),
        );
      }
    }
  };

  const handleSettlementCurrencyChange = (val: DropdownOption) => {
    const option = val as DropdownOption;
    dispatch(
      getPairedCurrenciesThunk({
        settlement_currency: option?.value?.toString() || '',
      }),
    );
    setValue('currency', option?.value?.toString());
    setValue('rate', '');
  };

  const handleCurrencyChange = (selectedOption: DropdownOption) => {
    const option = selectedOption as DropdownOption;
    setValue('currency', option ? option.value.toString() : '');
    clearErrors('currency');
    if (watchedSettlementCurrency !== option?.value?.toString()) {
      setValue('trading', 'sell');
    }
    setValue('rate', '');
  };

  const handleAccountNameChange = useCallback(
    (value: string) => {
      if (value) {
        dispatch(getAccountNamesThunk(value));
        return;
      }
      dispatch(resetAccountNames());
      return;
    },
    [dispatch],
  );
  const accountNameRef = useRef<HTMLDivElement>(null);

  useOutsideClick(accountNameRef, () => setShowAccountNameDropdown(false));
  const accountNameRefs = useRef<(HTMLDivElement | null)[]>([]);

  useOutsideClick(
    { current: accountNameRefs.current[showMultiAccountNameDropdown ?? -1] },
    () => {
      setShowMultiAccountNameDropdown(null);
    },
  );
  const handleMultiAccountNameChange = useCallback(
    (value: string, index: number) => {
      if (value) {
        setShowMultiAccountNameDropdown(index);
        dispatch(getAccountNamesThunk(value));
      }
    },
    [],
  );
  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      loader={transactionLoading}
      className={`min-w-[80%] sm:[min-width:unset] ${
        isMultiOrder ? 'md:max-w-[1151px] max-w-[80%]' : ''
      }`}
      preventOutsideClick
    >
      <div className="flex flex-col max-h-[80vh]">
        <div className="border-b pb-4">
          <h2 className="text-lg font-bold">
            {isEditMode ? 'Edit Transaction' : 'Add Transaction'}
          </h2>
        </div>
        <div
          className="flex-grow overflow-y-auto py-4"
          ref={scrollContainerRef}
          style={{ maxHeight: 'calc(80vh - 150px)' }}
        >
          <AddTransactionForm onSubmit={onSubmit} form={form as any}>
            <div className="space-y-4">
              {!settlementCurrency ||
                (showSettlementCurrency && (
                  <div>
                    <Dropdown
                      label="Settlement Currency"
                      name="settlementCurrency"
                      options={currencies}
                      placeholder="Select Settlement Currency"
                      control={control}
                      onChange={(val) =>
                        handleSettlementCurrencyChange(val as DropdownOption)
                      }
                    />
                  </div>
                ))}

              {!isEditMode && (
                <>
                  <div
                    className={`${
                      isMultiOrder ? 'flex gap-6 mid-range:flex-col' : ''
                    }`}
                  >
                    <div
                      className={`${
                        isMultiOrder
                          ? 'w-[50%] mid-range:w-[100%]'
                          : 'w-full mb-4'
                      } flex items-center justify-between border rounded-lg p-3`}
                    >
                      <label>Multi Transaction?</label>
                      <Controller
                        name="isMultiOrder"
                        control={control}
                        render={({ field }) => (
                          <ToggleButton
                            {...field}
                            checked={field.value}
                            id="isMultiOrder"
                          />
                        )}
                      />
                    </div>
                    <div
                      className={`${
                        isMultiOrder ? 'w-[50%] mid-range:w-[100%]' : 'w-full'
                      }`}
                    >
                      <Controller
                        name="type"
                        control={control}
                        render={({ field }) => (
                          <ButtonGroup
                            {...field}
                            options={TRANSFER_BY_DROPDOWN_ITEMS}
                            value={field.value}
                            onChange={field.onChange}
                          />
                        )}
                      />
                    </div>
                  </div>
                  <div
                    className={`${isMultiOrder ? 'flex gap-2 items-center' : ''}`}
                  >
                    <div className={`${isMultiOrder ? '' : 'w-full'}`}>
                      <RadioGroup
                        name="trading"
                        control={control}
                        options={
                          isMultiOrder
                            ? SELL_DATA_FOR_ADD_TRANSACTION_MODAL
                            : ALL_DATA_FOR_ADD_TRANSACTION_MODAL

                          // watchedSettlementCurrency === watchedCurrency
                          //   ? ALL_DATA_FOR_ADD_TRANSACTION_MODAL
                          //   : SELL_DATA_FOR_ADD_TRANSACTION_MODAL
                        }
                        // customClassName="gap-x-[15px] gap-y-[10px] grid xs:grid-cols-[1fr_1fr_1fr] sm:grid-cols-[1fr_1fr_1fr]"
                        customClassName={`gap-x-[15px] grid ${
                          isMultiOrder
                            ? 'xs:grid-cols-[1fr]'
                            : ' xs:grid-cols-[1fr_1fr_1fr] gap-y-[10px]'
                        }`}
                        childClassName="border rounded-[8px] py-[10px] px-[17px]"
                      />
                    </div>

                    <div
                      className={`flex justify-start items-start gap-2 transition-all duration-500 ease-in-out ${
                        isMultiOrder ? 'opacity-100' : 'opacity-0 hidden'
                      }`}
                      title="Information"
                    >
                      <span className="min-h-4 min-w-4">
                        <InfoIcon />
                      </span>
                      <p className="text-gray-400 leading-4">
                        Adjustment and Transfer options are not applicable for
                        multiple transaction.
                      </p>
                    </div>
                  </div>
                </>
              )}

              {isMultiOrder ? (
                <MultiTransactionForm
                  form={form}
                  accountNameRefs={accountNameRefs}
                  handleMultiAccountNameChange={handleMultiAccountNameChange}
                  showMultiAccountNameDropdown={showMultiAccountNameDropdown}
                  setShowMultiAccountNameDropdown={
                    setShowMultiAccountNameDropdown
                  }
                  items={items}
                  selectedItems={selectedItems}
                  setSelectedItems={setSelectedItems}
                  scrollContainerRef={scrollContainerRef}
                  pairedCurrencies={pairedCurrency || []}
                />
              ) : (
                <SingleTransactionForm
                  form={form as any}
                  pairedCurrencies={pairedCurrencies}
                  handleCurrencyChange={handleCurrencyChange}
                  showRateField={showRateField}
                  accountNameRef={accountNameRef}
                  handleAccountNameChange={handleAccountNameChange}
                  showAccountNameDropdown={showAccountNameDropdown}
                  setShowAccountNameDropdown={setShowAccountNameDropdown}
                  items={items}
                  selectedItem={selectedItem}
                  setSelectedItem={setSelectedItem}
                  fields={fields}
                  isEditMode={isEditMode}
                />
              )}
            </div>
          </AddTransactionForm>
        </div>
        <div className="flex justify-end gap-4">
          <Button
            type="button"
            onClick={handleClose}
            variant="secondary"
            fullWidth={false}
            className={`h-[56px!important] ${
              isMultiOrder ? 'max-w-[250px] w-full' : 'w-[50%]'
            }`}
          >
            Cancel
          </Button>
          <Button
            isLoading={isEditMode ? editLoader : addLoader || addBulkLoader}
            type="submit"
            form="add-transaction-form"
            variant="primary"
            fullWidth={false}
            className={`h-[56px!important] ${
              isMultiOrder ? 'max-w-[250px] w-full' : 'w-[50%]'
            }`}
          >
            {isEditMode ? 'Update' : 'Save'}
          </Button>
        </div>
      </div>
    </Modal>
  );
};

export default AddTransactionModal;
