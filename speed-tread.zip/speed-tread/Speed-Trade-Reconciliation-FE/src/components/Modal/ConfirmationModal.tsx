import React from 'react';
import Modal from './Modal';
import Button from '../formFields/Button';
import { useTranslation } from 'react-i18next';
import CompleteOrderIcon from '../../assets/svg/CompleteOrderIcon';
import Exclamation from '../Images/Exclamation';

interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string | React.ReactNode;
  confirmButtonText: string;
  cancelButtonText: string;
  icon?: React.ReactNode;
  isLoading?: boolean;
  info?: string;
  closeIcon?: boolean;
}

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmButtonText,
  cancelButtonText,
  icon,
  isLoading = false,
  info,
  closeIcon = true,
}) => {
  const { t } = useTranslation();

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-xl text-center"
    >
      {closeIcon && (
        <button
          onClick={onClose}
          title="Close"
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 focus:outline-none"
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>
      )}
      <div className="mb-4 flex justify-center">
        {icon || <CompleteOrderIcon />}
      </div>
      <h2 className="text-xl font-bold text-gray-800 mb-2">{title}</h2>
      <p className="text-gray-600 mb-6">{message}</p>
      {
        <div className={`flex justify-center items-start`}>
          <div
            className={`text-black bg-light-sandal border-dark-sandal border mb-5 transition-all duration-1000 ease-in-out rounded-lg w-max py-2 px-6 flex ${
              info
                ? 'opacity-100 translate-y-0'
                : 'opacity-0 -translate-y-2 hidden'
            }`}
          >
            <div className="min-h-6 min-w-6 mr-2">
              <Exclamation />
            </div>
            <p className="text-left leading-5">{info}</p>
          </div>
        </div>
      }
      <div className="flex justify-center space-x-4">
        <Button
          onClick={onClose}
          variant="secondary"
          className="w-full max-w-[120px] bg-gray-100 hover:bg-gray-200 text-gray-800"
        >
          {cancelButtonText}
        </Button>
        <Button
          onClick={onConfirm}
          variant="primary"
          className="w-full max-w-[120px] bg-gray-800 hover:bg-gray-900 text-white"
          isLoading={isLoading}
        >
          {confirmButtonText}
        </Button>
      </div>
    </Modal>
  );
};

export default ConfirmationModal;
