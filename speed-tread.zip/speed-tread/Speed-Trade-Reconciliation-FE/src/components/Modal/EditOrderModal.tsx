import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useForm, SubmitHandler, Resolver } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import Modal from './Modal';
import Input from '../formFields/Input';
import TextArea from '../formFields/TextArea';
import { EditOrderModalProps } from '../../interfaces/components';
import { EditOrderFormValues } from '../../interfaces/order';
import { AccountName } from '../../store/interfaces/accountName';
import { useAppSelector, RootState, useAppDispatch } from '../../store/store';
import { getOrderByIdThunk, updateOrderThunk } from '../../store/thunks/order';
import { UpdateOrderPayload } from '../../store/interfaces/order';
import Button from '../formFields/Button';
import { editOrderFormSchema } from '../../validations/order';
import { getPairedCurrenciesThunk } from '../../store/thunks/pairedCurrencies';
import { getAccountNamesThunk } from '../../store/thunks/accountName';
import FormattedInput from '../formFields/FormattedInput';
import StyledLi from '../common/StyledLi';
import StyledUl from '../common/StyledUl';
import { resetAccountNames } from '../../store/slices/accountNameSlice';
import useOutsideClick from '../../utils/outsideClick';
import AmountInput from '../formFields/AmountInput';
import { resetGetOrderById } from '../../store/slices/order/getOrderByIdSlice';

const EditOrderModal: React.FC<EditOrderModalProps> = ({
  isOpen,
  onClose,
  orderId,
  onOrderUpdated,
}) => {
  const dispatch = useAppDispatch();
  const { loading: updateOrderLoading } = useAppSelector(
    (state: RootState) => state.updateOrderReducer,
  );
  const { data: order, isLoading: orderLoading } = useAppSelector(
    (state: RootState) => state.getOrderByIdReducer,
  );
  const { accountNames } = useAppSelector((state) => state.accountNameReducer);
  const [selectedItem, setSelectedItem] = useState<AccountName | null>(null);
  const [showAccountNameDropdown, setShowAccountNameDropdown] = useState(false);

  const handleAccountNameChange = useCallback(
    (value: string) => {
      if (value) {
        dispatch(getAccountNamesThunk(value));
        return;
      }
      dispatch(resetAccountNames());
      return;
    },
    [dispatch],
  );

  const {
    control,
    handleSubmit,
    reset,
    watch,
    setValue,
    clearErrors,
    formState: { errors },
  } = useForm<EditOrderFormValues>({
    resolver: yupResolver(
      editOrderFormSchema(order?.settlement_currency || ''),
    ) as Resolver<EditOrderFormValues>,
  });

  useEffect(() => {
    if (orderId) {
      dispatch(getOrderByIdThunk({ payload: { id: orderId } }));
    }
  }, [orderId, dispatch]);

  useEffect(() => {
    if (order) {
      reset({
        ...order,
        amount: order.amount,
        rate: order.rate,
        accountName: order.account?.name,
        fee: order?.fee && Number(order?.fee) !== 0 ? order?.fee : undefined,
      });
    }
  }, [order, reset]);

  const currencyValue = watch('currency');

  useEffect(() => {
    if (isOpen && order?.settlement_currency) {
      dispatch(
        getPairedCurrenciesThunk({
          settlement_currency: order.settlement_currency,
        }),
      );
    }
  }, [isOpen, order?.settlement_currency]);

  const onSubmit: SubmitHandler<EditOrderFormValues> = (data) => {
    if (!order) return;
    const payload: UpdateOrderPayload = {
      group_id: order.group_id,
      settlement_currency: order.settlement_currency,
      unique_id: order.unique_id,
      order_by: data.order_by,
      trading: data.trading,
      amount: parseFloat(data.amount),
      currency: data.currency,
      remarks: data.remarks || '',
      fee: Number(data.fee) || 0,
      account_id: selectedItem?.unique_id || data.accountName,
      rate:
        data.currency !== order.settlement_currency
          ? Number(data.rate)
          : undefined,
    };

    dispatch(
      updateOrderThunk({
        payload,
        callbackAfterSuccess: () => {
          setSelectedItem(null);
          onClose();
          dispatch(resetGetOrderById());
          if (onOrderUpdated) {
            onOrderUpdated();
          }
        },
      }),
    );
  };

  const accountNameRef = useRef<HTMLDivElement>(null);

  useOutsideClick(accountNameRef, () => setShowAccountNameDropdown(false));

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        onClose();
        dispatch(resetGetOrderById());
      }}
      className="min-w-[80%] sm:[min-width:unset]"
      loader={orderLoading}
    >
      <div className="flex flex-col max-h-[90vh]">
        <div className="pb-6 border-b">
          <h2 className="text-lg font-bold">Edit Order</h2>
        </div>
        <div className="flex-grow overflow-y-auto pt-6">
          <form
            id="edit-order-form"
            onSubmit={handleSubmit(onSubmit)}
            autoComplete="off"
          >
            <div className="flex flex-col py-6 px-4 border rounded-lg gap-y-4">
              <div>
                <div>
                  <AmountInput
                    name="amount"
                    control={control}
                    label="Amount"
                    placeholder="Amount"
                    decimalPlaces={2}
                    prefix={currencyValue}
                    maxDigits={10}
                  />
                </div>
              </div>

              {order && currencyValue !== order.settlement_currency && (
                <FormattedInput
                  name="rate"
                  control={control}
                  label="Rate"
                  placeholder="Rate"
                  decimalPlaces={3}
                />
              )}

              <div ref={accountNameRef} className="relative">
                <Input
                  maxLength={50}
                  name="accountName"
                  control={control}
                  label="Account Name"
                  placeholder="Account Name"
                  onChange={handleAccountNameChange}
                  onFocus={() => {
                    setShowAccountNameDropdown(true);
                  }}
                />
                {accountNames &&
                  accountNames?.length > 0 &&
                  showAccountNameDropdown && (
                    <div className="absolute z-10 w-full pt-1">
                      <StyledUl
                        parentFocus={() => setShowAccountNameDropdown(true)}
                      >
                        {accountNames.map((item) => (
                          <StyledLi
                            key={item.unique_id}
                            selected={
                              selectedItem?.unique_id === item.unique_id
                            }
                            onClick={() => {
                              setValue('accountName', item.name);
                              setSelectedItem(item);
                              setShowAccountNameDropdown(false);
                              clearErrors('accountName');
                            }}
                          >
                            {item.name}
                          </StyledLi>
                        ))}
                      </StyledUl>
                    </div>
                  )}
              </div>
              {order?.trading !== 'adjustment' && (
                <div>
                  <FormattedInput
                    label="Fee (Optional)"
                    name="fee"
                    control={control}
                    placeholder="Enter Fee"
                    decimalPlaces={2}
                  />
                </div>
              )}
              <div>
                <TextArea
                  name="remarks"
                  control={control}
                  label="Remarks (Optional)"
                  placeholder="Enter Remarks"
                  maxLength={150}
                />
              </div>
            </div>
          </form>
        </div>
        <div className="pt-6 flex justify-end gap-4">
          <Button
            type="button"
            variant="secondary"
            onClick={() => {
              onClose();
              setSelectedItem(null);
              dispatch(resetGetOrderById());
            }}
            fullWidth={false}
            className="h-[56px!important] w-[50%]"
          >
            Cancel
          </Button>
          <Button
            isLoading={updateOrderLoading}
            type="submit"
            form="edit-order-form"
            fullWidth={false}
            className="h-[56px!important] w-[50%]"
          >
            Update
          </Button>
        </div>
      </div>
    </Modal>
  );
};

export default EditOrderModal;
