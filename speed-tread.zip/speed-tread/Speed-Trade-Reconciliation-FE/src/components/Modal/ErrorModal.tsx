import React from 'react';
import { useAppDispatch, useAppSelector } from '../../store/store';
import { hideErrorModal } from '../../store/slices/errorSlice';
import error401 from '../../assets/images/error401.png';
import error403 from '../../assets/images/error403.png';
import error404 from '../../assets/images/error404.png';
import error500 from '../../assets/images/error500.png';
import errorNetwork from '../../assets/images/errorNetwork.png';
import { useNavigate } from 'react-router-dom';

const ErrorModal: React.FC = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const contactMail = process.env.REACT_APP_CONTACT_MAIL;

  const { isVisible, errorCode, message } = useAppSelector(
    (state) => state.error,
  );

  if (!isVisible) {
    return null;
  }

  const getErrorContent = () => {
    switch (errorCode) {
      case 401:
        return {
          title: 'Unauthorized',
          image: error401,
          description: `If you cannot access the page continuously, \ncontact ${contactMail}`,
        };
      case 403:
        return {
          title: 'Forbidden',
          image: error403,
          description: `If you cannot access the page continuously, \ncontact ${contactMail}`,
        };
      case 404:
        return {
          title: 'Not Found',
          image: error404,
          description: `If you cannot access the page continuously, \ncontact ${contactMail}`,
        };
      case 500:
        return {
          title: 'Internal Server Error',
          image: error500,
          description: `If you cannot access the page continuously, \ncontact ${contactMail}`,
        };
      case 503:
        return {
          title: 'Service Unavailable',
          image: errorNetwork,
          description: `Service is temporarily unavailable. \nPlease try again later.`,
        };
      default:
        return {
          title: 'Error',
          image: error500,
          description: message || 'An unexpected error occurred.',
        };
    }
  };

  const { title, image, description } = getErrorContent();

  const handleLogout = () => {
    window.location.reload()
    localStorage.removeItem('authToken');
    dispatch(hideErrorModal());
    navigate('/login');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white rounded-lg p-8 w-[85vw] sm:max-w-md text-center">
        <img src={image} alt={title} className="mx-auto mb-4 h-40" />
        <h2 className="text-2xl font-bold mb-2">{title}</h2>
        <p className="text-gray-600 mb-6" style={{ whiteSpace: 'pre-line' }}>
          {description}
        </p>
        <button
          onClick={handleLogout}
          className="bg-primary-blue text-white px-6 py-2 rounded-lg"
        >
          Login Again
        </button>
      </div>
    </div>
  );
};

export default ErrorModal;
