import React, { useEffect, useState } from 'react';
import {
  formatAmount,
  formatAmountWithSuperscript,
} from '../../utils/numberUtils';
import Modal from './Modal';
import Button from '../formFields/Button';
import '../../assets/print.css';
import moment from 'moment';
import NoData from '../NoData';

interface SummaryData {
  status: string;
  value: number;
  currency: string;
  overall_calculated_amount: number;
}

interface TransactionAccount {
  unique_id: string;
  name: string;
}

interface Transaction {
  unique_id: string;
  transaction_id: string;
  group_id: string;
  transfer_by: "we" | "customer" | string;
  sell_value: string;
  sell_currency: string;
  settlement_currency: string;
  rate: string;
  fee: string;
  trading: string;
  remarks: string;
  updated_at: string;
  transferred_date: string;
  created_at: string;
  account_unique_id: string;
  account_name: string;
  calculated_amount: string;
  running_balance: number;
  running_status: string;
  account: TransactionAccount;
}

interface Summary {
  status: "we_owe" | "owe_us" | "all_clear" | string;
  value: number;
  currency: string;
  overall_calculated_amount: number;
}

interface TransactionsResponse {
  summary_till_yesterday: Summary;
  transactions: Transaction[];
  summary_today: Summary;
}


interface ExportTransactionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: TransactionsResponse;
  groupName: string;
  overAllAmount: SummaryData;
  groupId: string;
  loading: boolean;
}

const ExportTransactionsModal: React.FC<ExportTransactionsModalProps> = ({
  isOpen,
  onClose,
  transactions,
  groupName,
  overAllAmount,
  groupId,
  loading
}) => {

  const handlePrint = () => {
    const printContent = document.querySelector(".printable-content");
    if (!printContent) return;

    const printWindow = window.open("", "_blank", "width=900,height=650");
    if (!printWindow) return;

    // Copy all <style> and <link> CSS from current document
    const styles = Array.from(document.styleSheets)
      .map((styleSheet) => {
        try {
          return Array.from(styleSheet.cssRules)
            .map((rule) => rule.cssText)
            .join("\n");
        } catch (e) {
          // For cross-origin styles
          return "";
        }
      })
      .join("\n");

    printWindow.document.write(`
    <html>
      <head>
        <title>[${groupId}] - ${groupName} - ${moment().format(
      "DD-MM"
    )}</title>
        <meta charset="UTF-8">
          <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
          <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@300;400;500;600;700&display=swap" rel="stylesheet">
          <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@300;400;500;600;700&display=swap" rel="stylesheet">
          <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Vietnamese:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <style>
          ${styles}
          @media print {
                  * {
              font-family: "Arial Unicode MS", "Noto Sans", "Noto Sans Thai", 
                          "Noto Sans Devanagari", "Noto Sans Vietnamese",
                          sans-serif !important;
              -webkit-print-color-adjust: exact !important;
              print-color-adjust: exact !important;
            }
          }
        </style>
      </head>
      <body>
        ${printContent.outerHTML}
      </body>
    </html>
  `);
    printWindow.document.close();
    printWindow.onload = () => {
      printWindow.focus();
      printWindow.print();
      printWindow.close();
    };
  };


  const formatCurrency = (value: any, wrapInParentheses: boolean = false, currency?: string) => {
    const num = Number(value);
    if (num === 0) {
      return '';
    }
    if (!isFinite(num)) {
      return value || '';
    }
    if (num < 0) {
      return (
        <span className="text-red-500">({currency ? `${currency} ` : ''}{formatAmount(Math.abs(num))})</span>
      );
    }
    const formatted = formatAmount(num);
    return wrapInParentheses ? <span className="text-[#FF0000]">({currency ? `${currency} ` : ''}{formatted})</span> : (currency ? `${currency} ` : '') + formatted;
  };

  const displayValue = (value: any) => {
    if (Number(value) === 0) return '';
    return value || '';
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="" className="max-w-[90%!important]" loader={loading}>
      {loading ? <div className='min-h-[300px]'></div> : <>
        {transactions?.transactions.length > 0 ? (
          <div id="print-section" className="printable-content">
            <div className="max-h-96 overflow-y-auto">
              <table className="w-full text-sm text-left text-gray-600">
                <thead className="text-xs text-white bg-[#124294] font-bold sticky top-0">
                  <tr className="border-b border-gray-300 bg-black">
                    <th scope="col" className="px-6 py-3" colSpan={3}>
                      <div className="flex-1">
                        <h2 className="text-sm font-bold">[{groupId}] - {groupName}</h2>
                      </div>
                    </th>
                    <th scope="col" className="px-6 py-3" colSpan={3}>
                      <div className="flex-1 text-left">
                        <p className="text-sm font-semibold ">
                          Closing: {moment().format('D MMMM YYYY, HH:mm:ss')}
                        </p>
                      </div>
                    </th>
                    <th scope="col" className={`text-sm px-6 py-3 ${overAllAmount?.status === 'owe_us'
                      ? 'bg-[#2E7D32] text-white bg-green'
                      : overAllAmount?.status === 'we_owe'
                        ? 'bg-[#C62828] text-white bg-red'
                        : 'bg-gray-100 text-gray-500 bg-grey'
                      }`}>
                      <div className="text-base font-semibold  text-right">
                        {overAllAmount?.status === 'owe_us'
                          ? 'Owe Us'
                          : overAllAmount?.status === 'we_owe'
                            ? 'We Owe'
                            : 'All Clear'}
                      </div>
                    </th>
                    <th scope="col" className={`text-sm px-6 py-3 ${overAllAmount?.status === 'owe_us'
                      ? 'bg-[#2E7D32] text-white bg-green'
                      : overAllAmount?.status === 'we_owe'
                        ? 'bg-[#C62828] text-white bg-red'
                        : 'bg-gray-100 text-gray-500 bg-grey'
                      }`}>
                      <div className="text-base font-semibold text-left">
                        {overAllAmount?.status === 'all_clear' ? (
                          '-'
                        ) : (
                          <>
                            {overAllAmount?.status === 'we_owe' && '('}
                            {overAllAmount?.currency}{' '}
                            {overAllAmount?.value &&
                              formatAmount(Number(overAllAmount?.value))
                            } 
                            {overAllAmount?.status === 'we_owe' && ')'}
                          </>
                        )}
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-gray-30 bg-[#124294] printable-header">
                    <td scope="col" className="px-6 py-3 text-white font-bold">
                      Account Name
                    </td>
                    <td scope="col" className="px-6 py-3 w-[100px] text-white font-bold">
                      Party
                    </td>
                    <td scope="col" className="px-6 py-3 w-[80px] text-white font-bold">
                      Currency
                    </td>
                    <td scope="col" className="px-6 py-3 w-[18%] text-white font-bold">
                      Amount
                    </td>
                    <td scope="col" className="px-6 py-3 w-[80px] text-white font-bold">
                      Rate
                    </td>
                    <td scope="col" className="px-6 py-3 w-[80px] text-white font-bold">
                      Fee
                    </td>
                    <td scope="col" className="px-6 py-3 w-[18%] text-white font-bold">
                      Settlement Amount
                    </td>
                    <td scope="col" className="px-6 py-3 w-[18%] text-white font-bold">
                      Balance
                    </td>
                  </tr>
                  {transactions?.transactions?.map((transaction, index) => (
                    <tr
                      key={transaction.unique_id}
                      className={`border-b border-gray-300 ${transaction.transfer_by !== 'we' ? 'bg-[#FBE9E7]' : 'bg-[#E4F4E2]'
                        }`}
                    >
                      <td className="px-6 py-4 text-black ">{transaction.account.name}</td>
                      {/* <td className="px-6 py-4"> */}
                      <td
                        className={`px-6 py-4 party-cell-print font-bold w-[100px] ${transaction.transfer_by === 'we'
                          ? 'bg-green-500 text-white'
                          : 'bg-red-500 text-white'
                          }`}
                      >
                        {transaction.transfer_by.charAt(0).toUpperCase() + transaction.transfer_by.slice(1).toLowerCase()}
                      </td>
                      <td className="px-6 py-4 text-black w-[80px]">{transaction.sell_currency}</td>
                      <td className="px-6 py-4 text-left text-black w-[15%]">
                        {formatCurrency(Number(transaction.sell_value))}
                      </td>
                      <td className="px-6 py-4 text-left text-black w-[80px]">{Number(transaction.rate) !== 0 ? displayValue(transaction.rate) : '1.000'}</td>

                      <td className="px-6 py-4 text-left text-black w-[80px]">
                        {displayValue(transaction.fee)}
                      </td>

                      <td className="px-6 py-4 text-left text-black w-[15%]">
                        {formatCurrency(transaction.calculated_amount, transaction.transfer_by !== 'we', transaction.settlement_currency)}
                      </td>
                      <td className="px-6 py-4 text-left text-black w-[15%]">
                        {formatCurrency(transaction.running_balance, false, transaction.settlement_currency)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <NoData />
        )} </>}
      <div className="flex justify-end mt-4 no-print">
        <Button
          type="button"
          variant="secondary"
          onClick={onClose}
          fullWidth={false}
          className="h-11 min-w-[89px] mr-2"
        >
          Close
        </Button>
        <Button
          type="button"
          variant="primary"
          onClick={handlePrint}
          fullWidth={false}
          className="h-11 min-w-[89px]"
        >
          Print
        </Button>
      </div>
    </Modal>
  );
};

export default ExportTransactionsModal;
