import React, { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import Spinner from '../Spinner';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
  className?: string;
  title?: string;
  preventOutsideClick?: boolean;
  loader?:boolean;
}

const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  children,
  className,
  title,
  preventOutsideClick = false,
  loader=false,
}) => {
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !preventOutsideClick) {
        onClose();
      }
    };

    const handleClickOutside = (event: MouseEvent) => {
      if (
        !preventOutsideClick &&
        modalRef.current &&
        !modalRef.current.contains(event.target as Node)
      ) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      document.addEventListener('mousedown', handleClickOutside);

      const focusableElements = modalRef.current?.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
      ) as NodeListOf<HTMLElement>;

      if (focusableElements && focusableElements.length > 0) {
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];

        const handleTabKey = (event: KeyboardEvent) => {
          if (event.key === 'Tab') {
            if (event.shiftKey) {
              // Shift + Tab
              if (document.activeElement === firstElement) {
                lastElement.focus();
                event.preventDefault();
              }
            } else {
              // Tab
              if (document.activeElement === lastElement) {
                firstElement.focus();
                event.preventDefault();
              }
            }
          }
        };

        modalRef.current?.addEventListener('keydown', handleTabKey);

        return () => {
          document.removeEventListener('keydown', handleEscape);
          document.removeEventListener('mousedown', handleClickOutside);
          modalRef.current?.removeEventListener('keydown', handleTabKey);
        };
      }
    } else {
      document.removeEventListener('keydown', handleEscape);
      document.removeEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose, preventOutsideClick]);

  if (!isOpen) return null;

  return createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div
        ref={modalRef}
        className={`bg-white rounded-lg shadow-xl p-6 relative transform transition-all sm:w-full sm:max-w-lg h-auto ${className} overflow-hidden model-responsive-space mx-3`}
      >
        {title && (
          <div className="border-b pb-4 mb-4">
            <h2 className="text-lg font-bold">{title}</h2>
          </div>
        )}
        {loader && <Spinner />}
        {children}
      </div>
    </div>,
    document.body,
  );
};

export default Modal;
