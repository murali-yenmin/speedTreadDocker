import React from 'react';
import SliderModal from './SliderModal';
import OrderSlider from '../OrderSlider';
import { OrderSliderModalProps } from '../../interfaces/components';

const OrderSliderModal: React.FC<OrderSliderModalProps> = ({
  isOpen,
  onClose,
  groupId,
  groupName,
  settlementCurrency,
  currency,
  group_uniqueId,
}) => {
  // Dummy comment to force re-compile
  return (
    <SliderModal isOpen={isOpen} onClose={onClose} showCloseIcon={false}>
      <OrderSlider
        groupId={groupId}
        groupName={groupName}
        settlementCurrency={settlementCurrency}
        onClose={onClose}
        currency={currency}
        group_uniqueId={group_uniqueId}
      />
    </SliderModal>
  );
};

export default OrderSliderModal;
