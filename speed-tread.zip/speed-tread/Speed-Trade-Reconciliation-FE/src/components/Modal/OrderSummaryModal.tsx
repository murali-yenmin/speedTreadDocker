import React from 'react';
import { OrderSummaryModalProps } from '../../interfaces/components';
import Modal from './Modal';
import CopyIcon from '../Images/CopyIcon';
import Button from '../formFields/Button';
import { showSuccessToast } from '../../utils/toast';
import {
  formatAmount,
  formatAmountWithSuperscript,
} from '../../utils/numberUtils';
import { formatOrderId, toTitleCase } from '../../utils/stringUtils';
import { defaultDateFormat } from '../formFields/DateRangeInput';
import moment from 'moment';

const OrderSummaryModal: React.FC<OrderSummaryModalProps> = ({
  isOpen,
  onClose,
  orderSummary,
}) => {
  if (!isOpen) {
    return null;
  }

  const handleCopy = () => {
    const formattedOrders = orderSummary.currencies
      .flatMap((currencyData) =>
        currencyData.orders.map((order) => {
          let orderString = ``;
          if (order.ordered_date)
            orderString += `${moment(order.ordered_date).format(defaultDateFormat)}\n`;
          orderString += `${formatOrderId(order.order_id)}\n`;
          orderString += `${toTitleCase(order.account_name)}\n`;
          orderString += `${order.currency} ${formatAmount(Number(order.amount))}${order.rate || order.remarks ? '\n' : ''}`;
          if (order?.settlement_currency !== order?.currency) {
            // Assuming group_id is settlement_currency for comparison
            orderString += `Rate ${formatAmount(Number(order.rate), 3)}${order.remarks ? '\n' : ''}`;
          }
          if (order.remarks) {
            orderString += `${order.remarks}`;
          }
          return orderString;
        }),
      )
      .join('\n\n---\n\n\n');

    navigator.clipboard.writeText(formattedOrders).then(() => {
      showSuccessToast('Copied to clipboard!');
    });
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} className="p-[25px]">
      <div>
        <div className="flex justify-between items-center p-5 border-b border-dashed">
          <h2 className="text-xl font-bold">Order Summary</h2>
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleCopy();
            }}
            title="Copy"
          >
            <CopyIcon />
          </button>
        </div>
        <div className="flex justify-between items-center pl-5 pr-5 pt-[30px] pb-[30px] border-b border-dashed">
          <div>
            <p className="text-gray-500 text-sm">
              {orderSummary.group.group_id}
            </p>
            <p className="font-medium text-base">{orderSummary.group.name}</p>
          </div>
        </div>

        {orderSummary.currencies.map((currency, index) => (
          <div
            key={index}
            className="pl-5 pr-5 pt-[30px] pb-[30px]  border-b border-dashed"
          >
            <div className="flex justify-between items-center mb-2">
              <p className="font-medium text-base">{currency.currency}</p>
              <p className="font-medium text-base">
                {formatAmountWithSuperscript(
                  formatAmount(Number(currency.total_amount)),
                )}
              </p>
            </div>
            {currency.orders.map((order, orderIndex) => (
              <div
                key={orderIndex}
                className="flex justify-between items-center"
              >
                <p className="text-sm font-medium text-gray-500">
                  {formatOrderId(order.order_id)}
                </p>
                <p className="text-sm font-medium text-gray-500">
                  {formatAmountWithSuperscript(
                    formatAmount(Number(order.amount)),
                  )}
                </p>
              </div>
            ))}
          </div>
        ))}

        <div className="flex justify-end gap-4 p-5">
          <Button variant="secondary" onClick={onClose}>
            Close
          </Button>
          <Button
            variant="primary"
            onClick={async (e) => {
              e.stopPropagation();
              await handleCopy();
              onClose();
            }}
          >
            Copy
          </Button>
        </div>
      </div>
    </Modal>
  );
};

export default OrderSummaryModal;
