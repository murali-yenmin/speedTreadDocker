import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import {
  restrictToParentElement,
  restrictToVerticalAxis,
} from '@dnd-kit/modifiers';
import { CSS } from '@dnd-kit/utilities';
import React, { useState, useEffect, useRef } from 'react';
import Modal from './Modal';
import Button from '../formFields/Button';
import Dropdown from '../formFields/Dropdown';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { useAppDispatch, useAppSelector } from '../../store/store';
import { getAllCurrenciesThunk } from '../../store/thunks/settings';
import { getAllGroupByUniqueIdThunk } from '../../store/thunks/groups';
import { resetGroupByUniqueId } from '../../store/slices/groups/getGroupUniqueIdSlice';
import CurrencyViewerSkeleton from '../CurrencyViewerSkeleton';
import { getUserRole } from '../../utils/auth';
import { ROLES } from '../../constants/roles';

interface ReOrderItemProps<T> {
  confirmButtonText: string;
  cancelButtonText: string;
  groupId: string;
  title: string;
  keyExtractor: (item: T) => string | number;
  onConfirm: (items: T[]) => void;
  children: (item: T) => React.ReactNode;
  isOpen: boolean;
  onClose: () => void;
}

// This new component correctly separates the drag handle from the content.
const SortableRow = <T,>({
  item,
  keyExtractor,
  children,
}: {
  item: T;
  keyExtractor: (item: T) => string | number;
  children: (item: T) => React.ReactNode;
}) => {
  const { attributes, listeners, setNodeRef, transform, transition } =
    useSortable({ id: keyExtractor(item) });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    cursor: 'default',
  };

  const Dots = () => {
    return <div className="min-h-1 min-w-1 bg-steel-blue rounded-sm"></div>;
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes} // Spread attributes on the root for accessibility
      className="bg-initialsBg mb-[8px] px-[10px] rounded-[14px] flex items-center justify-between pl-[10px] pr-[15px] w-full"
    >
      <div className="flex-grow py-4">{children(item)}</div>
      <div
        {...listeners} // Listeners are ONLY on the handle
        className="grid grid-cols-2 gap-1 cursor-grab p-2"
      >
        {Array.from({ length: 6 }).map((_, index) => (
          <Dots key={`dots-${index}`} />
        ))}
      </div>
    </div>
  );
};

function ReOrderItem<T>({
  cancelButtonText,
  confirmButtonText,
  groupId,
  title,
  keyExtractor,
  onConfirm,
  children,
  isOpen,
  onClose,
}: ReOrderItemProps<T>) {
  const { t } = useTranslation();
  const dispatch = useAppDispatch();

  const containerRef = useRef<HTMLDivElement>(null);
  const userRole = getUserRole();

  const { control } = useForm();

  const items = useAppSelector(
    (state) => state.getGroupUniqueIdCurrencyReducer.data,
  );
  const getItemLoading = useAppSelector(
    (state) => state.getGroupUniqueIdCurrencyReducer.loading,
  );
  const reOrderLoading = useAppSelector(
    (state) => state.updateCurrencyReorderReducer.loading,
  );

  const [internalItems, setInternalItems] = useState<any[]>(items || []);

  const { currency, loading } = useAppSelector((state) => ({
    currency: state.getAllCurrenciesReducer.data?.map((cur) => ({
      label: cur.code,
      value: cur.unique_id,
    })),
    loading: state.addCurrencyPairReducer.loading,
  }));

  const selectedCurrencies = internalItems.map((item) => item.currency);

  const filteredCurrencyOptions = [
    ...(currency?.filter(
      (option) => !selectedCurrencies.includes(option.label),
    ) ?? []),
    // .sort((a, b) => a.label.localeCompare(b.label)) ?? []),
  ];

  const [addCurrencyItem, setAddCurrencyItem] = useState<any>();

  useEffect(() => {
    if (groupId) {
      dispatch(
        getAllGroupByUniqueIdThunk({
          payload: {
            groupId,
            role: userRole === ROLES.ORDER_MANAGER ? 'order' : 'transaction',
          },
        }),
      );
    }
  }, [groupId]);

  useEffect(() => {
    dispatch(getAllCurrenciesThunk());

    return () => {
      dispatch(resetGroupByUniqueId());
    };
  }, []);

  useEffect(() => {
    if (items) setInternalItems(items);
  }, [items]);

  const close = () => {
    onClose();
  };

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 5, // Require mouse to move 5px to start drag
      },
    }),
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (over && active.id !== over.id) {
      setInternalItems((currentItems) => {
        const oldIndex = currentItems.findIndex(
          (item) => keyExtractor(item) === active.id,
        );
        const newIndex = currentItems.findIndex(
          (item) => keyExtractor(item) === over.id,
        );
        return arrayMove(currentItems, oldIndex, newIndex);
      });
    }
  };

  const handleConfirm = () => {
    onConfirm(internalItems);
  };

  const onSubmit = () => {
    let newItem = {
      status: 'all_clear',
      value: 0,
      currency: addCurrencyItem.label,
      currency_id: addCurrencyItem.value,
    };
    setInternalItems([...internalItems, newItem]);
    setAddCurrencyItem('');

    setTimeout(() => {
      if (containerRef.current) {
        containerRef.current.scrollTo({
          top: containerRef.current.scrollHeight,
          behavior: 'smooth',
        });
      }
    }, 400);
  };

  const dragAbleItem = (): React.ReactNode => {
    return (
      <div>
        {!getItemLoading && internalItems && internalItems.length > 0 ? (
          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={handleDragEnd}
            modifiers={[restrictToVerticalAxis, restrictToParentElement]}
          >
            <SortableContext
              items={internalItems.map((item) => keyExtractor(item))}
              strategy={verticalListSortingStrategy}
            >
              <div
                className="overflow-y-auto overflow-x-hidden overscroll-contain max-h-[400px] h-[auto]"
                ref={containerRef}
              >
                {internalItems.map((item: T) => {
                  return (
                    <SortableRow
                      key={keyExtractor(item)}
                      item={item}
                      keyExtractor={keyExtractor}
                    >
                      {children}
                    </SortableRow>
                  );
                })}
              </div>
            </SortableContext>
          </DndContext>
        ) : (
          <>
            {getItemLoading ? (
              <>
                {Array.from({ length: 5 }).map((_, index) => (
                  <div className="my-3" key={`CurrencyViewerSkeleton-${index}`}>
                    <CurrencyViewerSkeleton />
                  </div>
                ))}
              </>
            ) : (
              <div className="flex items-center justify-center h-40 text-gray-500">
                There are no items to re-order.
              </div>
            )}
          </>
        )}
        <div className="flex justify-between items-end gap-x-[15px] mt-7">
          <div className="w-full">
            <h2 className="text-sm font-bold">Add Currency</h2>
            <Dropdown
              name="currency"
              control={control}
              label=""
              options={filteredCurrencyOptions || []}
              dropDownMinH={56}
              onChange={(item) => {
                setAddCurrencyItem(item);
              }}
            />
          </div>
          <Button
            isLoading={false}
            type="submit"
            fullWidth={false}
            disabled={!addCurrencyItem}
            className="min-h-14 min-w-[84px]"
            onClick={() => addCurrencyItem.label && onSubmit()}
          >
            Add
          </Button>
        </div>

        <div>
          <div className="pt-6 flex justify-end gap-4">
            <Button
              type="button"
              variant="secondary"
              onClick={onClose}
              fullWidth={false}
              className="h-[56px!important] w-[50%]"
            >
              {cancelButtonText || 'Cancel'}
            </Button>
            <Button
              isLoading={reOrderLoading}
              type="button"
              onClick={handleConfirm}
              fullWidth={false}
              className="h-[56px!important] w-[50%]"
              disabled={!internalItems || internalItems.length === 0}
            >
              {confirmButtonText || 'Ok'}
            </Button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <Modal
      className="min-w-[80%] sm:[min-width:unset]"
      children={dragAbleItem()}
      isOpen={isOpen}
      onClose={close}
      title={title}
    />
  );
}

export default ReOrderItem;
