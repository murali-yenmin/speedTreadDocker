import React from 'react';
import Modal from './Modal';
import Button from '../formFields/Button';
import Tick from '../Images/Tick'; // Assuming Tick is for the header icon
import CopyIcon from '../Images/CopyIcon';
import LeftArrow from '../Images/LeftArrow';
import { showSuccessToast } from '../../utils/toast';
import {
  formatAmount,
  formatAmountWithSuperscript,
} from '../../utils/numberUtils';
import moment from 'moment';
import { SettlementData } from '../../store/interfaces/settlement';

interface SettlementByCurrencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  currency: string;
  customerOutItems: {
    groupId: string;
    currencyCode: string;
    amount: number;
  }[];
  weOutItems: {
    groupId: string;
    currencyCode: string;
    amount: number;
  }[];
  customerOutTotal: { amount: number; currencyCode: string };
  weOutTotal: { amount: number; currencyCode: string };
  currencyOptions: { label: string; value: string }[];
  dateLabel: string;
  allData: SettlementData | null;
}

const SettlementByCurrencyModal: React.FC<SettlementByCurrencyModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  currency,
  weOutItems,
  customerOutItems,
  weOutTotal,
  customerOutTotal,
  currencyOptions,
  dateLabel,
  allData,
}) => {
  const currencyObj = currencyOptions?.find((item) => item?.value === currency);

  const formatDateRange = (): string => {
    if (!allData?.start_date) return ''; // safety check

    const cleanDate = (date: string | Date): string => {
      const m = moment(date);
      const day = parseInt(m.format('DD'), 10); // remove leading zero
      const month = parseInt(m.format('MM'), 10);
      return `${day}/${month}`;
    };

    const cleanTime = (date: string | Date): string => {
      const m = moment(date);

      let hours = parseInt(m.format('HH'), 10);
      let minutes = m.minutes();
      const suffix = m.format('A'); // AM / PM

      // Convert 24hr to 12hr format
      hours = hours % 12 || 12; // handles 12AM/PM correctly

      // If minutes are zero → no need :00
      if (minutes === 0) {
        return `${hours}${suffix}`;
      }

      // Otherwise show with padded minute
      const minuteString = minutes < 10 ? `0${minutes}` : minutes;
      return `${hours}:${minuteString}${suffix}`;
    };

    // Start formatted
    const formattedStart = `${cleanDate(allData.start_date)}, ${cleanTime(allData.start_date)}`;

    // If Today → Present
    if (allData?.day === 'today') {
      return `Today (${formattedStart} - Present)`;
    }

    // End formatted
    const formattedEnd = `${cleanDate(allData.end_date)}, ${cleanTime(allData.end_date)}`;

    return `Yesterday (${formattedStart} - ${formattedEnd})`;
  };

  const handleCopy = () => {
    const lines: string[] = [];
    const date = formatDateRange();
    lines.push(`Currency: ${currencyObj?.label}`);
    lines.push(`Date: ${date}`);

    if (weOutItems.length > 0) {
      lines.push('');
      lines.push('---');
      lines.push('**We / Out:**');
      weOutItems.forEach((item) => {
        lines.push(
          `${item.groupId} — ${item.currencyCode} ${formatAmount(item.amount)}`,
        );
      });
      lines.push(
        `**Total : ${weOutTotal.currencyCode} ${formatAmount(weOutTotal.amount)}**`,
      );
    }

    if (customerOutItems.length > 0) {
      lines.push('');
      lines.push('---');
      lines.push('**Customer / Out:**');
      customerOutItems.forEach((item) => {
        lines.push(
          `${item.groupId} — ${item.currencyCode} ${formatAmount(item.amount)}`,
        );
      });
      lines.push(
        `**Total : ${customerOutTotal.currencyCode} ${formatAmount(
          customerOutTotal.amount,
        )}**`,
      );
    }

    const textToCopy = lines.join('\n');
    navigator.clipboard.writeText(textToCopy).then(() => {
      showSuccessToast('Settlement details copied to clipboard!');
    });
    onConfirm();
  };

  const copyOutItems = () => {
    const lines: string[] = [];
    const date = formatDateRange();
    lines.push(`Currency: ${currencyObj?.label}`);
    lines.push(`Date: ${date}`);
    lines.push('');
    lines.push('---');

    if (weOutItems.length > 0) {
      lines.push('**We / Out:**');
      weOutItems.forEach((item) => {
        lines.push(
          `${item.groupId} — ${item.currencyCode} ${formatAmount(item.amount)}`,
        );
      });
      lines.push(
        `**Total : ${weOutTotal.currencyCode} ${formatAmount(weOutTotal.amount)}**`,
      );
    }

    const textToCopy = lines.join('\n');
    navigator.clipboard.writeText(textToCopy).then(() => {
      showSuccessToast('Settlement details copied to clipboard!');
    });
    //  onConfirm();
  };
  const copyCustomerItems = () => {
    const lines: string[] = [];
    const date = formatDateRange();
    lines.push(`Currency: ${currencyObj?.label}`);
    lines.push(`Date: ${date}`);
    lines.push('');
    lines.push('---');

    if (customerOutItems.length > 0) {
      lines.push('**Customer / Out:**');
      customerOutItems.forEach((item) => {
        lines.push(
          `${item.groupId} — ${item.currencyCode} ${formatAmount(item.amount)}`,
        );
      });
      lines.push(
        `**Total : ${customerOutTotal.currencyCode} ${formatAmount(
          customerOutTotal.amount,
        )}**`,
      );
    }

    const textToCopy = lines.join('\n');
    navigator.clipboard.writeText(textToCopy).then(() => {
      showSuccessToast('Settlement details copied to clipboard!');
    });
    // onConfirm();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      className="!p-0 sm:min-w-[unset] md:min-w-[700px] lg:min-w-[980px]"
    >
      <div className="border-b px-[32px] py-[23px] mb-[24px] flex items-center space-x-4">
        {/* <div className="w-10 h-10 rounded-full bg-[#E8E8E8] flex items-center justify-center">
          <Tick />
        </div> */}
        <h2 className="text-xl font-bold">Settlement By Currency</h2>
      </div>

      <div className="px-8">
        <div className="my-9">
          <p className="font-medium text-base gap-5 flex">
            <span className="min-w-[70px]">Currency</span>
            <span>: {currencyObj?.label}</span>
          </p>
          <p className="font-medium text-base gap-5 flex">
            <span className="min-w-[70px]">Date</span>
            <span>: {dateLabel}</span>
          </p>
        </div>

        <div className="grid gap-5 grid-cols-1 md:grid-cols-2 max-h-[45vh] overflow-y-auto">
          <div className="bg-[#E8E8E8] shadow-md border border-gray-200 rounded-lg overflow-hidden">
            <div className="bg-primary-blue text-white flex justify-between px-[18px] pt-[13px] pb-[19px]">
              <h3 className="font-semibold text-[18px]">We / Out</h3>
              {weOutItems.length > 0 && (
                <div className="cursor-pointer" onClick={copyOutItems}>
                  <CopyIcon sm color="white" />
                </div>
              )}
            </div>
            <div className="space-y-2 p-4 overflow-y-auto h-[210px]">
              {weOutItems.length > 0 ? (
                <>
                  {weOutItems.map((item, index) => (
                    <div key={index} className="flex items-center font-medium">
                      <span className="text-[#4B5563]  min-w-[40px]">
                        {item.groupId}
                      </span>
                      <span className="bg-[#4B5563] h-[2px] min-w-2 mx-[15px]"></span>
                      <span className="text-[#4B5563]">
                        {item.currencyCode}{' '}
                        <span className="text-[#4B5563]">
                          {formatAmount(item.amount)}
                        </span>
                      </span>
                    </div>
                  ))}
                  <div className="text-[16px] flex items-center font-bold">
                    <span className="min-w-[40px]">Total</span>
                    <span className="text-[#4B5563] mx-[15px]">:&nbsp;</span>
                    <span>
                      {weOutTotal.currencyCode}{' '}
                      {formatAmount(weOutTotal.amount)}
                    </span>
                  </div>
                </>
              ) : (
                <div className="h-full flex items-center justify-center">
                  <p className="text-center">No Record</p>
                </div>
              )}
            </div>
          </div>

          <div className="bg-[#E8E8E8] shadow-md border border-gray-200  rounded-lg overflow-hidden">
            <div className="bg-primary-blue text-white flex justify-between px-[18px] pt-[13px] pb-[19px]">
              <h3 className="font-semibold text-[18px]">Customer / Out</h3>
              {customerOutItems.length > 0 && (
                <div className="cursor-pointer" onClick={copyCustomerItems}>
                  <CopyIcon sm color="white" />
                </div>
              )}
            </div>
            <div className="space-y-2 p-4 overflow-y-auto h-[210px]">
              {customerOutItems.length > 0 ? (
                <>
                  {customerOutItems.map((item, index) => (
                    <div key={index} className="flex items-center font-medium">
                      <span className="text-[#4B5563]  min-w-[40px]">
                        {item.groupId}
                      </span>
                      <span className="bg-[#4B5563] h-[2px] min-w-2 mx-[15px]"></span>
                      <span className="text-[#4B5563]">
                        {item.currencyCode}{' '}
                        <span className="text-[#4B5563]">
                          {formatAmount(item.amount)}
                        </span>
                      </span>
                    </div>
                  ))}
                  <div className="text-[16px] flex items-center font-bold ">
                    <span className="min-w-[40px]">Total</span>
                    <span className="text-[#4B5563] mx-[15px]">:&nbsp;</span>
                    <span>
                      {customerOutTotal.currencyCode}{' '}
                      {formatAmount(customerOutTotal.amount)}
                    </span>
                  </div>
                </>
              ) : (
                <div className="h-full flex items-center justify-center">
                  <p className="text-center">No Record</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Button area */}
        <div className="my-[32px] flex justify-end gap-x-4 self-end">
          <Button
            type="button"
            variant="secondary"
            onClick={onClose}
            className="text-gray-500 focus:ring-0 focus:outline-none max-w-[210px] min-h-14"
          >
            {/* <LeftArrow />  */}
            <span className="ms-2">Cancel</span>
          </Button>
          {(weOutItems.length > 0 || customerOutItems.length > 0) && (
            <Button
              type="button"
              variant="primary"
              className="max-w-[210px] min-h-14"
              onClick={handleCopy}
            >
              {/* <CopyIcon sm color="white" />  */}
              <span className="ms-2">Copy All</span>
            </Button>
          )}
        </div>
      </div>
    </Modal>
  );
};

export default SettlementByCurrencyModal;
