import React, { useEffect, useMemo, useState } from 'react';
import Modal from './Modal';
import Button from '../formFields/Button';
import Dropdown from '../formFields/Dropdown';
import RadioGroup from '../formFields/RadioGroup';
import { useForm, useWatch } from 'react-hook-form';
import moment from 'moment-timezone';
import { defaultDateFormat } from '../formFields/DateRangeInput';
import { useAppDispatch, useAppSelector } from '../../store/store';
import { getSettlementDetailsThunk } from '../../store/thunks/settlement';
import SettlementByCustomerModal from './SettlementByCustomerModal';
import SettlementByCurrencyModal from './SettlementByCurrencyModal';
import { getAllCurrenciesThunk } from '../../store/thunks/settings';
import { CurrencyProps } from '../../store/interfaces/settings';
import { getAllGroupsThunk } from '../../store/thunks/groups';
import { Group } from '../../store/interfaces/group';
import { dateOptions, settlementTypeOptions } from '../../constants/dropdowns';
import { getUserRole } from '../../utils/auth';
import { ROLES } from '../../constants/roles';
import {
  GroupedCurrency,
  SettlementCurrency,
  SettlementData,
} from '../../store/interfaces/settlement';
import { getValue } from '@testing-library/user-event/dist/utils';

interface SettlementModalProps {
  isOpen: boolean;
  onClose: () => void;
}
interface SettlementFormData {
  settlementType: 'currency' | 'customer';
  date: string;
  currency?: string;
  customer?: string;
}
const SettlementModal: React.FC<SettlementModalProps> = ({
  isOpen,
  onClose,
}) => {
  const userRole = getUserRole();
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
  const [isCurrencyModalOpen, setIsCurrencyModalOpen] = useState(false);
  const [isToday, setIsToday] = useState(dateOptions[0].label);
  const [settlementData, setSettlementData] =
    useState<SettlementFormData | null>(null);

  const dispatch = useAppDispatch();
  const allData: SettlementData | null = useAppSelector(
    (state) => state.settlementDetailsReducer?.data,
  );
  const allDataLoading: boolean = useAppSelector(
    (state) => state.settlementDetailsReducer?.loading,
  );
  const settlementDetails = allData?.grouped_currency;

  const { data: currencies } = useAppSelector(
    (state) => state.getAllCurrenciesReducer,
  );
  const { groups: allGroups } = useAppSelector(
    (state) => state.getAllGroupsReducer,
  );

  useEffect(() => {
    if (isOpen) {
      dispatch(getAllCurrenciesThunk());
      dispatch(getAllGroupsThunk({ payload: { cp: 0, pl: 0, query: [] } })); // Fetch all groups with a high page limit
    }
  }, [isOpen, dispatch]);

  const {
    control,
    handleSubmit,
    setValue,
    getValues,
    watch,
    reset,
    formState: { errors },
  } = useForm<SettlementFormData>({
    defaultValues: {
      settlementType: 'currency',
      date: moment
        .tz(process.env.REACT_APP_TIMEZONE as string)
        .format(defaultDateFormat), // Use moment.tz for default date
    },
  });
  const settlementType = useWatch({
    control,
    name: 'settlementType',
  });

  const handleClose = () => {
    reset({
      settlementType: 'currency',
      date: moment
        .tz(process.env.REACT_APP_TIMEZONE as string)
        .format(defaultDateFormat),
      currency: '',
      customer: '',
    });
    setSettlementData(null);
    setIsCustomerModalOpen(false);
    setIsCurrencyModalOpen(false);
    onClose();
  };

  const currencyOptions = useMemo(() => {
    if (!currencies) return [];
    return currencies.map((currency: CurrencyProps) => ({
      label: currency.code,
      value: currency.unique_id,
    }));
  }, [currencies]);

  const customerOptions = useMemo(() => {
    if (!allGroups?.customer_groups_list) return [];
    return allGroups.customer_groups_list.map((group: Group) => ({
      label: group.group_id,
      value: group.unique_id,
    }));
  }, [allGroups?.customer_groups_list]);

  const onSubmit = (data: SettlementFormData) => {
    setSettlementData(data);
    const payload =
      data.settlementType === 'currency'
        ? {
            currency_id: [data.currency!],
            day_filter: data.date,
          }
        : {
            group_id: [data.customer!],
            day_filter: data.date,
          };

    dispatch(
      getSettlementDetailsThunk({
        payload,
        role: userRole === ROLES.ORDER_MANAGER ? 'order' : 'transaction',
        callbackAfterSuccess: () => {
          if (data.settlementType === 'customer') {
            setIsCustomerModalOpen(true);
          } else if (data.settlementType === 'currency') {
            setIsCurrencyModalOpen(true);
          }
        },
      }),
    );
  };

  const handleCustomerConfirm = () => {
    handleClose();
  };

  const handleCurrencyConfirm = () => {
    handleClose();
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={handleClose}
        className="sm !p-0 settlementmodel"
        preventOutsideClick
      >
        <div className="border-b border-[#E8EDF5]">
          <h3 className="py-[25px] px-[23px] font-bold text-xl">Settlement</h3>
        </div>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="space-y-[28px] p-[23px] pb-[26px]"
        >
          <RadioGroup
            name="settlementType"
            control={control}
            options={settlementTypeOptions}
            customClassName="flex gap-4 settlement-option"
            hasBorder={true}
            onChange={() =>
              reset((prev) => {
                return {
                  settlementType: prev.settlementType,
                  date: moment
                    .tz(process.env.REACT_APP_TIMEZONE as string)
                    .format(defaultDateFormat),
                  currency: '',
                  customer: '',
                };
              })
            }
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Date
            </label>
            <Dropdown
              label=""
              name="date"
              control={control}
              options={dateOptions}
              placeholder="Select Date"
              rules={{ required: 'Date is required' }}
              onChange={(data) => {
                const selectedOption = data as { label: string; value: string };
                if (selectedOption) {
                  setIsToday(selectedOption.label || '');
                }
              }}
            />
          </div>

          {settlementType === 'currency' && (
            <Dropdown
              label="Currency"
              name="currency"
              control={control}
              options={currencyOptions}
              placeholder="Select Currency"
              rules={{ required: 'Currency is required' }}
            />
          )}

          {settlementType === 'customer' && (
            <Dropdown
              label="Customer"
              name="customer"
              control={control}
              options={customerOptions}
              placeholder="Select Customer"
              rules={{ required: 'Customer is required' }}
            />
          )}

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="secondary" onClick={handleClose}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" isLoading={allDataLoading}>
              Proceed
            </Button>
          </div>
        </form>
      </Modal>
      {settlementData &&
        settlementData.settlementType === 'customer' &&
        settlementDetails && (
          <SettlementByCustomerModal
            isOpen={isCustomerModalOpen}
            onClose={() => setIsCustomerModalOpen(false)}
            onConfirm={handleCustomerConfirm}
            groupId={
              settlementDetails[0]?.group_code ??
              allGroups?.customer_groups_list?.find(
                (item) => item?.unique_id == getValues('customer'),
              )?.group_id ??
              ''
            }
            weOutItems={
              settlementDetails[0]?.currencies
                .filter((c: SettlementCurrency) => c.totalOweUs > 0)
                .map((c: SettlementCurrency) => ({
                  currencyCode: c.settlement_currency_code,
                  amount: c.totalOweUs,
                })) || []
            }
            weOutTotal={{
              currencyCode:
                settlementDetails[0]?.currencies[0]?.settlement_currency_code,
              amount: settlementDetails[0]?.currencies[0]?.totalWeOwe,
            }}
            customerOutItems={
              settlementDetails[0]?.currencies
                .filter((c: SettlementCurrency) => c.totalWeOwe > 0)
                .map((c: SettlementCurrency) => ({
                  currencyCode: c.settlement_currency_code,
                  amount: c.totalWeOwe,
                })) || []
            }
            customerOutTotal={{
              currencyCode:
                settlementDetails[0]?.currencies[0]?.settlement_currency_code,
              amount: settlementDetails[0]?.currencies[0]?.totalOweUs,
            }}
            dateLabel={isToday}
            allData={allData}
          />
        )}
      {settlementData &&
        settlementData.settlementType === 'currency' &&
        settlementDetails && (
          <SettlementByCurrencyModal
            isOpen={isCurrencyModalOpen}
            onClose={() => setIsCurrencyModalOpen(false)}
            onConfirm={handleCurrencyConfirm}
            currency={settlementData.currency || ''}
            customerOutItems={
              settlementDetails?.flatMap((detail: GroupedCurrency) =>
                detail.currencies
                  .filter((c: SettlementCurrency) => c.totalWeOwe > 0)
                  .map((c: SettlementCurrency) => ({
                    groupId: detail.group_code,
                    currencyCode: c.settlement_currency_code,
                    amount: c.totalWeOwe,
                  })),
              ) || []
            }
            weOutItems={
              settlementDetails?.flatMap((detail: GroupedCurrency) =>
                detail.currencies
                  .filter((c: SettlementCurrency) => c.totalOweUs > 0)
                  .map((c: SettlementCurrency) => ({
                    groupId: detail.group_code,
                    currencyCode: c.settlement_currency_code,
                    amount: c.totalOweUs,
                  })),
              ) || []
            }
            customerOutTotal={{
              amount:
                settlementDetails
                  ?.flatMap((detail: GroupedCurrency) =>
                    detail.currencies.map(
                      (c: SettlementCurrency) => c.totalWeOwe,
                    ),
                  )
                  .reduce((acc: number, amount: number) => acc + amount, 0) ||
                0,
              currencyCode:
                currencyOptions.find(
                  (c) => c.value === settlementData?.currency,
                )?.label || '',
            }}
            weOutTotal={{
              amount:
                settlementDetails
                  ?.flatMap((detail: GroupedCurrency) =>
                    detail.currencies.map(
                      (c: SettlementCurrency) => c.totalOweUs,
                    ),
                  )
                  .reduce((acc: number, amount: number) => acc + amount, 0) ||
                0,
              currencyCode:
                currencyOptions.find(
                  (c) => c.value === settlementData?.currency,
                )?.label || '',
            }}
            currencyOptions={currencyOptions}
            dateLabel={isToday}
            allData={allData}
          />
        )}
    </>
  );
};

export default SettlementModal;
