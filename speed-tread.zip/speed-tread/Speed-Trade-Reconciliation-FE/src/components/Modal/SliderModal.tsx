import React, { ReactNode, useEffect, useRef, useCallback } from 'react';
import CloseIcon from '../Images/CloseIcon';

interface SliderModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: ReactNode;
  showCloseIcon?: boolean;
}

const SliderModal: React.FC<SliderModalProps> = ({
  isOpen,
  onClose,
  children,
  showCloseIcon = true,
}) => {
  const modalRef = useRef<HTMLDivElement>(null); // Ref for the modal content

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';

      // Focus trapping logic
      const focusableElements =
        modalRef.current?.querySelectorAll(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
        ) || [];
      const firstElement = focusableElements[0] as HTMLElement;
      const lastElement = focusableElements[
        focusableElements.length - 1
      ] as HTMLElement;

      const handleKeyDown = (event: KeyboardEvent) => {
        if (event.key === 'Tab') {
          if (event.shiftKey) {
            // Shift + Tab
            if (document.activeElement === firstElement) {
              lastElement?.focus();
              event.preventDefault();
            }
          } else {
            // Tab
            if (document.activeElement === lastElement) {
              firstElement?.focus();
              event.preventDefault();
            }
          }
        }
      };

      modalRef.current?.addEventListener('keydown', handleKeyDown);
      firstElement?.focus(); // Focus on the first element when modal opens

      return () => {
        document.body.style.overflow = '';
        modalRef.current?.removeEventListener('keydown', handleKeyDown);
      };
    } else {
      document.body.style.overflow = '';
    }
  }, [isOpen]);

  return (
    <div
      className={`fixed inset-0 z-50 transition-opacity duration-300 ${
        isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
      }`}
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black bg-opacity-50"
        onClick={(e) => {
          e.stopPropagation();
          onClose();
        }}
      ></div>

      {/* Content */}
      <div
        ref={modalRef} // Assign ref to the modal content div
        onClick={(e) => e.stopPropagation()}
        className={`fixed top-0 right-0 h-full bg-white shadow-lg transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        } w-[98vw] mid-range-xl:w-[90vw]`}
        role="dialog" // Add ARIA role for accessibility
        aria-modal="true" // Add ARIA attribute for accessibility
      >
        {showCloseIcon && (
          <button
            className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
            onClick={onClose}
          >
            <CloseIcon />
          </button>
        )}
        {children}
      </div>
    </div>
  );
};

export default SliderModal;
