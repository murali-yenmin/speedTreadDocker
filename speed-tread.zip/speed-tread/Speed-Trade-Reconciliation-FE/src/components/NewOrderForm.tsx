import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { NewOrderFormProps } from '../interfaces/components';
import RadioGroup from '../components/formFields/RadioGroup';
import Dropdown from '../components/formFields/Dropdown';
import Input from '../components/formFields/Input';
import Button from '../components/formFields/Button';
import { newOrderSchema } from '../validations/order';
import { useTranslation } from 'react-i18next';

const NewOrderForm: React.FC<NewOrderFormProps> = ({
  initialBuyCurrency = 'MYR',
}) => {
  const { t } = useTranslation();

  const [currencies] = useState(['MYR', 'THB', 'RMB', 'USDT', 'IDR', 'USD']);
  const { control, handleSubmit, reset, watch } = useForm({
    resolver: yupResolver(newOrderSchema(t)),
    defaultValues: {
      order_for: 'customer',
      buy: initialBuyCurrency,
      sell: 'USD',
      amount: 1000,
      rate: 4.2,
    },
  });

  const buyCurrency = watch('buy');

  useEffect(() => {
    reset({ buy: initialBuyCurrency });
  }, [initialBuyCurrency, reset]);

  const onSubmit = (data: any) => {
    // In a real application, you would dispatch an action to save the new order. 
    alert('New order submitted! Check the console for the data.');
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6">Create New Order</h2>
      <form onSubmit={handleSubmit(onSubmit)} autoComplete="off">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Order For
            </label>
            <RadioGroup
              name="order_for"
              control={control}
              options={[
                { label: 'Customer', value: 'customer' },
                { label: 'Us (Internal)', value: 'us' },
              ]}
            />
          </div>

          <Dropdown
            name="buy"
            control={control}
            label="Buy Currency"
            options={currencies.map((currency) => ({
              label: currency,
              value: currency,
            }))}
          />

          <Dropdown
            name="sell"
            control={control}
            label="Sell Currency"
            options={currencies.map((currency) => ({
              label: currency,
              value: currency,
            }))}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          <div>
            <Input
              name="amount"
              control={control}
              label="Amount"
              type="number"
              inputClassName="rounded-r-none"
              rightAddon={
                <span className="inline-flex items-center px-3 rounded-r-md border border-l-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm">
                  {buyCurrency}
                </span>
              }
            />
          </div>

          <div>
            <Input name="rate" control={control} label="Rate" type="number" />
          </div>
        </div>

        <div className="flex justify-end gap-4 mt-8">
          <Button type="button" variant="secondary" onClick={() => reset()}>
            Cancel
          </Button>
          <Button type="submit" variant="primary">
            Create Order
          </Button>
        </div>
      </form>
    </div>
  );
};

export default NewOrderForm;
