import React, { ReactNode } from 'react';

interface NoDataProps {
  message?: string;
  icon?: ReactNode;
  minHeight?: string;
}

const DefaultDocumentIcon: React.FC = () => (
  <svg width="68" height="44" viewBox="0 0 68 44" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M21.9915 8.05853L15.8299 39.7009L15.0293 43.8433L56.1061 43.6519C57.9511 43.6519 59.5872 41.9984 60.179 39.5791L67.4719 9.71201C67.9244 7.86707 66.9323 5.95251 65.5399 5.95251L23.9583 5.98733C23.0532 5.98733 22.2351 6.84017 22.0089 8.07593L21.9915 8.05853Z" fill="#4E6484"/>
<g opacity="0.5">
<path d="M21.9915 8.05853L15.8299 39.7009L15.0293 43.8433L56.1061 43.6519C57.9511 43.6519 59.5872 41.9984 60.179 39.5791L67.4719 9.71201C67.9244 7.86707 66.9323 5.95251 65.5399 5.95251L23.9583 5.98733C23.0532 5.98733 22.2351 6.84017 22.0089 8.07593L21.9915 8.05853Z" fill="black"/>
</g>
<path d="M52.1732 37.5601L47.8218 2.50633C47.6478 1.07912 46.499 0 45.1414 0L35.6032 0.0348096C34.8896 0.0348096 34.2108 0.348101 33.7234 0.870253L29.198 5.69145L2.6721 5.8307C1.0534 5.8307 -0.199795 7.37975 0.0264756 9.10285L4.06454 41.4937C4.23859 42.9209 5.38735 44 6.72757 44L52.9564 43.913C58.1084 44.0174 58.5958 42.5032 58.5958 42.5032C52.6779 43.8085 52.1558 37.5775 52.1558 37.5775L52.1732 37.5601Z" fill="#4E6484"/>
<g opacity="0.9">
<path d="M32.2249 30.546L30.6758 32.2169L18.666 21.4257L20.2151 19.7374L32.2249 30.546Z" fill="white"/>
<path d="M30.0153 19.3719L31.7384 20.921L20.8774 32.5998L19.1543 31.0507L30.0153 19.3719Z" fill="white"/>
</g>
</svg>
);

const NoData: React.FC<NoDataProps> = ({
  message = 'No Data Available',
  icon,
  minHeight = 'min-h-[380px]',
}) => {
  return (
    <div className={`flex flex-col items-center justify-center py-8 text-gray-500 ${minHeight}`}>
      {icon ? (
        <div className="text-4xl">{icon}</div>
      ) : (
        <div className="text-4xl">
          <DefaultDocumentIcon />
        </div>
      )}
      <p className="text-lg font-medium">{message}</p>
    </div>
  );
};

export default NoData;
