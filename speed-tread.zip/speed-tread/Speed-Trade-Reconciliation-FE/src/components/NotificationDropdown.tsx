import React from 'react';
import { Link } from 'react-router-dom'; // New import
import { formatNotificationTime } from '../utils/timeFormatter';

interface NotificationItem {
  id: string;
  icon?: React.ReactNode; // Placeholder for icon
  title: string;
  details: string;
  time: string;
}

interface NotificationDropdownProps {
  notifications: NotificationItem[];
  onSeeAllClick: () => void; // New prop
}

const NotificationDropdown: React.FC<NotificationDropdownProps> = ({
  notifications,
  onSeeAllClick, // Destructure new prop
}) => {
  return (
    <div
      className="origin-top-right absolute right-0 mt-2 w-80 rounded-2xl shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none p-[13px] notification-right-show z-[1]"
      role="menu"
      aria-orientation="vertical"
      aria-labelledby="notification-menu-button"
      tabIndex={-1}
    >
      <div className="px-4 py-3 flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-900">Notifications</h3>
        <Link
          to="/notifications"
          className="text-sm font-medium text-gray-600 hover:text-gray-800"
          onClick={onSeeAllClick} // New prop to close dropdown
        >
          See all
        </Link>
      </div>
      <div className="py-1 max-h-[360px] overflow-y-scroll">
        {notifications.length > 0 ? (
          notifications.map((notification) => (
            <div
              key={notification.id}
              className="flex items-start px-4 py-3 hover:bg-gray-100 rounded-xl cursor-pointer"
            >
              <div className="flex-shrink-0 mr-4">
                <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                  <svg
                    className="w-6 h-6 text-gray-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-gray-800">
                  {notification.title}
                </p>
                <p className="text-sm text-gray-600 mt-1">
                  {notification.details}
                </p>
                <p className="text-xs text-gray-500 mt-2">
                  {formatNotificationTime(notification.time)}
                </p>
              </div>
            </div>
          ))
        ) : (
          <p className="px-4 py-3 text-sm text-gray-500">
            No new notifications.
          </p>
        )}
      </div>
    </div>
  );
};

export default NotificationDropdown;
