import React, { useState } from 'react';
import Accordion from './Accordion';
import ThreeDotDropdown from './ThreeDotDropdown';
import TransactionDetailCard from './TransactionDetailCard';
import { Transaction } from '../store/interfaces/transaction';
import { Order } from '../interfaces/order';
import {
  formatAmount,
  formatAmountWithSuperscript,
} from '../utils/numberUtils';
import { toTitleCase } from '../utils/stringUtils';
import AddOrderTransactionModal from './Modal/AddOrderTransactionModal';
import EditOrderModal from './Modal/EditOrderModal';
import Remark from './Remark';
import useMediaQuery from '../hooks/useMediaQuery';
import ConfirmationModal from './Modal/ConfirmationModal';
import CompleteOrderIcon from '../assets/svg/CompleteOrderIcon';
import { useAppDispatch, useAppSelector } from '../store/store';
import { completeOrderThunk } from '../store/thunks/orderTransaction';
import TextTooltip from './TextTooltip';
import OrderComplete from './OrderComplete';
import { ORDER_CARD_DROPDOWN_OPTIONS } from '../constants/dropdowns';
import { deleteOrderThunk } from '../store/thunks/order';
import CopyIcon from './Images/CopyIcon';
import { showSuccessToast } from '../utils/toast';
import { formatOrderId } from '../utils/stringUtils';
import moment from 'moment';
import { defaultDateFormat } from './formFields/DateRangeInput';

interface OrderCardProps {
  order: Order;
  onOrderUpdated: () => void;
  showGroup?: boolean;
  isSelectMode?: boolean;
  onSelect?: (order: Order) => void;
  isSelected?: boolean;
  onCopyOrder?: (order: Order) => void;
}
const OrderCard: React.FC<OrderCardProps> = ({
  order,
  onOrderUpdated,
  showGroup = false,
  isSelectMode = false,
  onSelect,
  isSelected = false,
  onCopyOrder,
}) => {
  const dispatch = useAppDispatch();
  const completeOrderLoading = useAppSelector(
    (state) => state.completeOrderReducer.loading,
  );
  const isLoading = useAppSelector((state) => state.deleteOrderReducer.loading);

  const [isAddTransactionModalOpen, setIsAddTransactionModalOpen] =
    useState(false);
  const [isEditOrderModalOpen, setIsEditOrderModalOpen] = useState(false);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteItem, setDeleteItem] = useState<null | Order>(null);

  const handleOpenModal = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    setIsAddTransactionModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsAddTransactionModalOpen(false);
  };

  const handleOpenConfirmModal = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    setIsConfirmModalOpen(true);
  };

  const handleCloseConfirmModal = () => {
    setIsConfirmModalOpen(false);
  };

  const handleConfirm = () => {
    let payload = { order_id: order.unique_id };
    dispatch(
      completeOrderThunk({
        payload,
        callbackAfterSuccess: completeOrderSideEffect,
      }),
    );
  };

  const completeOrderSideEffect = () => {
    handleCloseConfirmModal();
    onOrderUpdated();
  };

  const getStatusColor = () => {
    switch (order.status) {
      case 'processing':
        return 'bg-warm-grey';
      case 'transferring':
        return 'bg-bright-orange';
      case 'completed':
        return 'bg-strong-green';
      case 'error':
        return 'bg-strong-red';
      default:
        return 'bg-gray-500';
    }
  };

  const isMobile = useMediaQuery('(max-width: 1220px)');

  const handleCopyOrder = (order: Order) => {
    let orderString = ``;
    orderString += `${moment(order.created_at).format(defaultDateFormat)}\n`;
    orderString += `${formatOrderId(order.order_id)}\n`;
    orderString += `${order.account.name}\n`;
    orderString += `${order.currency} ${formatAmount(Number(order.amount))}\n`;
    if (order.settlement_currency !== order.currency) {
      orderString += `Rate ${formatAmount(Number(order.rate), 3)}\n`;
    }
    if(order.fee){
      orderString += `Fee ${formatAmount(Number(order.fee), 2)}\n`;
    }
    if (order.remarks) {
      orderString += `Remark ${order.remarks}`;
    }

    navigator.clipboard.writeText(orderString).then(() => {
      showSuccessToast('Order details copied to clipboard!');
    });
  };

  const handleDelete = () => {
    setIsDeleteModalOpen(true);
  };
  const handleDeleteClose = () => {
    setIsDeleteModalOpen(false);
    setDeleteItem(null);
  };
  const DeleteOrder = async () => {
    if (deleteItem) {
      dispatch(
        deleteOrderThunk({
          payload: { id: deleteItem?.unique_id },
          callbackAfterSuccess: deleteSideEffect,
        }),
      );
    }
  };

  const deleteSideEffect = () => {
    onOrderUpdated && onOrderUpdated();
    setDeleteItem(null);
    handleDeleteClose();
  };

  const hasTransactions = order.transactions && order.transactions.length > 0;

  const orderCardDropdownOptions = ORDER_CARD_DROPDOWN_OPTIONS.map((item) =>
    item.action === 'edit' && hasTransactions ? { ...item, disabled: true } : item,
  );

  const headerContent = isMobile ? (
    <div className="sm:p-4">
      <div className="grid grid-cols-1 gap-4 sm:mt-4 mid-range-sm:grid-cols-1 mid-range-lg:grid-cols-1">
        {showGroup && (
          <div className="min-w-0">
            <p className="text-sm text-gray-500 whitespace-nowrap">
              {order.customer_group?.group_id}
            </p>
            <TextTooltip text={order.customer_group?.name}>
              <p className="font-semibold break-words whitespace-nowrap overflow-hidden text-ellipsis max-w-100">
                {order.customer_group?.name}
              </p>
            </TextTooltip>
          </div>
        )}
        <div className="flex justify-between items-start">
          <div className={`${isMobile ? 'flex-1' : 'flex-none'}`}>
            {isMobile ? (
              <TextTooltip text={order?.account?.name} position="left">
                <p className="text-lg font-semibold break-words whitespace-nowrap overflow-hidden text-ellipsis max-w-[160px] mid-range-sm:max-w-[400px] mid-range-lg:max-w-[400px] mid-range:max-w-[160px] capitalize">
                  {order?.account?.name}
                </p>
              </TextTooltip>
            ) : (
              <TextTooltip text={order?.account?.name}>
                <p className="text-lg font-semibold break-words whitespace-nowrap overflow-hidden text-ellipsis max-w-[100px] capitalize">
                  {order?.account?.name}
                </p>
              </TextTooltip>
            )}

            <div
              className={`w-[95px] h-[20px] flex items-center justify-center pb-[1px] text-white text-sm font-semibold rounded-full whitespace-nowrap ${
                order.order_by === 'we' ? 'bg-strong-green' : 'bg-strong-red'
              }`}
            >
              {order.order_by == 'we' ? 'We' : 'Cust'}{' '}
              {order.trading === 'buy'
                ? 'BUY'
                : order.trading === 'transfer'
                  ? 'TRF'
                  : 'ADJ'}
            </div>
          </div>
          <div className="flex gap-2 item-center absolute top-[20px] right-[10px]">
            <button
              className="flex justify-center"
              title="Copy"
              onClick={(e) => {
                e.stopPropagation();
                if (onCopyOrder) {
                  onCopyOrder(order);
                } else {
                  handleCopyOrder(order);
                }
              }}
            >
              <CopyIcon />
            </button>
            <ThreeDotDropdown
              items={orderCardDropdownOptions}
              onAction={(action) => {
                if (action === 'edit') {
                  setIsEditOrderModalOpen(true);
                } else if (action === 'delete') {
                  handleDelete();
                  setDeleteItem(order);
                }
              }}
            />
          </div>
        </div>
      </div>
      <div className="grid grid-cols-1 gap-4 mt-4 mid-range-sm:grid-cols-2 mid-range-lg:grid-cols-2">
        <div className="">
          <p className="text-sm text-gray-500 whitespace-nowrap">Amount</p>
          <p className="font-semibold whitespace-nowrap">
            {order.currency}{' '}
            {formatAmountWithSuperscript(formatAmount(Number(order.amount)))}
          </p>
        </div>
        {order.rate && parseFloat(order.rate) > 0 && (
          <div>
            <p className="text-sm text-gray-500 whitespace-nowrap">Rate</p>
            <p className="font-semibold whitespace-nowrap">
              {formatAmountWithSuperscript(formatAmount(Number(order.rate), 3))}
            </p>
          </div>
        )}
        {order.fee && parseFloat(order.fee) > 0 && (
          <div>
            <p className="text-sm text-gray-500 whitespace-nowrap">Fee</p>
            <p className="font-semibold whitespace-nowrap">
              {formatAmountWithSuperscript(formatAmount(Number(order.fee), 2))}
            </p>
          </div>
        )}
        <div className="border rounded-lg p-2 h-[50px] min-w-[174px] max-w-max flex flex-col justify-center">
          <p className="text-[13px] font-normal text-gray-500 whitespace-nowrap">
            {order.calculation?.status === 'by_us'
              ? 'Pending Us'
              : order.calculation?.status === 'by_customer'
                ? 'Pending Customer'
                : 'All Clear'}
          </p>
          <p className="text-[15px] font-medium whitespace-nowrap">
            {order.calculation?.status === 'by_us' &&
            order.calculation?.value ? (
              <span className="text-strong-red">
                ({order.currency}{' '}
                {formatAmountWithSuperscript(
                   formatAmount(order.calculation.pending_amount),
                )}
                )
              </span>
            ) : order.calculation?.status === 'by_customer' &&
              order.calculation?.value ? (
              <span className="text-strong-green">
                 {order.currency}{' '}
                {formatAmountWithSuperscript(
                 formatAmount(order.calculation.pending_amount),
                )}
                
              </span>
            ) : order.calculation?.status === 'all_clear' ? (
              <span className="text-black">-</span>
            ) : (
              '-'
            )}
          </p>
        </div>
        <div>
          <p className="text-sm text-gray-500 whitespace-nowrap">Status</p>
          <div
            className={`px-3 pb-[2px] text-white text-sm font-normal rounded-full whitespace-nowrap max-w-[143px] h-[20px] flex items-center justify-center ${getStatusColor()}`}
          >
            {order.status === 'transferring'
              ? `Transferring (${Math.floor(order.transfer_percent * 10) / 10}%)`
              : order.status &&
                order.status.charAt(0).toUpperCase() + order.status.slice(1)}
          </div>
        </div>
      </div>
      {order.remarks && (
        <div className="mt-4">
          <p className="text-sm text-gray-500">Remarks</p>
          {order.remarks}
        </div>
      )}
      <OrderComplete
        order={order}
        handleOpenConfirmModal={handleOpenConfirmModal}
        handleOpenModal={handleOpenModal}
      />
    </div>
  ) : (
    <div className="flex">
      <div
        className={`grid gap-[15px] ${
          showGroup
            ? 'grid-cols-[100px_100px_170px_80px_80px_150px_150px] mid-range-xl:grid-cols-[170px_170px_170px_80px_80px_170px_170px]'
            : 'grid-cols-[170px_170px_80px_80px_170px_170px]'
        }`}
      >
        {showGroup && (
          <div className="min-w-0">
            <p className="text-sm text-gray-500 whitespace-nowrap">
              {order.customer_group?.group_id}
            </p>
            <TextTooltip text={order.customer_group?.name}>
              <p className="sm:max-w-100 font-semibold break-words whitespace-nowrap overflow-hidden text-ellipsis max-w-[100px] mid-range-xl:max-w-[170px]">
                {order.customer_group?.name}
              </p>
            </TextTooltip>
          </div>
        )}
        <div className="min-w-0">
          <div>
            <TextTooltip text={toTitleCase(order?.account?.name)}>
              <p className="text-lg font-semibold break-words whitespace-nowrap overflow-hidden text-ellipsis max-w-[100px] mid-range-xl:max-w-[170px]">
                {order?.account?.name}
              </p>
            </TextTooltip>

            <div
              className={`w-[95px] h-[20px] flex items-center justify-center pb-[1px] text-white text-sm font-semibold rounded-full whitespace-nowrap ${
                order.order_by === 'we' ? 'bg-strong-green' : 'bg-strong-red'
              }`}
            >
              {order.order_by == 'we' ? 'We' : 'Cust'}{' '}
              {order.trading === 'buy'
                ? 'BUY'
                : order.trading === 'transfer'
                  ? 'TRF'
                  : 'ADJ'}
            </div>
          </div>
        </div>
        <div className="min-w-0">
          <p className="text-sm text-gray-500 whitespace-nowrap">Amount</p>
          <p className="font-semibold break-words whitespace-normal">
            {order.currency}{' '}
            {formatAmountWithSuperscript(formatAmount(Number(order.amount)))}
          </p>
        </div>
        <div className="min-w-0">
          {order.rate && parseFloat(order.rate) > 0 && (
            <>
              <p className="text-sm text-gray-500 whitespace-nowrap">Rate</p>
              <p className="font-semibold break-words whitespace-normal">
                {formatAmountWithSuperscript(
                  formatAmount(Number(order.rate), 3),
                )}
              </p>
            </>
          )}
        </div>
        <div className="min-w-0">
          {order.fee && parseFloat(order.fee) > 0 && (
            <>
              <p className="text-sm text-gray-500 whitespace-nowrap">Fee</p>
              <p className="font-semibold break-words whitespace-normal">
                {formatAmountWithSuperscript(
                  formatAmount(Number(order.fee), 2),
                )}
              </p>
            </>
          )}
        </div>
        <div className="border rounded-lg p-2 h-[50px] w-[174px] flex flex-col justify-center">
          <p className="text-[13px] font-normal text-gray-500 whitespace-nowrap">
            {order.calculation?.status === 'by_us'
              ? showGroup ? "Pending Us" : 'Pending Us'
              : order.calculation?.status === 'by_customer'
                ? showGroup ? "Pending Customer" : 'Pending Customer'
                : 'All Clear'}
          </p>
          <p className="text-[15px] font-medium whitespace-nowrap">
            {order.calculation?.status === 'by_us' &&
            order.calculation?.value ? (
              <span className="text-strong-red">
                ({order.currency}{' '}
                {formatAmountWithSuperscript(
                  formatAmount(order.calculation.pending_amount),
                )}
                )
              </span>
            ) : order.calculation?.status === 'by_customer' &&
              order.calculation?.value ? (
              <span className="text-strong-green">
                {order.currency}{' '}
                {formatAmountWithSuperscript(
                  formatAmount(order.calculation.pending_amount),
                )}
                
              </span>
            ) : order.calculation?.status === 'all_clear' ? (
              <span className="text-black">-</span>
            ) : (
              '-'
            )}
          </p>
        </div>

        <div className="min-w-0">
          <p className="text-sm text-gray-500 whitespace-nowrap">Status</p>
          <div className="flex">
            <p
              className={`px-3 pb-[2px] text-white text-sm font-normal rounded-full whitespace-nowrap w-auto h-[20px] flex items-center justify-center ${getStatusColor()}`}
            >
              {order.status === 'transferring'
                ? `Transferring (${Math.floor(order.transfer_percent * 10) / 10}%)`
                : order.status &&
                  order.status.charAt(0).toUpperCase() + order.status.slice(1)}
            </p>
          </div>
        </div>
      </div>
      <div className="flex items-center gap-[12px] w-full justify-end">
        {order.remarks && <Remark remarks={order.remarks} />}
        <button
          className="flex justify-center"
          title="Copy"
          onClick={(e) => {
            e.stopPropagation();
            if (onCopyOrder) {
              onCopyOrder(order);
            } else {
              handleCopyOrder(order);
            }
          }}
        >
          <CopyIcon />
        </button>
        <OrderComplete
          order={order}
          handleOpenConfirmModal={handleOpenConfirmModal}
          handleOpenModal={handleOpenModal}
        />
        <div className="flex items-center justify-end">
          <ThreeDotDropdown
            items={orderCardDropdownOptions}
            onAction={(action) => {
              if (action === 'edit') {
                setIsEditOrderModalOpen(true);
              } else if (action === 'delete') {
                handleDelete();
                setDeleteItem(order);
              }
            }}
          />
        </div>
      </div>
    </div>
  );

  return (
    <>
      <Accordion
        header={headerContent}
        className="bg-gray-50 rounded-[20px] border border-gray-200 shadow-none"
        isSelectMode={isSelectMode}
        onSelect={() => onSelect && onSelect(order)}
        checked={isSelected}
      >
        <div>
          {isMobile ? (
            <div className="sm:p-4 space-y-4 mid-range-sm:pb-8 mid-range-lg:pb-8 mid-range:pb-8">
              {order.transactions && order.transactions.length > 0 ? (
                order.transactions.map((transaction) => (
                  <TransactionDetailCard
                    key={transaction.unique_id}
                    transaction={transaction as unknown as Transaction}
                    settlementCurrency={order.settlement_currency}
                    context="orders"
                    order_uniqueId={order.unique_id}
                    group_uniqueId={order.group_id}
                    onOrderUpdated={onOrderUpdated}
                    cardStyle="bg-white"
                    sellCurrency={order.currency}
                    order_by={order.order_by}
                    account_name={order.account?.name}
                    order_trading={order.trading}
                    moreOptions={order.trading === 'adjustment' ? false : true}
                    rateLabel={false}
                    disableEdit={hasTransactions}
                    orderRate={order.rate ? Number(order.rate) : undefined}
                  />
                ))
              ) : (
                <p className="text-center text-gray-500">
                  No Transactions Recorded
                </p>
              )}
            </div>
          ) : (
            <div className="flex-grow p-0">
              <div className="flex flex-col gap-4  h-full">
                {order.transactions && order.transactions.length > 0 ? (
                  order.transactions.map((transaction, index, _self) => (
                    <TransactionDetailCard
                      index={index}
                      self={_self}
                      key={transaction.unique_id}
                      transaction={transaction as unknown as Transaction}
                      settlementCurrency={order.settlement_currency}
                      context="orders"
                      order_uniqueId={order.unique_id}
                      group_uniqueId={order.group_id}
                      onOrderUpdated={onOrderUpdated}
                      cardStyle="bg-white"
                      sellCurrency={order.currency}
                      order_by={order.order_by}
                      account_name={order.account?.name}
                      order_trading={order.trading}
                      moreOptions={
                        order.trading === 'adjustment' ? false : true
                      }
                      rateLabel={false}
                      disableEdit={hasTransactions}
                      orderRate={order.rate ? Number(order.rate) : undefined}
                    />
                  ))
                ) : (
                  <p className="text-center text-gray-500">
                    No Transactions Recorded
                  </p>
                )}{' '}
              </div>
            </div>
          )}
        </div>
      </Accordion>
      {isAddTransactionModalOpen && (
        <AddOrderTransactionModal
          isOpen={isAddTransactionModalOpen}
          onClose={handleCloseModal}
          onSuccess={() => {
            handleCloseModal();
            onOrderUpdated();
          }}
          id={order.customer_group?.group_id}
          name={order.customer_group?.name}
          settlementCurrency={order.settlement_currency}
          sellCurrency={order.currency}
          group_uniqueId={order.group_id}
          order_uniqueId={order?.unique_id}
          order_by={order.order_by}
          trading={order.trading}
          rate={order.rate ? Number(order.rate) : undefined} // Pass the order rate
          selectedDate={order?.ordered_date}
        />
      )}
      {isEditOrderModalOpen && (
        <EditOrderModal
          isOpen={isEditOrderModalOpen}
          onClose={() => setIsEditOrderModalOpen(false)}
          orderId={order?.unique_id}
          onOrderUpdated={() => {
            setIsEditOrderModalOpen(false);
            onOrderUpdated();
          }}
        />
      )}
      <ConfirmationModal
        isOpen={isConfirmModalOpen}
        onClose={handleCloseConfirmModal}
        onConfirm={handleConfirm}
        title="Complete Order"
        message="Do you want to complete this order?"
        confirmButtonText="Confirm"
        cancelButtonText="Cancel"
        icon={<CompleteOrderIcon />}
        isLoading={completeOrderLoading}
      />
      {isDeleteModalOpen && (
        <ConfirmationModal
          isOpen={isDeleteModalOpen}
          onClose={handleDeleteClose}
          onConfirm={DeleteOrder}
          title="Delete Order"
          message="Do you want to delete this order?"
          confirmButtonText="Confirm"
          cancelButtonText="Cancel"
          isLoading={isLoading}
        />
      )}
    </>
  );
};

export default OrderCard;
