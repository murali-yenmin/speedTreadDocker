import { SetStateAction } from 'react';
import CheckIcon from './Images/CheckIcon';
import { ReactComponent as AddIcon } from '../assets/svg/AddIcon.svg';

interface OrderCompleteInterface {
  order: any;
  handleOpenModal: SetStateAction<any>;
  handleOpenConfirmModal: SetStateAction<any>;
}

function OrderComplete({
  order,
  handleOpenModal,
  handleOpenConfirmModal,
}: OrderCompleteInterface) {
  return (
    <>
      {order?.status !== 'completed' && order?.status !== 'error' ? (
        <div>
          <div className="flex justify-end mid-range-sm:mt-[18px] mid-range-sm:gap-2 mid-range-lg:mt-[18px] mid-range-lg:gap-2 mid-range:gap-2 mid-range:mt-[18px]">
            <button
              className={`flex justify-center bg-primary-blue rounded p-2 mr-2 hover:bg-royal-purple ${order?.status !== 'transferring' ? 'mr-2' : 'mr-0'} mid-range-sm:flex-1 mid-range-sm:mr-0 mid-range-lg:flex-1 mid-range-lg:mr-0 mid-range:flex-1 mid-range:mr-0`}
              onClick={handleOpenModal}
              title="Partial Pay"
            >
              <AddIcon />
            </button>
            <button
              className="flex justify-center bg-primary-blue rounded p-2 hover:bg-royal-purple mid-range-sm:flex-1 mid-range-lg:flex-1 mid-range:flex-1"
              onClick={handleOpenConfirmModal}
              title="Full Pay"
            >
              <CheckIcon />
            </button>
          </div>
        </div>
      ) : (
        <div></div>
      )}
    </>
  );
}

export default OrderComplete;
