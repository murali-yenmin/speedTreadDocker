import React from 'react';

const OrderListSkeleton: React.FC = () => {
  return (
    <div
      className="animate-pulse grid items-center w-full gap-[36px] p-4 border rounded-lg"
      style={{
        gridTemplateColumns: '127px 2fr 1fr 174px 1.5fr 1.5fr 1fr 0.5fr',
      }}
    >
      <div>
        <div className="h-5 bg-gray-300 rounded w-24 mb-2"></div>
        <div className="h-5 bg-gray-300 rounded-full w-24"></div>
      </div>
      <div>
        <div className="h-4 bg-gray-300 rounded w-20 mb-2"></div>
        <div className="h-5 bg-gray-300 rounded w-28"></div>
      </div>
      <div>
        <div className="h-4 bg-gray-300 rounded w-16 mb-2"></div>
        <div className="h-5 bg-gray-300 rounded w-20"></div>
      </div>
      <div className="border rounded-lg p-2 h-[50px] w-[174px] flex flex-col justify-center">
        <div className="h-4 bg-gray-300 rounded w-20 mb-2"></div>
        <div className="h-5 bg-gray-300 rounded w-28"></div>
      </div>
      <div> {/* Placeholder for Remarks */}
        <div className="h-4 bg-gray-300 rounded w-20 mb-2"></div>
        <div className="h-5 bg-gray-300 rounded w-28"></div>
      </div>
      <div>
        <div className="h-4 bg-gray-300 rounded w-20 mb-2"></div>
        <div className="h-5 bg-gray-300 rounded w-24"></div>
      </div>
      <div> {/* Placeholder for Status */}
        <div className="h-4 bg-gray-300 rounded w-20 mb-2"></div>
        <div className="h-5 bg-gray-300 rounded-full w-28"></div>
      </div>
      <div> {/* Placeholder for Buttons */}
        <div className="h-8 w-8 bg-gray-300 rounded-full"></div>
      </div> 
    </div>
  );
};

export default OrderListSkeleton;
