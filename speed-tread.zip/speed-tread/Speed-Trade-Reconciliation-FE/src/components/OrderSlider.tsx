import React, { useState, useMemo, useEffect, useCallback } from 'react';
import BackArrow from './Images/BackArrow';
import { DateRangeInput, defaultDateFormat } from './formFields/DateRangeInput';
import Dropdown from './formFields/Dropdown';
import OrderCard from './OrderCard';
import { Order } from '../interfaces/order';
import moment from 'moment';
import OrderListSkeleton from './OrderListSkeleton';
import {
  deleteMultipleOrdersThunk,
  getAllOrdersThunk,
  getOrderDateStatusThunk,
} from '../store/thunks/order';
import NoData from './NoData';
import { useForm } from 'react-hook-form';
import AddOrderModal from './Modal/AddOrderModal';
import CurrencyTabFilter from './CurrencyTabFilter';
import { useAppSelector, RootState, useAppDispatch } from '../store/store';
import { Role } from '../store/interfaces/roles';
import { getAllCurrenciesThunk } from '../store/thunks/settings';
import { getGroupBasedOrderCurrenciesThunk } from '../store/thunks/groupBasedOrderCurrencies';
import { getOrderSellCurrenciesThunk } from '../store/thunks/order/sellCurrencies';
import { TRANSFER_BY_DROPDOWN_ITEMS } from '../constants/dropdowns';
import OrderRecordCount from './OrderRecordCount';
import { OrderSliderProps } from '../interfaces/components';
import {
  formatAmount,
  formatAmountWithSuperscript,
} from '../utils/numberUtils';
import SliderHeaderLeftSkeleton from './SliderHeaderLeftSkeleton';
import SliderHeaderRightSkeleton from './SliderHeaderRightSkeleton';
import FavoriteIcon from './FavoriteIcon';
import { updateGroupThunk } from '../store/thunks/groups';
import CurrencyTabFilterSkeleton from './CurrencyTabFilterSkeleton';
import { updateFavoriteInOrderGroup } from '../store/slices/groups/orderGroupGetAllSlice';
import SmallButton from './SmallButton';
import ConfirmationModal from './Modal/ConfirmationModal';
import { CheckBoxInput } from './formFields/CheckBoxInput';
import CopyIcon from './Images/CopyIcon';
import { showSuccessToast } from '../utils/toast';
import { formatOrderId, toTitleCase } from '../utils/stringUtils';
import { AddButtonDotted } from './AddButtonDotted';
import { buildOrderString } from '../utils/copyorder';

const OrderSlider: React.FC<OrderSliderProps> = ({
  groupId,
  groupName,
  onClose,
  settlementCurrency,
  currency,
  group_uniqueId,
  onUpdate,
  is_favorite,
}) => {
  const dispatch = useAppDispatch();

  const currencyLoading = useAppSelector(
    (state) => state.groupBasedOrderCurrenciesReducer.loading,
  );

  const { data: ordersData, loading } = useAppSelector(
    (state: RootState) => state.getAllOrdersReducer,
  );
  const { data: availableDates } = useAppSelector(
    (state: RootState) => state.orderDateStatusReducer,
  );
  const [dateRange, setDateRange] = useState<{
    startDate: string;
    endDate: string;
  } | null>({
    startDate: moment().subtract(6, 'days').format(defaultDateFormat),
    endDate: moment().format(defaultDateFormat),
  });

  const [isLast7Days, setIsLast7Days] = useState(false);

  const { loading: deleteLoading } = useAppSelector(
    (state: RootState) => state.deleteAllOrdersSlice,
  );

  useEffect(() => {
    if (dateRange) {
      const today = moment().format(defaultDateFormat);
      const sixDaysAgo = moment().subtract(6, 'days').format(defaultDateFormat);
      if (dateRange.startDate === sixDaysAgo && dateRange.endDate === today) {
        setIsLast7Days(true);
      } else {
        setIsLast7Days(false);
      }
    }
  }, [dateRange]);

  const { control, watch, setValue } = useForm();
  const selectedTransferBy = watch('transferByDropdown');
  const selectedCurrencyFilter = watch('currencyDropdown');
  const selectedStatusFilter = watch('status');
  const [isAddOrderModalOpen, setIsAddOrderModalOpen] = useState(false);
  const [selectedCurrency, setSelectedCurrency] = useState(settlementCurrency);
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [oneTimeLoad, setOneTimeLoad] = useState(true);

  const [isSelectMode, setIsSelectMode] = useState(false);

  const [selectedOrders, setSelectedOrders] = useState<string[]>([]);
  const [selectedOrdersDetails, setSelectedOrdersDetails] = useState<Order[]>(
    [],
  );
  const [selectedDateForModal, setSelectedDateForModal] = useState<string>('');
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  const handleDeleteClick = () => {
    setIsDeleteModalOpen(true);
  };

  const handleDeleteClose = () => {
    setIsDeleteModalOpen(false);
  };

  const isAllSelected = useMemo(() => {
    const totalOrders =
      ordersData?.orders?.reduce(
        (acc, group) => acc + group.orders.length,
        0,
      ) || 0;
    return (
      !!ordersData?.orders &&
      totalOrders > 0 &&
      selectedOrders.length === totalOrders
    );
  }, [selectedOrders, ordersData]);

  const isIntermediate = useMemo(() => {
    const totalOrders =
      ordersData?.orders?.reduce(
        (acc, group) => acc + group.orders.length,
        0,
      ) || 0;
    return (
      !!ordersData?.orders &&
      selectedOrders.length > 0 &&
      selectedOrders.length < totalOrders
    );
  }, [selectedOrders, ordersData]);

  useEffect(() => {
    if (group_uniqueId && selectedCurrency && ordersData && ordersData.orders) {
      dispatch(
        getOrderDateStatusThunk({
          group_id: group_uniqueId,
          settlement_currency: selectedCurrency,
        }),
      );
    }
  }, [ordersData]);

  const handleOrderSelect = (order: Order) => {
    setSelectedOrders((prev) =>
      prev.includes(order.unique_id)
        ? prev.filter((id) => id !== order.unique_id)
        : [...prev, order.unique_id],
    );
    setSelectedOrdersDetails((prev) =>
      prev.some((o) => o.unique_id === order.unique_id)
        ? prev.filter((o) => o.unique_id !== order.unique_id)
        : [...prev, order],
    );
  };

  const handleSelectAll = () => {
    if (isAllSelected) {
      setSelectedOrders([]);
      setSelectedOrdersDetails([]);
    } else {
      const allOrderIds =
        ordersData?.orders?.flatMap((group) =>
          group.orders.map((o) => o.unique_id),
        ) || [];
      const allOrders =
        ordersData?.orders?.flatMap((group) => group.orders) || [];
      setSelectedOrders(allOrderIds);
      setSelectedOrdersDetails(allOrders);
    }
  };

  const handleCopySelected = () => {
    if (!selectedOrdersDetails?.length) return;

    const copyText = selectedOrdersDetails
      .map((o) => `${buildOrderString(o)}--------------------\n`)
      .join('');

    navigator.clipboard.writeText(copyText).then(() => {
      showSuccessToast('Selected order details copied to clipboard!');
    });
  };

  const handleDeleteSelected = () => {
    if (selectedOrders.length === 0) return;

    dispatch(
      deleteMultipleOrdersThunk({
        payload: { ids: selectedOrders },
        callbackAfterSuccess: () => {
          getOrders();
          if (onUpdate) {
            onUpdate();
          }
          setSelectedOrders([]);
          setSelectedOrdersDetails([]);
          setIsSelectMode(false);
          handleDeleteClose();
        },
      }),
    );
  };

  const handleCurrencyChange = (currency: string) => {
    if (selectedCurrency !== currency) {
      setIsInitialLoad(true);
      setSelectedCurrency(currency);
      setValue('transferByDropdown', '');
      setValue('currencyDropdown', '');
      setValue('status', '');
      setDateRange({
        startDate: moment().subtract(6, 'days').format(defaultDateFormat),
        endDate: moment().format(defaultDateFormat),
      }); // Reset date to today
      setSelectedOrders([]);
      setSelectedOrdersDetails([]);
    }
  };

  const onOrderUpdated = () => {
    getOrders();
    if (onUpdate) {
      onUpdate();
    }
  };

  const groupBasedOrderCurrencies = useAppSelector(
    (state: RootState) => state.groupBasedOrderCurrenciesReducer.data,
  );

  const orderSellCurrencies = useAppSelector(
    (state) => state.orderSellCurrenciesReducer.data,
  );

  const currencies = useAppSelector(
    (state: RootState) =>
      state.getAllCurrenciesReducer.data?.map(
        (item: { code: string }) => item.code,
      ) || [],
  );

  const getOrders = useCallback(() => {
    setSelectedOrders([]);
    setSelectedOrdersDetails([]);
    const query = [
      {
        fieldName: 'group_id',
        fieldString: group_uniqueId,
        operation: 'eq',
      },
      {
        fieldName: 'settlement_currency',
        fieldString: selectedCurrency,
        operation: 'eq',
      },
    ];

    if (selectedCurrencyFilter) {
      query.push({
        fieldName: 'currency',
        fieldString: selectedCurrencyFilter,
        operation: 'eq',
      });
    }

    if (selectedTransferBy) {
      query.push({
        fieldName: 'order_by',
        fieldString: selectedTransferBy,
        operation: 'eq',
      });
    }

    if (selectedStatusFilter && selectedStatusFilter !== 'all') {
      query.push({
        fieldName: 'status',
        fieldString: selectedStatusFilter,
        operation: 'eq',
      });
    }

    dispatch(
      getAllOrdersThunk({
        payload: {
          cp: 0,
          pl: 0, // Fetch all
          query: query,
          from_date: dateRange?.startDate,
          to_date: dateRange?.endDate,
        },
        callbackAfterSuccess: () => {
          setIsInitialLoad(false);
          setOneTimeLoad(false);
        },
      }),
    );
  }, [
    dispatch,
    group_uniqueId,
    dateRange,
    selectedTransferBy,
    selectedCurrency,
    selectedCurrencyFilter,
    selectedStatusFilter,
  ]);

  const handleFavoriteToggle = () => {
    const payload = {
      unique_id: group_uniqueId,
      is_favorite: !is_favorite,
    };
    // For OrderSlider, we use updateFavoriteInOrderGroup
    dispatch(updateFavoriteInOrderGroup(payload));
    dispatch(
      updateGroupThunk({
        payload: {
          unique_id: group_uniqueId,
          name: groupName,
          is_favorite: !is_favorite,
        },
        callbackAfterSuccess: () => {
          if (onUpdate) {
            onUpdate();
          }
        },
        callbackAfterFailure: () => {
          const payload = {
            unique_id: group_uniqueId,
            is_favorite: is_favorite,
          };
          dispatch(updateFavoriteInOrderGroup(payload));
        },
      }),
    );
  };

  const handleCopyOrder = (order: Order) => {
    navigator.clipboard.writeText(buildOrderString(order)).then(() => {
      showSuccessToast('Order details copied to clipboard!');
    });
  };

  useEffect(() => {
    dispatch(getGroupBasedOrderCurrenciesThunk(group_uniqueId));
    if (group_uniqueId && settlementCurrency) {
      dispatch(
        getOrderSellCurrenciesThunk({
          group_id: group_uniqueId,
          settlement_currency: settlementCurrency,
        }),
      );
    }
    dispatch(getAllCurrenciesThunk());
    // Set initial values for dropdowns to 'All'
    setValue('transferByDropdown', '');
    setValue('currencyDropdown', '');
    setValue('status', '');
  }, [dispatch, group_uniqueId, settlementCurrency, setValue]);

  useEffect(() => {
    getOrders();
  }, [getOrders, selectedCurrencyFilter]);

  return (
    <div className="h-full flex flex-col">
      <div className={`pl-6 border-b order-header-align-container`}>
        <div className="flex items-center justify-between order-header-align">
          {loading && oneTimeLoad ? (
            <SliderHeaderLeftSkeleton />
          ) : (
            <div className="flex items-center gap-4 order-header-first-section">
              <BackArrow onClick={onClose} />
              <div>
                <div className="text-sm text-gray-500 flex items-center gap-2">
                  {groupId}{' '}
                  <button onClick={handleFavoriteToggle}>
                    <FavoriteIcon
                      isFavorite={is_favorite || false}
                      width="w-[15px]"
                      hoverEffect
                    />
                  </button>
                </div>
                <h2 className="text-lg font-bold text-gray-800">{groupName}</h2>
              </div>
            </div>
          )}
          {loading && isInitialLoad ? (
            <SliderHeaderRightSkeleton />
          ) : (
            <div
              className={`min-w-[265px] w-auto h-[75px] sm:h-[95px] text-left pt-[10px] pb-[10px] pl-[25px] sm:pt-[20px] sm:pb-[20px] sm:pl-[35px] pr-[35px] owe-us-width ${
                ordersData?.overall_calculation?.status === 'owe_us'
                  ? 'bg-green-600 text-white'
                  : ordersData?.overall_calculation?.status === 'we_owe'
                    ? 'bg-red-600 text-white'
                    : 'bg-gray-100 text-gray-500'
              }`}
            >
              <div className="text-[17px] font-normal">
                {ordersData?.overall_calculation?.status === 'owe_us'
                  ? 'Owe Us'
                  : ordersData?.overall_calculation?.status === 'we_owe'
                    ? 'We Owe'
                    : 'All Clear'}
              </div>
              <div className="text-[20px] font-semibold">
                {ordersData?.overall_calculation?.status === 'all_clear' ? (
                  '-'
                ) : (
                  <>
                    {ordersData?.overall_calculation?.status === 'we_owe' &&
                      '('}
                    {ordersData?.overall_calculation?.currency}{' '}
                    {ordersData?.overall_calculation?.value
                      ? formatAmountWithSuperscript(
                          formatAmount(
                            Number(ordersData?.overall_calculation?.value),
                          ),
                        )
                      : '-'}
                    {ordersData?.overall_calculation?.status === 'we_owe' &&
                      ')'}
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
      <div className="overflow-y-auto">
        <div className="px-6 pt-5 md_lg:sticky top-0 z-20 bg-white">
          <div className="mb-6">
            {currencyLoading ? (
              <CurrencyTabFilterSkeleton />
            ) : (
              <CurrencyTabFilter
                currencies={groupBasedOrderCurrencies}
                selectedCurrency={selectedCurrency}
                onCurrencyChange={handleCurrencyChange}
              />
            )}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <DateRangeInput
              label=""
              id="dateRange"
              value={dateRange}
              onChange={(newDateRange) => {
                setDateRange(newDateRange);
              }}
              maxDate={new Date()}
              isRange={true}
              isLast7Days={isLast7Days}
              selectUptoDays={7}
              availableDates={availableDates}
            />
            <Dropdown
              label=""
              name="transferByDropdown"
              options={[
                { label: 'All Parties', value: '' },
                ...TRANSFER_BY_DROPDOWN_ITEMS,
              ]}
              placeholder="Transfer By"
              control={control}
            />
            <Dropdown
              label=""
              name="currencyDropdown"
              options={[
                { label: 'All Currencies', value: '' },
                ...orderSellCurrencies.map((c) => ({
                  label: c,
                  value: c,
                })),
              ]}
              placeholder="Currency"
              control={control}
            />
            <Dropdown
              label=""
              name="status"
              options={[
                { label: 'All Status', value: '' },
                ...(ordersData?.statuses?.map((c) => {
                  const labelText = c?.label || ''; // safely handle undefined
                  return {
                    label:
                      labelText.charAt(0).toUpperCase() + labelText.slice(1),
                    value: c?.label,
                    count: String(c?.value),
                  };
                }) || []),
              ]}
              placeholder="Status"
              control={control}
              customComp={true}
            />
          </div>
          {loading && isInitialLoad ? (
            <div className="flex items-center text-sm text-gray-500 mb-4 animate-pulse">
              <div className="flex-grow h-px bg-gray-300"></div>
              <div className="px-4 w-48 h-4 bg-gray-200 rounded"></div>
              <div className="flex-grow h-px bg-gray-300"></div>
            </div>
          ) : (
            <OrderRecordCount
              count={ordersData?.totalCount || 0}
              date={dateRange}
              transferBy={selectedTransferBy}
              currency={selectedCurrencyFilter}
              isLast7Days={isLast7Days}
            />
          )}
          <>
            {!ordersData?.orders?.length ||
            ordersData?.orders?.length === 0 ? null : (
              <div className="actions px-6 pl-0 mb-[10px]">
                {isSelectMode ? (
                  <div className="flex flex-wrap gap-4">
                    <SmallButton variant="secondary" onClick={handleSelectAll}>
                      <div className="flex items-center gap-2">
                        <CheckBoxInput
                          checked={isAllSelected}
                          indeterminate={isIntermediate}
                          onChange={handleSelectAll}
                        />
                        Select All
                      </div>
                    </SmallButton>
                    <SmallButton
                      onClick={handleCopySelected}
                      variant="primary"
                      disabled={selectedOrdersDetails.length === 0}
                    >
                      <div className="flex items-center gap-2">
                        <span className="icon">
                          <CopyIcon sm color="white" />
                        </span>
                        <span>Copy Selected</span>
                        <span className="count text-primary-blue text-[14px] font-normal w-[20px] h-[20px] rounded-[5px] bg-initialsBg flex items-center justify-center">
                          {selectedOrdersDetails.length}
                        </span>
                      </div>
                    </SmallButton>
                    <SmallButton
                      onClick={handleDeleteClick}
                      variant="secondary"
                      disabled={selectedOrders.length === 0}
                    >
                      Delete
                    </SmallButton>
                    <SmallButton
                      onClick={() => {
                        setIsSelectMode(false);
                        setSelectedOrders([]);
                        setSelectedOrdersDetails([]);
                      }}
                      variant="secondary"
                    >
                      Cancel
                    </SmallButton>
                  </div>
                ) : (
                  <SmallButton
                    onClick={() => setIsSelectMode(true)}
                    variant="secondary"
                  >
                    Select
                  </SmallButton>
                )}
              </div>
            )}
          </>
        </div>
        <div className={`mx-6`}>
          <div className={`flex-grow pb-[40px]`}>
            <div className="flex flex-col gap-[30px] ">
              {loading && isInitialLoad ? (
                Array.from({ length: 3 }).map((_, index) => (
                  <OrderListSkeleton key={index} />
                ))
              ) : ordersData?.orders?.length === 0 ? (
                <NoData />
              ) : (
                ordersData?.orders?.map((orderGroup) => (
                  <div key={orderGroup.date}>
                    <p className="mb-1 text-sm font-normal text-initialsText">
                      {orderGroup.date}
                    </p>
                    <div className="flex flex-col gap-4 h-full">
                      {orderGroup.orders.map((order: Order) => (
                        <OrderCard
                          key={order.unique_id}
                          order={order}
                          onOrderUpdated={onOrderUpdated}
                          isSelectMode={isSelectMode}
                          onSelect={() => handleOrderSelect(order)}
                          isSelected={selectedOrders.includes(order.unique_id)}
                          onCopyOrder={handleCopyOrder}
                        />
                      ))}
                      <AddButtonDotted
                        onClick={() => {
                          setSelectedDateForModal(orderGroup.date);
                          setIsAddOrderModalOpen(true);
                        }}
                        fullWidth
                        title="Add Order"
                      />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {isAddOrderModalOpen && (
        <AddOrderModal
          isOpen={isAddOrderModalOpen}
          onClose={() => setIsAddOrderModalOpen(false)}
          groupId={groupId}
          groupName={groupName}
          settlementCurrency={selectedCurrency}
          group_uniqueId={group_uniqueId}
          onOrderAdded={onOrderUpdated}
          selectedDate={selectedDateForModal}
        />
      )}
      <ConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={handleDeleteClose}
        onConfirm={handleDeleteSelected}
        title="Delete Order"
        message="Do you want to delete the selected orders?"
        confirmButtonText="Confirm"
        cancelButtonText="Cancel"
        isLoading={deleteLoading}
      />
    </div>
  );
};

export default OrderSlider;
