import React from 'react';
import { Search } from './formFields/Search';
import PrimaryButton from './formFields/PrimaryButton';
import FavoriteIcon from './FavoriteIcon';
import SelectDropdown from '../components/formFields/SelectDropdown';
import { DropdownOption } from '../interfaces/formfields';

interface PageHeaderProps {
  handleFavoriteButtonClick: () => void;
  isFavorite: boolean;
  searchTerm: string;
  setSearchTerm: (value: string) => void;
  onNewGroupClick: () => void;
  searchPlaceholder: string;
  newButtonText: string;
  onFilterChange: (filter: string) => void;
  currentFilter: string;
}

const PageHeader: React.FC<PageHeaderProps> = ({
  handleFavoriteButtonClick,
  isFavorite,
  searchTerm,
  setSearchTerm,
  onNewGroupClick,
  searchPlaceholder,
  newButtonText,
  onFilterChange,
  currentFilter,
}) => {
  const filterOptions: DropdownOption[] = [
    { value: 'show all', label: 'Show All' },
    { value: 'cus own', label: 'Cust Owe' },
    { value: 'owns us', label: 'We Owe' },
    { value: 'not tally', label: 'Not Tally' },
  ];

  const selectedOption = filterOptions.find(
    (option) => option.value === currentFilter,
  );

  return (
    <div className="flex flex-wrap items-center gap-4 page-header-width">
      <button
        className="flex items-center space-x-2 bg-tertiary-grey border border-gray-300 rounded-md px-4 py-2 text-sm font-medium text-gray-700"
        onClick={handleFavoriteButtonClick}
      >
        <span>Favorite</span>
        <FavoriteIcon isFavorite={isFavorite} />
      </button>
      <div className='max-w-[150px] h-[100%]'>
        <SelectDropdown
          className='w-[150px!important] h-[100%]'
          options={filterOptions}
          value={selectedOption || null}
          onChange={(selected) => {
            const selectedValue = (selected as DropdownOption)?.value;
            if (selectedValue) {
              onFilterChange(selectedValue as string);
            }
          }}
        />
      </div>
      <Search
        placeholder={searchPlaceholder}
        className="w-full sm:w-auto bg-tertiary-grey page-header page-header-input-width"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <PrimaryButton className="w-full sm:w-auto" onClick={onNewGroupClick}>
        {newButtonText}
      </PrimaryButton>
    </div>
  );
};

export default PageHeader;
