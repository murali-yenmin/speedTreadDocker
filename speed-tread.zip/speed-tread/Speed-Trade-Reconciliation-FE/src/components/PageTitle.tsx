import React from 'react';
import { Helmet } from 'react-helmet';
import { PageTitleProps } from '../interfaces/components';

const PageTitle: React.FC<PageTitleProps> = ({ title }) => {
  return (
    <Helmet>
      <title>{`${title} - Speed Trade`}</title>
    </Helmet>
  );
};

export default PageTitle;
