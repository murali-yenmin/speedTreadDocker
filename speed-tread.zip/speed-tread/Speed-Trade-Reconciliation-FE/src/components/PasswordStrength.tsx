import React, { useState, useEffect } from 'react';
import { ReactComponent as CheckIcon } from '../assets/svg/CheckIcon.svg';

interface PasswordStrengthProps {
  password?: string;
}

// ✅ Define allowed keys
type RequirementKey = 'length' | 'upperCase' | 'lowerCase' | 'numeric';

interface RequirementState {
  length: boolean;
  upperCase: boolean;
  lowerCase: boolean;
  numeric: boolean;
}

const PasswordStrength: React.FC<PasswordStrengthProps> = ({
  password = '',
}) => {
  const [requirements, setRequirements] = useState<RequirementState>({
    length: false,
    upperCase: false,
    lowerCase: false,
    numeric: false,
  });

  useEffect(() => {
    setRequirements({
      length: password.length >= 8,
      upperCase: /[A-Z]/.test(password),
      lowerCase: /[a-z]/.test(password),
      numeric: /[0-9]/.test(password),
    });
  }, [password]);

  // ✅ Keys are strongly typed now
  const requirementList: { key: RequirementKey; text: string }[] = [
    { key: 'length', text: '8 or more characters' },
    { key: 'lowerCase', text: 'Lowercase' },
    { key: 'upperCase', text: 'Uppercase' },
    { key: 'numeric', text: 'Numbers' },
  ];

  return (
    <div className="flex flex-wrap gap-2 mt-2">
      {requirementList.map((req) => (
        <div
          key={req.key}
          className={`flex items-center text-sm px-2 py-1 rounded-md border ${requirements[req.key] ? 'border-primary-blue text-primary-blue' : 'border-gray-300 text-gray-500'}`}
        >
          <CheckIcon
            className={`h-4 w-4 mr-2 ${requirements[req.key] ? 'text-primary-blue' : 'text-gray-300'}`}
          />
          {req.text}
        </div>
      ))}
    </div>
  );
};

export default PasswordStrength;
