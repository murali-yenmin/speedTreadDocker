import React, { useState, useRef, useLayoutEffect } from 'react';
import { createPortal } from 'react-dom';
import RemarkIcon from './Images/RemarkIcon';

interface RemarkProps {
  remarks: string;
}

const Remark: React.FC<RemarkProps> = ({ remarks }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [tooltipStyle, setTooltipStyle] = useState<React.CSSProperties>({
    opacity: 0,
    pointerEvents: 'none',
  });
  const [arrowStyle, setArrowStyle] = useState<React.CSSProperties>({});
  const [arrowVClass, setArrowVClass] = useState('border-t-gray-100 top-full');

  const iconRef = useRef<HTMLDivElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const timeoutRef = useRef<number | null>(null);

  const handleMouseEnter = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    timeoutRef.current = window.setTimeout(() => {
      setIsHovered(false);
    }, 100);
  };

  useLayoutEffect(() => {
    if (isHovered && iconRef.current && tooltipRef.current) {
      const iconRect = iconRef.current.getBoundingClientRect();
      const tooltipRect = tooltipRef.current.getBoundingClientRect();
      const { innerWidth: viewportWidth } = window;

      // Vertical position
      let top = iconRect.top - tooltipRect.height - 8;
      let newArrowVClass = 'border-t-8 border-t-gray-100 top-full';
      if (top < 8) {
        top = iconRect.bottom + 8;
        newArrowVClass = 'border-b-8 border-b-gray-100 bottom-full';
      }
      setArrowVClass(newArrowVClass);

      // Horizontal position
      let left = iconRect.left + iconRect.width / 2 - tooltipRect.width / 2;

      // Clamp tooltip within viewport
      if (left < 8) left = 8;
      else if (left + tooltipRect.width > viewportWidth - 8)
        left = viewportWidth - tooltipRect.width - 8;

      // Compute arrow’s horizontal center relative to tooltip
      const arrowLeft =
        iconRect.left +
        iconRect.width / 2 -
        left; // icon center relative to tooltip’s left edge

      setArrowStyle({
        left: `${arrowLeft}px`,
        transform: 'translateX(-50%)',
      });

      setTooltipStyle({
        position: 'fixed',
        top: `${top}px`,
        left: `${left}px`,
        opacity: 1,
        zIndex: 1000,
        pointerEvents: 'auto',
        transition: 'opacity 300ms',
      });
    } else {
      setTooltipStyle((prev) => ({
        ...prev,
        opacity: 0,
        pointerEvents: 'none',
      }));
    }
  }, [isHovered]);

  const tooltipContent = (
    <div
      ref={tooltipRef}
      style={tooltipStyle}
      className="w-64 bg-gray-100 text-gray-800 text-sm rounded-lg p-4 shadow-lg relative"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {remarks}
      <div
        className={`absolute w-0 h-0 border-x-8 border-x-transparent ${arrowVClass}`}
        style={arrowStyle}
      ></div>
    </div>
  );

  return (
    <div
      ref={iconRef}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className="cursor-pointer inline-flex items-center"
    >
      <RemarkIcon />
      {createPortal(tooltipContent, document.body)}
    </div>
  );
};

export default Remark;
