import React from 'react';
import BackArrow from '../Images/BackArrow';

interface FilterSliderProps {
  onClose: () => void;
  children: React.ReactNode;
  visible: boolean;
  footer?: React.ReactNode;
}

const FilterSlider: React.FC<FilterSliderProps> = ({
  onClose,
  children,
  visible,
  footer,
}) => {
  return (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity duration-300 ease-in-out ${visible ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
        onClick={onClose}
      />
      {/* Slider */}
      <div
        className={`fixed top-0 right-0 h-full w-full max-w-[320px] bg-white shadow-lg z-50 transform transition-transform duration-300 ease-in-out flex flex-col ${visible ? 'translate-x-0' : 'translate-x-full'
          }`}
      >
        <div className="p-4 border-b flex-shrink-0">
          <div className="flex items-center">
            <BackArrow onClick={onClose} />
            <h2 className="text-lg font-bold text-gray-800 ms-4">Filters</h2>
          </div>
        </div>
        <div className="p-4 flex-grow overflow-y-auto">{children}</div>
        {footer && <div className="p-4 border-t flex-shrink-0">{footer}</div>}
      </div>
    </>
  );
};

export default FilterSlider;