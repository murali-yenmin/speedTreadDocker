import React, { useState } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import moment from 'moment';
import {
  DateRangeInput,
  defaultDateFormat,
} from '../formFields/DateRangeInput';
import Input from '../formFields/Input';
import Dropdown from '../formFields/Dropdown';
import MultiSelect, { MultiSelectOption } from '../formFields/MultiSelect';
import StyledUl from '../common/StyledUl';
import StyledLi from '../common/StyledLi';
import useOutsideClick from '../../utils/outsideClick';
import { AccountName } from '../../store/interfaces/accountName';
import { Order } from '../../interfaces/order';
import { Control, UseFormSetValue } from 'react-hook-form/dist/types/form';
import useMediaQuery from '../../hooks/useMediaQuery';
import FilterSlider from './FilterSlider';
import FilterIcon from '../../assets/icons/FilterIcon';
import TagFilter from './TagFilter';
import Button from '../formFields/Button';
import { MultiValue, SingleValue } from 'react-select';
import { DropdownOption } from '../../interfaces/formfields';

interface ReportFiltersProps {
  date: { startDate: string; endDate: string | null };
  setDate: React.Dispatch<
    React.SetStateAction<{ startDate: string; endDate: string | null }>
  >;
  selectedGroups: MultiSelectOption[];
  setSelectedGroups: React.Dispatch<React.SetStateAction<MultiSelectOption[]>>;
  handleGroupNameChange: (value: string) => void;
  groupsLoading: boolean;
  account: AccountName | null;
  setAccount: React.Dispatch<React.SetStateAction<AccountName | null>>;
  showAccountNameDropdown: boolean;
  setShowAccountNameDropdown: React.Dispatch<React.SetStateAction<boolean>>;
  handleAccountNameChange: (value: string) => void;
  items: AccountName[];
  groupOptions: MultiSelectOption[];
  orderedByOptions: { label: string; value: string }[];
  selectedCurrencies: MultiSelectOption[];
  setSelectedCurrencies: React.Dispatch<
    React.SetStateAction<MultiSelectOption[]>
  >;
  handleCurrencyChange: (value: string) => void;
  currencies: MultiSelectOption[];
  currenciesLoading: boolean;
  orderStatus: { label: string; value: string }[];
  control: Control<any>;
  setValue: UseFormSetValue<any>;
  visible: boolean;
  showStatusFilter?: boolean;
  onChangeOrderBy?: (
    value: SingleValue<DropdownOption> | MultiValue<DropdownOption>,
  ) => void;
}

const ReportFilters: React.FC<ReportFiltersProps> = ({
  date,
  setDate,
  selectedGroups,
  setSelectedGroups,
  handleGroupNameChange,
  groupsLoading,
  account,
  setAccount,
  showAccountNameDropdown,
  setShowAccountNameDropdown,
  handleAccountNameChange,
  items,
  groupOptions,
  orderedByOptions,
  selectedCurrencies,
  setSelectedCurrencies,
  handleCurrencyChange,
  currencies,
  currenciesLoading = false,
  orderStatus,
  control,
  setValue,
  visible,
  showStatusFilter = true,
  onChangeOrderBy,
}) => {
  const accountNameRef = React.useRef<HTMLDivElement>(null);
  useOutsideClick(accountNameRef, () => setShowAccountNameDropdown(false));
  const isMobile = useMediaQuery('(max-width: 1260px)');
  const [isSliderOpen, setIsSliderOpen] = useState(false);

  // Watch values for initialization
  const orderedByValue = useWatch({ control, name: 'orderedBy' });
  const statusValue = useWatch({ control, name: 'status' });

  // Draft states for sidebar
  const [draftOrderedBy, setDraftOrderedBy] = useState('');
  const [draftStatus, setDraftStatus] = useState('');
  const [draftCurrencies, setDraftCurrencies] = useState<MultiSelectOption[]>(
    [],
  );

  // Sync drafts when slider opens
  React.useEffect(() => {
    if (isSliderOpen) {
      setDraftOrderedBy(orderedByValue || '');
      setDraftStatus(statusValue || '');
      setDraftCurrencies(selectedCurrencies);
    }
  }, [isSliderOpen, orderedByValue, statusValue, selectedCurrencies]);

  const handleApply = () => {
    setValue('orderedBy', draftOrderedBy);
    setValue('status', draftStatus);
    setSelectedCurrencies(draftCurrencies);
    setIsSliderOpen(false);
  };

  const handleCancel = () => {
    setIsSliderOpen(false);
  };

  const handleDraftCurrencyChange = (values: string[]) => {
    const newSelected = currencies.filter((c) => values.includes(c.value));
    setDraftCurrencies(newSelected);
  };

  const renderFilters = () => (
    <>
      <Dropdown
        name="orderedBy"
        placeholder="All Parties"
        control={control}
        label=""
        options={orderedByOptions}
        className="min-w-36"
        onChange={onChangeOrderBy}
      />
      <MultiSelect
        options={currencies}
        selected={selectedCurrencies}
        onChange={setSelectedCurrencies}
        onSearch={handleCurrencyChange}
        placeholder="All Currency"
        loading={currenciesLoading}
      />
      {showStatusFilter && (
        <div className="flex gap-4 md:gap-4 md:col-span-2 lg:gap-7 lg:col-span-1">
          <Dropdown
            name="status"
            placeholder="Status"
            control={control}
            label=""
            options={[{ label: 'All Status', value: '' }, ...orderStatus]}
            className="min-w-36"
          />
        </div>
      )}
    </>
  );

  return (
    <>
      <form autoComplete="off">
        <div
          className={`
            transition-all duration-500 ease-in-out
            ${
              visible
                ? 'opacity-100'
                : 'opacity-0 -translate-y-5 pointer-events-none h-2'
            }
            px-4
            pt-4
            mb-7
            grid
            grid-cols-1 gap-2
            sm:px-6
            md:px-12
            md:grid-cols-1 md:gap-4
            ${showStatusFilter ? 'mid-range-x:grid-cols-[1.5fr_1fr_1fr_1fr_1fr_1fr]' : 'mid-range-x:grid-cols-[1.5fr_1fr_1fr_1fr_1fr]'}
            lg:grid-cols-[1.5fr_1fr_1fr_60px] lg:gap-7                  
          `}
        >
          <DateRangeInput
            label=""
            id="reportsDateRange"
            value={date}
            onChange={(date) => setDate(date)}
            maxDate={new Date()}
            isRange={true}
            isQuickSelect={true}
            selectUptoDays={60}
          />
          <MultiSelect
            options={groupOptions}
            selected={selectedGroups}
            onChange={setSelectedGroups}
            onSearch={handleGroupNameChange}
            placeholder="All Group ID"
            loading={groupsLoading}
          />
          <div ref={accountNameRef} className="relative">
            <Input
              label=""
              searchIcon={true}
              name="accountName"
              control={control}
              placeholder="Account Name"
              onChange={handleAccountNameChange}
              onFocus={() => {
                setShowAccountNameDropdown(true);
              }}
              clearCb={() => setAccount(null)}
              maxLength={50}
            />
            {items && items?.length > 0 && showAccountNameDropdown && (
              <div className="absolute z-10 w-full pt-1">
                <StyledUl parentFocus={() => setShowAccountNameDropdown(true)}>
                  {items.map((item) => (
                    <StyledLi
                      key={item.unique_id}
                      selected={account?.unique_id === item.unique_id}
                      onClick={() => {
                        setValue('accountName', item.name);
                        setAccount(item);
                        setShowAccountNameDropdown(false);
                      }}
                    >
                      {item.name}
                    </StyledLi>
                  ))}
                </StyledUl>
              </div>
            )}
          </div>
          {isMobile ? (
            <div
              className="flex items-center gap-2 cursor-pointer justify-end mid-range-s:justify-start"
              onClick={() => setIsSliderOpen(true)}
            >
              <FilterIcon />
              <span>Filters</span>
            </div>
          ) : (
            renderFilters()
          )}
        </div>
      </form>
      {isMobile && (
        <FilterSlider
          visible={isSliderOpen}
          onClose={() => setIsSliderOpen(false)}
          footer={
            <div className="flex gap-4">
              <Button
                variant="secondary"
                onClick={handleCancel}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                onClick={handleApply}
                className="flex-1"
              >
                Apply
              </Button>
            </div>
          }
        >
          <div className="flex flex-col gap-6">
            <TagFilter
              label="Ordered By"
              options={orderedByOptions}
              selected={draftOrderedBy}
              onChange={setDraftOrderedBy}
            />
            <TagFilter
              label="Currency"
              options={currencies}
              selected={draftCurrencies.map((c) => c.value)}
              onChange={handleDraftCurrencyChange}
              isMulti={true}
            />
            {showStatusFilter && (
              <TagFilter
                label="Status"
                options={[{ label: 'All Status', value: '' }, ...orderStatus]}
                selected={draftStatus}
                onChange={setDraftStatus}
              />
            )}
          </div>
        </FilterSlider>
      )}
    </>
  );
};

export default ReportFilters;
