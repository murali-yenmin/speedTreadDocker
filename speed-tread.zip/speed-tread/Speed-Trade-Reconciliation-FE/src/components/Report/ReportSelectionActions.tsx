import React from 'react';
import SmallButton from '../SmallButton';
import { CheckBoxInput } from '../formFields/CheckBoxInput';
import CopyIcon from '../Images/CopyIcon';

interface ReportSelectionActionsProps {
  isSelectionModeActive: boolean;
  selectedOrderIdsSize: number;
  handleSelectAll: () => void;
  isAllSelected: boolean;
  isIntermediate: boolean;
  handleCopySelectedOrders: () => void;
  handleCancelSelectionMode: () => void;
  onToggleSelectionMode: () => void;
  hasOrdersInView: boolean;
}

const ReportSelectionActions: React.FC<ReportSelectionActionsProps> = ({
  isSelectionModeActive,
  selectedOrderIdsSize,
  handleSelectAll,
  isAllSelected,
  isIntermediate,
  handleCopySelectedOrders,
  handleCancelSelectionMode,
  onToggleSelectionMode,
  hasOrdersInView,
}) => {
  if (!hasOrdersInView) {
    return null;
  }

  return (
    <div className="actions px-4 sm:px-6 md:px-12 mb-[10px] ">
      {isSelectionModeActive ? (
        <div className="flex flex-wrap gap-4">
          <SmallButton variant="secondary" onClick={handleSelectAll}>
            <div className="flex items-center gap-2">
              <CheckBoxInput
                checked={isAllSelected}
                indeterminate={isIntermediate}
                onChange={handleSelectAll}
              />
              Select All
            </div>
          </SmallButton>
          <SmallButton
            onClick={handleCopySelectedOrders}
            variant="primary"
            disabled={selectedOrderIdsSize === 0}
          >
            <div className="flex items-center gap-2">
              <span className="icon">
                <CopyIcon sm color="white" />
              </span>
              <span>Copy Selected</span>
              <span className="count text-primary-blue text-[14px] font-normal w-[20px] h-[20px] rounded-[5px] bg-initialsBg flex items-center justify-center">
                {selectedOrderIdsSize}
              </span>
            </div>
          </SmallButton>
          <SmallButton
            onClick={handleCancelSelectionMode}
            variant="secondary"
          >
            Cancel
          </SmallButton>
        </div>
      ) : (
        <SmallButton
          onClick={onToggleSelectionMode}
          variant="secondary"
        >
          Select
        </SmallButton>
      )}
    </div>
  );
};

export default ReportSelectionActions;