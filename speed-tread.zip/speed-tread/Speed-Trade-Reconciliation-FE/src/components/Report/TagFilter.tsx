import React from 'react';

interface TagFilterOption {
    label: string;
    value: string;
}

interface TagFilterProps {
    options: TagFilterOption[];
    selected: string | string[];
    onChange: (value: any) => void;
    isMulti?: boolean;
    label?: string;
}

const TagFilter: React.FC<TagFilterProps> = ({
    options,
    selected,
    onChange,
    isMulti = false,
    label,
}) => {
    const handleSelect = (value: string) => {
        if (isMulti) {
            const currentSelected = Array.isArray(selected) ? selected : [];
            if (currentSelected.includes(value)) {
                onChange(currentSelected.filter((item) => item !== value));
            } else {
                onChange([...currentSelected, value]);
            }
        } else {
            onChange(value);
        }
    };

    const isSelected = (value: string) => {
        if (isMulti) {
            return Array.isArray(selected) && selected.includes(value);
        }
        return selected === value;
    };

    return (
        <div className="flex flex-col gap-2">
            {label && <label className="text-sm font-medium text-gray-700">{label}</label>}
            <div className="flex flex-wrap gap-2">
                {options.map((option) => (
                    <button
                        key={option.value}
                        type="button"
                        onClick={() => handleSelect(option.value)}
                        className={`
              px-3 py-2.5 rounded-full text-sm font-medium leading-none transition-colors duration-200 border inline-flex items-center justify-center
              ${isSelected(option.value)
                                ? 'bg-primary-blue text-white border-primary-blue'
                                : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
                            }
            `}
                    >
                        {option.label}
                    </button>
                ))}
            </div>
        </div>
    );
};

export default TagFilter;
