import React from 'react';
import ReportFilters from './ReportFilters';
import { MultiSelectOption } from '../formFields/MultiSelect';
import { AccountName } from '../../store/interfaces/accountName';
import { Control, UseFormSetValue } from 'react-hook-form';

interface TransactionReportFiltersProps {
  date: { startDate: string; endDate: string | null };
  setDate: React.Dispatch<
    React.SetStateAction<{ startDate: string; endDate: string | null }>
  >;
  selectedGroups: MultiSelectOption[];
  setSelectedGroups: React.Dispatch<React.SetStateAction<MultiSelectOption[]>>;
  handleGroupNameChange: (value: string) => void;
  groupsLoading: boolean;
  account: AccountName | null;
  setAccount: React.Dispatch<React.SetStateAction<AccountName | null>>;
  showAccountNameDropdown: boolean;
  setShowAccountNameDropdown: React.Dispatch<React.SetStateAction<boolean>>;
  handleAccountNameChange: (value: string) => void;
  items: AccountName[];
  groupOptions: MultiSelectOption[];
  orderedByOptions: { label: string; value: string }[];
  selectedCurrencies: MultiSelectOption[];
  setSelectedCurrencies: React.Dispatch<
    React.SetStateAction<MultiSelectOption[]>
  >;
  handleCurrencyChange: (value: string) => void;
  currencies: MultiSelectOption[];
  currenciesLoading: boolean;
  control: Control<any>;
  setValue: UseFormSetValue<any>;
  visible: boolean;
}

const TransactionReportFilters: React.FC<TransactionReportFiltersProps> = (
  props,
) => {
  return <ReportFilters {...props} orderStatus={[]} />;
};

export default TransactionReportFilters;
