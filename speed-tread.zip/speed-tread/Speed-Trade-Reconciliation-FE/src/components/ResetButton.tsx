import { useState } from 'react';
import ReloadIcon from '../assets/icons/ReloadIcon';
interface ResetButtonProps {
  parentClass?: string;
  disabled?: boolean;
  resetAll: () => void;
}
function ResetButton({ resetAll, disabled, parentClass }: ResetButtonProps) {
  const [isAnimating, setIsAnimating] = useState(false);
  const [rotation, setRotation] = useState(0);

  const handleClick = () => {
    if (isAnimating) return;

    setIsAnimating(true);
    setRotation((prev) => prev + 360);
    resetAll();
    setTimeout(() => {
      setIsAnimating(false);
    }, 1000); // Animation duration of 1 second
  };

  return (
    <div className={`flex justify-start align-middle min-h-9 ${parentClass}`}>
      <button
        title="Reset All"
        disabled={disabled || isAnimating}
        className={`px-2 rounded-md text-gray-700 align-middle flex items-center justify-center ${
          disabled || isAnimating
            ? 'cursor-not-allowed opacity-50'
            : 'cursor-pointer'
        }`}
        type="button" // Changed from 'reset' to 'button' to prevent default form behavior
        onClick={handleClick}
        style={{
          backgroundColor: '#E8EDF5',
          border: '1px solid #d1d5db',
        }}
      >
        <span
          className="inline-block transition-transform duration-1000"
          style={{ transform: `rotate(${rotation}deg) scaleX(-1)` }}
        >
          <ReloadIcon />
        </span>
      </button>
    </div>
  );
}

export default ResetButton;
