import React from 'react';

const SliderHeaderRightSkeleton: React.FC = () => {
  return (
    <div className="w-[265px] h-[95px] text-left pt-[20px] pb-[20px] pl-[35px] pr-[35px] bg-gray-200 owe-us-width animate-pulse">
      <div className="h-5 bg-gray-300 rounded w-1/2 mb-2"></div>
      <div className="h-6 bg-gray-300 rounded w-3/4"></div>
    </div>
  );
};

export default SliderHeaderRightSkeleton;
