import React from 'react';
import Loader from './Loader';

interface SmallButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  className?: string;
  isLoading?: boolean;
  variant?: 'primary' | 'secondary';
}

const SmallButton: React.FC<SmallButtonProps> = ({ children, className, isLoading = false, variant = 'secondary', ...props }) => {
  const baseStyles = "font-semibold text-base py-[6px] px-[20px] rounded-md transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed";

  const variants = {
    secondary:
      'text-rich-black bg-initialsBg hover:bg-gray-300',
    primary: 'bg-primary-blue text-primary-white hover:bg-royal-purple',
  };

  return (
    <button
      className={`${baseStyles} ${variants[variant]} ${className}`}
      disabled={isLoading || props.disabled}
      {...props}
    >
      {isLoading ? <Loader /> : children}
    </button>
  );
};

export default SmallButton;
