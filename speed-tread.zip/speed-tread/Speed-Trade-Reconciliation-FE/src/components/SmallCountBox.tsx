import React from 'react';
import TextTooltip from './TextTooltip';

interface SmallCountBoxProps {
  count: number;
  tooltipText?: string;
  transferring?: string;
  processing?: string;
  error?: string;
}

const SmallCountBox: React.FC<SmallCountBoxProps> = ({
  count,
  tooltipText,
  processing,
  transferring,
  error,
}) => {
  const content = (
    <div className="w-[17px] h-[17px] rounded-[5px] bg-bright-orange text-white text-[12px] font-semibold flex items-center justify-center">
      {count}
    </div>
  );

  // Default static multiline tooltip
  const staticTooltip = (
    <div>
      {Number(processing) > 0 && <div>{`Processing (${processing})`}</div>}

      {Number(transferring) > 0 && (
        <div>{`Transferring (${transferring})`}</div>
      )}
      {Number(error) > 0 && <div>{`Error (${error})`}</div>}
    </div>
  );

  if (count > 0) {
    return (
      <TextTooltip text="" customTextNode={staticTooltip} children={content} />
    );
  }

  return content;
};

export default SmallCountBox;
