import React from 'react';

const SocialMediaSourceListItemSkeleton: React.FC = () => {
  return (
    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg animate-pulse">
      <div className="h-4 bg-gray-300 rounded w-1/3"></div>
      <div className="h-8 w-14 bg-gray-300 rounded-full"></div>
    </div>
  );
};

export default SocialMediaSourceListItemSkeleton;
