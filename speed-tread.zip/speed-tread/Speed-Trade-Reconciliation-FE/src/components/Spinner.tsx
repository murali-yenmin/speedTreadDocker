import React from 'react';

const Spinner: React.FC = () => {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50 z-50">
      <div className='p-2 rounded-full bg-white '>
      <div
        className="w-8 h-8 border-4 border-primary-blue border-solid rounded-full animate-spin"
        style={{ borderTopColor: 'transparent' }}
      ></div>
      </div>
    </div>
  );
};

export default Spinner;
