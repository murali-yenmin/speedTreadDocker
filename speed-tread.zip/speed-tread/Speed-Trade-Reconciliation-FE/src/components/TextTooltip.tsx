import React, { useState, useRef, useLayoutEffect } from 'react';
import { createPortal } from 'react-dom';

interface TextTooltipProps {
  text: string;
  children: React.ReactNode;
  position?: 'left' | 'center' | 'right'; // new prop
  wrapperClassName?: string; 
  customTextNode?:React.ReactNode;
}

const TextTooltip: React.FC<TextTooltipProps> = ({ text, children, position = 'center', wrapperClassName,customTextNode }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [tooltipStyle, setTooltipStyle] = useState<React.CSSProperties>({
    opacity: 0,
    pointerEvents: 'none',
  });
  const [arrowHClass, setArrowHClass] = useState('left-1/2 -translate-x-1/2');
  const [arrowVClass, setArrowVClass] = useState('border-t-gray-100 top-full');

  const targetRef = useRef<HTMLDivElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const timeoutRef = useRef<number | null>(null);

  const handleMouseEnter = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    timeoutRef.current = window.setTimeout(() => {
      setIsHovered(false);
    }, 100);
  };

  useLayoutEffect(() => {
    if (isHovered && targetRef.current && tooltipRef.current) {
      const targetRect = targetRef.current.getBoundingClientRect();
      const tooltipRect = tooltipRef.current.getBoundingClientRect();
      const { innerWidth: viewportWidth } = window;

      // --- Vertical positioning ---
      let top = targetRect.top - tooltipRect.height - 8;
      let newArrowVClass = 'border-t-8 border-t-gray-100 top-full';
      if (top < 8) {
        top = targetRect.bottom + 8;
        newArrowVClass = 'border-b-8 border-b-gray-100 bottom-full';
      }
      setArrowVClass(newArrowVClass);

      // --- Horizontal positioning based on "position" prop ---
      let left: number;
      let newArrowHClass = '';

      if (position === 'left') {
        left = targetRect.left;
        newArrowHClass = 'left-4'; // arrow aligns near start
      } else if (position === 'right') {
        left = targetRect.right - tooltipRect.width;
        newArrowHClass = 'right-4'; // arrow aligns near end
      } else {
        // default center
        left = targetRect.left + targetRect.width / 2 - tooltipRect.width / 2;
        newArrowHClass = 'left-1/2 -translate-x-1/2';
      }

      // Prevent tooltip overflow (viewport bounds)
      if (left < 8) left = 8;
      if (left + tooltipRect.width > viewportWidth - 8)
        left = viewportWidth - tooltipRect.width - 8;

      setArrowHClass(newArrowHClass);

      setTooltipStyle({
        position: 'fixed',
        top: `${top}px`,
        left: `${left}px`,
        opacity: 1,
        zIndex: 1000,
        pointerEvents: 'auto',
        transition: 'opacity 300ms',
      });
    } else {
      setTooltipStyle((prev) => ({
        ...prev,
        opacity: 0,
        pointerEvents: 'none',
      }));
    }
  }, [isHovered, position]);

  const tooltipContent = (
    <div
      ref={tooltipRef}
      style={tooltipStyle}
      className="capitalize w-64 bg-gray-100 text-gray-800 text-sm rounded-lg p-4 shadow-lg"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {customTextNode ? customTextNode : text}
      <div
        className={`absolute w-0 h-0 border-x-8 border-x-transparent ${arrowVClass} ${arrowHClass}`}
      ></div>
    </div>
  );

  return (
    <div
      ref={targetRef}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className={`cursor-pointer inline-block ${wrapperClassName || ''}`}
    >
      {children}
      {createPortal(tooltipContent, document.body)}
    </div>
  );
};

export default TextTooltip;
