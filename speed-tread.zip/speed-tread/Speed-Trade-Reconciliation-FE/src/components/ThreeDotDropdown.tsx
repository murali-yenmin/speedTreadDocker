import React, { useState, useRef, useEffect, CSSProperties } from 'react';
import { createPortal } from 'react-dom';

export type Placement =
  | 'top'
  | 'bottom'
  | 'left'
  | 'right'
  | 'top-left'
  | 'top-right'
  | 'bottom-left'
  | 'bottom-right';

interface CustomPositionStyle extends CSSProperties {
  triangleLeft?: string;
  triangleRight?: string;
  triangleTop?: string;
  triangleBottom?: string;
  borderTop?: string;
  borderBottom?: string;
  borderLeft?: string;
  borderRight?: string;
}

interface DropdownItem {
  label: string;
  action: string;
  disabled?: boolean;
}

export interface ThreeDotDropdownProps {
  items: DropdownItem[];
  onAction: (action: string) => void;
  placement?: Placement;
}

// Mock the outsideClick hook - replace with your actual import
const useOutsideClick = (
  ref: React.RefObject<HTMLElement | null>,
  handler: () => void,
) => {
  useEffect(() => {
    const listener = (event: MouseEvent | TouchEvent) => {
      if (!ref.current || ref.current.contains(event.target as Node)) {
        return;
      }
      handler();
    };
    document.addEventListener('mousedown', listener);
    document.addEventListener('touchstart', listener);
    return () => {
      document.removeEventListener('mousedown', listener);
      document.removeEventListener('touchstart', listener);
    };
  }, [ref, handler]);
};

const ThreeDotDropdown: React.FC<ThreeDotDropdownProps> = ({
  items,
  onAction,
  placement = 'bottom-right',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const dropdownRef = useRef<HTMLDivElement | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const [positionStyle, setPositionStyle] = useState<CustomPositionStyle>({});
  const [finalPlacementValue, setFinalPlacementValue] = useState<
    Placement | undefined
  >(placement);

  useOutsideClick(dropdownRef, () => setIsOpen(false));

  // Update position on scroll
  useEffect(() => {
    if (!isOpen) return;

    const updatePosition = () => {
      if (buttonRef.current && menuRef.current) {
        const buttonRect = buttonRef.current.getBoundingClientRect();
        const menuRect = menuRef.current.getBoundingClientRect();
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;

        calculatePosition(buttonRect, menuRect, viewportWidth, viewportHeight);
      }
    };

    window.addEventListener('scroll', updatePosition, true);
    window.addEventListener('resize', updatePosition);

    return () => {
      window.removeEventListener('scroll', updatePosition, true);
      window.removeEventListener('resize', updatePosition);
    };
  }, [isOpen, placement]);

  // Auto-close dropdown when scrolling anywhere
  useEffect(() => {
    if (!isOpen) return;

    const handleScroll = (e: any) => {
      // Do NOT close if scrolling inside dropdown
      if (dropdownRef.current && dropdownRef.current.contains(e.target)) return;
      setIsOpen(false);
    };

    window.addEventListener("scroll", handleScroll, true);

    return () => {
      window.removeEventListener("scroll", handleScroll, true);
    };
  }, [isOpen]);


  const calculatePosition = (
    buttonRect: DOMRect,
    menuRect: DOMRect,
    viewportWidth: number,
    viewportHeight: number,
  ) => {
    let newStyle: CustomPositionStyle = {};

    // --- Placement logic if prop is given ---
    if (placement) {
      // Determine available space
      const spaceAbove = buttonRect.top;
      const spaceBelow = viewportHeight - buttonRect.bottom;
      const spaceLeft = buttonRect.left;
      const spaceRight = viewportWidth - buttonRect.right;

      let finalPlacement = placement;

      // Fallback for TOP/BOTTOM
      if (placement === 'bottom' && spaceBelow < menuRect.height + 10) {
        if (spaceAbove >= menuRect.height) finalPlacement = 'top';
      }

      if (placement === 'top' && spaceAbove < menuRect.height + 10) {
        if (spaceBelow >= menuRect.height) finalPlacement = 'bottom';
      }

      // Fallback for LEFT/RIGHT
      if (placement === 'left' && spaceLeft < menuRect.width + 10) {
        if (spaceRight >= menuRect.width) finalPlacement = 'right';
      }

      if (placement === 'right' && spaceRight < menuRect.width + 10) {
        if (spaceLeft >= menuRect.width) finalPlacement = 'left';
      }

      // Fallback for corner placements
      if (placement.includes('bottom') && spaceBelow < menuRect.height + 10) {
        if (spaceAbove >= menuRect.height) {
          finalPlacement = placement.replace('bottom', 'top') as Placement;
        }
      }

      if (placement.includes('top') && spaceAbove < menuRect.height + 10) {
        if (spaceBelow >= menuRect.height) {
          finalPlacement = placement.replace('top', 'bottom') as Placement;
        }
      }
      setFinalPlacementValue(finalPlacement);

      const baseGap = 8;
      const triangleOffset = 7;
      const topOffset = buttonRect.height + baseGap + triangleOffset;

      let top: number | string = 'auto',
        bottom: number | string = 'auto',
        left: number | string = 'auto',
        right: number | string = 'auto';
      let triangleLeft = 'auto',
        triangleRight = 'auto',
        triangleTop = 'auto',
        triangleBottom = 'auto';
      let borderTop = '8px solid transparent',
        borderBottom = '8px solid transparent',
        borderLeft = '8px solid transparent',
        borderRight = '8px solid transparent';

      switch (finalPlacement) {
        case 'bottom':
          top = buttonRect.bottom + baseGap + triangleOffset;
          left = buttonRect.left + buttonRect.width / 2 - menuRect.width / 2;
          triangleTop = `-${triangleOffset}px`;
          triangleLeft = 'calc(50% - 8px)';
          borderBottom = '8px solid white';
          break;

        case 'top':
          bottom = viewportHeight - buttonRect.top + baseGap + triangleOffset;
          left = buttonRect.left + buttonRect.width / 2 - menuRect.width / 2;
          triangleBottom = `-${triangleOffset}px`;
          triangleLeft = 'calc(50% - 8px)';
          borderTop = '8px solid white';
          break;

        case 'left':
          top = buttonRect.top + buttonRect.height / 2 - menuRect.height / 2;
          right = viewportWidth - buttonRect.left + baseGap + triangleOffset;
          triangleRight = `-${triangleOffset}px`;
          triangleTop = 'calc(50% - 8px)';
          borderLeft = '8px solid white';
          break;

        case 'right':
          top = buttonRect.top + buttonRect.height / 2 - menuRect.height / 2;
          left = buttonRect.right + baseGap + triangleOffset;
          triangleLeft = `-${triangleOffset}px`;
          triangleTop = 'calc(50% - 8px)';
          borderRight = '8px solid white';
          break;

        case 'bottom-right':
          top = buttonRect.bottom + baseGap + triangleOffset;
          left = buttonRect.right - menuRect.width + 10;
          triangleTop = `-${triangleOffset}px`;
          triangleRight = '16px';
          borderBottom = '8px solid white';
          break;

        case 'bottom-left':
          top = buttonRect.bottom + baseGap + triangleOffset;
          left = buttonRect.left - 10;
          triangleTop = `-${triangleOffset}px`;
          triangleLeft = '16px';
          borderBottom = '8px solid white';
          break;

        case 'top-right':
          bottom = viewportHeight - buttonRect.top + baseGap + triangleOffset;
          left = buttonRect.right - menuRect.width + 10;
          triangleBottom = `-${triangleOffset}px`;
          triangleRight = '16px';
          borderTop = '8px solid white';
          break;

        case 'top-left':
          bottom = viewportHeight - buttonRect.top + baseGap + triangleOffset;
          left = buttonRect.left - 10;
          triangleBottom = `-${triangleOffset}px`;
          triangleLeft = '16px';
          borderTop = '8px solid white';
          break;
      }

      newStyle = {
        position: 'absolute',
        top: typeof top === 'number' ? `${top}px` : top,
        bottom: typeof bottom === 'number' ? `${bottom}px` : bottom,
        left: typeof left === 'number' ? `${left}px` : left,
        right: typeof right === 'number' ? `${right}px` : right,
        triangleLeft,
        triangleRight,
        triangleTop,
        triangleBottom,
        borderTop,
        borderBottom,
        borderLeft,
        borderRight,
      };

      setPositionStyle(newStyle);
      return;
    }

    // --- Auto-positioning (default) ---
    let top: number | string = buttonRect.bottom + 15;
    let left: number | string = buttonRect.left - 10;
    let right: number | string = 'auto';
    let bottom: number | string = 'auto';

    let triangleLeft: string | undefined;
    let triangleRight: string | undefined;
    let triangleTop: string | undefined;
    let triangleBottom: string | undefined;
    let borderTop: string | undefined;
    let borderBottom: string | undefined;

    const spaceBelow = viewportHeight - buttonRect.bottom;
    const spaceAbove = buttonRect.top;

    if (spaceBelow >= menuRect.height || spaceBelow >= spaceAbove) {
      top = buttonRect.bottom + 15;
      bottom = 'auto';
      triangleTop = '-7px';
      borderBottom = '8px solid white';
    } else {
      bottom = viewportHeight - buttonRect.top + 15;
      top = 'auto';
      triangleBottom = '-7px';
      borderTop = '8px solid white';
    }

    const spaceRight = viewportWidth - buttonRect.left;
    const spaceLeft = buttonRect.right;

    if (spaceLeft >= menuRect.width || spaceLeft >= spaceRight) {
      right = viewportWidth - buttonRect.right - 10;
      left = 'auto';
    } else {
      left = buttonRect.left - 10;
      right = 'auto';
    }

    if (left === 'auto') {
      triangleRight = '16px';
    } else {
      triangleLeft = '16px';
    }

    setPositionStyle({
      position: 'absolute',
      top: typeof top === 'number' ? `${top}px` : top,
      left: typeof left === 'number' ? `${left}px` : left,
      right: typeof right === 'number' ? `${right}px` : right,
      bottom: typeof bottom === 'number' ? `${bottom}px` : bottom,
      triangleLeft,
      triangleRight,
      triangleTop,
      triangleBottom,
      borderTop,
      borderBottom,
    });
  };

  useEffect(() => {
    if (isOpen && buttonRef.current && menuRef.current) {
      const buttonRect = buttonRef.current.getBoundingClientRect();
      const menuRect = menuRef.current.getBoundingClientRect();
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;
      calculatePosition(buttonRect, menuRect, viewportWidth, viewportHeight);
    }
  }, [isOpen]);

  const dropdownMenu = isOpen && (
    <div
      ref={dropdownRef}
      className={`w-48 bg-white rounded-md z-[9999] m-0 ${finalPlacementValue ? '' : ' p-2 pb-0'}`}
      style={{
        ...positionStyle,
        boxShadow: '0px 0px 38px 3px rgba(0,0,0,0.1)',
      }}
    >
      <div
        className="absolute w-0 h-0"
        style={{
          left:
            finalPlacementValue === 'bottom-right' ||
              finalPlacementValue === 'top-right'
              ? undefined
              : positionStyle.triangleLeft,
          right:
            finalPlacementValue === 'bottom-right' ||
              finalPlacementValue === 'top-right'
              ? 10
              : positionStyle.triangleRight,
          top:
            finalPlacementValue === 'bottom-right'
              ? -24
              : finalPlacementValue && finalPlacementValue.startsWith('top')
                ? undefined
                : finalPlacementValue &&
                  finalPlacementValue.startsWith('bottom')
                  ? `-${7}px`
                  : positionStyle.triangleTop,
          bottom:
            finalPlacementValue && finalPlacementValue.startsWith('top')
              ? `-${24}px`
              : finalPlacementValue && finalPlacementValue.startsWith('bottom')
                ? undefined
                : positionStyle.triangleBottom,
          borderLeft: positionStyle.borderLeft || '8px solid transparent',
          borderRight: positionStyle.borderRight || '8px solid transparent',
          borderTop: positionStyle.borderTop,
          borderBottom: positionStyle.borderBottom,
        }}
      />
      <div ref={menuRef}>
        {items.map((item, index) => (
          <button
            key={index}
            disabled={item.disabled}
            onClick={(e) => {
              if (item.disabled) return;
              e.stopPropagation();
              onAction(item.action);
              setIsOpen(false);
            }}
            className={`block w-full text-left px-4 py-2 text-sm ${item.disabled
                ? 'text-gray-400 cursor-not-allowed'
                : 'text-gray-700 hover:bg-gray-100'
              }`}
          >
            {item.label}
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <>
      <button
        ref={buttonRef}
        type="button"
        className="p-1 rounded-full hover:bg-gray-100 focus:outline-none"
        onClick={(e) => {
          e.stopPropagation();
          setIsOpen(!isOpen);
        }}
        title="More Options"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth="1.5"
          stroke="currentColor"
          className="w-5 h-5 text-gray-500 rotate-90"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M6.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM12.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM18.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0z"
          />
        </svg>
      </button>
      {dropdownMenu && createPortal(dropdownMenu, document.body)}
    </>
  );
};

export default ThreeDotDropdown;
