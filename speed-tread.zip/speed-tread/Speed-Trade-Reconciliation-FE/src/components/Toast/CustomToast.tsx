import React from 'react';
import { ToastOptions } from 'react-toastify'; // Import ToastOptions for closeToast

interface CustomToastProps {
  type: 'success' | 'error' | 'warning' | 'info'; // Add 'info'
  message: string;
  title?: string; // Make title optional
  closeToast?: () => void; // Add closeToast prop
}

const CustomToast: React.FC<CustomToastProps> = ({
  type,
  message,
  title,
  closeToast,
}) => {
  let icon;
  let iconColorClass;
  let titleColorClass;

  switch (type) {
    case 'success':
      icon = (
        <svg
          className="w-6 h-6"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
          />
        </svg>
      );
      iconColorClass = 'text-green-500'; // Tailwind green
      titleColorClass = 'text-green-700'; // Darker green for title
      break;
    case 'error':
      icon = (
        <svg
          className="w-6 h-6"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"
          />
        </svg>
      );
      iconColorClass = 'text-red-500'; // Tailwind red
      titleColorClass = 'text-red-700'; // Darker red for title
      break;
    case 'warning':
      icon = (
        <svg
          className="w-6 h-6"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
          />
        </svg>
      );
      iconColorClass = 'text-orange-500'; // Tailwind orange
      titleColorClass = 'text-orange-700'; // Darker orange for title
      break;
    case 'info': // Add info case
      icon = (
        <svg
          className="w-6 h-6"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
          />
        </svg>
      );
      iconColorClass = 'text-blue-500'; // Tailwind blue for info
      titleColorClass = 'text-blue-700'; // Darker blue for info title
      break;
    default:
      icon = null;
      iconColorClass = '';
      titleColorClass = '';
  }

  return (
    <div className="message-section flex items-center p-4 bg-white rounded-lg shadow-lg max-w-xs relative">
      {' '}
      {/* Add relative for positioning close button */}
      <div className={`flex-shrink-0 ${iconColorClass}`}>{icon}</div>
      <div className="ml-3 flex-1">
        {title && (
          <p className={`text-sm font-medium ${titleColorClass}`}>{title}</p>
        )}
        <p className={`${title ? 'mt-1' : ''} text-sm text-gray-500`}>
          {message}
        </p>
      </div>
      {closeToast && (
        <button
          onClick={closeToast}
          className="absolute top-2 right-2 text-gray-400 hover:text-gray-600 focus:outline-none"
        >
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>
      )}
    </div>
  );
};

export default CustomToast;
