import React, { useState } from 'react';
import ThreeDotDropdown from './ThreeDotDropdown';
import { TRANSACTION_DETAIL_CARD_DROPDOWN_ITEMS } from '../constants/dropdowns';
import AddTransactionModal from './Modal/AddTransactionModal';
import AddOrderTransactionModal from './Modal/AddOrderTransactionModal';
import { Transaction } from '../store/interfaces/transaction';
import { formatOrderId, toTitleCase } from '../utils/stringUtils';
import {
  formatAmount,
  formatAmountWithSuperscript,
} from '../utils/numberUtils';
import Remark from './Remark';
import ConfirmationModal from './Modal/ConfirmationModal';
import { useAppDispatch, useAppSelector } from '../store/store';
import { deleteTransactionThunk } from '../store/thunks/transaction';
import { deleteOrderTransactionThunk } from '../store/thunks/order';
import { Order } from '../interfaces/order';
import TextTooltip from './TextTooltip';
import { Group } from '../store/interfaces/group';
import CopyIcon from './Images/CopyIcon';
import { showSuccessToast } from '../utils/toast';
import moment from 'moment';
import { defaultDateFormat } from './formFields/DateRangeInput';
import { handleCopyTransaction } from '../utils/copyorder';
import { CheckBoxInput } from './formFields/CheckBoxInput';

interface TransactionDetailCardProps {
  transaction: Transaction;
  settlementCurrency: string;
  context?: 'transactions' | 'orders';
  order_uniqueId?: string;
  group_uniqueId?: string;
  onOrderUpdated?: () => void;
  onUpdate?: () => void;
  cardStyle?: string;
  moreOptions?: boolean;
  selectedDate?: string;
  index?: number;
  self?: any[];
  sellCurrency?: string;
  order_by?: string;
  account_name?: string;
  order_trading?: string;
  showGroup?: boolean;
  group?: Group;
  showCopy?: boolean; // New prop for copy functionality
  rateLabel?: boolean;
  disableEdit?: boolean;
  orderRate?: number;
  isSelectMode?: boolean;
  onSelect?: (transaction: Transaction) => void;
  isSelected?: boolean;
}

const TransactionDetailCard: React.FC<TransactionDetailCardProps> = ({
  transaction,
  settlementCurrency,
  context = 'transactions',
  order_uniqueId,
  group_uniqueId,
  onOrderUpdated,
  onUpdate,
  cardStyle,
  moreOptions = true,
  selectedDate,
  index,
  self,
  sellCurrency,
  order_by = '',
  account_name,
  order_trading = '',
  showGroup = false,
  group,
  showCopy = false,
  rateLabel = true,
  disableEdit = false,
  orderRate,
  isSelectMode = false,
  onSelect,
  isSelected = false,
}) => {
  const dispatch = useAppDispatch();

  const deleteTransactionLoading = useAppSelector(
    (state) => state.deleteTransactionReducer.loading,
  );
  const deleteOrderTransactionLoading = useAppSelector(
    (state) => state.deleteOrderTransactionReducer.loading,
  );
  const isLoading = deleteTransactionLoading || deleteOrderTransactionLoading;

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteItem, setDeleteItem] = useState<
    null | Transaction | Order | any
  >(null);

  const handleEdit = () => {
    setIsModalOpen(true);
  };
  const handleDelete = () => {
    setIsDeleteModalOpen(true);
  };
  const handleDeleteClose = () => {
    setIsDeleteModalOpen(false);
    setDeleteItem(null);
  };
  const DeleteTransaction = async () => {
    if (deleteItem && deleteItem.order_id) {
      dispatch(
        deleteOrderTransactionThunk({
          payload: { id: deleteItem?.unique_id },
          callbackAfterSuccess: deleteSideEffect,
        }),
      );
      return;
    }

    if (deleteItem) {
      dispatch(
        deleteTransactionThunk({
          payload: { id: deleteItem?.unique_id },
          callbackAfterSuccess: deleteSideEffect,
        }),
      );
    }
  };

  const deleteSideEffect = () => {
    // commonly delete handle for both
    onOrderUpdated && onOrderUpdated();
    onUpdate && onUpdate();
    setDeleteItem(null);
    handleDeleteClose();
  };

  return (
    <>
      <div
        className={`rounded-[20px] p-4 border border-gray-200 flex flex-row w-full gap-4 ${cardStyle}`}
      >
        {isSelectMode && (
          <div className="flex items-center justify-center">
            <CheckBoxInput
              checked={isSelected}
              onChange={() => onSelect && onSelect(transaction)}
              indeterminate={false}
            />
          </div>
        )}
        <div className="flex flex-col lg_xl:flex-row relative w-full">
          <div
            className={`grid grid-cols-1 xs:grid-cols-2 lg_xl:w-full gap-[15px] ${
              showGroup
                ? 'lg_xl:grid-cols-[208px,208px,240px,170px,170px]'
                : 'lg_xl:grid-cols-[208px,240px,170px,170px]'
            }`}
          >
            {showGroup && (
              <div className="min-w-0">
                <p className="text-sm text-gray-500 whitespace-nowrap">
                  {group?.group_id}
                </p>
                <TextTooltip text={group?.name || ''}>
                  <p className="font-semibold break-words whitespace-nowrap overflow-hidden text-ellipsis max-w-100">
                    {group?.name}
                  </p>
                </TextTooltip>
              </div>
            )}
            <div className="">
              <div className="text-sm text-gray-500 whitespace-nowrap">
                {formatOrderId(transaction?.transaction_id)}
              </div>
              <div
                className={`w-[95px] h-[20px] flex items-center justify-center pb-[1px] text-white text-sm font-semibold rounded-full whitespace-nowrap mt-1 ${
                  transaction.transfer_by === 'we'
                    ? 'bg-strong-green'
                    : 'bg-strong-red'
                }`}
              >
                {transaction.transfer_by === 'we' ? 'We' : 'Cust'}{' '}
                {transaction.trading === 'sell'
                  ? 'SELL'
                  : transaction.trading === 'transfer'
                    ? 'TRF'
                    : transaction.trading === 'buy'
                      ? 'BUY'
                      : 'ADJ'}
              </div>
            </div>
            <div className="">
              <TextTooltip text={account_name || transaction?.account?.name || ''} wrapperClassName="w-full">
                <div className="text-sm text-gray-500 whitespace-nowrap text-ellipsis overflow-hidden transaction-card-tooltip">
                {account_name && account_name}
                {transaction?.account?.name}
              </div>
              </TextTooltip>
              
              <div
                className={`text-lg font-bold ${
                  transaction.transfer_by === 'we'
                    ? 'text-strong-green'
                    : 'text-strong-red'
                }`}
              >
                {transaction.transfer_by === 'we' ? 'Out' : '(In'}
                {' / '}
                {transaction.sell_currency}{' '}
                {formatAmountWithSuperscript(
                  formatAmount(Number(transaction.sell_value)),
                )}
                {transaction.transfer_by !== 'we' && ')'}
              </div>
            </div>
            {Number(transaction.rate) > 0 &&
              Number(transaction.calculated_amount) > 0 && (
                <div className={`block`}>
                  <>
                    <div
                      className={`text-sm text-gray-500 whitespace-nowrap ${rateLabel ? 'opacity-100' : 'opacity-0'}`}
                    >
                      Rate{' '}
                      {formatAmountWithSuperscript(
                        formatAmount(Number(transaction.rate), 3),
                      )}
                    </div>

                    {transaction.calculated_amount && (
                      <div className={`text-sm font-bold text-gray-800 'block`}>
                        {transaction.settlement_currency}{' '}
                        {formatAmountWithSuperscript(
                          formatAmount(Number(transaction.calculated_amount)),
                        )}
                      </div>
                    )}
                  </>
                </div>
              )}
            <div
              className={`${transaction.fee && Number(transaction.fee) > 0 ? 'block' : 'hidden'}`}
            >
              {transaction.fee && Number(transaction.fee) > 0 && (
                <>
                  <div className="text-sm text-gray-500 whitespace-nowrap">
                    Fee
                  </div>
                  <div className="text-sm font-bold text-gray-800">
                    {transaction.settlement_currency}{' '}
                    {formatAmountWithSuperscript(
                      formatAmount(Number(transaction?.fee)),
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
          <div className="w-full flex items-center justify-start gap-[8px] lg_xl:justify-end ">
            <div className="hidden lg_xl:flex items-center">
              {showCopy && (
                <button
                  className="flex justify-center mr-2"
                  title="Copy"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleCopyTransaction(transaction);
                  }}
                >
                  <CopyIcon />
                </button>
              )}
              {transaction.remarks && (
                <>
                  <Remark remarks={transaction.remarks} />
                </>
              )}
            </div>
            {transaction.remarks && (
              <div className="flex w-full lg_xl:hidden mt-2 ">
                <div className="lg_xl:hidden w-full pt-4 border-t border-gray-200">
                  <div className="text-sm text-gray-500 whitespace-nowrap mr-2">
                    Remarks
                  </div>
                  <p className="text-sm">{transaction.remarks}</p>
                </div>
              </div>
            )}
            <div
              className={`absolute lg_xl:relative top-[0px] lg_xl:top-auto bottom-auto right-[0px]`}
            >
              {moreOptions && (
                <ThreeDotDropdown
                  items={TRANSACTION_DETAIL_CARD_DROPDOWN_ITEMS}
                  onAction={(action) => {
                    if (action === 'edit') {
                      handleEdit();
                    } else if (action === 'delete') {
                      handleDelete();
                      setDeleteItem(transaction);
                    }
                  }}
                  placement={
                    index === (self?.length ?? 0) - 1
                      ? 'top-right'
                      : 'bottom-right'
                  }
                />
              )}
            </div>
          </div>
        </div>
      </div>
      {isModalOpen && context === 'transactions' && (
        <AddTransactionModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          transactionId={transaction?.unique_id}
          settlementCurrency={settlementCurrency}
          onSuccess={() => {
            if (onUpdate) {
              onUpdate();
            }
            setIsModalOpen(false);
          }}
          selectedDate={selectedDate}
        />
      )}
      {isModalOpen && context === 'orders' && (
        <AddOrderTransactionModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onSuccess={() => {
            setIsModalOpen(false);
            if (onOrderUpdated) {
              onOrderUpdated();
            }
          }}
          transactionId={transaction.unique_id}
          sellCurrency={sellCurrency}
          settlementCurrency={settlementCurrency}
          order_uniqueId={order_uniqueId || ''}
          group_uniqueId={group_uniqueId}
          order_by={order_by}
          trading={order_trading}
          rate={orderRate}
        />
      )}

      <ConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={handleDeleteClose}
        onConfirm={DeleteTransaction}
        title="Delete Transaction"
        message="Do you want to delete this transaction?"
        confirmButtonText="Confirm"
        cancelButtonText="Cancel"
        isLoading={isLoading}
      />
    </>
  );
};

export default TransactionDetailCard;
