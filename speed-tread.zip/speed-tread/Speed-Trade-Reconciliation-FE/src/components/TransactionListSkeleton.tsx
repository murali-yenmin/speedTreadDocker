import React from 'react';

const TransactionListSkeleton: React.FC = () => {
  return (
    <div className="animate-pulse rounded-[20px] p-4 border border-gray-200 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 items-center w-full gap-4">
      <div>
        <div className="h-4 bg-gray-300 rounded w-20 mb-2"></div>
        <div className="h-5 bg-gray-300 rounded-full w-24"></div>
      </div>
      <div>
        <div className="h-4 bg-gray-300 rounded w-24 mb-2"></div>
        <div className="h-6 bg-gray-300 rounded w-32"></div>
      </div>
      <div>
        <div className="h-4 bg-gray-300 rounded w-20 mb-2"></div>
        <div className="h-5 bg-gray-300 rounded w-28"></div>
      </div>
      <div>
        <div className="h-4 bg-gray-300 rounded w-16 mb-2"></div>
        <div className="h-5 bg-gray-300 rounded w-20"></div>
      </div>
      <div>
        <div className="h-4 bg-gray-300 rounded w-20 mb-2"></div>
        <div className="h-5 bg-gray-300 rounded w-24"></div>
      </div>
      <div className="flex items-center justify-end">
        <div className="h-6 w-6 bg-gray-300 rounded-full"></div>
      </div>
    </div>
  );
};

export default TransactionListSkeleton;
