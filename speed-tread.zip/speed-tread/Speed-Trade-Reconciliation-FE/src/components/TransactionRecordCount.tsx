import React from 'react';
import { capitalizeFirstLetter } from '../utils/stringUtils';
import {
  formatAmount,
  formatAmountWithSuperscript,
} from '../utils/numberUtils';

interface TransactionRecordCountProps {
  count: number;
  transferBy?: string;
  currency?: string;
  date?: string | { startDate: string; endDate: string | null } | null;
  loading?: boolean; // Add loading prop
  overall_calculated_amount?: number;
  settlement_currency?: string;
  isLast7Days?: boolean;
}

const TransactionRecordCount: React.FC<TransactionRecordCountProps> = ({
  count,
  transferBy,
  currency,
  date,
  loading, // Destructure loading prop
  overall_calculated_amount,
  settlement_currency,
  isLast7Days,
}) => {
  const generateMessage = () => {
    if (count === 0) {
      return null;
    }

    let dateString = '';
    if (isLast7Days) {
      dateString = 'past 7 days';
    } else if (date) {
      if (typeof date === 'string') {
        dateString = date;
      } else if (date.startDate && date.endDate) {
        if (date.startDate === date.endDate) {
          dateString = date.startDate;
        } else {
          dateString = `${date.startDate} ~ ${date.endDate}`;
        }
      }
    }

    if (dateString && transferBy && currency) {
      return (
        <>
          {capitalizeFirstLetter(transferBy)} made {count} {currency} transfer
          {count > 1 ? 's' : ''} worth {settlement_currency}{' '}
          {overall_calculated_amount &&
            overall_calculated_amount > 0 &&
            formatAmountWithSuperscript(
              formatAmount(overall_calculated_amount),
            )}{' '}
          on {dateString}
        </>
      );
    } else if (dateString && transferBy) {
      return `${capitalizeFirstLetter(transferBy)} made ${count} transfer${count > 1 ? 's' : ''} on ${dateString}.`;
    } else if (dateString && currency) {
      return `${count} ${currency} transfer${count > 1 ? 's' : ''} on ${dateString}.`;
    } else if (dateString) {
      return `${count} transaction records on ${dateString}.`;
    } else {
      return `${count} transaction records`;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center text-sm text-gray-500 mb-4 animate-pulse">
        <div className="flex-grow h-px bg-gray-300"></div>
        <div className="px-4">
          <div className="h-5 bg-gray-300 rounded w-48"></div>
        </div>
        <div className="flex-grow h-px bg-gray-300"></div>
      </div>
    );
  }

  return (
    <>
      {generateMessage() && (
        <div className="flex items-center text-sm text-gray-500 mb-4">
          <div className="flex-grow h-px bg-gray-300"></div>
          <div className="px-4">{generateMessage()}</div>
          <div className="flex-grow h-px bg-gray-300"></div>
        </div>
      )}
    </>
  );
};

export default TransactionRecordCount;
