import { Transaction } from '../store/interfaces/transaction';
import React, { useState, useCallback, useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import BackArrow from './Images/BackArrow';
import { DateRangeInput, defaultDateFormat } from './formFields/DateRangeInput';
import Dropdown from './formFields/Dropdown';
import TransactionDetailCard from './TransactionDetailCard';
import TransactionRecordCount from './TransactionRecordCount';
import AddTransactionModal from './Modal/AddTransactionModal';
import { useAppDispatch, useAppSelector, RootState } from '../store/store';
import { Role } from '../store/interfaces/roles';
import {
  getAllTransactionsThunk,
  amountOverviewThunk,
  deleteMultipleTransactionsThunk,
} from '../store/thunks/transaction';
import TransactionListSkeleton from './TransactionListSkeleton';
import moment from 'moment';
import { getGroupBasedCurrenciesThunk } from '../store/thunks/groupBasedCurrencies';
import { updateGroupThunk } from '../store/thunks/groups';
import { getTransactionSellCurrenciesThunk } from '../store/thunks/transaction/sellCurrencies';
import { TRANSFER_BY_DROPDOWN_ITEMS } from '../constants/dropdowns';
import NoData from './NoData';
import SliderHeaderLeftSkeleton from './SliderHeaderLeftSkeleton';
import SliderHeaderRightSkeleton from './SliderHeaderRightSkeleton';
import ExportModal from './Modal/ExportTransactionsModal';
import CurrencyTabFilter from './CurrencyTabFilter';
import {
  formatAmount,
  formatAmountWithSuperscript,
} from '../utils/numberUtils';
import FavoriteIcon from './FavoriteIcon';
import CurrencyTabFilterSkeleton from './CurrencyTabFilterSkeleton';
import { updateFavorite } from '../store/slices/groups/getAllGroupsSlice';
import { AddButtonDotted } from './AddButtonDotted';
import PrimaryButton from './formFields/PrimaryButton';
import Button from './formFields/Button';
import {
  fetchExportTransactions,
  clearExportTransactions,
} from '../store/slices/exportTransactionsSlice';
import SmallButton from './SmallButton';
import { CheckBoxInput } from './formFields/CheckBoxInput';
import CopyIcon from './Images/CopyIcon';
import ConfirmationModal from './Modal/ConfirmationModal';
import { showSuccessToast } from '../utils/toast';
import { buildTransactionString } from '../utils/copyorder';

interface TransactionSliderContentProps {
  groupId: string;
  groupName: string;
  settlementCurrency: string;
  group_uniqueId: string;
  onClose: () => void;
  onUpdate?: () => void;
  is_favorite?: boolean;
}

const TransactionSliderContent: React.FC<TransactionSliderContentProps> = ({
  groupId,
  groupName,
  onClose,
  settlementCurrency,
  group_uniqueId,
  onUpdate,
  is_favorite,
}) => {
  const dispatch = useAppDispatch();
  const userRoleId = useAppSelector(
    (state: RootState) => state.profileReducer.profileData?.role_id,
  );
  const roles = useAppSelector((state: RootState) => state.rolesReducer.roles);
  const currencyLoading = useAppSelector(
    (state) => state.groupBasedOrderCurrenciesReducer.loading,
  );

  const {
    exportTransactions,
    loading: exportLoading,
    error: exportError,
  } = useAppSelector((state) => state.exportTransactionsReducer);

  const currentUserRole = useMemo(() => {
    return roles.find((role: Role) => role.unique_id === userRoleId)?.role_type;
  }, [roles, userRoleId]);

  const fabSliderType: 'transaction' | 'order' | undefined = useMemo(() => {
    if (currentUserRole === 'transaction_manager') {
      return 'transaction';
    } else if (currentUserRole === 'order_manager') {
      return 'order';
    }
    return 'transaction'; // Default to 'transaction' for TransactionSliderContent
  }, [currentUserRole]);

  const { data: transactionsData, loading } = useAppSelector(
    (state) => state.getAllTransactionsReducer,
  );
  const groupBasedCurrencies = useAppSelector(
    (state) => state.groupBasedCurrenciesReducer.data,
  );
  const sellCurrencies = useAppSelector(
    (state) => state.sellCurrenciesReducer.data,
  );
  const overAllAmount = useAppSelector(
    (state) => state.amountOverviewReducer.data,
  );

  const [date, setDate] = useState<{
    startDate: string;
    endDate: string | null;
  }>({
    startDate: moment().subtract(6, 'days').format(defaultDateFormat),
    endDate: moment().format(defaultDateFormat),
  });

  const [isAddTransactionModalOpen, setIsAddTransactionModalOpen] =
    useState(false);
  const [currentCurrency, setCurrentCurrency] = useState(settlementCurrency);
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [oneTimeLoad, setOneTimeLoad] = useState(true);
  const [isLast7Days, setIsLast7Days] = useState(false);
  const [selectedDateForModal, setSelectedDateForModal] = useState<string>(
    date.startDate,
  );
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isSelectMode, setIsSelectMode] = useState(false);
  const [selectedTransactions, setSelectedTransactions] = useState<string[]>(
    [],
  );
  const [selectedTransactionsDetails, setSelectedTransactionsDetails] =
    useState<Transaction[]>([]);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  const { control, watch, setValue } = useForm();

  const { loading: deleteLoading } = useAppSelector(
    (state: RootState) => state.deleteMultipleTransactionsReducer,
  );

  const handleDeleteClick = () => {
    setIsDeleteModalOpen(true);
  };

  const handleDeleteClose = () => {
    setIsDeleteModalOpen(false);
  };

  const isAllSelected = useMemo(() => {
    const totalTransactions =
      transactionsData?.transactions?.reduce(
        (acc, group) => acc + group.transactions.length,
        0,
      ) || 0;
    return (
      !!transactionsData?.transactions &&
      totalTransactions > 0 &&
      selectedTransactions.length === totalTransactions
    );
  }, [selectedTransactions, transactionsData]);

  const isIntermediate = useMemo(() => {
    const totalTransactions =
      transactionsData?.transactions?.reduce(
        (acc, group) => acc + group.transactions.length,
        0,
      ) || 0;
    return (
      !!transactionsData?.transactions &&
      selectedTransactions.length > 0 &&
      selectedTransactions.length < totalTransactions
    );
  }, [selectedTransactions, transactionsData]);

  const handleTransactionSelect = (transaction: Transaction) => {
    setSelectedTransactions((prev) =>
      prev.includes(transaction.unique_id)
        ? prev.filter((id) => id !== transaction.unique_id)
        : [...prev, transaction.unique_id],
    );
    setSelectedTransactionsDetails((prev) =>
      prev.some((t) => t.unique_id === transaction.unique_id)
        ? prev.filter((t) => t.unique_id !== transaction.unique_id)
        : [...prev, transaction],
    );
  };

  const handleSelectAll = () => {
    if (isAllSelected) {
      setSelectedTransactions([]);
      setSelectedTransactionsDetails([]);
    } else {
      const allTransactionIds =
        transactionsData?.transactions?.flatMap((group) =>
          group.transactions.map((t) => t.unique_id),
        ) || [];
      const allTransactions =
        transactionsData?.transactions?.flatMap(
          (group) => group.transactions,
        ) || [];
      setSelectedTransactions(allTransactionIds);
      setSelectedTransactionsDetails(allTransactions);
    }
  };

  const handleCopySelected = () => {
    if (!selectedTransactionsDetails?.length) return;

    const copyText = selectedTransactionsDetails
      .map((t) => `${buildTransactionString(t)}--------------------\n`)
      .join('');

    navigator.clipboard.writeText(copyText).then(() => {
      showSuccessToast('Selected transaction details copied to clipboard!');
    });
  };

  const getamountOverviewThunk = () => {
    if (currentCurrency && group_uniqueId) {
      dispatch(
        amountOverviewThunk({
          payload: {
            currency: currentCurrency,
            group_id: group_uniqueId,
          },
        }),
      );
    }
  };

  const handleDeleteSelected = () => {
    if (selectedTransactions.length === 0) return;

    dispatch(
      deleteMultipleTransactionsThunk({
        payload: { ids: selectedTransactions },
        callbackAfterSuccess: () => {
          if (onUpdate) {
            onUpdate();
          }
          setSelectedTransactions([]);
          setSelectedTransactionsDetails([]);
          setIsSelectMode(false);
          handleDeleteClose();
          fetchAllTransactions();
          getamountOverviewThunk();
        },
      }),
    );
  };

  useEffect(() => {
    setValue('weDropdown', '');
    setValue('currencyDropdown', '');
  }, [setValue]);

  useEffect(() => {
    if (isExportModalOpen && group_uniqueId && currentCurrency) {
      dispatch(
        fetchExportTransactions({
          group_id: group_uniqueId,
          settlement_currency: currentCurrency,
        }),
      );
    }
  }, [isExportModalOpen, group_uniqueId, currentCurrency, dispatch]);

  const handleCurrencyChange = (currency: string) => {
    if (currentCurrency !== currency) {
      setIsInitialLoad(true);
      setCurrentCurrency(currency);
      setValue('weDropdown', '');
      setValue('currencyDropdown', '');
      setDate({
        startDate: moment().subtract(6, 'days').format(defaultDateFormat),
        endDate: moment().format(defaultDateFormat),
      }); // Reset date to today
    }
  };

  const selectedTransferBy = watch('weDropdown');
  const selectedCurrency = watch('currencyDropdown');

  const fetchAllTransactions = useCallback(() => {
    const query = [
      {
        operation: 'eq',
        fieldName: 'group_id',
        fieldString: group_uniqueId,
      },
    ];

    if (currentCurrency) {
      query.push({
        operation: 'eq',
        fieldName: 'settlement_currency',
        fieldString: currentCurrency,
      });
    }

    if (selectedCurrency) {
      query.push({
        operation: 'eq',
        fieldName: 'sell_currency',
        fieldString: selectedCurrency,
      });
    }

    if (selectedTransferBy) {
      query.push({
        operation: 'eq',
        fieldName: 'transfer_by',
        fieldString: selectedTransferBy,
      });
    }

    dispatch(
      getAllTransactionsThunk({
        payload: {
          cp: 0,
          pl: 0,
          query: query,
          from_date: date.startDate,
          to_date: date.endDate ?? undefined,
        },
        callbackAfterSuccess: () => {
          if (isInitialLoad) {
            setIsInitialLoad(false);
            setOneTimeLoad(false);
          }
        },
      }),
    );
  }, [
    dispatch,
    settlementCurrency,
    group_uniqueId,
    date,
    currentCurrency,
    selectedTransferBy,
    selectedCurrency,
  ]);

  const handleClose = () => {
    setIsAddTransactionModalOpen(false);
  };

  const handleAddOrUpdateTransactionSuccess = () => {
    fetchAllTransactions();
    dispatch(
      amountOverviewThunk({
        payload: {
          currency: currentCurrency,
          group_id: group_uniqueId,
        },
      }),
    );
    if (onUpdate) {
      onUpdate();
    }
    setIsAddTransactionModalOpen(false);
  };

  useEffect(() => {
    fetchAllTransactions();
  }, [fetchAllTransactions, selectedCurrency]);

  useEffect(() => {
    dispatch(getGroupBasedCurrenciesThunk(group_uniqueId));
    if (group_uniqueId && settlementCurrency) {
      dispatch(
        getTransactionSellCurrenciesThunk({
          group_id: group_uniqueId,
          settlement_currency: settlementCurrency,
        }),
      );
    }
  }, [dispatch, group_uniqueId, settlementCurrency]);

  useEffect(() => {
    getamountOverviewThunk();
  }, [dispatch, currentCurrency, group_uniqueId, date]);

  useEffect(() => {
    if (date) {
      const today = moment().format(defaultDateFormat);
      const sixDaysAgo = moment().subtract(6, 'days').format(defaultDateFormat);
      if (date.startDate === sixDaysAgo && date.endDate === today) {
        setIsLast7Days(true);
      } else {
        setIsLast7Days(false);
      }
    }
  }, [date]);

  const handleFavoriteToggle = () => {
    const payload = {
      unique_id: group_uniqueId,
      is_favorite: !is_favorite,
    };
    // Assuming 'transaction' sliderType for TransactionSliderContent
    dispatch(updateFavorite(payload));
    dispatch(
      updateGroupThunk({
        payload: {
          unique_id: group_uniqueId,
          name: groupName,
          is_favorite: !is_favorite,
        },
        callbackAfterSuccess: () => {
          if (onUpdate) {
            onUpdate();
          }
        },
        callbackAfterFailure: () => {
          const payload = {
            unique_id: group_uniqueId,
            is_favorite: is_favorite,
          };
          dispatch(updateFavorite(payload));
        },
      }),
    );
  };

  const handleExport = () => {
    setIsExportModalOpen(true);
  };

  const handleCloseExportModal = () => {
    setIsExportModalOpen(false);
    dispatch(clearExportTransactions());
  };

  return (
    <div className="h-full flex flex-col">
      <div className={`pl-6 border-b  order-header-align-container`}>
        <div className="flex items-center justify-between order-header-align">
          {loading && oneTimeLoad ? (
            <SliderHeaderLeftSkeleton />
          ) : (
            <div className="flex items-center gap-4 order-header-first-section">
              <BackArrow onClick={onClose} />
              <div>
                <div className="text-sm text-gray-500 flex items-center gap-2">
                  {groupId}{' '}
                  <button onClick={handleFavoriteToggle}>
                    <FavoriteIcon
                      isFavorite={is_favorite || false}
                      width="w-[15px]"
                      hoverEffect
                    />
                  </button>
                </div>
                <h2 className="text-lg font-bold text-gray-800">{groupName}</h2>
              </div>
            </div>
          )}
          {loading && isInitialLoad ? (
            <SliderHeaderRightSkeleton />
          ) : (
            <div
              className={`min-w-[265px] w-auto h-[95px] text-left pt-[20px] pb-[20px] pl-[35px] pr-[35px] owe-us-width ${
                overAllAmount?.status === 'owe_us'
                  ? 'bg-green-600 text-white'
                  : overAllAmount?.status === 'we_owe'
                    ? 'bg-red-600 text-white'
                    : 'bg-gray-100 text-gray-500'
              }`}
            >
              <div className="text-[17px] font-normal">
                {overAllAmount?.status === 'owe_us'
                  ? 'Owe Us'
                  : overAllAmount?.status === 'we_owe'
                    ? 'We Owe'
                    : 'All Clear'}
              </div>
              <div className="text-[20px] font-semibold">
                {overAllAmount?.status === 'all_clear' ? (
                  '-'
                ) : (
                  <>
                    {overAllAmount?.status === 'we_owe' && '('}
                    {overAllAmount?.currency}{' '}
                    {overAllAmount?.value &&
                      formatAmountWithSuperscript(
                        formatAmount(Number(overAllAmount?.value)),
                      )}
                    {overAllAmount?.status === 'we_owe' && ')'}
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="px-6 pt-5">
        <div className="mb-6 flex justify-between">
          {currencyLoading ? (
            <CurrencyTabFilterSkeleton />
          ) : (
            <CurrencyTabFilter
              currencies={groupBasedCurrencies}
              selectedCurrency={currentCurrency}
              onCurrencyChange={handleCurrencyChange}
            />
          )}
          <Button
            type="button"
            variant="primary"
            fullWidth={false}
            className="h-11 min-w-[89px]"
            onClick={handleExport}
          >
            Closing Statement
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <DateRangeInput
            label=""
            id="dateRange"
            isRange={true}
            value={date}
            onChange={(newDate) => {
              setDate(newDate);
            }}
            maxDate={new Date()}
            selectUptoDays={7}
            isLast7Days={isLast7Days}
          />
          <Dropdown
            label=""
            name="weDropdown"
            options={[
              { label: 'All Parties', value: '' },
              ...TRANSFER_BY_DROPDOWN_ITEMS,
            ]}
            placeholder="Transfer By"
            control={control}
          />
          <Dropdown
            label=""
            name="currencyDropdown"
            options={[
              { label: 'All Currencies', value: '' },
              ...sellCurrencies.map((c) => ({ label: c, value: c })),
            ]}
            placeholder="Currency"
            control={control}
          />
        </div>
        {transactionsData?.total_count > 0 && (
          <TransactionRecordCount
            count={transactionsData?.total_count || 0}
            date={date}
            transferBy={selectedTransferBy}
            currency={selectedCurrency}
            overall_calculated_amount={
              transactionsData?.overall_calculated_amount
            }
            settlement_currency={currentCurrency}
            loading={loading && isInitialLoad}
            isLast7Days={isLast7Days}
          />
        )}
      </div>

      {!transactionsData?.transactions?.length ||
      transactionsData?.transactions?.length === 0 ? null : (
        <div className="actions px-6 mb-[10px]">
          {isSelectMode ? (
            <div className="flex flex-wrap gap-4">
              <SmallButton variant="secondary" onClick={handleSelectAll}>
                <div className="flex items-center gap-2">
                  <CheckBoxInput
                    checked={isAllSelected}
                    indeterminate={isIntermediate}
                    onChange={handleSelectAll}
                  />
                  Select All
                </div>
              </SmallButton>
              {/* <SmallButton
                onClick={handleCopySelected}
                variant="primary"
                disabled={selectedTransactionsDetails.length === 0}
              >
                <div className="flex items-center gap-2">
                  <span className="icon">
                    <CopyIcon sm color="white" />
                  </span>
                  <span>Copy Selected</span>
                  <span className="count text-primary-blue text-[14px] font-normal w-[20px] h-[20px] rounded-[5px] bg-initialsBg flex items-center justify-center">
                    {selectedTransactionsDetails.length}
                  </span>
                </div>
              </SmallButton> */}
              <SmallButton
                onClick={handleDeleteClick}
                variant="secondary"
                disabled={selectedTransactions.length === 0}
              >
                Delete
              </SmallButton>
              <SmallButton
                onClick={() => {
                  setIsSelectMode(false);
                  setSelectedTransactions([]);
                  setSelectedTransactionsDetails([]);
                }}
                variant="secondary"
              >
                Cancel
              </SmallButton>
            </div>
          ) : (
            <SmallButton
              onClick={() => setIsSelectMode(true)}
              variant="secondary"
            >
              Select
            </SmallButton>
          )}
        </div>
      )}

      <div className="flex-grow overflow-y-auto px-6 pb-6">
        <div className="flex flex-col gap-4 h-full overflow-x-hidden">
          {loading && isInitialLoad ? (
            Array.from({ length: 3 }).map((_, index) => (
              <TransactionListSkeleton key={index} />
            ))
          ) : transactionsData?.transactions?.length === 0 ? (
            <NoData message="No Transactions Found" />
          ) : (
            transactionsData?.transactions?.map((transactionGroup) => (
              <div key={transactionGroup.date}>
                <p className="mb-1 text-sm font-normal text-initialsText">
                  {transactionGroup.date}
                </p>
                <div className="flex flex-col gap-4 h-full">
                  {transactionGroup.transactions.map(
                    (transaction: Transaction) => (
                      <TransactionDetailCard
                        key={transaction.unique_id}
                        transaction={transaction}
                        settlementCurrency={currentCurrency}
                        context="transactions"
                        onUpdate={handleAddOrUpdateTransactionSuccess}
                        cardStyle="bg-gray-50"
                        selectedDate={transactionGroup.date}
                        isSelectMode={isSelectMode}
                        onSelect={() => handleTransactionSelect(transaction)}
                        isSelected={selectedTransactions.includes(
                          transaction.unique_id,
                        )}
                      />
                    ),
                  )}
                  <AddButtonDotted
                    onClick={() => {
                      setSelectedDateForModal(transactionGroup.date);
                      setIsAddTransactionModalOpen(true);
                    }}
                    fullWidth
                    title="Add Transaction"
                  />
                </div>
              </div>
            ))
          )}
        </div>
      </div>
      {isAddTransactionModalOpen && (
        <AddTransactionModal
          isOpen={isAddTransactionModalOpen}
          onClose={handleClose}
          onSuccess={handleAddOrUpdateTransactionSuccess}
          id={groupId}
          name={groupName}
          group_uniqueId={group_uniqueId}
          settlementCurrency={currentCurrency}
          selectedDate={selectedDateForModal}
        />
      )}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={handleCloseExportModal}
        transactions={
          exportTransactions || {
            summary_till_yesterday: {
              status: 'all_clear',
              value: 0,
              currency: '',
              overall_calculated_amount: 0,
            },
            transactions: [],
            summary_today: {
              status: 'all_clear',
              value: 0,
              currency: '',
              overall_calculated_amount: 0,
            },
          }
        }
        groupName={groupName}
        overAllAmount={overAllAmount}
        groupId={groupId}
        loading={exportLoading}
      />
      <ConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={handleDeleteClose}
        onConfirm={handleDeleteSelected}
        title="Delete Transaction"
        message="Do you want to delete the selected transactions?"
        confirmButtonText="Confirm"
        cancelButtonText="Cancel"
        isLoading={Boolean(deleteLoading)}
      />
    </div>
  );
};

export default TransactionSliderContent;
