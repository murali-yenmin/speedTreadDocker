import React from 'react';

interface WarningMessageProps {
  visible: boolean;
  message: string;
  onClose?: () => void;
}

const WarningMessage: React.FC<WarningMessageProps> = ({
  visible,
  message,
  onClose,
}) => {
  return (
    <div
      className={`transition-all duration-500 ease-in-out ${
        visible
          ? 'opacity-100 translate-y-0 max-h-20 mt-2'
          : 'opacity-0 -translate-y-2 max-h-0 mt-0'
      } overflow-hidden`}
    >
      <p className="bg-yellow-100 py-2 px-2 border border-yellow-300 rounded-md text-center text-sm">
        {message}
        {/* <span
          className="cursor-pointer text-black ml-2 font-semibold"
          onClick={onClose}
        >
          ✕
        </span> */}
      </p>
    </div>
  );
};

export default WarningMessage;
