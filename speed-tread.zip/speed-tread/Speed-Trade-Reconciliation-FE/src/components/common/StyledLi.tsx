import React from 'react';

interface StyledLiProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  selected?: boolean;
}

const StyledLi: React.FC<StyledLiProps> = ({ children, className, onClick, selected }) => {
  const selectedClasses = selected ? 'bg-primary-blue text-white' : '';
  return (
    <li
      className={`px-4 py-2 hover:bg-royal-purple hover:text-white focus:bg-secondary-blue focus:text-white cursor-pointer ${selectedClasses} ${className}`}
      onClick={onClick}
    >
      {children}
    </li>
  );
};

export default StyledLi;
