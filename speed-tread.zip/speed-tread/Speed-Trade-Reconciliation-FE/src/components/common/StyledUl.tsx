import React from 'react';

interface StyledUlProps {
  children: React.ReactNode;
  className?: string;
  parentFocus?: () => void;
}

const StyledUl: React.FC<StyledUlProps> = ({
  children,
  className,
  parentFocus,
}) => {
  return (
    <ul
      className={`w-full border border-gray-300 rounded-lg max-h-[125px] bg-white overflow-y-auto ${className}`}
      onFocus={parentFocus}
    >
      {children}
    </ul>
  );
};

export default StyledUl;
