import React, { useRef } from 'react';
import { Controller, FieldValues, UseControllerProps } from 'react-hook-form';
import ErrorMessage from './ErrorMessage';

interface AmountInputProps<T extends FieldValues = FieldValues>
  extends UseControllerProps<T> {
  placeholder: string;
  decimalPlaces: number;
  maxDigits?: number;
  disabled?: boolean;
  label?: string;
  className?: string;
  prefix?: React.ReactNode;
  onBlurCb?: () => void;
}

const formatAmountForDisplay = (
  value: string | number | null | undefined,
): string => {
  if (value === null || value === undefined || String(value).trim() === '')
    return '';

  const stringValue = String(value);
  const [integerPart, decimalPart] = stringValue.split('.');

  const formattedInteger = integerPart
    .replace(/,/g, '')
    .replace(/\B(?=(\d{3})+(?!\d))/g, ',');

  if (decimalPart !== undefined) {
    return `${formattedInteger}.${decimalPart}`;
  }

  if (stringValue.endsWith('.')) {
    return `${formattedInteger}.`;
  }

  return formattedInteger;
};

const formatOnBlur = (
  value: string | number | null | undefined,
  decimalPlaces: number,
): string => {
  if (value === null || value === undefined || String(value).trim() === '')
    return '';
  const num = parseFloat(String(value).replace(/,/g, ''));
  if (isNaN(num)) return '';
  return num.toFixed(decimalPlaces);
};

const AmountInput = <T extends FieldValues = FieldValues>({
  control,
  name,
  placeholder,
  decimalPlaces,
  maxDigits,
  disabled,
  label,
  className,
  prefix,
  onBlurCb,
}: AmountInputProps<T>) => {
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState }) => {
        const handleOnChange = (e: React.ChangeEvent<HTMLInputElement>) => {
          const { value: currentValue, selectionStart } = e.target;

          // Find the number of commas in the value before the cursor
          const commasBeforeCursor = (
            currentValue.substring(0, selectionStart ?? 0).match(/,/g) || []
          ).length;

          // Sanitize input to get the raw value for the form state
          let rawValue = currentValue.replace(/,/g, '');
          if (decimalPlaces > 0) {
            rawValue = rawValue.replace(/[^0-9.]/g, '');
          } else {
            rawValue = rawValue.replace(/[^0-9]/g, '');
          }

          // Enforce maxIntegerDigits limit
          if (maxDigits && maxDigits > 0) {
            const parts = rawValue.split('.');
            let integerPart = parts[0];
            const decimalPart = parts[1];

            if (integerPart.length > maxDigits) {
              integerPart = integerPart.substring(0, maxDigits);
              rawValue =
                decimalPart !== undefined
                  ? `${integerPart}.${decimalPart}`
                  : integerPart;
            }
          }

          const dotIndex = rawValue.indexOf('.');
          if (dotIndex !== -1) {
            if (rawValue.substring(dotIndex + 1).indexOf('.') !== -1) {
              rawValue = rawValue.slice(0, rawValue.lastIndexOf('.'));
            }
            if (rawValue.length - dotIndex > decimalPlaces + 1) {
              rawValue = rawValue.substring(0, dotIndex + decimalPlaces + 1);
            }
          }

          // Update the form state. This will trigger a re-render.
          field.onChange(rawValue);

          // Defer the cursor position update until after the re-render
          requestAnimationFrame(() => {
            if (inputRef.current) {
              const newDisplayValue = formatAmountForDisplay(rawValue);

              // If the input was rejected (e.g., max length reached), the DOM value
              // can be out of sync with our state. Forcefully update it.
              inputRef.current.value = newDisplayValue;

              // The raw position of the cursor is its original position minus the commas
              const rawCursorPosition =
                (selectionStart ?? 0) - commasBeforeCursor;

              // Calculate how many commas are in the new formatted value up to the raw cursor position
              let newCommasBeforeCursor = 0;
              let newCursorPosition = 0;
              let rawCharsCounted = 0;

              for (const char of newDisplayValue) {
                if (rawCharsCounted >= rawCursorPosition) break;
                newCursorPosition++;
                if (char !== ',') {
                  rawCharsCounted++;
                }
              }

              // If the cursor was at the end, ensure it stays at the end
              if (rawCursorPosition > rawValue.length) {
                newCursorPosition = newDisplayValue.length;
              }

              inputRef.current.setSelectionRange(
                newCursorPosition,
                newCursorPosition,
              );
            }
          });
        };

        const handleOnBlur = () => {
          field.onBlur();
          const currentValue = field.value;
          if (currentValue && !isNaN(parseFloat(currentValue))) {
            const formatted = formatOnBlur(currentValue, decimalPlaces);
            field.onChange(formatted);
          } else {
            // Clear if the value is invalid on blur
            field.onChange('');
          }
          onBlurCb && onBlurCb();
        };

        // The value shown in the input is always the formatted version of the raw form value
        const displayValue = formatAmountForDisplay(field.value);

        return (
          <div>
            {label && (
              <label
                htmlFor={name}
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                {label}
              </label>
            )}
            <div className="relative w-full flex items-center w-100">
              {prefix && (
                <div className='inline-block'>
                <div
                  className={`flex items-center bg-light-bluish-gray border border-r-0 rounded-l-md px-3 py-[6px] ${
                    fieldState.error
                      ? 'border-red-500 border-t border-b border-l'
                      : 'border-gray-300'
                  }`}
                >
                  <p className="text-steel-blue">{prefix}</p>
                </div></div>
              )}
             <div className='inline-block flex-1'>
               <input
                {...field}
                ref={(input) => {
                  field.ref(input);
                  // @ts-ignore
                  inputRef.current = input;
                }}
                value={displayValue} // Show the formatted value
                placeholder={placeholder}
                type="text"
                inputMode="decimal"
                disabled={disabled}
                onWheel={(e) => (e.target as HTMLElement).blur()}
                className={`block w-full py-2 border ${disabled ? 'opacity-50 cursor-not-allowed' : ''} ${
                  fieldState.error
                    ? 'border-red-500'
                    : 'border-gray-300 hover:border-blue-400'
                } rounded-md focus:outline-none sm:text-sm ${prefix ? 'pl-3 rounded-l-none' : 'px-3'}  ${className}`}
                onChange={handleOnChange}
                onBlur={handleOnBlur}
              />
             </div>
            </div>
            {fieldState.error && (
              <ErrorMessage
                errors={[fieldState.error.message || 'Invalid value']}
              />
            )}
          </div>
        );
      }}
    />
  );
};

export default AmountInput;
