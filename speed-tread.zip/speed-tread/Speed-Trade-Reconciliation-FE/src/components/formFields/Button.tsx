import React from 'react';
import Loader from '../../components/Loader';
import { ButtonProps, ButtonVariant } from '../../interfaces/components';

const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  className,
  isLoading = false,
  fullWidth = true, // Default to true to avoid breaking existing layouts
  ...props
}) => {
  const baseClasses =
    'group relative flex justify-center items-center py-3 px-4 border border-transparent text-sm font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2';

  const widthClass = fullWidth ? 'w-full' : '';

  const variantClasses: Record<ButtonVariant, string> = {
    primary:
      'text-white bg-primary-blue hover:bg-royal-purple focus:ring-primary-blue',
    secondary:
      'text-gray-700 bg-gray-200 hover:bg-gray-300 focus:ring-gray-400',
  };

  return (
    <button
      {...props}
      className={`h-[45px] ${baseClasses} ${widthClass} ${variantClasses[variant]} ${className} ${isLoading ? 'cursor-not-allowed' : ''}  ${props.disabled ? 'cursor-not-allowed opacity-50' : ''}`}
      disabled={props.disabled || isLoading}
    >
      {isLoading ? <Loader /> : children}
    </button>
  );
};

export default Button;
