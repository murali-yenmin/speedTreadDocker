import React from 'react';

interface ButtonGroupProps {
  options: { label: string; value: string }[];
  value: string;
  onChange?: (value: string) => void;
  disable?: boolean;
}

const ButtonGroup: React.FC<ButtonGroupProps> = ({
  options,
  value,
  onChange,
  disable = false,
}) => {
  return (
    <div className="flex w-full rounded-lg shadow-sm p-1 border border-border-grey gap-1 ">
      {options.map((option, index) => (
        <button
          key={option.value}
          type="button"
          onClick={() => {
            if (!disable) onChange?.(option.value);
          }}
          className={`flex-1 px-4 py-3 text-sm font-medium rounded-lg 
            ${
              value === option.value
                ? `bg-primary-blue text-white ${disable ? 'cursor-not-allowed' : 'hover:bg-royal-purple'}`
                : `bg-white text-gray-700 ${disable ? 'cursor-not-allowed' : 'hover:bg-gray-300'}`
            }
            ${
              index > 0 &&
              value !== options[index - 1].value &&
              value !== option.value
                ? '-ml-px'
                : ''
            }`}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
};

export default ButtonGroup;
