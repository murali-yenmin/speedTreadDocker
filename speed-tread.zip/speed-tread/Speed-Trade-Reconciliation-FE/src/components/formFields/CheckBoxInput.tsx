import CustomCheckbox from './CustomCheckbox';
import { CheckBoxInputProps } from '../../interfaces/formfields';

export const CheckBoxInput = ({
  checked,
  indeterminate,
  onChange,
}: CheckBoxInputProps) => {
  return (
    <CustomCheckbox
      checked={checked}
      indeterminate={indeterminate}
      onChange={onChange}
    />
  );
};
