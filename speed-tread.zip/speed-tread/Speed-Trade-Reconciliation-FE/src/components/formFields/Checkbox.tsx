import { Controller } from 'react-hook-form';
import CheckBoxTick from '../Images/CheckBoxTick';
import ErrorValidationMessage from './ErrorMessage'; // Assuming ErrorValidationMessage is ErrorMessage
import { CheckboxProps } from '../../interfaces/formfields';

export const Checkbox = (checkboxProps: Readonly<CheckboxProps>) => {
  const {
    label,
    name,
    control,
    error,
    required = false,
    parentClassName = '',
    labelClassName = '',
    defaultSelected = false,
    disabled = false,
    onChange,
  } = checkboxProps;

  return (
    <div className={parentClassName}>
      <div className="flex items-center">
        <Controller
          name={name}
          control={control}
          render={({ field }) => (
            <div>
              <label
                htmlFor={`${name}`}
                className={`flex items-center cursor-pointer ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <input
                  id={name}
                  type="checkbox"
                  defaultChecked={defaultSelected}
                  {...field}
                  disabled={disabled}
                  onChange={(e) => {
                    field.onChange(e);
                    onChange?.(e.target.checked);
                  }}
                  className="hidden peer"
                />
                <span
                  className={`flex items-center justify-center w-4 h-4 rounded-full border border-gray-400 text-transparent transition-all duration-200 ${field.value ? 'bg-blue-500 text-white border-blue-500' : 'bg-transparent'}`}
                >
                  {field.value && <CheckBoxTick />}
                </span>
              </label>
            </div>
          )}
        />
        {label && (
          <label
            htmlFor={name}
            className={`ml-2 text-sm text-gray-900 ${labelClassName}`}
          >
            {label}
            {required && <span className="text-red-500">*</span>}
          </label>
        )}
        {error && <ErrorValidationMessage errors={error} />}
      </div>
    </div>
  );
};
