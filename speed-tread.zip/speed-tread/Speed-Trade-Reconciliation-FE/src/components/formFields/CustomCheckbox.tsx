import React, { useRef, useEffect } from 'react';
import CheckBoxTick from '../Images/CheckBoxTick';
import { CustomCheckboxProps } from '../../interfaces/formfields';

const CustomCheckbox: React.FC<CustomCheckboxProps> = ({
  label,
  className,
  indeterminate,
  ...props
}) => {
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.indeterminate = !!indeterminate;
    }
  }, [indeterminate]);

  return (
    <label
      className={`flex items-center cursor-pointer ${className}`}
      onClick={(e) => e.stopPropagation()}
    >
      <input
        type="checkbox"
        ref={inputRef}
        className="hidden peer"
        {...props}
      />
      <div
        className={`w-3.5 h-3.5 border flex items-center justify-center transition-all duration-200 ${indeterminate || props.checked ? 'bg-primary-blue border-primary-blue' : 'border-gray-400'}`}
      >
        {indeterminate ? (
          <div className="w-2 h-0.5 bg-white rounded-full"></div>
        ) : (
          props.checked && <CheckBoxTick />
        )}
      </div>
      {label && <span className="ml-2 text-sm text-gray-900">{label}</span>}
    </label>
  );
};

export default CustomCheckbox;
