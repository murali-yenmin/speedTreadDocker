import { useEffect, useRef, useState } from 'react';
import DatePicker from 'react-multi-date-picker';
import { DateObject } from 'react-multi-date-picker';
import CalendarIcon from '../Images/CalendarIcon';
import { DateRangeInputProps } from '../../interfaces/formfields';
import { isToday } from '../../utils/timeFormatter';
import useOutsideClick from '../../utils/outsideClick';
import moment from 'moment';
import Button from '../../components/formFields/Button';
import useMediaQuery from '../../hooks/useMediaQuery';

export const defaultDateFormat = 'DD-MM-YYYY';

// A simple component that allows DatePicker to read the `position` prop for plugins
const QuickSelectPlugin = ({ children, position }: any) => children;

export const DateRangeInput = ({
  label,
  id,
  value,
  onChange,
  maxDate,
  minDate,
  placeholder,
  isRange = false,
  isLast7Days = false,
  availableDates = [],
  isQuickSelect = false,
  selectUptoDays,
  displayValue: customDisplayValue,
}: DateRangeInputProps) => {
  const isMobile = useMediaQuery('(max-width: 480px)');
  const datePickerRef = useRef<any>(null);

  const getDatesArray = (value: any) => {
    if (!value) return [];
    if (isRange) {
      if (value.startDate && value.endDate) {
        return [
          moment(value.startDate, defaultDateFormat).toDate(),
          moment(value.endDate, defaultDateFormat).toDate(),
        ];
      }
      return [];
    }
    return moment(value, defaultDateFormat).toDate();
  };

  const [dates, setDates] = useState<any>(getDatesArray(value));

  useEffect(() => {
    setDates(getDatesArray(value));
  }, [value]);

  // Convert dates for DatePicker
  const datePickerValue =
    isRange && value && value.startDate && value.endDate
      ? [
          moment(value.startDate, defaultDateFormat).toDate(),
          moment(value.endDate, defaultDateFormat).toDate(),
        ]
      : value;

  useOutsideClick(datePickerRef, () => {
    datePickerRef.current.closeCalendar();
  });

  const handleQuickSelect = (type: 'days' | 'today', days?: number) => {
    if (type === 'today') {
      const today = moment().format(defaultDateFormat);
      onChange({
        startDate: today,
        endDate: today,
      });
    } else if (type === 'days' && days) {
      const endDate = moment().format(defaultDateFormat);
      const startDate = moment()
        .subtract(days - 1, 'days')
        .format(defaultDateFormat);
      onChange({
        startDate,
        endDate,
      });
    }
    datePickerRef.current.closeCalendar();
  };

  const mobilePlugins = isQuickSelect
    ? [
        <QuickSelectPlugin position="top">
          <div className="box-border w-full flex flex-col gap-2 p-2 border-b border-gray-200">
            <Button
              type="button"
              onClick={() => handleQuickSelect('today')}
              variant="secondary"
              className="text-xs text-center h-[32px]"
              fullWidth={true}
            >
              Today
            </Button>
            <Button
              type="button"
              onClick={() => handleQuickSelect('days', 7)}
              variant="secondary"
              className="text-xs text-center h-[32px]"
              fullWidth={true}
            >
              Last 7 Days
            </Button>
            <Button
              type="button"
              onClick={() => handleQuickSelect('days', 30)}
              variant="secondary"
              className="text-xs text-center h-[32px]"
              fullWidth={true}
            >
              Last 30 Days
            </Button>
          </div>
        </QuickSelectPlugin>,
      ]
    : []; 

  return (
    <div>
      <label htmlFor={id}>{label}</label>
      <DatePicker
        portal
        key={isRange ? 'range' : 'single'}
        ref={datePickerRef}
        value={dates}
        onChange={(date: DateObject | DateObject[] | any) => {
          setDates(date);
          if (isRange) {
            if (Array.isArray(date) && date.length === 2) {
              const startDate = moment(date[0].toDate()).format(
                defaultDateFormat,
              );
              const endDate = moment(date[1].toDate()).format(
                defaultDateFormat,
              );

              onChange({
                startDate,
                endDate,
              });
              datePickerRef.current.closeCalendar();
            } else if (
              date === null ||
              (Array.isArray(date) && date.length === 0)
            ) {
              onChange(null);
            }
          } else {
            if (date && !Array.isArray(date)) {
              const formattedDate = moment(date.toDate()).format(
                defaultDateFormat,
              );
              onChange(formattedDate);
              datePickerRef.current.closeCalendar();
            } else {
              onChange(null);
            }
          }
        }}
        range={isRange}
        rangeHover={isRange}
        format={defaultDateFormat}
        maxDate={maxDate || new Date()}
        minDate={minDate}
        numberOfMonths={isRange && !isMobile ? 2 : 1}
        plugins={isMobile ? mobilePlugins : []}
        className="!rounded-lg !p-2"
        inputClass="!text-gray-900 !bg-white !border !border-emerald-400 focus:!border-emerald-500"
        placeholder={placeholder}
        render={(value, openCalendar) => {
          let displayValue;
          if (customDisplayValue) {
            displayValue = customDisplayValue;
          } else if (isRange) {
            if (isLast7Days && dates) {
              displayValue = 'Past 7 Days';
            } else if (Array.isArray(value) && value.length === 2) {
              const startDate = value[0].format(defaultDateFormat);
              const endDate = value[1].format(defaultDateFormat);
              if (startDate === endDate) {
                displayValue = startDate;
              } else {
                displayValue = `${startDate} - ${endDate}`;
              }
            } else if (value) {
              displayValue = value.toString();
            } else {
              displayValue = '';
            }
          } else {
            displayValue =
              value && isToday(value) ? 'Today' : value?.toString();
          }

          return (
            <div className="relative w-full">
              <input
                type="text"
                id={id}
                value={displayValue || ''}
                onClick={openCalendar}
                readOnly
                placeholder={placeholder}
                className="w-full h-[38px] px-3 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none hover:border-blue-400 bg-initialsBg"
              />
              <div
                className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer"
                onClick={openCalendar}
              >
                <CalendarIcon className="h-[12px] w-[11px] text-gray-400" />
              </div>
            </div>
          );
        }}
        mapDays={({ date }) => {
          let isDisabled = false;
          if (
            isRange &&
            Array.isArray(dates) &&
            dates.length === 1 &&
            selectUptoDays
          ) {
            const tempStartDate = dates[0];
            const diff = Math.abs(date.toUnix() - tempStartDate.toUnix());
            const days = Math.ceil(diff / (60 * 60 * 24)) + 1;
            if (days > selectUptoDays) {
              isDisabled = true;
            }
          }

          const formatted = date.format(defaultDateFormat);
          const isAvailable = availableDates.includes(formatted);

          const props: any = {};
          if (isDisabled) {
            props.disabled = true;
          }

          if (isAvailable) {
            props.children = (
              <div className="relative flex flex-col items-center justify-center">
                <p>{date.day}</p>
                <div
                  className="absolute top-[-2px] w-[5px] h-[5px] rounded-full bg-active-red"
                  title="Available"
                ></div>
              </div>
            );
          }

          return props;
        }}
        containerClassName="custom-datepicker-container"
        calendarPosition="bottom-left"
      >
        {isQuickSelect && !isMobile && (
          <div className="flex items-start gap-4 p-2">
            {/* Quick select buttons on the left */}
            <div className="flex flex-col gap-2 min-w-[120px]">
              <Button
                type="button"
                onClick={() => handleQuickSelect('today')}
                variant="secondary"
                className="text-xs text-left h-[32px]"
                fullWidth={true}
              >
                Today
              </Button>
              <Button
                type="button"
                onClick={() => handleQuickSelect('days', 7)}
                variant="secondary"
                className="text-xs text-left h-[32px]"
                fullWidth={true}
              >
                Last 7 Days
              </Button>
              <Button
                type="button"
                onClick={() => handleQuickSelect('days', 30)}
                variant="secondary"
                className="text-xs text-left h-[32px]"
                fullWidth={true}
              >
                Last 30 Days
              </Button>
            </div>
          </div>
        )}
      </DatePicker>
    </div>
  );
};
