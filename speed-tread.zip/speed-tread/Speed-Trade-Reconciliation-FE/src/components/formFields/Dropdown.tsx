import {
  Controller,
  ControllerRenderProps,
  FieldValues,
  Path,
} from 'react-hook-form';
import Select, { components, GroupBase, OptionProps } from 'react-select';
import ErrorMessage from './ErrorMessage';
import { DropdownOption, DropdownProps } from '../../interfaces/formfields';

const Dropdown = <T extends FieldValues>({
  label,
  name,
  control,
  rules,
  options,
  className,
  id,
  isMulti,
  valueContainerClassName,
  required,
  placeholder = 'Select...',
  onChange,
  isSearchable = false,
  customPadding,
  disabled = false,
  customComp = false,
  defaultValue,
  dropDownMinH,
}: DropdownProps<T>) => {
  const getValue = (field: ControllerRenderProps<T, Path<T>>) => {
    const result = isMulti
      ? options.filter((option) => field.value?.includes(option.value))
      : options.find((option) => option.value === field.value);
    return result;
  };

  return (
    <div className={`w-full ${className}`}>
      {label && (
        <label
          htmlFor={id || name}
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          {label}
          {required && <span className="text-red-500">*</span>}
        </label>
      )}

      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field, fieldState }) => {
          const errorsToDisplay = fieldState.error
            ? [fieldState.error.message || 'Invalid value']
            : [];

          const isInvalid = Boolean(fieldState.error);

          const customStyles = {
            control: (base: any, state: any) => ({
              ...base,
              minHeight: dropDownMinH || 38,
              height: 38,
              fontSize: '14px',
              borderRadius: 6,
              paddingLeft: 8,
              paddingRight: 8,
              borderWidth: 1,
              backgroundColor: '#F7FAFC',
              borderColor: isInvalid
                ? '#ef4444'
                : state.isFocused
                  ? '#d1d5db'
                  : '#d1d5db',
              boxShadow: isInvalid
                ? '0 0 0 1px rgba(239,68,68,0.25)'
                : state.isFocused
                  ? 'none'
                  : 'none',
              '&:hover': {
                borderColor: isInvalid
                  ? '#ef4444'
                  : state.isFocused
                    ? '#0ea5e9'
                    : '#60a5fa',
              },
            }),
            valueContainer: (base: any) => ({
              ...base,
              padding: valueContainerClassName ? undefined : '0 12px',
            }),
            input: (base: any) => ({
              ...base,
              margin: 0,
              padding: 0,
            }),
            placeholder: (base: any) => ({
              ...base,
              color: '#9ca3af',
              paddingLeft: customPadding ? '1px' : '0px',
            }),
            singleValue: (base: any) => ({
              ...base,
              color: '#111827',
              paddingLeft: customPadding ? customPadding : '0px',
            }),
            multiValue: (base: any) => ({
              ...base,
              background: '#e5e7eb',
              borderRadius: 4,
            }),
            multiValueLabel: (base: any) => ({
              ...base,
              color: '#111827',
            }),
            multiValueRemove: (base: any) => ({
              ...base,
              ':hover': {
                background: '#ef4444',
                color: 'white',
              },
            }),
            indicatorSeparator: () => ({ display: 'none' }),
            menu: (base: any) => ({
              ...base,
              zIndex: 9999,
              borderRadius: 6,
              padding: '8px',
            }),
            option: (base: any, state: any) => ({
              ...base,
              cursor: 'pointer',
              padding: '8px 12px',
              borderRadius: '4px',
              backgroundColor: state.isSelected
                ? '#1A2B47' // Dark blue for selected
                : state.isFocused
                  ? '#5F49AE' // Light blue for hover/focused
                  : null,
              color:
                state.isSelected || state.isFocused
                  ? 'white' // 👈 White text for selected or focused
                  : '#111827', // Default black text, // White text for selected, black for others
              ':active': {
                backgroundColor: state.isSelected ? '#1A2B47' : '#E0F2F7',
              },
              ':hover': {
                color: 'white', // 👈 Text becomes white on hover
              },
            }),
            menuPortal: (base: any) => ({ ...base, zIndex: 9999 }),
          };

          const CustomOptions = (
            props: OptionProps<
              DropdownOption,
              boolean,
              GroupBase<DropdownOption>
            >,
          ) => {
            const {
              data: { label, value, count },
            } = props;
            return (
              <components.Option {...props}>
                <div className="flex items-center gap-2 justify-between">
                  <span>{label}</span>
                  {count ? (
                    <span
                      style={{ fontSize: '14px' }}
                      className="bg-initialsBg text-13px py-[1px] px-[5px] text-grey-300 rounded-md min-h-5 min-w-5 text-center"
                    >
                      {count}
                    </span>
                  ) : (
                    <span></span>
                  )}
                </div>
              </components.Option>
            );
          };

          return (
            <>
              <Select
                key={JSON.stringify(options)}
                id={id || name}
                {...field}
                placeholder={placeholder}
                options={options}
                isMulti={isMulti}
                classNamePrefix="react-select"
                styles={customStyles}
                menuPortalTarget={document.body}
                menuPosition="fixed"
                menuShouldBlockScroll={true}
                isSearchable={isSearchable}
                onChange={(selectedOption) => {
                  let valueToPass;
                  if (isMulti) {
                    valueToPass = (selectedOption as DropdownOption[]).map(
                      (option) => option.value,
                    );
                  } else {
                    valueToPass =
                      (selectedOption as DropdownOption)?.value || '';
                  }
                  field.onChange(valueToPass);
                  onChange?.(selectedOption);
                }}
                value={getValue(field)}
                isDisabled={disabled}
                components={customComp ? { Option: CustomOptions } : undefined}
              />
              <ErrorMessage errors={errorsToDisplay} />
            </>
          );
        }}
      />
    </div>
  );
};

export default Dropdown;
