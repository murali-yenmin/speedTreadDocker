import React from 'react';
import { ErrorMessageProps } from '../../interfaces/formfields';

const ErrorMessage: React.FC<ErrorMessageProps> = ({ errors, className }) => {
  if (!errors || errors.length === 0) {
    return null;
  }

  return (
    <div className={`text-red-500 text-sm mt-1 ${className}`}>
      {errors.map((error, index) => (
        <p key={index}>{error}</p>
      ))}
    </div>
  );
};

export default ErrorMessage;
