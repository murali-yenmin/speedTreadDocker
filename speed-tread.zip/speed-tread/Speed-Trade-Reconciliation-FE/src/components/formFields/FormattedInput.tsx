import React, { useEffect, useRef } from 'react';
import { Controller } from 'react-hook-form';
import ErrorMessage from './ErrorMessage';

interface FormattedInputProps {
  control: any;
  name: string;
  placeholder: string;
  decimalPlaces: number;
  disabled?: boolean;
  label?: string;
  className?: string;
  prefix?: React.ReactNode;
  onBlurCb?: () => void;
}

const FormattedInput: React.FC<FormattedInputProps> = ({
  control,
  name,
  placeholder,
  decimalPlaces,
  disabled,
  label,
  className,
  prefix,
  onBlurCb,
}) => {
  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState }) => {
        // eslint-disable-next-line react-hooks/rules-of-hooks
        const isFirstRender = useRef(true);
        // eslint-disable-next-line react-hooks/rules-of-hooks
        const hasFormattedInitialValue = useRef(false);

        // ✅ Format value only on initial mount if value exists (edit scenario)
        useEffect(() => {
          if (
            isFirstRender.current &&
            !hasFormattedInitialValue.current &&
            field.value !== undefined &&
            field.value !== '' &&
            field.value !== null &&
            !isNaN(Number(field.value))
          ) {
            const formatted = Number(field.value).toFixed(decimalPlaces);
            field.onChange(formatted);
            hasFormattedInitialValue.current = true;
          }
        }, [field.value]); // Empty dependency array - only runs once on mount

        return (
          <div>
            {label && (
              <label
                htmlFor={name}
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                {label}
              </label>
            )}
            <div className="relative w-full flex items-center">
              {prefix && (
                <div
                  className={`absolute inset-y-0 left-0 flex items-center bg-light-bluish-gray border border-r-0 rounded-l-md px-3 ${fieldState.error ? 'border-red-500 border-t border-b border-l' : 'border-gray-300'}`}
                >
                  <p className="text-steel-blue">{prefix}</p>
                </div>
              )}
              <input
                {...field}
                value={field.value || ''}
                placeholder={placeholder}
                type="text"
                disabled={disabled}
                onWheel={(e) => (e.target as HTMLElement).blur()}
                className={`block w-full py-2 border ${
                  disabled ? 'opacity-50 cursor-not-allowed' : ''
                } ${
                  fieldState.error
                    ? 'border-red-500'
                    : 'border-gray-300 hover:border-blue-400'
                } rounded-md focus:outline-none sm:text-sm ${prefix ? 'pl-16' : 'px-3'}  ${className}`}
                onChange={(e) => {
                  // Mark that user has started typing
                  if (isFirstRender.current) {
                    isFirstRender.current = false;
                  }

                  let value = e.target.value.replace(/[^0-9.]/g, '');
                  const dotIndex = value.indexOf('.');
                  if (dotIndex !== -1) {
                    // Prevent multiple dots
                    if (value.substring(dotIndex + 1).indexOf('.') !== -1) {
                      value = value.substring(0, value.length - 1);
                    }
                    // Limit decimal places during typing
                    if (value.length - dotIndex > decimalPlaces + 1) {
                      value = value.substring(0, dotIndex + decimalPlaces + 1);
                    }
                  }
                  field.onChange(value);
                }}
                onBlur={(e) => {
                  field.onBlur();
                  let value = e.target.value;
                  // Format to fixed decimal places on blur
                  if (value && !isNaN(parseFloat(value))) {
                    field.onChange(parseFloat(value).toFixed(decimalPlaces));
                  }
                  onBlurCb && onBlurCb();
                }}
              />
            </div>
            {fieldState.error && (
              <ErrorMessage
                errors={[fieldState.error.message || 'Invalid value']}
              />
            )}
          </div>
        );
      }}
    />
  );
};

export default FormattedInput;
