import { useEffect, useState } from 'react';
import { useController, FieldValues } from 'react-hook-form';
import ErrorMessage from './ErrorMessage';
import { ReactComponent as EyeIcon } from '../../assets/svg/EyeIcon.svg';
import { ReactComponent as EyeOffIcon } from '../../assets/svg/EyeOffIcon.svg';
import { InputProps } from '../../interfaces/formfields';
import { useDebounce } from '../../hooks/useDebounce';
import SearchIcon from '../Images/SearchIcon';
import CloseIcon from '../Images/CloseIcon';

const Input = <T extends FieldValues>(props: InputProps<T>) => {
  const {
    label,
    name,
    control,
    rules,
    type = 'text',
    placeholder,
    className,
    inputClassName,
    required,
    rightAddon,
    prefix,
    maxLength,
    onKeyPress,
    onChange,
    readOnly,
    disabled,
    onFocus,
    onBlur,
    searchIcon = false,
    clearCb,
  } = props;
  const { field, fieldState } = useController(props);
  const [inputValue, setInputValue] = useState<string>(field.value || '');
  const debouncedValue = useDebounce(inputValue, 500);

  const [showPassword, setShowPassword] = useState(false);

  const errors = fieldState.error
    ? [fieldState.error.message || 'Invalid value']
    : [];

  const togglePasswordVisibility = () => {
    setShowPassword((prev) => !prev);
  };

  const inputType = type === 'password' && showPassword ? 'text' : type;

  useEffect(() => {
    if (debouncedValue !== undefined) {
      onChange?.(debouncedValue);
    }
  }, [debouncedValue]);

  const clear = () => {
    setInputValue('');
    field.onChange('');
    clearCb && clearCb();
  };

  return (
    <div className={className}>
      {label && (
        <label
          htmlFor={field.name}
          className="block text-sm font-medium text-gray-700"
        >
          {label}
          {required && <span className="text-red-500">*</span>}
        </label>
      )}
      <div className={`flex items-center ${label ? 'mt-1' : ''}`}>
        <div className={`relative w-full flex items-center ${disabled ? 'opacity-70' : ''}`}>
          {prefix && (
            <div className={`absolute inset-y-0 left-0 flex items-center bg-light-bluish-gray border border-r-0 rounded-l-md px-3 ${fieldState.error ? 'border-red-500 border-t border-b border-l' : 'border-gray-300'}`}>
              <p className="text-steel-blue">{prefix}</p>
            </div>
          )}
          {searchIcon && (
            <div className="absolute inset-y-0 left-0 ml-2 flex items-center">
              <SearchIcon />
            </div>
          )}
          <input
            id={field.name}
            {...field}
            type={inputType}
            placeholder={placeholder}
            maxLength={maxLength}
            onKeyPress={(e) => {
              // Handle number-type restrictions first
              if (type === 'number') {
                const invalidChars = ['e', 'E', '+', '-', '.'];
                if (invalidChars.includes(e.key)) {
                  e.preventDefault();
                  return; // stop further processing
                }
              }

              // Call user's custom handler if provided
              onKeyPress?.(e);
            }}
            readOnly={readOnly}
            disabled={disabled}
            onWheel={(e) => {
              (e.target as HTMLElement).blur();
            }}
            className={`block w-full   ${searchIcon ? 'px-8' : 'px-3'}   ${prefix ? 'pl-12' : 'px-3'}   py-2 border   ${fieldState.error ? 'border-red-500' : disabled || readOnly ? 'border-gray-300 cursor-not-allowed bg-gray-100' : 'border-gray-300 hover:border-blue-400'}   rounded-md focus:outline-none sm:text-sm ${inputClassName} appearance-none bg-light-bluish-gray`}

            onChange={(e) => {
                 let value = e.target.value;

              // ✅ Enforce maxLength for number type manually
              if (type === 'number' && maxLength && value.length > maxLength) {
                value = value.slice(0, maxLength);
              }
              field.onChange(value);
              setInputValue(value);
            }}
            onFocus={(e) => {
              onFocus?.(e); // your custom callback
            }}
            onBlur={(e) => {
              field.onBlur(); // react-hook-form internal blur handler
              onBlur?.(e); // your custom callback
            }}
          />
          {type === 'password' && (
            <button
              type="button"
              onClick={togglePasswordVisibility}
              className="absolute inset-y-0 right-0 px-2 flex items-center"
            >
              {showPassword ? (
                <EyeOffIcon className="h-5 w-5 text-gray-400" />
              ) : (
                <EyeIcon className="h-5 w-5 text-gray-400" />
              )}
            </button>
          )}
        </div>
        {rightAddon}
        {searchIcon && field.value && (
          <div
            className="absolute inset-y-0 right-0 mr-2 flex items-center cursor-pointer"
            onClick={clear}
          >
            <CloseIcon />
          </div>
        )}
      </div>

      <ErrorMessage errors={errors} />
    </div>
  );
};

export default Input;
