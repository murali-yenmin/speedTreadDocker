import React, { useState, useRef, useEffect } from 'react';
import { ReactComponent as ChevronDownIcon } from '../../assets/svg/ChevronDownIcon.svg';
import { ReactComponent as ChevronUpIcon } from '../../assets/svg/ChevronUpIcon.svg';
import SearchIcon from '../../assets/icons/SearchIcon';
import useOutsideClick from '../../utils/outsideClick';

export interface MultiSelectOption {
  label: string;
  value: string;
}

interface MultiSelectProps {
  options: MultiSelectOption[];
  selected: MultiSelectOption[];
  onChange: (selected: MultiSelectOption[]) => void;
  onSearch: (query: string) => void;
  placeholder?: string;
  loading?: boolean;
}

const MultiSelect: React.FC<MultiSelectProps> = ({
  options,
  selected,
  onChange,
  onSearch,
  placeholder = 'Select...',
  loading = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const wrapperRef = useRef<HTMLDivElement>(null);
  useOutsideClick(wrapperRef, () => setIsOpen(false));

  const handleToggle = () => setIsOpen(!isOpen);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const trimmedValue = e.target.value;
    setSearchQuery(trimmedValue);
    onSearch(trimmedValue);
  };

  const handleOptionClick = (option: MultiSelectOption) => {
    const isCurrentlySelected = selected.find(
      (item) => item.value === option.value,
    );

    if (isCurrentlySelected) {
      // If it's already selected, remove it
      onChange(selected.filter((item) => item.value !== option.value));
    } else {
      // If it's not selected, add it
      onChange([...selected, option]);
    }
  };

  const handleClearAll = () => {
    onChange([]);
  };

  const isSelected = (option: MultiSelectOption) => {
    return selected.some((item) => item.value === option.value);
  };

  return (
    <div className="relative" ref={wrapperRef}>
      <div
        className="w-full min-h-[38px] px-[10px] py-[6px] hover:border-blue-400 bg-[#f7fafc] border border-gray-300 rounded-md flex justify-between items-center cursor-pointer"
        onClick={handleToggle}
      >
        <div className="flex-grow flex items-center overflow-x-auto hide-scrollbar mr-2 max-w-[192px]">
          {selected.length > 0 ? (
            <>
              {selected.slice(0, 2).map((item) => (
                <span
                  key={item.value}
                  className="flex items-center bg-gray-200 text-gray-800 text-xs px-2 py-1 rounded-full mr-1 whitespace-nowrap"
                >
                  {item.label}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleOptionClick(item); // Re-use handleOptionClick to deselect
                    }}
                    className="ml-1 text-gray-500 hover:text-gray-700 focus:outline-none"
                  >
                    &times;
                  </button>
                </span>
              ))}
              {selected.length > 2 && (
                <span className="flex items-center bg-gray-200 text-gray-800 text-xs px-2 py-1 rounded-full mr-1 whitespace-nowrap">
                  +{selected.length - 2}
                </span>
              )}
            </>
          ) : (
            <span className="text-[#111827] text-sm">{placeholder}</span>
          )}
        </div>
        <svg
          height="20"
          width="20"
          viewBox="0 0 20 20"
          aria-hidden="true"
          focusable="false"
          className="css-tj5bde-Svg"
          fill="red"
        >
          <path
            fill={isOpen ? '#616770ff' : '#c0c3c9ff'}
            d="M4.516 7.548c0.436-0.446 1.043-0.481 1.576 0l3.908 3.747 3.908-3.747c0.533-0.481 1.141-0.446 1.574 0 0.436 0.445 0.408 1.197 0 1.615-0.406 0.418-4.695 4.502-4.695 4.502-0.217 0.223-0.502 0.335-0.787 0.335s-0.57-0.112-0.789-0.335c0 0-4.287-4.084-4.695-4.502s-0.436-1.17 0-1.615z"
          ></path>
        </svg>
        {/* {isOpen ? <ChevronUpIcon /> : <ChevronDownIcon />} */}
      </div>
      {isOpen && (
        <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg">
          <div className="p-2">
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-2">
                <SearchIcon />
              </span>
              <input
                type="text"
                placeholder="Search..."
                className="w-full pl-8 p-2 border border-gray-300 rounded-md"
                value={searchQuery}
                onChange={handleSearchChange}
              />
            </div>
          </div>
          <ul className="max-h-60 overflow-y-auto">
            {loading ? (
              <div className="p-4 text-center">Loading...</div>
            ) : (
              options.map((option) => (
                <li
                  key={option.value}
                  className="p-2 hover:bg-royal-purple hover:text-white cursor-pointer flex items-center"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleOptionClick(option);
                  }}
                >
                  <div>
                    <div
                      className={`w-5 h-5 border border-gray-400 rounded mr-2 flex items-center justify-center ${
                        isSelected(option) ? 'bg-primary-blue' : ''
                      }`}
                    >
                      {isSelected(option) && (
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 20 20"
                          className="w-5 h-5"
                        >
                          <path
                            id="circle-path"
                            fill-rule="evenodd"
                            d="M10 18a8 8 0 100-16 8 8 0 000 16z"
                            clip-rule="evenodd"
                            fill="currentColor"
                            className="text-primary-blue"
                          />
                          <path
                            id="tick-path"
                            fill-rule="evenodd"
                            d="M13.857 8.191a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z"
                            clip-rule="evenodd"
                            fill="currentColor"
                            className="text-white"
                          />
                        </svg>
                      )}
                    </div>
                  </div>
                  <span>{option.label}</span>
                </li>
              ))
            )}
          </ul>
          {selected.length > 0 && (
            <div className="p-2 border-t border-gray-200">
              <button
                onClick={handleClearAll}
                className="w-full p-2 text-sm text-center text-red-500 hover:bg-red-50 rounded-md"
              >
                Clear All
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default MultiSelect;
