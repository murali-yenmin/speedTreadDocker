import Input from './Input';
import { FieldValues } from 'react-hook-form';
import { PasswordInputProps } from '../../interfaces/formfields';

const PasswordInput = <T extends FieldValues>({
  label,
  name,
  control,
  rules,
  placeholder,
  className,
  inputClassName,
  required,
}: PasswordInputProps<T>) => {
  return (
    <Input
      name={name}
      control={control}
      label={label}
      type="password"
      placeholder={placeholder}
      rules={rules}
      className={className}
      inputClassName={`pr-[37px] ${inputClassName}`}
      required={required}
    />
  );
};

export default PasswordInput;
