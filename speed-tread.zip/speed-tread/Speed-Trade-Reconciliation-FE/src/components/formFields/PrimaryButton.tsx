import React from 'react';

interface PrimaryButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  className?: string;
}

const PrimaryButton: React.FC<PrimaryButtonProps> = ({
  children,
  className,
  ...props
}) => {
  return (
    <button
      {...props}
      className={`group relative flex justify-center py-[10px] px-4 border border-transparent text-sm font-medium rounded-md text-white bg-primary-blue hover:bg-royal-purple focus:outline-none ${className}`}
    >
      {children}
    </button>
  );
};

export default PrimaryButton;
