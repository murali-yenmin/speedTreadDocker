import { useController, FieldValues } from 'react-hook-form';
import ErrorMessage from './ErrorMessage';
import { RadioGroupProps } from '../../interfaces/formfields';

const RadioGroup = <T extends FieldValues>({
  name,
  control,
  rules,
  options,
  customClassName,
  disabled = false,
  childClassName = '',
  hasBorder = false, // New prop for conditional border/padding
  onChange,
}: RadioGroupProps<T>) => {
  const { field, fieldState } = useController({
    name,
    control,
    rules,
  });

  const errors = fieldState.error
    ? [fieldState.error.message || 'Invalid value']
    : [];

  return (
    <div>
      <div className={`${customClassName}`}>
        {options.map((option) => (
          <label
            key={option.value}
            className={`flex items-center ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'} ${childClassName} ${
              hasBorder
                ? `border border-gray-300 py-4 px-[30px] rounded-md flex-1 hover:bg-gray-50`
                : ''
            }`}
          >
            <input
              type="radio"
              name={name}
              value={option.value}
              checked={field.value === option.value}
              onChange={() => {
                field.onChange(option.value);
                onChange?.(option);
              }}
              className="hidden"
              disabled={disabled}
            />
            <span
              className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                field.value === option.value
                  ? 'border-gray-400'
                  : 'border-gray-400'
              }`}
            >
              {field.value === option.value && (
                <span className="w-[10px] h-[10px] rounded-full bg-primary-blue"></span>
              )}
            </span>
            <span
              className={`ml-2 text-sm font-medium text-gray-700 ${disabled && field.value !== option.value ? 'opacity-60' : ''}`}
            >
              {option.label}
            </span>
          </label>
        ))}
      </div>
      <ErrorMessage errors={errors} />
    </div>
  );
};

export default RadioGroup;
