import React, { useState, useEffect } from 'react';
import SearchIcon from '../Images/SearchIcon';
import { useDebounce } from '../../hooks/useDebounce';
import CloseIcon from '../Images/CloseIcon';

export const Search = ({
  placeholder,
  onChange,
  value,
  className,
  inputClassName,
  delay = 500,
}: {
  placeholder?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  value?: string;
  className?: string;
  delay?: number;
  inputClassName?: string;
}) => {
  const [inputValue, setInputValue] = useState(value || '');
  const debouncedValue = useDebounce(inputValue, delay);

  useEffect(() => {
    if (onChange) {
      const event = {
        target: {
          value: debouncedValue,
        },
      } as React.ChangeEvent<HTMLInputElement>;
      onChange(event);
    }
  }, [debouncedValue, onChange]);

  useEffect(() => {
    setInputValue(value || '');
  }, [value]);
  const hasBgClass =
    inputClassName && /(bg-|background-color:|bg\[)/.test(inputClassName);
  return (
    <div className={`relative ${className} bg-anti-flash-white`}>
      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
        <SearchIcon />
      </div>
      <input
        type="text"
        placeholder={placeholder}
        onChange={(e) => setInputValue(e.target.value)}
        value={inputValue}
        className={`md:w-[370px] w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md focus:outline-none hover:border-blue-400 ${
          hasBgClass ? `${inputClassName} !important` : 'bg-anti-flash-white'
        }`}
        // className={`md:w-[370px] w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md focus:outline-none hover:border-blue-400 bg-[#F1F1F1!important] ${inputClassName}`}
      />
      {inputValue && (
        <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
          <button
            type="button"
            onClick={() => setInputValue('')}
            className="focus:outline-none"
          >
            <CloseIcon />
          </button>
        </div>
      )}
    </div>
  );
};
