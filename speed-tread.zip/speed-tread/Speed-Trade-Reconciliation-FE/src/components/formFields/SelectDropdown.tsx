import React from 'react';
import Select from 'react-select';
import ErrorMessage from './ErrorMessage';
import { SelectDropdownProps } from '../../interfaces/formfields';

const SelectDropdown: React.FC<SelectDropdownProps> = ({
  label,
  options,
  className,
  id,
  isMulti,
  valueContainerClassName,
  required,
  placeholder = 'Select...',
  onChange,
  value,
  error,
  customPadding,
  isSearchable=false
}) => {
  const isInvalid = !!error;

  const customStyles = {
    control: (base: any, state: any) => ({
      ...base,
      minHeight: 38,
      height: 38,
      borderRadius: 6,
      paddingLeft: 8,
      paddingRight: 8,
      borderWidth: 1,
      backgroundColor: '#F7FAFC',
      borderColor: isInvalid
        ? '#ef4444'
        : state.isFocused
          ? '#d1d5db'
          : '#d1d5db',
      boxShadow: isInvalid
        ? '0 0 0 1px rgba(239,68,68,0.25)'
        : state.isFocused
          ? 'none'
          : 'none',
      '&:hover': {
        borderColor: isInvalid
          ? '#ef4444'
          : state.isFocused
            ? '#0ea5e9'
            : '#60a5fa',
      },
    }),
    valueContainer: (base: any) => ({
      ...base,
      padding: valueContainerClassName ? undefined : '0 12px',
    }),
    input: (base: any) => ({
      ...base,
      margin: 0,
      padding: 0,
    }),
    placeholder: (base: any) => ({
      ...base,
      color: '#9ca3af',
    }),
    singleValue: (base: any) => ({
      ...base,
      color: '#111827',
      paddingLeft: customPadding ? customPadding : '0px',
    }),
    multiValue: (base: any) => ({
      ...base,
      background: '#e5e7eb',
      borderRadius: 4,
    }),
    multiValueLabel: (base: any) => ({
      ...base,
      color: '#111827',
    }),
    multiValueRemove: (base: any) => ({
      ...base,
      ':hover': {
        background: '#ef4444',
        color: 'white',
      },
    }),
    indicatorSeparator: () => ({ display: 'none' }),
    menu: (base: any) => ({
      ...base,
      zIndex: 9999,
      borderRadius: 6,
      padding: '8px',
    }),
    option: (base: any, state: any) => ({
      ...base,
      cursor: 'pointer',
      padding: '8px 12px',
      borderRadius: '4px',
      backgroundColor: state.isSelected
        ? '#1A2B47' // Dark blue for selected
        : state.isFocused
          ? '#5F49AE' // Light blue for hover/focused
          : null,
      color: state.isSelected || state.isFocused ? 'white' : '#111827', // White text for selected, black for others
      ':active': {
        backgroundColor: state.isSelected ? '#1A2B47' : '#E0F2F7',
      },
    }),
    menuPortal: (base: any) => ({ ...base, zIndex: 9999 }),
  };

  return (
    <div className={`w-full ${className}`}>
      {label && (
        <label
          htmlFor={id}
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          {label}
          {required && <span className="text-red-500">*</span>}
        </label>
      )}
      <Select
        id={id}
        placeholder={placeholder}
        options={options}
        isMulti={isMulti}
        classNamePrefix="react-select"
        styles={customStyles}
        menuPortalTarget={document.body}
        onChange={onChange}
        value={value}
        isSearchable={isSearchable}
      />
      {error && <ErrorMessage errors={[error]} />}
    </div>
  );
};

export default SelectDropdown;
