import { useState, useRef, useEffect } from 'react';
import { useController, FieldValues } from 'react-hook-form';
import ErrorMessage from './ErrorMessage';
import { TextAreaProps } from '../../interfaces/formfields';

const TextArea = <T extends FieldValues>(props: TextAreaProps<T>) => {
  const {
    label,
    name,
    control,
    rules,
    placeholder,
    className,
    inputClassName,
    required,
    maxLength,
    onChange,
    readOnly,
    disabled,
    rows = 1,
  } = props;
  const { field, fieldState } = useController(props);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const [charCount, setCharCount] = useState(
    field.value ? field.value.length : 0,
  );

  const errors = fieldState.error
    ? [fieldState.error.message || 'Invalid value']
    : [];

  const handleOnChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setCharCount(e.target.value.length);
    field.onChange(e);
    if (onChange) {
      onChange(e);
    }
  };

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [field.value]);

  
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  }, []);

  return (
    <div className={className}>
      {label && (
        <label
          htmlFor={field.name}
          className="block text-sm font-medium text-gray-700"
        >
          {label}
          {required && <span className="text-red-500">*</span>}
        </label>
      )}
      <div className={`flex items-center ${label ? 'mt-1' : ''}`}>
        <div className="relative w-full">
          <textarea
            id={field.name}
            {...field}
            placeholder={placeholder}
            maxLength={maxLength}
            readOnly={readOnly}
            disabled={disabled}
            onChange={handleOnChange}
            className={`block w-full px-3 py-2 border ${fieldState.error ? 'border-red-500' : 'border-gray-300 hover:border-blue-400'} rounded-md focus:outline-none sm:text-sm ${inputClassName} ${readOnly || disabled ? '' : ''} bg-[#E8EDF5] resize-y`}
            rows={rows}
            ref={textareaRef}
          />
          {maxLength && (
            <p className="text-xs text-gray-500 text-right mt-1">
              {maxLength - charCount} characters remaining
            </p>
          )}
        </div>
      </div>

      <ErrorMessage errors={errors} />
    </div>
  );
};

export default TextArea;
