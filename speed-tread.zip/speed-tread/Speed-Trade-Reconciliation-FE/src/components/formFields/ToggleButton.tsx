import React from 'react';
import { ToggleButtonProps } from '../../interfaces/formfields';

const ToggleButton: React.FC<ToggleButtonProps> = ({
  checked,
  onChange,
  id,
}) => {
  return (
    <label htmlFor={id} className="flex items-center cursor-pointer">
      <div className="relative">
        <input
          type="checkbox"
          id={id}
          className="sr-only"
          checked={checked}
          onChange={onChange}
        />
        <div
          className={`block w-14 h-8 rounded-full ${checked ? 'bg-primary-blue' : 'bg-gray-300'}`}
        ></div>
        <div
          className={`dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition-transform ${checked ? 'transform translate-x-6' : ''}`}
        ></div>
      </div>
    </label>
  );
};

export default ToggleButton;
