import React from 'react';
import { useController } from 'react-hook-form';
import ButtonGroup from './ButtonGroup';

interface TypeSelectorProps {
  control: any;
  name: string;
}

const TypeSelector: React.FC<TypeSelectorProps> = ({ control, name }) => {
  const { field } = useController({ control, name });

  return (
    <ButtonGroup
      options={[
        { label: 'CTM', value: 'customer' },
        { label: 'WE', value: 'we' },
      ]}
      value={field.value}
      onChange={field.onChange}
    />
  );
};

export default TypeSelector;
