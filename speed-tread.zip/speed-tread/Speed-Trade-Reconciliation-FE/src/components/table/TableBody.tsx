import StatusBadge from '../StatusBadge';
import { HasId, tableBodyProps } from '../../interfaces/table';
import { useEffect, useState } from 'react';
import CustomCheckbox from '../formFields/CustomCheckbox';
import { distributeColumnWidths } from '../../utils/tableColumnsDistributeWidths';

const TableBody = <T extends HasId>({
  data,
  columns,
  tableName,
  isExpanded,
  rowSubComponent,
  selectedRows,
  onSelectRow,
  isSelected,
}: tableBodyProps<T>) => {
  const expanded = sessionStorage.getItem('expanded');
  const [expandedRow, setExpandedRow] = useState<string[]>(() => {
    const savedExpandedRow = sessionStorage.getItem('expandedRow');
    return expanded
      ? JSON.parse(expanded)
      : savedExpandedRow
        ? JSON.parse(savedExpandedRow)
        : [];
  });
  const [hoveredCell, setHoveredCell] = useState<string | null>(null);

  const [activeRow, setActiveRow] = useState<number | null>(null);

  const expandedHandler = (e: React.MouseEvent, key: string) => {
    const target = e.target as HTMLElement;
    if (target.closest('.dropdown-btn') || target.closest('.dot-menu')) {
      return;
    }
    setExpandedRow((prev: string[]) => {
      sessionStorage.removeItem('expanded');
      let updatedExpandedRow;
      if (prev.includes(key)) {
        updatedExpandedRow = prev.filter((item) => item !== key);
      } else {
        updatedExpandedRow = [key];
      }
      sessionStorage.setItem('expandedRow', JSON.stringify(updatedExpandedRow));
      return updatedExpandedRow;
    });
  };

  const handleRowSelection = (row: T) => {
    onSelectRow && onSelectRow(row.id);
  };

  useEffect(() => {
    if (!expanded) setExpandedRow([]);
    sessionStorage.removeItem('expandedRow');
  }, [data]);

  return (
    <div className="">
      {data?.length === 0 && (
        <div className="text-center py-4 text-gray-500" key="no-data">
          <p>No Data</p>
        </div>
      )}
      {data?.map((item, index) => {
        const rowKey = `${tableName}-body-data-${index}`;
        return (
          <div
            className={`divide-x divide-gray-200 border-gray-200 ${isExpanded ? 'expanded' : ''}  ${
              isExpanded && expandedRow.includes(rowKey) ? 'bg-gray-50' : ''
            }`}
            key={rowKey}
            onClick={() => setActiveRow(index)}
          >
            <div
              className={`flex ${isExpanded ? 'cursor-pointer' : ''} ${
                activeRow === index ? 'bg-gray-100' : ''
              }`}
              onClick={(e) => {
                isExpanded && expandedHandler(e, rowKey);
              }}
            >
              {isSelected && (
                <div
                  className="p-3 sticky left-0 flex pl-8"
                  key={`${rowKey}-checkbox`}
                >
                  <CustomCheckbox
                    checked={selectedRows?.some(
                      (selectedRow) => selectedRow.id === item.id,
                    )}
                    onChange={() => handleRowSelection(item)}
                  />
                </div>
              )}

              {isExpanded && (
                <div
                  key={`${rowKey}-arrow`}
                  className={`p-3 sticky left-0 bg-white transition-transform duration-200 ${
                    expandedRow.includes(rowKey) ? 'transform rotate-180' : ''
                  }`}
                >
                  <svg width="15" height="9" viewBox="0 0 15 9" fill="none">
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M1.1762 1.04395C1.59865 0.688203 2.2295 0.742276 2.58525 1.16472L7.26098 6.71716C7.35815 6.83254 7.44786 6.85309 7.50006 6.85309C7.55226 6.85309 7.64198 6.83254 7.73914 6.71716L12.4149 1.16472C12.7706 0.742276 13.4015 0.688203 13.8239 1.04395C14.2464 1.3997 14.3004 2.03055 13.9447 2.453L9.26896 8.00543C8.3172 9.13565 6.68292 9.13565 5.73116 8.00543L1.05542 2.453C0.699677 2.03055 0.75375 1.3997 1.1762 1.04395Z"
                      fill="#747474"
                    />
                  </svg>
                </div>
              )}

              {distributeColumnWidths(columns)?.map(
                (column: any, cellIndex) => {
                  let parts = column?.accessField.split('.');
                  let result =
                    parts &&
                    parts.reduce(
                      (obj: string, key: number) => obj?.[key],
                      item,
                    );

                  return (
                    <div
                      className={`table-body-cell px-6 py-4 text-sm text-gray-800 font-normal flex items-center ${column?.cellClassName || ''} ${
                        column?.thClassName || ''
                      } ${column?.fixed ? 'sticky bg-white z-10' : ''} ${
                        cellIndex === columns.length - 1 ? 'pr-8' : ''
                      }`}
                      style={{
                        left: column?.fixed ? column?.left : 'unset',
                        width: column.width,
                      }}
                      key={`${rowKey}-${column.accessField}-${cellIndex}`}
                    >
                      <div
                        className={`flex items-center gap-2 ${column.header === 'Amount' ? 'font-bold' : ''}`}
                      >
                        {column.accessField === 'status' ? (
                          <StatusBadge status={result} />
                        ) : column?.td ? (
                          column?.td({ row: item }, index, data)
                        ) : (
                          result
                        )}
                      </div>
                    </div>
                  );
                },
              )}
            </div>

            {isExpanded && (
              <div
                key={`${rowKey}-expanded`}
                className={`${expandedRow.includes(rowKey) ? 'p-4 bg-gray-50' : ''}`}
              >
                {expandedRow.includes(rowKey) &&
                  typeof rowSubComponent === 'function' &&
                  rowSubComponent(item)}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default TableBody;
