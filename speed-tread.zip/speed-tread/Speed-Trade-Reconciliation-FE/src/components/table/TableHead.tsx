import { tableHeadProps } from '../../interfaces/table';
import { distributeColumnWidths } from '../../utils/tableColumnsDistributeWidths';
import { CheckBoxInput } from '../formFields/CheckBoxInput';
import AscendingIcon from '../Images/AscendingIcon';
import DescendingIcon from '../Images/DescendingIcon';
import SortIcon from '../Images/SortIcon';

const TableHead = <T extends object>({
  columns,
  tableName,
  setSort,
  sort,
  onSelectAll,
  selectedRows,
  isSelected,
  data,
  defaultSort,
  isExpanded,
}: tableHeadProps<T>) => {
  const getSort = (fieldName: string) => {
    if (sort?.value === '' || sort?.field !== fieldName) return <SortIcon />;
    else if (sort?.value === 'ascending') return <AscendingIcon />;
    else if (sort?.value === 'descending') return <DescendingIcon />;
  };

  const handleSort = (fieldName: string) => {
    if (fieldName === sort?.field && setSort) {
      if (sort?.value === '') {
        setSort({ value: 'ascending', field: sort?.field });
      } else if (sort?.value === 'ascending') {
        setSort({ value: 'descending', field: sort?.field });
      } else if (sort?.value === 'descending') {
        setSort({ value: '', field: defaultSort || '' });
      }
    } else {
      if (setSort) setSort({ value: 'ascending', field: fieldName });
    }
  };

  return (
    <div className="flex border-b border-gray-200">
      {isSelected && (
        <div className="p-3 sticky top-0 flex pl-8">
          <CheckBoxInput
            checked={
              selectedRows &&
              data?.length > 0 &&
              selectedRows?.length === data.length
            }
            indeterminate={
              selectedRows &&
              data?.length > 0 &&
              selectedRows?.length > 0 &&
              selectedRows?.length < data.length
            }
            onChange={onSelectAll}
          />
        </div>
      )}
      {isExpanded && <div className="w-10 sticky top-0 bg-gray-50 "></div>}
      {distributeColumnWidths(columns)?.map((column, index) => {
        return (
          <div
            className={`table-head-cell px-6 py-4 font-semibold text-sm text-dark-blue tracking-wider flex items-center gap-2 ${
              column?.cellClassName || ''
            } ${column?.thClassName || ''} 
              ${column?.fixed ? 'sticky top-0 bg-white z-10' : ''}  ${
                index === columns.length - 1 ? 'pr-8' : ''
              }`}
            style={{ width: column.width }}
            key={`${tableName}-table-header-${column?.header}-${index}`}
          >
            <div
              className={`flex items-center gap-2 ${column?.isSort ? 'cursor-pointer' : ''}`}
            >
              <span
                onClick={() => {
                  column?.isSort && handleSort(column?.accessField);
                }}
              >
                {column?.th ? column?.th({ column }) : column?.header}
              </span>
              {column?.isSort && (
                <span
                  className="inline-block ml-2"
                  onClick={() => handleSort(column?.accessField)}
                >
                  {getSort(column?.accessField)}
                </span>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default TableHead;
