import { defaultDateFormat } from '../components/formFields/DateRangeInput';
import { DropdownItem } from '../interfaces/components';
import moment from 'moment-timezone';

export const CURRENCY_DROPDOWN_ITEMS: DropdownItem[] = [
  { label: 'Edit', action: 'edit' },
  { label: 'Delete', action: 'delete' },
];

export const getCurrencyPairDropdownItems = (
  isActive?: boolean,
): DropdownItem[] => {
  return [
    // { label: 'Edit', action: 'edit' },
    { label: 'Swap', action: 'swap' },
    { label: 'Delete', action: 'delete' },
    // { label: isActive ? 'InActive' : 'Active', action: 'status' },
  ];
};

export const CALCULATION_TYPE_DROPDOWN_OPTIONS = [
  { label: 'Multiply', value: 'multiply' },
  { label: 'Divide', value: 'divide' },
];

export const TRANSACTION_DETAIL_CARD_DROPDOWN_ITEMS = [
  { label: 'Edit', action: 'edit' },
  { label: 'Delete', action: 'delete' },
];

export const TRANSFER_BY_DROPDOWN_ITEMS = [
  { label: 'We', value: 'we' },
  { label: 'Customer', value: 'customer' },
];

export const ADD_ORDER_MODAL = [
  { label: 'Buy', value: 'buy' },
  { label: 'Transfer', value: 'transfer' },
  { label: 'Adjustment', value: 'adjustment' },
];

export const ALL_DATA_FOR_ADD_TRANSACTION_MODAL = [
  { label: 'Sell', value: 'sell' },
  { label: 'Transfer', value: 'transfer' },
  { label: 'Adjustment', value: 'adjustment' },
];

export const SELL_DATA_FOR_ADD_TRANSACTION_MODAL = [
  { label: 'Sell', value: 'sell' },
];

export const ORDER_CARD_DROPDOWN_OPTIONS = [
  { label: 'Edit', action: 'edit' },
  { label: 'Delete', action: 'delete' },
];

export const groupMoreOption = (sliderType: string) => {
  return [
    { label: 'Edit Group', action: 'edit' },
    // {
    //   label: `Add ${sliderType === 'order' ? 'Order' : 'Transaction'}`,
    //   action: 'add',
    // },
    { label: 'Edit Currency', action: 'reorder' },
  ];
};

export const orderedByOptions = [
  { label: 'All Parties', value: 'all' },
  { label: 'We', value: 'we' },
  { label: 'Customer', value: 'customer' },
];

export const settlementTypeOptions = [
  { label: 'By Currency', value: 'currency' },
  { label: 'By Customer', value: 'customer' },
];

const today = moment
  .tz(process.env.REACT_APP_TIMEZONE as string)
  .format(defaultDateFormat); // Use moment.tz
const yesterday = moment
  .tz(process.env.REACT_APP_TIMEZONE as string)
  .subtract(1, 'days')
  .format(defaultDateFormat); // Use moment.tz

export const dateOptions = [
  { label: 'Today', value: today },
  { label: 'Yesterday', value: yesterday },
];
