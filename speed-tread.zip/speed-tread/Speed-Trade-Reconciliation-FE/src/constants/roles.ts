export const ROLES = {
  TRANSACTION_MANAGER: 'transfer_manager',
  ORDER_MANAGER: 'order_manager',
  MANAGEMENT: 'management',
  AGENT: 'agent',
};
