export const validations_field = {
  groupNameMin: 1,
  groupNamemax: 150,
  remarksMax: 150,
  accNameMin: 1,
  accNamemax: 50,
};
