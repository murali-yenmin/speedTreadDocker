import axios, { AxiosResponse, AxiosError } from 'axios';
import { store } from '../store/store';
import { showErrorModal } from '../store/slices/errorSlice';
import { showErrorToast } from '../utils/toast';

const BASE_URL =
  process.env.REACT_APP_API_URL || 'http://localhost:3000/api/v1/';

// Create axios instance with baseURL
const api = axios.create({
  baseURL: BASE_URL, // <- automatically prepends this to all requests
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error),
);

// Response interceptor
api.interceptors.response.use(
  (response: AxiosResponse) => response,
  (error: AxiosError) => {
    if (error.response) {
      const { status, data } = error.response as {
        status: number;
        data: { message?: string };
      };
      const errorData = error.response?.data as {
        data?: { login: boolean };
        message?: string;
      };

      if (errorData?.data?.login === false) {
        showErrorToast(errorData?.message);
        return Promise.reject(error);
      }

      switch (status) {
        case 401:
          store.dispatch(
            showErrorModal({
              errorCode: 401,
              message: 'You are not authorized to access this page.',
            }),
          );
          break;
        case 403:
          store.dispatch(
            showErrorModal({
              errorCode: 403,
              message: 'You do not have permission to access this page.',
            }),
          );
          break;
        case 404:
          store.dispatch(
            showErrorModal({
              errorCode: 404,
              message: 'The page you are looking for does not exist.',
            }),
          );
          break;
        case 500:
          store.dispatch(
            showErrorModal({
              errorCode: 500,
              message: 'Something went wrong. Please try again later.',
            }),
          );
          break;
        default:
          // For other errors, you might want to show a generic error message
          // or handle them differently.
          break;
      }
    } else if (error.request) {
      store.dispatch(
        showErrorModal({
          errorCode: 503,
          message:
            'Service is temporarily unavailable. Please try again later.',
        }),
      );
    } else {
      console.error('Error setting up API request:', error.message);
    }
    return Promise.reject(error);
  },
);

import { trimObjectStrings } from '../utils/objectUtils';

// Reusable API methods
export const get = (url: string, params?: object) => {
  if (url.includes('search=')) {
    const urlParts = url.split('search=');
    const searchValue = urlParts[1];
    const trimmedSearchValue = searchValue.trim();
    url = urlParts[0] + 'search=' + trimmedSearchValue;
  }
  return api.get(url, { params });
};
export const post = (url: string, data?: object) =>
  api.post(url, data ? trimObjectStrings(data) : data);
export const put = (url: string, data?: object) =>
  api.put(url, data ? trimObjectStrings(data) : data);
export const del = (url: string, params?: object) =>
  api.delete(url, { params });

export default api;
