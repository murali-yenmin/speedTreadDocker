import { ResetPasswordCredentials } from './../store/interfaces/authentication';
import {
  ForgotCredentials,
  LoginCredentials,
} from '../store/interfaces/authentication';
import {
  AddBulkTransactionPayload,
  AddTransactionPayload,
  AmountOverviewPayload,
  EditTransactionPayload,
} from '../store/interfaces/transaction';
import {
  AddOrderTransactionPayload,
  CompleteOrderTransactionPayload,
  EditOrderTransactionPayload,
} from '../store/interfaces/orderTransaction';
import { UpdateOrderPayload } from '../store/interfaces/order';
import { get, post, put, del } from './api';
import { API_ENDPOINTS } from './backend_url';
import { GetProps } from '../interfaces/files';
import { ReOrderCurrencyPayload } from '../interfaces/order';
import { SettlementDetailsPayload } from '../store/interfaces/settlement';

// Example API functions
export const auth = {
  login: (credentials: LoginCredentials) =>
    post(API_ENDPOINTS.LOGIN, credentials),
  forgotPassword: (payload: ForgotCredentials) =>
    post(API_ENDPOINTS.FORGOT_PASSWORD, payload),
  resetPassword: (payload: ResetPasswordCredentials) =>
    post(API_ENDPOINTS.RESET_PASSWORD, payload),
  changePassword: (payload: any) =>
    post(API_ENDPOINTS.CHANGE_PASSWORD, payload), // New function
  regeneratePassword: (payload: { email_address: string }) =>
    post(API_ENDPOINTS.REGENERATE_PASSWORD, payload), // New function
};

export const users = {
  getAllUsers: () => get(API_ENDPOINTS.GET_USERS),
  getRoles: () => get(API_ENDPOINTS.GET_ROLES),
  getUserById: (id: string) => get(`${API_ENDPOINTS.GET_USERS}/${id}`),
  createUser: (userData: object) => post(API_ENDPOINTS.CREATE_USER, userData),
  updateUser: (id: string, userData: object) =>
    put(`${API_ENDPOINTS.GET_USERS}/${id}`, userData),
  deleteUser: (id: string) => del(`${API_ENDPOINTS.GET_USERS}/${id}`),
  getUsersList: (payload: any) => post(API_ENDPOINTS.GET_ALL_USERS, payload),
  editUser: (payload: any) => put(API_ENDPOINTS.EDIT_USER, payload),
  updateUserStatus: (unique_id: string, is_active: boolean) =>
    put(API_ENDPOINTS.UPDATE_USER_STATUS, { unique_id, is_active }),
  getUserProfile: () => get(API_ENDPOINTS.GET_USER_PROFILE),
  updateUserProfile: (payload: any) =>
    put(API_ENDPOINTS.UPDATE_USER_PROFILE, payload), // New function
};

export const settings = {
  getAllMediaSources: () => get(API_ENDPOINTS.GET_ALL_MEDIA_SOURCES),
  addMediaSource: (sourceData: { label: string }) =>
    post(API_ENDPOINTS.ADD_MEDIA_SOURCE, sourceData),
  updateMediaSourceStatus: (payload: {
    unique_id: string;
    is_active: boolean;
  }) => put(`${API_ENDPOINTS.UPDATE_MEDIA_SOURCE_STATUS}`, payload),
  getAllCurrencies: (search?: string) =>
    get(
      `${API_ENDPOINTS.GET_ALL_CURRENCIES}${search ? '?search=' + search : ''}`,
    ),
  addCurrency: (currencyData: { name: string; code: string }) =>
    post(API_ENDPOINTS.ADD_CURRENCY, currencyData),
  updateCurrency: (currencyData: {
    name: string;
    code: string;
    unique_id: string;
  }) => put(`${API_ENDPOINTS.UPDATE_CURRENCY}`, currencyData),
  updateCurrencyStatus: (id: string, status: { enabled: boolean }) =>
    put(`${API_ENDPOINTS.UPDATE_CURRENCY_STATUS}/${id}/status`, status),
  getAllCurrencyPairs: () => get(API_ENDPOINTS.GET_ALL_CURRENCY_PAIRS),
  getAllFilterCurrencyPairs: (id?: string) =>
    get(
      `${API_ENDPOINTS.GET_ALL_CURRENCY_PAIRS}${id ? '?currencyId=' + id : ''}`,
    ),
  addCurrencyPair: (currencyPairData: {
    from: string;
    to: string;
    is_greater: boolean;
  }) => post(API_ENDPOINTS.ADD_CURRENCY_PAIR, currencyPairData),
  updateCurrencyPair: (payload: {
    unique_id: string;
    is_active?: boolean;
    buy_currency_id?: string;
    sell_currency_id?: string;
    calculation_type?: string;
  }) => put(`${API_ENDPOINTS.UPDATE_CURRENCY_PAIR_STATUS}`, payload),
  swapCurrencyPair: (payload: {
    unique_id: string;
  }) => put(API_ENDPOINTS.SWAP_CURRENCY_PAIR, payload),
  getPairedCurrencies: (payload: { settlement_currency: string }) =>
    post(API_ENDPOINTS.GET_PAIRED_CURRENCIES, payload),

  getAllFilterSearchCurrencies: (search?: string) =>
    get(
      `${API_ENDPOINTS.GET_ALL_CURRENCIES}${search ? '?search=' + search : ''}`,
    ),

  deleteCurrencyPair: (currencyData: { id: string }) =>
    del(API_ENDPOINTS.ADD_CURRENCY_PAIR + '/' + currencyData.id),
};

export const groups = {
  addGroup: (groupData: {
    name: string;
    settlement_currency: string;
    group_id: string;
  }) => post(API_ENDPOINTS.BASE_GROUP, groupData),
  getAllGroups: (payload: GetProps) =>
    post(API_ENDPOINTS.GET_ALL_GROUPS, payload),
  updateGroup: (groupData: {
    unique_id: string;
    name: string;
    settlement_currency?: string;
    is_favorite?: boolean;
  }) => put(`${API_ENDPOINTS.UPDATE_GROUP}`, groupData),
  orderGroupGetAll: (payload: GetProps) =>
    post(API_ENDPOINTS.ORDER_VIEW_GROUP, payload),
  getOrderGroups: (search?: string) =>
    get(`${API_ENDPOINTS.BASE_GROUP}?search=${search}`),
  getGroupByUniqueId: (groupId: string) =>
    get(`${API_ENDPOINTS.CURRENCY_ORDER}/${groupId}`),
  getGroupByUniqueIdTransactionFlow: (groupId: string) =>
    get(
      `${API_ENDPOINTS.CURRENCY_ORDER}/${API_ENDPOINTS.ADD_TRANSACTION}/${groupId}`,
    ),
  currencyReorder: (payload: ReOrderCurrencyPayload) =>
    post(API_ENDPOINTS.CURRENCY_ORDER_UPSET, payload),
  getTransactionGroupById: (id: string) =>
    get(`${API_ENDPOINTS.GET_TRANSACTION_GROUP_BY_ID}/${id}`),
  getOrderGroupById: (id: string) => get(`${API_ENDPOINTS.BASE_GROUP}/${id}`),
};

export const transactions = {
  addTransaction: (transactionData: AddTransactionPayload) =>
    post(API_ENDPOINTS.ADD_TRANSACTION, transactionData),
  getAllTransactions: (payload: GetProps) =>
    post(API_ENDPOINTS.GET_ALL_TRANSACTIONS, payload),
  getAmountOverview: (payload: AmountOverviewPayload) =>
    post(API_ENDPOINTS.GET_AMOUNT_OVERVIEW, payload),
  editTransaction: (transactionData: EditTransactionPayload) =>
    put(API_ENDPOINTS.EDIT_TRANSACTION, transactionData),
  getGroupBasedCurrencies: (id: string) =>
    get(`${API_ENDPOINTS.GET_GROUP_BASED_CURRENCIES}/${id}`),
  getTransactionSellCurrencies: (payload: {
    group_id: string;
    settlement_currency: string;
  }) => post(API_ENDPOINTS.GET_TRANSACTION_SELL_CURRENCIES, payload),
  deleteTransaction: (transactionData: { id: string }) =>
    del(API_ENDPOINTS.ADD_TRANSACTION + '/' + transactionData.id),
  getTransactionById: (id: string) =>
    get(`${API_ENDPOINTS.GET_TRANSACTION_BY_ID}/${id}`),
  addBulkTransaction: (transactionData: AddBulkTransactionPayload) =>
    post(API_ENDPOINTS.ADD_BULK_TRANSACTION, transactionData),
  getExportTransactions: (payload: {
    group_id: string;
    settlement_currency: string;
  }) => post(API_ENDPOINTS.TRANSACTION_GROUP_CURRENCY, payload),
  deleteMultipleTransactions: (payload: { ids: string[] }) =>
    put(API_ENDPOINTS.DELETE_MULTIPLE_TRANSACTIONS, payload),
};

export const order = {
  addOrder: (orderData: any) => post(API_ENDPOINTS.ADD_ORDER, orderData),
  getAllOrders: (payload: GetProps) =>
    post(API_ENDPOINTS.GET_ALL_ORDERS, payload),
  getAllReportOrders: (payload: GetProps) =>
    post(API_ENDPOINTS.GET_ALL_ORDERS_REPORTS, payload),
  updateOrder: (orderData: UpdateOrderPayload) =>
    put(API_ENDPOINTS.UPDATE_ORDER, orderData),
  getOrderSellCurrencies: (payload: {
    group_id: string;
    settlement_currency: string;
  }) => post(API_ENDPOINTS.GET_ORDER_SELL_CURRENCIES, payload),
  getOrderStatus: () => get(`${API_ENDPOINTS.ORDER_STATUS}`),
  deleteOrderTransaction: (transactionData: { id: string }) =>
    del(API_ENDPOINTS.ORDER_TRANSACTION + '/' + transactionData.id),
  deleteOrder: (transactionData: { id: string }) =>
    del(API_ENDPOINTS.ADD_ORDER + '/' + transactionData.id),
  deleteMultipleOrders: (payload: { ids: string[] }) =>
    post(API_ENDPOINTS.DELETE_MULTIPLE_ORDERS, payload),
  getOrderById: (id: string) => get(`${API_ENDPOINTS.GET_ORDER_BY_ID}/${id}`),
  getOrderDateStatus: (payload: {
    group_id: string;
    settlement_currency: string;
  }) => post(API_ENDPOINTS.ORDER_DATE_STATUS, payload),
};

export const orderTransaction = {
  addOrderTransaction: (orderTransactionData: AddOrderTransactionPayload) =>
    post(API_ENDPOINTS.ADD_ORDER_TRANSACTION, orderTransactionData),
  editOrderTransaction: (orderTransactionData: EditOrderTransactionPayload) =>
    put(API_ENDPOINTS.EDIT_ORDER_TRANSACTION, orderTransactionData),
  getGroupBasedOrderCurrencies: (id: string) =>
    get(`${API_ENDPOINTS.GET_GROUP_BASED_ORDER_CURRENCIES}/${id}`),
  completeOrder: (payload: CompleteOrderTransactionPayload) =>
    post(API_ENDPOINTS.COMPLETE_ORDER, payload),
  getAddTransRemindBal: (payload: {
    order_id: string;
    transaction_id?: string;
  }) => post(API_ENDPOINTS.REMAINING_BALANCE, payload),
  getOrderTransactionById: (id: string) =>
    get(`${API_ENDPOINTS.GET_ORDER_TRANSACTION_BY_ID}/${id}`),
};

export const accounts = {
  getAccountNames: (query: string) =>
    get(
      `${API_ENDPOINTS.GET_ACCOUNTS}?search=${query}&limit=${process.env.REACT_APP_ACCOUNT_NAME_LIMIT}`,
    ),
};

export const settlement = {
  getSettlementDetails: (payload: SettlementDetailsPayload, role: string) =>
    post(
      role === 'order'
        ? API_ENDPOINTS.LIST_ORDERS_GROUP_CALCULATION
        : API_ENDPOINTS.LIST_GROUP_CALCULATION,
      payload,
    ),
};

// Add more categories of API functions as needed (e.g., products, orders)
