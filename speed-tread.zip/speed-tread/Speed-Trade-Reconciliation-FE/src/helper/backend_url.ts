export const API_ENDPOINTS = {
  // Authentication
  LOGIN: `secure/login`,
  FORGOT_PASSWORD: `secure/forgot-password`,
  RESET_PASSWORD: `secure/verify-forgot`,

  // Users
  GET_USERS: `users`,
  GET_ROLES: `roles`,
  CREATE_USER: `user`,
  GET_ALL_USERS: `user/get-all`,
  EDIT_USER: `user`,
  UPDATE_USER_STATUS: `user/status`,
  GET_USER_PROFILE: `secure/profile-details`,
  UPDATE_USER_PROFILE: `user`, // New endpoint for updating user profile
  CHANGE_PASSWORD: `secure/change-password`,
  REGENERATE_PASSWORD: `secure/regenerate-password`,

  // Source
  GET_ALL_MEDIA_SOURCES: `media-source`,
  ADD_MEDIA_SOURCE: `media-source`,
  UPDATE_MEDIA_SOURCE_STATUS: `media-source`,

  // Currency
  GET_ALL_CURRENCIES: `currencies/get-all`,
  ADD_CURRENCY: `currencies`,
  UPDATE_CURRENCY_STATUS: `currencies`,
  UPDATE_CURRENCY: `currencies`,

  // Currency Pair
  GET_ALL_CURRENCY_PAIRS: `currency-pair`,
  ADD_CURRENCY_PAIR: `currency-pair`,
  UPDATE_CURRENCY_PAIR_STATUS: `currency-pair`,
  SWAP_CURRENCY_PAIR: `currency-pair/swap`,
  GET_PAIRED_CURRENCIES: `currencies/sellable-for`,
  CURRENCY_ORDER: `currency-order`,
  CURRENCY_ORDER_UPSET: `currency-order/bulk-upsert`,

  // Groups
  BASE_GROUP: `groups`,
  GET_ALL_GROUPS: `groups/get-all`,
  UPDATE_GROUP: `groups`,
  ORDER_VIEW_GROUP: `groups/order-view`,
  GET_TRANSACTION_GROUP_BY_ID: `groups/group-details`,

  // Transactions
  ADD_TRANSACTION: `transaction`,
  GET_ALL_TRANSACTIONS: `transaction/get-all`,
  GET_AMOUNT_OVERVIEW: 'transaction/overall-amount',
  EDIT_TRANSACTION: 'transaction',
  GET_GROUP_BASED_CURRENCIES: 'transaction/currencies',
  GET_TRANSACTION_SELL_CURRENCIES: 'transaction/cumulative-currencies',
  GET_TRANSACTION_BY_ID: 'transaction/details',
  ADD_BULK_TRANSACTION: `transaction/multi`,
  TRANSACTION_GROUP_CURRENCY: `transaction/group-currency`,
  DELETE_MULTIPLE_TRANSACTIONS: 'transaction/multi',

  // Order
  ADD_ORDER: 'order',
  GET_ALL_ORDERS: 'order/get-all',
  UPDATE_ORDER: 'order',
  GET_ORDER_SELL_CURRENCIES: 'order/cumulative-currencies',
  ORDER_STATUS: 'order/status',
  GET_ALL_ORDERS_REPORTS: 'order/get-all-report',
  ORDER_TRANSACTION: 'order-transaction',
  GET_ORDER_BY_ID: 'order/details',
  GET_ORDER_TRANSACTION_BY_ID: 'order-transaction/details',
  ORDER_DATE_STATUS: 'order/date-status',
  DELETE_MULTIPLE_ORDERS: 'order/multi',

  // Order Transaction
  ADD_ORDER_TRANSACTION: 'order-transaction',
  EDIT_ORDER_TRANSACTION: 'order-transaction',
  GET_GROUP_BASED_ORDER_CURRENCIES: 'order-transaction/order-currencies',
  COMPLETE_ORDER: 'order-transaction/full-pay',
  REMAINING_BALANCE: 'order-transaction/remaining-balance',

  // Account Names
  GET_ACCOUNTS: 'accounts',

  // Settlement
  LIST_GROUP_CALCULATION: 'transaction/list-group-calculation',
  LIST_ORDERS_GROUP_CALCULATION: 'order-transaction/list-based-on-group-currency',

  // Add more endpoints as needed
};
