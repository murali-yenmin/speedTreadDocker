import { useEffect, useState } from 'react';

/**
 * Hook to track horizontal scroll percentage of an element
 * @param className - The class name of the element to watch
 * @returns scroll percentage (0 - 100)
 */
export const useHorizontalScroll = (className: string) => {
  const [scrollPercent, setScrollPercent] = useState(0);

  useEffect(() => {
    const element = document.querySelector<HTMLElement>(`.${className}`);
    if (!element) return;

    const handleScroll = () => {
      const maxScroll = element.scrollWidth - element.clientWidth;
      const percent = maxScroll ? (element.scrollLeft / maxScroll) * 100 : 0;
      setScrollPercent(percent);
    };

    element.addEventListener('scroll', handleScroll);
    handleScroll(); // initialize

    return () => {
      element.removeEventListener('scroll', handleScroll);
    };
  }, [className]);

  return scrollPercent;
};
