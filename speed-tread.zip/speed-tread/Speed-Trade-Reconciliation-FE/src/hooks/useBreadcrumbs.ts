import { useLocation } from 'react-router-dom';
import { breadcrumbConfig, breadcrumbParents } from '../utils/breadcrumbConfig';

interface BreadcrumbItem {
  label: string;
  link?: string;
}

const useBreadcrumbs = (
  customLabels?: Record<string, string>,
): BreadcrumbItem[] => {
  const location = useLocation();
  const pathnames = location.pathname.split('/').filter((x) => x);

  const breadcrumbs: BreadcrumbItem[] = [];

  // Build breadcrumbs from current path up to the root
  let currentPath = location.pathname;
  while (currentPath) {
    const label = customLabels?.[currentPath] || breadcrumbConfig[currentPath];
    if (label) {
      let itemLink = currentPath;
      if (
        currentPath === '/settings' &&
        (location.pathname.startsWith('/settings/currency') ||
          location.pathname.startsWith('/settings/social-media'))
      ) {
        itemLink = '/settings/currency';
      }
      breadcrumbs.unshift({
        label: label,
        link: itemLink,
      });
    }
    currentPath = breadcrumbParents[currentPath] || '';
  }

  // Ensure Dashboard is always the first item if it's a parent
  if (breadcrumbs.length > 0 && breadcrumbs[0].link !== '/dashboard') {
    const dashboardItem = { label: 'Dashboard', link: '/dashboard' };
    breadcrumbs.unshift(dashboardItem);
  }

  return breadcrumbs;
};

export default useBreadcrumbs;
