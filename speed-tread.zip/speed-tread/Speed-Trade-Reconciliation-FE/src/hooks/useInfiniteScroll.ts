import { useState, useRef, useCallback, useEffect } from 'react';

interface UseInfiniteScrollProps<T> {
  fetcher: (page: number) => Promise<T[]>;
  itemsPerPage: number;
}

export const useInfiniteScroll = <T>({
  fetcher,
  itemsPerPage,
}: UseInfiniteScrollProps<T>) => {
  const [page, setPage] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [initialized, setInitialized] = useState(false);

  const observer = useRef<IntersectionObserver | null>(null);

  const lastElementRef = useCallback(
    (node: HTMLElement | null) => {
      if (isLoading || !initialized) return;

      if (observer.current) observer.current.disconnect();

      observer.current = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && hasMore) {
          setPage((prev) => prev + 1);
        }
      });

      if (node) observer.current.observe(node);
    },
    [isLoading, hasMore, initialized],
  );

  useEffect(() => {
    const load = async () => {
      setIsLoading(true);
      const newItems = await fetcher(page);
      if (!newItems || newItems.length < itemsPerPage) {
        setHasMore(false);
      }
      setIsLoading(false);
      setInitialized(true); // first load completed
    };

    // only load if we have more data
    if (hasMore) {
      load();
    }
  }, [page, fetcher, itemsPerPage, hasMore]);

  const reset = useCallback(() => {
    setPage(1);
    setHasMore(true);
    // setInitialized(false);
  }, []);

  return { isLoading, lastElementRef, hasMore, reset };
};
