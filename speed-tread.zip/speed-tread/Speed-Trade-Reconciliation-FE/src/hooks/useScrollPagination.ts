import { useEffect, useState, RefObject } from 'react';

interface UseScrollPaginationProps {
  ref: RefObject<HTMLElement> | any;
  trigger: (nextPage: number) => void;
  maxPage: number;
  isLoading: boolean;
  distance?: number;
}

export const useScrollPagination = ({
  ref,
  trigger,
  maxPage,
  isLoading,
  distance = 100,
}: UseScrollPaginationProps) => {
  const [page, setPage] = useState(1);

  useEffect(() => {
    const element = ref.current;

    const handleScroll = () => {
      if (!element || isLoading || page >= maxPage) {
        return;
      }

      const { scrollHeight, scrollTop, clientHeight } = element;

      const isNearBottom = scrollHeight - scrollTop - clientHeight <= distance;

      if (isNearBottom) {
        const nextPage = page + 1;
        trigger(nextPage);
        setPage(nextPage);
      }
    };

    if (element) {
      element.addEventListener('scroll', handleScroll);
    }

    return () => {
      if (element) {
        element.removeEventListener('scroll', handleScroll);
      }
    };
  }, [ref, trigger, maxPage, isLoading, distance, page]);

  const reset = () => {
    setPage(1);
  };

  return { page, reset };
};
