import { useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { AppDispatch } from '../store/store';
import { fetchUserListThunk } from '../store/thunks/userList';
import {
  UserListItem,
  UserListPayload,
} from '../store/interfaces/user/userList';

interface UseUserListFetcherProps {
  appliedFilters: {
    operation: string;
    fieldName: string;
    fieldString: string | string[];
  }[];
  debouncedSearchQuery: string;
  sort: { field: string; value: string };
  pageSize: number;
}

export const useUserListFetcher = ({
  appliedFilters,
  debouncedSearchQuery,
  sort,
  pageSize,
}: UseUserListFetcherProps) => {
  const dispatch: AppDispatch = useDispatch();

  const fetcher = useCallback(
    async (page: number): Promise<UserListItem[]> => {
      const allFilters = [...appliedFilters];
      if (debouncedSearchQuery) {
        allFilters.push(
          {
            operation: '%',
            fieldName: 'user_name',
            fieldString: debouncedSearchQuery,
          },
          {
            operation: '%',
            fieldName: 'email_address',
            fieldString: debouncedSearchQuery,
          },
        );
      }

      const payload: UserListPayload = {
        cp: page,
        pl: pageSize,
        sort: sort,
        query: allFilters,
      };

      const result = await dispatch(fetchUserListThunk(payload));
      if (fetchUserListThunk.fulfilled.match(result)) {
        return result.payload.users;
      } else {
        return [];
      }
    },
    [dispatch, appliedFilters, debouncedSearchQuery, sort, pageSize],
  );

  return fetcher;
};
