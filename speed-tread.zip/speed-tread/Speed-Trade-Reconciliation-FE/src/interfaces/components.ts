import { Group } from '../store/interfaces/group';
import { Currency } from './currency';
import { Order } from '../interfaces/order';

export interface OrderCardProps {
  order: Order;
}

export interface CardProps {
  data: {
    id: string;
    name: string;
    closingDate: string;
    currencies: Currency[];
    favorite: boolean;
  };
  onFavoriteClick?: () => void;
}

export interface FavoriteIconProps {
  isFavorite: boolean;
  onClick?: () => void;
  width?: string;
  height?: string;
  hoverEffect?: boolean;
}

export interface BreadcrumbProps {
  items: {
    label: React.ReactNode;
    link?: string;
  }[];
}

export interface NewOrderState {
  order_for: 'us' | 'customer';
  buy: string;
  sell: string;
  amount: number;
  rate: number;
}

export interface NewOrderFormProps {
  initialBuyCurrency?: string;
}

export interface Tab {
  id: string;
  label: string;
  content: React.ReactNode;
}

export interface TabsProps {
  tabs: Tab[];
  activeTab: string;
  onTabChange: (tabId: string) => void;
}

export type ButtonVariant = 'primary' | 'secondary';

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: ButtonVariant;
  className?: string;
  isLoading?: boolean;
  fullWidth?: boolean;
}

export interface LoaderProps {
  dotColor?: string;
}

export interface BadgeProps {
  children: React.ReactNode;
  color?: 'gray' | 'green' | 'red';
}

export interface ProtectedRouteProps {
  children: React.ReactNode;
  isAuthenticated: boolean;
  allowedRoles?: string[];
}

export interface UserCardProps {
  user: {
    id: string;
    name: string;
    role: string;
    email: string;
    phoneNumber: string;
    isActive: boolean;
  };
}

export interface DecodedToken {
  exp: number;
  role: {
    access: string;
    created_at: string;
    description: string;
    is_active: true;
    is_deleted: true;
    role_type: string;
    unique_id: string;
    updated_at: string;
  };
  [key: string]: any;
}

export interface AuthLayoutProps {
  children: React.ReactNode;
}

export interface HeaderProps {
  toggleSidebar: () => void;
  isMobile: boolean;
  toggleSettlementModal: () => void;
}

export interface LayoutProps extends AuthLayoutProps {}

export interface MenuItem {
  name: string;
  path: string;
  icon?: React.ReactNode;
  subItems?: MenuItem[];
  roles?: string[];
  isModal?: boolean;
}

export interface SidebarProps {
  isSidebarOpen: boolean;
  toggleSidebar: () => void;
  isSidebarCollapsed: boolean;
  isMobile: boolean;
  toggleSettlementModal: () => void;
}
export interface User {
  id: string;
  name: string;
  role: string;
  email: string;
  phoneNumber: string;
  isActive: boolean;
}

export interface DropdownItem {
  label: string;
  action: string;
  disabled?: boolean;
}

export interface ThreeDotDropdownProps {
  items: DropdownItem[];
  onAction: (action: string, itemData?: any) => void;
}

export interface SocialMediaSource {
  name: string;
  enabled: boolean;
}

export interface AddGroupModalProps {
  isOpen: boolean;
  onClose: () => void;
  settlementCurrency?: string;
  groupId?: string;
  onDataUpdate?: () => void;
  context?: 'order' | 'transaction';
}

export interface AddGroupFormData {
  name: string;
  settlement_currency: string;
  group_id: string;
}

import { Transaction } from '../store/interfaces/transaction';

export interface AddTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  id?: string;
  name?: string;
  settlementCurrency?: string;
  group_uniqueId?: string;
  transactionId?: string;
  showSettlementCurrency?: boolean;
  selectedDate?: string;
}

export interface AddTransactionFormData {
  isMultiOrder: boolean;
  settlementCurrency: string;
  type: string;
  account: string;
  sell?: number | string | undefined;
  trading: string;
  currency?: string;
  rate?: string | undefined;
  remarks?: string | null | undefined;
  fee?: number | null;
  orders?: {
    amount: number | undefined;
    currency: string;
    rate: number | undefined;
    accountName?: string;
    remarks?: string;
    fee?: number | null;
  }[];
}

export interface AddOrderTransactionFormData {
  settlementCurrency: string;
  type: string;
  account?: string | null;
  sell: number | string | null;
  trading: string;
  currency?: string;
  rate?: string | null;
  remarks?: string | null;
  fee?: number | null;
}

export interface AddOrderTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  id?: string;
  name?: string;
  settlementCurrency?: string;
  group_uniqueId?: string;
  transactionId?: string;
  order_uniqueId: string;
  selectedDate?: string;
  sellCurrency?: string;
  order_by: string;
  trading?: string;
  rate?: number;
}

export interface AccordionProps {
  header: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  isSelectMode?: boolean;
  onSelect?: () => void;
  checked?: boolean;
}

export interface CurrencyItemProps {
  currency: Currency;
  groupId: string;
  groupName: string;
  group_uniqueId: string;
  sliderType: 'transaction' | 'order';
  onDataUpdate?: () => void;
  is_favorite?: boolean;
}

export interface GroupCardProps {
  group: Group;
  sliderType: 'transaction' | 'order';
  onDataUpdate?: () => void;
}

export interface OrderSliderProps {
  groupId: string;
  groupName: string;
  settlementCurrency: string;
  onClose: () => void;
  currency: Currency;
  group_uniqueId: string;
  onUpdate?: () => void;
  is_favorite?: boolean;
}

export interface OrderSliderModalProps {
  isOpen: boolean;
  onClose: () => void;
  groupId: string;
  groupName: string;
  settlementCurrency: string;
  currency: Currency;
  group_uniqueId: string;
}

export interface AddOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  groupId: string;
  groupName: string;
  settlementCurrency?: string;
  group_uniqueId: string;
  onOrderAdded?: () => void;
  selectedDate?: string;
}

export interface EditOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderId: string;
  onOrderUpdated?: () => void;
}

export interface PageTitleProps {
  title: string;
}

export interface OrderSummary {
  group: {
    name: string;
    group_id: string;
  };
  currencies: {
    currency: string;
    total_amount: string;
    orders: {
      order_id: string;
      ordered_date: string;
      amount: string;
      order_by: string;
      account_name: string;
      rate?: string;
      remarks?: string;
      currency: string;
      settlement_currency: string;
    }[];
  }[];
}

export interface OrderSummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderSummary: OrderSummary;
}
