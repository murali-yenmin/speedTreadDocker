import { CurrencyProps } from '../store/interfaces/settings';
export interface Currency {
  status: 'owe_us' | 'we_owe' | 'all_clear';
  value: number;
  currency: string;
  is_mismatch?: boolean;
  changes_required?: number;
  currency_id?: string;
  processing?:string;
  transferring?:string;
  error?:string
}

export interface CurrencyPairListProps {
  isLoading: boolean;
  isUpdateLoading: boolean;
  currencies: CurrencyProps[]; // Pass all currencies for dropdown options
  resetCurrencyPairFilter: number;
  getAllCb?: () => void;
}
