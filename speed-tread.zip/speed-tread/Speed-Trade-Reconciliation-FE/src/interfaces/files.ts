/**
 * sample:
 * for search - {"operation":"%","fieldName":"the field name you want to filter","fieldString":"the partial or exact value to filter"}
 * for exact filter - {"operation":"eq","fieldName":"the field name you want to filter","fieldString":"the exact value to filter"},
 */
interface QueryProps {
  operation: string;
  fieldName: string;
  fieldString: string | string[] | number | boolean;
}

export interface GetProps {
  cp: number;
  pl: number;
  query: QueryProps[];
  date?: string;
  from_date?: string;
  to_date?: string;
  sort?: {
    field: string;
    value: string;
  };
}
