export interface FilterOption {
  label: string;
  value: string;
  fieldName: string;
}
