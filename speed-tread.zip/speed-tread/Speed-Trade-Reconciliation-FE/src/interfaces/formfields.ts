import { FieldValues, UseControllerProps } from 'react-hook-form';
import { MultiValue, SingleValue } from 'react-select';

export interface CheckboxProps {
  label?: string;
  name: string;
  control: any; // react-hook-form control
  error?: any; // react-hook-form error object
  required?: boolean;
  parentClassName?: string;
  labelClassName?: string;
  defaultSelected?: boolean;
  disabled?: boolean;
  onChange?: (checked: boolean) => void;
}

export interface CheckBoxInputProps {
  checked?: boolean;
  indeterminate?: boolean;
  onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

export interface CustomCheckboxProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: React.ReactNode;
  indeterminate?: boolean;
}

export interface ErrorMessageProps {
  errors: string[];
  className?: string;
}

export interface InputProps<T extends FieldValues>
  extends UseControllerProps<T> {
  label: string;
  type?: React.HTMLInputTypeAttribute;
  placeholder?: string;
  className?: string;
  inputClassName?: string;
  required?: boolean;
  rightAddon?: React.ReactNode;
  prefix?: React.ReactNode;
  maxLength?: number;
  onKeyPress?: (event: React.KeyboardEvent<HTMLInputElement>) => void;
  onChange?: (value: string) => void;
  error?: string; // Added error prop
  readOnly?: boolean;
  disabled?: boolean;
  onFocus?: (event: React.FocusEvent<HTMLInputElement, Element>) => void;
  onBlur?: (event: React.FocusEvent<HTMLInputElement, Element>) => void;
  searchIcon?: boolean;
  clearCb?: () => void;
}

export interface TextAreaProps<T extends FieldValues>
  extends UseControllerProps<T> {
  label?: string;
  placeholder?: string;
  className?: string;
  inputClassName?: string;
  required?: boolean;
  maxLength?: number;
  onChange?: (event: React.ChangeEvent<HTMLTextAreaElement>) => void;
  readOnly?: boolean;
  disabled?: boolean;
  rows?: number;
}

export interface PasswordInputProps<T extends FieldValues>
  extends UseControllerProps<T> {
  label: string;
  placeholder?: string;
  className?: string;
  inputClassName?: string;
  required?: boolean;
}

export interface RadioGroupProps<T extends FieldValues>
  extends UseControllerProps<T> {
  options: { label: string; value: string }[];
  customClassName?: string;
  childClassName?: string;
  hasBorder?: boolean; // New prop for conditional border/padding
  onChange?: (option: { label: string; value: string }) => void;
}

export interface ToggleButtonProps {
  checked: boolean;
  onChange: () => void;
  id: string;
}

export interface DropdownOption {
  label: string;
  value: string | boolean | number;
  count?: string | number;
}

export interface DropdownProps<T extends FieldValues>
  extends UseControllerProps<T> {
  label: string;
  options: DropdownOption[];
  className?: string;
  id?: string;
  isMulti?: boolean; // Added for multiple select
  valueContainerClassName?: string;
  isSearchable?: boolean;
  required?: boolean;
  placeholder?: string; // Added placeholder prop
  onChange?: (
    val: MultiValue<DropdownOption> | SingleValue<DropdownOption>,
  ) => void;
  customPadding?: string;
  customComp?: boolean;
  dropDownMinH?: number;
}

export interface DateRangeInputProps {
  label: string;
  id: string;
  value: any;
  onChange: (date: any) => void;
  maxDate?: any;
  minDate?: any;
  placeholder?: string; // Added placeholder prop
  isRange?: boolean;
  isLast7Days?: boolean;
  availableDates?: string[];
  isQuickSelect?: boolean;
  selectUptoDays?: number;
  displayValue?: string; // New prop for custom display value
}

export interface SelectDropdownProps {
  label?: string;
  options: DropdownOption[];
  className?: string;
  id?: string;
  isMulti?: boolean;
  valueContainerClassName?: string;
  required?: boolean;
  placeholder?: string;
  onChange: (
    selectedOption: SingleValue<DropdownOption> | MultiValue<DropdownOption>,
  ) => void;
  value: SingleValue<DropdownOption> | MultiValue<DropdownOption>;
  error?: string;
  customPadding?: string;
  isSearchable?:boolean;
}
