export interface AddOrderFormValues {
  isMultiOrder: boolean;
  orderFor: string;
  orderType: string;
  settlementCurrency?: string;
  orders: {
    amount: number | undefined;
    currency: string;
    rate: number | undefined;
    accountName?: string;
    remarks?: string;
    fee?: string | undefined;
  }[];
  remarks?: string;
  accountName?: string;
  fee?: number | undefined;
}

export interface OrderTransaction {
  unique_id: string;
  transaction_id: string;
  order_id: string;
  group_id: string;
  transfer_by: string;
  trading: string;
  sell_value: string;
  sell_currency: string;
  settlement_currency: string;
  rate: string;
  fee: string;
  account_name: string;
  remarks: string;
}

export interface OrderCalculation {
  status: string;
  value: number;
  currency: string;
  transferred_amount: number;
  pending_amount: number;
}

export interface CustomerGroup {
  unique_id: string;
  group_id: string;
  name: string;
}

export interface Order {
  unique_id: string;
  order_id: string;
  status: string;
  group_id: string;
  order_by: string;
  currency: string;
  settlement_currency: string;
  amount: string;
  trading: string;
  remarks: string;
  customer_group: CustomerGroup;
  transactions: OrderTransaction[];
  transfer_percent: number;
  calculation: OrderCalculation;
  rate?: string;
  account_id: string;
  ordered_date: string;
  account: {
    name: string;
    unique_id: string;
  };
  fee?: string;
  updated_at?: string;
  created_at?: string;
}

export interface GetAllOrdersResponse {
  orders: { date: string; orders: Order[] }[];
  overall_calculation: { currency: string; status: string; value: number };
  totalCount: number;
  statuses: any[];
}

export interface EditOrderFormValues {
  order_by: string;
  trading: string;
  amount: string;
  currency: string;
  remarks?: string;
  accountName: string;
  rate?: string;
  fee?: string;
}

interface ReorderCurrency {
  currency_id: string;
  order: number;
}
export interface ReOrderCurrencyPayload {
  orders: ReorderCurrency[];
  group_id: string;
}
