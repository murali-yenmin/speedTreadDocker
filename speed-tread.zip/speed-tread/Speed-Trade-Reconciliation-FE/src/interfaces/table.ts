// frontend/src/interfaces/table.ts

export interface DataPerPageOptionsProps {
  label: string;
  value: string;
}

export interface FilterItem {
  name: string;
  label: string;
  fieldName: string;
  operation: string;
  value: string;
}

export interface FilterOutput {
  [key: string]: string[];
}

export interface QueryProps {
  operation: string;
  fieldName: string;
  fieldString: string | string[];
}

export interface PaginationProps {
  onPageChange: (page: number) => void;
  totalCount: number;
  siblingCount?: number;
  currentPage?: number;
  pageSize: number;
}

export interface UsePaginationProps {
  totalCount: number;
  pageSize: number;
  siblingCount?: number;
  currentPage: number;
}

export interface HasId {
  id?: any; // Or a more specific type like string | number
}

export interface Column<T extends HasId> {
  key: string;
  header?: string;
  accessField: string;
  cellClassName?: string;
  thClassName?: string;
  fixed?: boolean;
  left?: string;
  width?: string;
  isSort?: boolean;
  th?: (props: { column: Column<T> }) => React.ReactNode;
  td?: (props: { row: T }, index: number, data: T[]) => React.ReactNode;
}

export interface TableProps<T extends HasId> {
  columns: Column<T>[];
  data: T[];
  tableName: string;
  sort: any;
  setSort: (sort: any) => void;
  currentPage?: number;
  setCurrentPage: (page: number) => void;
  isPagination?: boolean;
  totalCount?: number;
  customPageSize?: boolean;
  pageSize?: string;
  setPageSize?: (size: string) => void;
  isExpanded?: boolean;
  rowSubComponent?: React.ReactNode | ((item: T) => React.ReactNode);
  tableWidth?: string;
  enableScrollX?: boolean;
  minWidth?: string;
  isSelected?: boolean;
  onSelectedRowsChange?: (selectedRows: T[]) => void;
  filterSection?: boolean;
  searchable?: boolean;
  filter?: { query: QueryProps[]; sort: any };
  searchableFields?: { fieldName: string; operation?: string }[];
  searchPlaceholder?: string;
  setFilter?: (filter: { query: QueryProps[]; sort: any }) => void;
  customFilter?: React.ReactNode;
  filterOption?: boolean;
  filterList?: FilterItem[];
  defaultSort?: string;
  scrollTop?: boolean;
  isDateFilter?: boolean;
  defaultDate?: any;
  daterange?: any;
  setDateRange?: (date: any) => void;
  preLoader?: boolean;
  minDate?: any;
  maxDate?: any;
  onSearchChange?: (query: string) => void;
}

export interface tableHeadProps<T extends HasId> {
  columns: Column<T>[];
  tableName: string;
  setSort: (sort: any) => void;
  sort: any;
  onSelectAll: () => void;
  selectedRows: T[];
  isSelected: boolean;
  data: T[];
  defaultSort?: string;
  isExpanded: boolean;
}

export interface tableBodyProps<T extends HasId> {
  data: T[];
  columns: Column<T>[];
  tableName: string;
  isExpanded: boolean;
  rowSubComponent: React.ReactNode | ((item: T) => React.ReactNode) | null;
  selectedRows: T[];
  onSelectRow: (rowKey: string) => void;
  isSelected: boolean;
  onSelectedRowsChange: (selectedRows: T[]) => void;
}

export interface DataPerPageProps {
  options: DataPerPageOptionsProps[];
  onSelect: (value: DataPerPageOptionsProps) => void;
  value: string;
  parentClass?: string;
  toggleClass?: string;
}
