import React from 'react';
import ImageSlider from '../components/ImageSlider';
import { ReactComponent as AuthSlider } from '../assets/svg/AuthSlider.svg';
import { ReactComponent as Logo } from '../assets/svg/Logo.svg';
import { AuthLayoutProps } from '../interfaces/components';

const AuthLayout: React.FC<AuthLayoutProps> = ({ children }) => {
  const slides = [
    {
      icon: <AuthSlider />,
      title: 'Sent Money Effortlessly',
      subtitle: '',
      highlightedTitle: 'with Just a Few Clicks!',
    },
    {
      icon: <AuthSlider />,
      title: 'Sent Money Effortlessly',
      subtitle: '',
      highlightedTitle: 'with Just a Few Clicks!',
    },
    {
      icon: <AuthSlider />,
      title: 'Sent Money Effortlessly',
      subtitle: '',
      highlightedTitle: 'with Just a Few Clicks!',
    },
  ];

  return (
    <div className="flex flex-col md_lg:flex-row h-screen items-center justify-center">
      {/* Left Column */}
      <div className="w-full md_lg:w-3/5 bg-light-blue-grey items-center justify-center p-8 md_lg:h-screen relative hidden md_lg:flex flex-col">
        <div className="absolute top-8 left-8">
          <Logo className="text-rich-black" />
        </div>

        {/* Put Slider here */}
        <div className="w-full flex-grow flex items-center justify-center mt-[100px]">
          <ImageSlider slides={slides} />
        </div>
      </div>

      {/* Right Column */}
      <div className="w-full md_lg:w-2/5 flex items-center justify-center bg-white py-8 md:py-0 md_lg:h-screen">
        <div className="absolute top-8 left-8 display md_lg:hidden">
          <Logo className="text-rich-black" />
        </div>
        <div className="max-w-md w-full p-8">{children}</div>
      </div>
    </div>
  );
};

export default AuthLayout;
