import React, { useState, useRef } from 'react';
import { Link, NavLink, useNavigate, useLocation } from 'react-router-dom';
import { ReactComponent as Logo } from '../assets/svg/Logo.svg';
import { ReactComponent as HamburgerIcon } from '../assets/svg/HamburgerIcon.svg';
import { ReactComponent as BellIcon } from '../assets/svg/BellIcon.svg';
import { ReactComponent as DropdownArrowIcon } from '../assets/svg/DropdownArrowIcon.svg';
import NotificationDropdown from '../components/NotificationDropdown';
import useOutsideClick from '../utils/outsideClick';
import { menuItems } from '../layout/menuItems';
import { getUserRole } from '../utils/auth';
import { HeaderProps, MenuItem } from '../interfaces/components';
import { useAppSelector } from '../store/store';

const Header: React.FC<HeaderProps> = ({
  toggleSidebar,
  isMobile,
  toggleSettlementModal,
}) => {
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [isNotificationDropdownOpen, setIsNotificationDropdownOpen] =
    useState(false);
  const [isSettingsDropdownOpen, setIsSettingsDropdownOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const notificationRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);
  const settingsRef = useRef<HTMLDivElement>(null);

  useOutsideClick(notificationRef, () => {
    if (isNotificationDropdownOpen) setIsNotificationDropdownOpen(false);
  });

  useOutsideClick(profileRef, () => {
    if (isProfileDropdownOpen) setIsProfileDropdownOpen(false);
  });

  useOutsideClick(settingsRef, () => {
    if (isSettingsDropdownOpen) setIsSettingsDropdownOpen(false);
  });

  const { profileData } = useAppSelector((state) => state.profileReducer);
  const userName = profileData?.user_name || 'Speed Trade';
  const userRole = getUserRole();

  const filteredMenuItems = menuItems
    .map((item) => {
      if (item.roles && userRole && !item.roles.includes(userRole)) {
        return null;
      }

      if (item.subItems) {
        const filteredSubItems = item.subItems.filter((subItem) => {
          return (
            !subItem.roles || (userRole && subItem.roles.includes(userRole))
          );
        });

        if (filteredSubItems.length === 0 && !item.path) {
          return null;
        }

        return { ...item, subItems: filteredSubItems };
      }

      return item;
    })
    .filter(Boolean) as MenuItem[];

  const toggleProfileDropdown = () => {
    setIsProfileDropdownOpen((prev) => !prev);
  };

  const toggleNotificationDropdown = () => {
    setIsNotificationDropdownOpen((prev) => !prev);
  };

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    navigate('/login');
    setIsProfileDropdownOpen(false);
    window.location.reload();
  };

  const notifications = [
    {
      id: '1',
      title: 'Order/Transaction Mismatch',
      details: 'Order ID: 12345, Customer ID: 67890, Amount: $100',
      time: new Date().toISOString(),
    },
    {
      id: '2',
      title: 'Order/Transaction Mismatch',
      details: 'Order ID: 12345, Customer ID: 67890, Amount: $100',
      time: new Date(
        new Date().setDate(new Date().getDate() - 2),
      ).toISOString(),
    },
    {
      id: '3',
      title: 'Order/Transaction Mismatch',
      details: 'Order ID: 12345, Customer ID: 67890, Amount: $100',
      time: new Date(
        new Date().setDate(new Date().getDate() - 3),
      ).toISOString(),
    },
  ];

  return (
    <header className="bg-primary-blue text-gray-800 p-0 fixed top-0 w-full z-30 flex items-center border-b border-gray-200 pe-4">
      <div className="flex justify-between items-center w-full p-0">
        <div className="flex items-center gap-8">
          {/* Logo */}
          <Link to={`/dashboard`} className={`cursor-pointer`}>
            <Logo className={`text-rich-black`} />
          </Link>
          {isMobile && (
            <button
              onClick={toggleSidebar}
              title="Menu"
              className="p-2 text-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white focus:ring-gray-300"
              style={{ boxShadow: 'none' }}
            >
              <HamburgerIcon className="text-white" />
            </button>
          )}

          {!isMobile && (
            <nav className="flex items-center space-x-4">
              {filteredMenuItems.map((item) => {
                if (item.isModal) {
                  return (
                    <button
                      title={item.name === 'Settlement' ? '' : item.name}
                      key={item.path}
                      onClick={toggleSettlementModal}
                      className="flex items-center px-4 py-4 text-sm leading-21px font-medium relative rounded-lg text-inactive-grey-blue hover:bg-royal-purple hover:text-white"
                    >
                      {item.icon && <span className="mr-2">{item.icon}</span>}
                      {item.name}
                    </button>
                  );
                }
                if (item.subItems) {
                  return (
                    <div key={item.path} className="relative" ref={settingsRef}>
                      <button
                        onClick={() =>
                          setIsSettingsDropdownOpen((prev) => !prev)
                        }
                        title={item.name === 'Settlement' ? '' : item.name}
                        className={`flex items-center px-4 py-4 rounded-lg text-sm leading-21px font-medium relative hover:bg-royal-purple hover:text-white ${
                          location.pathname.startsWith(item.path)
                            ? 'after:content-[""] after:absolute after:-bottom-1 after:left-0 after:w-full after:h-[3px] after:bg-active-red text-white'
                            : 'text-inactive-grey-blue'
                        }`}
                      >
                        {item.icon && <span className="mr-2">{item.icon}</span>}
                        {item.name}
                        {isSettingsDropdownOpen ? (
                          <span className="ml-2 flex items-center justify-center h-6 w-6">
                            <DropdownArrowIcon
                              className={`${
                                isSettingsDropdownOpen ? 'text-white' : ''
                              } rotate-180`}
                            />
                          </span>
                        ) : (
                          <span className="ml-2 flex items-center justify-center h-6 w-6">
                            <DropdownArrowIcon
                              className={`${
                                isSettingsDropdownOpen ? 'text-white' : ''
                              }`}
                            />
                          </span>
                        )}
                      </button>
                      {isSettingsDropdownOpen && (
                        <div className="origin-top-right absolute left-0 mt-2 w-48 rounded-2xl overflow-hidden shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none px-4">
                          {item.subItems.map((subItem) => (
                            <NavLink
                              key={subItem.path}
                              to={subItem.path}
                              className={({ isActive }) =>
                                `block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 ${
                                  isActive ? 'hover:text-primary-blue' : ''
                                }`
                              }
                              onClick={() => setIsSettingsDropdownOpen(false)}
                            >
                              {subItem.name}
                            </NavLink>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                }
                return (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    className={({ isActive }) =>
                      `flex items-center px-4 py-4 text-sm leading-21px font-medium relative rounded-lg ${
                        isActive
                          ? 'text-white'
                          : 'text-inactive-grey-blue hover:bg-royal-purple hover:text-white '
                      } ${
                        isActive
                          ? 'after:content-[""] after:absolute after:-bottom-1 after:left-0 after:w-full after:h-[3px] after:bg-[#FF2400]'
                          : ''
                      }`
                    }
                  >
                    {item.icon && <span className="mr-2">{item.icon}</span>}
                    {item.name}
                  </NavLink>
                );
              })}
            </nav>
          )}
        </div>
        <div className="flex items-center space-x-4 ml-[-20px] sm:ml-0">
          <div ref={notificationRef} className="relative">
            {/* <button
              onClick={toggleNotificationDropdown}
              title="Notifications"
              className="relative p-[14px] rounded-[8px] shadow-sm focus:box-shadow-none flex items-center justify-center border border-border-light-grey max-h-[40px] mob-notification hover:bg-royal-purple"
            >
              <BellIcon className="text-white" />              
            </button> */}
            {isNotificationDropdownOpen && (
              <NotificationDropdown
                notifications={notifications}
                onSeeAllClick={() => setIsNotificationDropdownOpen(false)}
              />
            )}
          </div>
          {!isMobile && (
            <>
              <div ref={profileRef} className="relative">
                <button
                  onClick={toggleProfileDropdown}
                  title="Open user menu"
                  className="flex items-center space-x-2 p-1 rounded-ful shadow-none focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white focus:ring-gray-300 focus:shadow-none"
                  id="user-menu-button"
                  aria-expanded="false"
                  aria-haspopup="true"
                  style={{ boxShadow: 'none' }}
                >
                  <span className="sr-only">Open user menu</span>
                  <div className="h-10 w-10 rounded-full flex items-center justify-center bg-initialsBg text-initialsText font-bold text-[19px]">
                    {getInitials(userName)}
                  </div>
                  {/* <div className="flex flex-col items-start hidden lg:flex">
                    <span className="text-gray-500 text-xs">Welcome</span>
                    <span className="text-gray-800 text-sm font-bold">
                      {userName}
                    </span>
                  </div> */}
                  {isProfileDropdownOpen ? (
                    <span className="ml-2 flex items-center justify-center h-6 w-6 pr-2">
                      <DropdownArrowIcon className="rotate-180 text-white" />
                    </span>
                  ) : (
                    <span className="ml-2 flex items-center justify-center h-6 w-6 pr-2">
                      <DropdownArrowIcon className="text-white" />
                    </span>
                  )}
                </button>

                {isProfileDropdownOpen && (
                  <div
                    className="origin-top-right absolute right-0 mt-2 w-48 rounded-2xl overflow-hidden shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none"
                    role="menu"
                    aria-orientation="vertical"
                    aria-labelledby="user-menu-button"
                    tabIndex={-1}
                  >
                    <Link
                      to="/profile"
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      role="menuitem"
                      tabIndex={-1}
                      id="user-menu-item-0"
                      onClick={() => setIsProfileDropdownOpen(false)}
                    >
                      Profile Settings
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      role="menuitem"
                      tabIndex={-1}
                      id="user-menu-item-2"
                    >
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
};

const getInitials = (name: string) => {
  const parts = name.split(' ');
  if (parts.length > 0 && parts[0].length > 0) {
    return parts[0].charAt(0).toUpperCase();
  }
  return '';
};

export default Header;
