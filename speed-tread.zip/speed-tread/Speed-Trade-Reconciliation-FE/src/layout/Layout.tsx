import React, { useState, useEffect } from 'react';
import Header from './Header';
import Sidebar from './Sidebar';
import { LayoutProps } from '../interfaces/components';
import SettlementModal from '../components/Modal/SettlementModal';

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 980);
  const [isSettlementModalOpen, setIsSettlementModalOpen] = useState(false);

  const toggleSettlementModal = () => {
    setIsSettlementModalOpen(!isSettlementModalOpen);
  };

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
  };

  const toggleSidebarCollapsed = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 980;
      setIsMobile(mobile);
      if (!mobile) {
        setIsSidebarOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useEffect(() => {
    if (isSidebarOpen && isMobile) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
  }, [isSidebarOpen, isMobile]);

  return (
    <div className="flex flex-col h-screen">
      <Header
        toggleSidebar={toggleSidebar}
        isMobile={isMobile}
        toggleSettlementModal={toggleSettlementModal}
      />
      <div className="flex flex-1 pt-16">
        {isMobile && (
          <Sidebar
            isSidebarOpen={isSidebarOpen}
            toggleSidebar={toggleSidebar}
            isSidebarCollapsed={isSidebarCollapsed}
            isMobile={isMobile}
            toggleSettlementModal={toggleSettlementModal}
          />
        )}
        <main
          className={`flex-1 p-0 transition-all duration-300 h-[calc(100dvh-66px)] overflow-y-auto bg-gray-50 `}
        >
          {children}
        </main>
      </div>
      {isSidebarOpen && isMobile && (
        <div
          className="fixed inset-0 bg-black opacity-50 z-30"
          onClick={closeSidebar}
        ></div>
      )}
      <SettlementModal
        isOpen={isSettlementModalOpen}
        onClose={toggleSettlementModal}
      />
    </div>
  );
};

export default Layout;
