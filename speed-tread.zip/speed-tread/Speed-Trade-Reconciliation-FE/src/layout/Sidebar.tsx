import React, { useState, useRef, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { menuItems, logoutMenuItem } from './menuItems';
import { ReactComponent as ChevronDownIcon } from '../assets/svg/ChevronDownIcon.svg';
import { ReactComponent as ChevronUpIcon } from '../assets/svg/ChevronUpIcon.svg';
import useOutsideClick from '../utils/outsideClick';
import { getUserRole } from '../utils/auth';
import { MenuItem, SidebarProps } from '../interfaces/components';
import { useAppDispatch, useAppSelector } from '../store/store';
import { fetchUserProfile } from '../store/slices/user/profileSlice';
import { ReactComponent as SettlementIconSvg } from '../assets/svg/SettlementIcon.svg';

const SettlementIcon = ({ className = '' }) => (
  <SettlementIconSvg className={`h-6 w-[1.8rem] ${className}`} />
);

const Sidebar: React.FC<SidebarProps> = ({
  isSidebarOpen,
  toggleSidebar,
  isSidebarCollapsed,
  isMobile,
  toggleSettlementModal,
}) => {
  const location = useLocation();
  const navigate = useNavigate();
  const profileName = useAppSelector(
    (state) => state.profileReducer?.profileData?.user_name,
  );
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [isNotificationDropdownOpen, setIsNotificationDropdownOpen] =
    useState(false);

  const notificationRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);
  const dispatch = useAppDispatch();

  useOutsideClick(notificationRef, () => {
    if (isNotificationDropdownOpen) setIsNotificationDropdownOpen(false);
  });

  useOutsideClick(profileRef, () => {
    if (isProfileDropdownOpen) setIsProfileDropdownOpen(false);
  });

  useEffect(() => {
    dispatch(fetchUserProfile());
  }, [dispatch]);

  const userName = profileName ? profileName : 'User';
  const userRole = getUserRole();

  const filteredMenuItems = menuItems
    .map((item) => {
      if (item.roles && userRole && !item.roles.includes(userRole)) {
        return null;
      }

      if (item.subItems) {
        const filteredSubItems = item.subItems.filter((subItem) => {
          return (
            !subItem.roles || (userRole && subItem.roles.includes(userRole))
          );
        });

        // if the main item has a path, it should be visible even if subitems are not
        if (filteredSubItems.length === 0 && !item.path) {
          return null;
        }

        return { ...item, subItems: filteredSubItems };
      }

      return item;
    })
    .filter(Boolean) as MenuItem[];

  const toggleProfileDropdown = () => {
    setIsProfileDropdownOpen((prev) => !prev);
  };

  const [openMenus, setOpenMenus] = useState<Record<string, boolean>>({});

  const toggleMenu = (path: string) => {
    setOpenMenus((prev) => ({ ...prev, [path]: !prev[path] }));
  };

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    navigate('/login');
    setIsProfileDropdownOpen(false);
  };

  const getInitials = (name: string) => {
    const parts = name.split(' ');
    if (parts.length === 1) {
      return parts[0].charAt(0).toUpperCase();
    } else if (parts.length > 1) {
      return (
        parts[0].charAt(0) + parts[parts.length - 1].charAt(0)
      ).toUpperCase();
    }
    return '';
  };

  return (
    <>
      <style>{`
        .tooltip::before {
          content: '';
          position: absolute;
          top: 50%;
          right: 100%;
          margin-top: -5px;
          border-width: 5px;
          border-style: solid;
          border-color: transparent theme('colors.grey.300') transparent transparent;
        }
      `}</style>

      <aside
        className={`flex flex-col justify-between bg-white text-gray-800 p-4 fixed top-0 transform transition-transform duration-300 ease-in-out z-40  ${
          isMobile
            ? `${
                isSidebarOpen
                  ? 'translate-x-0 left-0'
                  : '-translate-x-full left-0'
              } w-64 h-full`
            : `${
                isSidebarCollapsed ? 'w-20' : 'w-64'
              } left-0 top-16 h-[calc(100vh-4rem)]`
        }`}
      >
        {isMobile && (
          <div
            className="p-2.5 flex items-center justify-between pl-0 w-full hover:bg-gray-100 cursor-pointer rounded-lg"
            onClick={() => {
              navigate('/profile');
              if (isMobile) {
                toggleSidebar();
              }
            }}
          >
            <div ref={profileRef} className="relative">
              <button
                onClick={toggleProfileDropdown}
                title="Open user menu"
                className="flex items-center space-x-2 p-1 rounded-full focus:outline-none"
                id="user-menu-button"
                aria-expanded="false"
                aria-haspopup="true"
              >
                <span className="sr-only">Open user menu</span>
                <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-white font-bold text-sm">
                  {getInitials(userName)}
                </div>
                <div className="flex flex-col items-start">
                  <span className="text-gray-500 text-xs">Welcome</span>
                  <span className="text-gray-800 text-sm font-bold sidebar-profile-namealign">
                    {userName}
                  </span>
                </div>
                {/* {isProfileDropdownOpen ? (
                  <ChevronUpIcon className="h-5 w-5 text-gray-400" />
                ) : (
                  <ChevronDownIcon className="h-5 w-5 text-gray-400" />
                )} */}
              </button>

              {/* {isProfileDropdownOpen && (
                <div
                  className="origin-top-right absolute right-0 mt-2 w-48 rounded-2xl overflow-hidden shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none z-10"
                  role="menu"
                  aria-orientation="vertical"
                  aria-labelledby="user-menu-button"
                  tabIndex={-1}
                >
                  <Link
                    to="/profile"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    role="menuitem"
                    tabIndex={-1}
                    id="user-menu-item-0"
                    onClick={() => {
                      setIsProfileDropdownOpen(false);
                      if (isMobile) {
                        toggleSidebar();
                      }
                    }}
                  >
                    Your Profile
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    role="menuitem"
                    tabIndex={-1}
                    id="user-menu-item-2"
                  >
                    Sign out
                  </button>
                </div>
              )} */}
            </div>
          </div>
        )}
        <nav>
          <ul className={`${isSidebarCollapsed ? 'w-[48px]' : 'pt-4 mt-2'}`}>
            {filteredMenuItems.map((item: MenuItem, index: number) => (
              <li key={index} className="mb-2 relative group">
                {item.isModal ? (
                  <div
                    onClick={() => {
                      toggleSettlementModal();
                      if (isMobile) {
                        toggleSidebar();
                      }
                    }}
                    className={`flex items-center cursor-pointer group ${
                      isSidebarCollapsed ? 'p-2 justify-center' : 'py-2 px-4'
                    } rounded-lg hover:bg-gray-100 text-gray-800`}
                  >
                    <span
                      className={`${
                        isSidebarCollapsed ? '' : 'mr-3'
                      } text-gray-800 group-hover:text-primary-blue`}
                    >
                      {item.name === 'Settlement' ? (
                        <SettlementIcon className="settlement-icon" />
                      ) : (
                        item.icon
                      )}
                    </span>
                    {!isSidebarCollapsed && (
                      <span
                        className={`text-gray-800 group-hover:text-primary-blue`}
                      >
                        {item.name}
                      </span>
                    )}
                  </div>
                ) : item.subItems && item.subItems.length > 0 ? (
                  <div
                    onClick={() => toggleMenu(item.path)}
                    className="cursor-pointer"
                  >
                    <div
                      className={`flex items-center justify-between w-full rounded-lg   ${
                        openMenus[item.path]
                          ? 'bg-gray-100 text-gray-800 rounded-b'
                          : location.pathname.startsWith(item.path)
                            ? 'bg-primary-blue text-white'
                            : 'hover:bg-gray-100 text-gray-800'
                      } ${
                        isSidebarCollapsed ? 'p-2 justify-center' : 'py-2 px-4'
                      }`}
                    >
                      <div className="flex items-center flex-grow">
                        <span
                          className={`${isSidebarCollapsed ? '' : 'mr-3'} ${
                            openMenus[item.path]
                              ? 'text-gray-800'
                              : location.pathname.startsWith(item.path)
                                ? 'text-white'
                                : 'text-gray-800'
                          }`}
                        >
                          {item.icon}
                        </span>
                        {!isSidebarCollapsed && <span>{item.name}</span>}
                      </div>
                      {!isSidebarCollapsed && (
                        <button
                          className="p-1 rounded-full"
                          title={
                            openMenus[item.path] ? 'Close menu' : 'Open menu'
                          }
                        >
                          {openMenus[item.path] ? (
                            <ChevronUpIcon
                              className={`h-5 w-5 ${
                                openMenus[item.path]
                                  ? 'text-gray-800'
                                  : location.pathname.startsWith(item.path)
                                    ? 'text-white'
                                    : ''
                              }`}
                            />
                          ) : (
                            <ChevronDownIcon
                              className={`h-5 w-5 ${
                                openMenus[item.path]
                                  ? 'text-gray-800'
                                  : location.pathname.startsWith(item.path)
                                    ? 'text-white'
                                    : ''
                              }`}
                            />
                          )}
                        </button>
                      )}
                    </div>
                    {openMenus[item.path] && !isSidebarCollapsed && (
                      <ul className="p-3 bg-gray-100 rounded-b-lg ">
                        {item.subItems.map((subItem) => (
                          <li key={subItem.path} className="mb-2">
                            <Link
                              to={subItem.path}
                              className={`flex items-center text-gray-800  py-2 px-4 rounded-lg ${
                                location.pathname === subItem.path
                                  ? 'bg-primary-blue text-white'
                                  : 'hover:bg-gray-300 bg-gray-200 text-gray-800'
                              }`}
                              onClick={() => {
                                if (isMobile) {
                                  toggleSidebar();
                                }
                              }}
                            >
                              {subItem.name}
                            </Link>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                ) : (
                  <Link
                    to={item.path}
                    className={`flex items-center cursor-pointer group ${
                      isSidebarCollapsed ? 'p-2 justify-center' : 'py-2 px-4'
                    } rounded-lg ${
                      location.pathname.startsWith(item.path)
                        ? 'bg-primary-blue text-white'
                        : 'hover:bg-gray-100 text-gray-800'
                    }`}
                    onClick={() => {
                      if (isMobile) {
                        toggleSidebar();
                      }
                    }}
                  >
                    <span
                      className={`${
                        isSidebarCollapsed ? '' : 'mr-3'
                      } ${location.pathname.startsWith(item.path) ? 'text-white' : 'text-gray-800 group-hover:text-primary-blue'}`}
                    >
                      {item.icon}
                    </span>
                    {!isSidebarCollapsed && (
                      <span
                        className={`${location.pathname.startsWith(item.path) ? 'text-white' : 'text-gray-800 group-hover:text-primary-blue'}`}
                      >
                        {item.name}
                      </span>
                    )}
                  </Link>
                )}
                {isSidebarCollapsed && (
                  <span className="absolute hidden group-hover:block left-full ml-4 w-auto p-2 text-sm text-white bg-gray-800 rounded-md shadow-lg whitespace-nowrap z-50 top-0.5 tooltip">
                    {item.name}
                  </span>
                )}
              </li>
            ))}
          </ul>
        </nav>
        <div className="mt-auto relative group">
          <Link
            to={logoutMenuItem.path}
            className={`flex items-center ${
              isSidebarCollapsed
                ? 'py-2 px-4 justify-center w-[48px]'
                : 'py-2 px-2.5'
            } rounded-lg ${
              location.pathname === logoutMenuItem.path
                ? 'bg-primary-blue text-white'
                : 'hover:bg-gray-100 text-gray-800'
            }`}
            onClick={()=>{
              window.location.reload();
            }}
          >
            <span className={`${isSidebarCollapsed ? '' : 'mr-3'}`}>
              {logoutMenuItem.icon}
            </span>
            {!isSidebarCollapsed && <span>{logoutMenuItem.name}</span>}
          </Link>
          {isSidebarCollapsed && (
            <span className="absolute hidden group-hover:block left-full ml-4 w-auto p-2 text-sm text-white bg-gray-800 rounded-md shadow-lg whitespace-nowrap z-50 top-0.5 tooltip">
              {logoutMenuItem.name}
            </span>
          )}
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
