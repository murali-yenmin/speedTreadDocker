import { ReactComponent as GridIconSvg } from '../assets/svg/GridIcon.svg';
import { ReactComponent as UsersGroupIconSvg } from '../assets/svg/UsersGroupIcon.svg';
import { ReactComponent as LogoutIconSvg } from '../assets/svg/LogoutIcon.svg';
import { ReactComponent as SettingsGearIconSvg } from '../assets/svg/SettingsGearIcon.svg'; // New import
import { ReactComponent as ReportIconSvg } from '../assets/svg/ReportIcon.svg';
import { ReactComponent as SettlementIconSvg } from '../assets/svg/SettlementIcon.svg';
import { ROLES } from '../constants/roles';
import { MenuItem } from '../interfaces/components';

const GridIcon = () => <GridIconSvg className="h-6 w-6" />;
const UsersGroupIcon = () => <UsersGroupIconSvg className="h-6 w-6" />;
const LogoutIcon = () => <LogoutIconSvg className="h-6 w-6" />;
const ReportIcon = () => <ReportIconSvg className="h-6 w-6" />;
const SettlementIcon = ({ className = '' }) => (
  <SettlementIconSvg className={`h-6 w-[1.8rem] ${className}`} />
);
const SettingsGearIcon = () => <SettingsGearIconSvg className="h-6 w-6 " />; // New component

export const menuItems: MenuItem[] = [
  {
    name: 'Dashboard',
    path: '/dashboard',
    icon: <GridIcon />,
    roles: [ROLES.MANAGEMENT, ROLES.ORDER_MANAGER, ROLES.TRANSACTION_MANAGER],
  },
  {
    name: 'Users',
    path: '/users',
    icon: <UsersGroupIcon />,
    roles: [ROLES.MANAGEMENT],
  },
  {
    name: 'Report',
    path: '/report',
    icon: <ReportIcon />,
    roles: [ROLES.ORDER_MANAGER],
  },
  {
    name: 'Report',
    path: '/transaction-reports',
    icon: <ReportIcon />,
    roles: [ROLES.TRANSACTION_MANAGER],
  },
  {
    name: 'Settlement',
    path: '#settlement',
    icon: <SettlementIcon />,
    roles: [ROLES.TRANSACTION_MANAGER, ROLES.ORDER_MANAGER],
    isModal: true,
  },
  {
    name: 'Settings',
    path: '/settings',
    icon: <SettingsGearIcon />,
    roles: [ROLES.MANAGEMENT],
    subItems: [
      {
        name: 'Currency Settings',
        path: '/settings/currency',
        roles: [ROLES.MANAGEMENT],
      },
      // {
      //   name: 'Social Media',
      //   path: '/settings/social-media',
      //   roles: [ROLES.MANAGEMENT],
      // },
    ],
  },
];

export const logoutMenuItem: MenuItem = {
  name: 'Logout',
  path: '/logout',
  icon: <LogoutIcon />,
};
