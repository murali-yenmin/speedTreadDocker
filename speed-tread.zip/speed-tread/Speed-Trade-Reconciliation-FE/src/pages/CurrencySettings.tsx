import React from 'react';
import Breadcrumb from '../components/Breadcrumb';
import useBreadcrumbs from '../hooks/useBreadcrumbs';

const CurrencySettings: React.FC = () => {
  const breadcrumbItems = useBreadcrumbs();

  return (
    <div className="h-[calc(100vh-160px)]">
      <div className="flex justify-between items-center mb-4 p-4 bg-white">
        <Breadcrumb items={breadcrumbItems} />
      </div>
      <div className="p-4">
        <h1 className="text-2xl font-bold">Currency Settings Page</h1>
        <p>This is where you can manage currency settings.</p>
      </div>
    </div>
  );
};

export default CurrencySettings;
