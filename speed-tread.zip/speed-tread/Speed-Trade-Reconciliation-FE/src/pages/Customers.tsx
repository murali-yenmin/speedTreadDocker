import React, { useEffect, useState } from 'react';
import { Table } from '../components/table/Table'; // Import the Table component
import { Column, QueryProps, FilterItem } from '../interfaces/table';

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  integrator?: string;
  member?: string;
}

const DUMMY_USERS: User[] = [
  {
    id: '1',
    name: 'John Doe',
    email: 'john.doe@example.com',
    role: 'Admin',
    member: '34',
    integrator: 'Integrator A',
  },
  {
    id: '2',
    name: 'Jane Smith',
    email: 'jane.smith@example.com',
    role: 'User',
    member: '28',
    integrator: 'Integrator B',
  },
  {
    id: '3',
    name: 'Peter Jones',
    email: 'peter.jones@example.com',
    role: 'User',
    member: '45',
    integrator: 'Integrator A',
  },
  {
    id: '4',
    name: 'Alice Brown',
    email: 'alice.brown@example.com',
    role: 'Admin',
    member: '22',
    integrator: 'Integrator C',
  },
  {
    id: '5',
    name: 'Bob White',
    email: 'bob.white@example.com',
    role: 'User',
    member: '19',
    integrator: 'Integrator B',
  },
  {
    id: '6',
    name: 'Charlie Green',
    email: 'charlie.green@example.example.com',
    role: 'User',
    member: '31',
    integrator: 'Integrator A',
  },
  {
    id: '7',
    name: 'Diana Prince',
    email: 'diana.prince@example.com',
    role: 'Admin',
    member: '40',
    integrator: 'Integrator C',
  },
  {
    id: '8',
    name: 'Eve Black',
    email: 'eve.black@example.com',
    role: 'User',
    member: '29',
    integrator: 'Integrator B',
  },
  {
    id: '9',
    name: 'Frank Red',
    email: 'frank.red@example.com',
    role: 'User',
    member: '36',
    integrator: 'Integrator A',
  },
  {
    id: '10',
    name: 'Grace Blue',
    email: 'grace.blue@example.com',
    role: 'Admin',
    member: '50',
    integrator: 'Integrator C',
  },
  {
    id: '11',
    name: 'Harry Potter',
    email: 'harry.potter@example.com',
    role: 'User',
    member: '33',
    integrator: 'Integrator B',
  },
  {
    id: '12',
    name: 'Hermione Granger',
    email: 'hermione.granger@example.com',
    role: 'User',
    member: '29',
    integrator: 'Integrator A',
  },
  {
    id: '13',
    name: 'Ron Weasley',
    email: 'ron.weasley@example.com',
    role: 'User',
    member: '25',
    integrator: 'Integrator C',
  },
  {
    id: '14',
    name: 'Albus Dumbledore',
    email: 'albus.dumbledore@example.com',
    role: 'Admin',
    member: '40',
    integrator: 'Integrator B',
  },
  {
    id: '15',
    name: 'Severus Snape',
    email: 'severus.snape@example.com',
    role: 'User',
    member: '30',
    integrator: 'Integrator A',
  },
];

const Customers: React.FC = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState('5');
  const [selectedRows, setSelectedRows] = useState<User[]>([]);
  const [sort, setSort] = useState({ key: 'id', order: 'asc' });
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filter, setFilter] = useState<{ query: QueryProps[]; sort: any }>({
    query: [],
    sort: {},
  });

  const columns: Column<User>[] = [
    { key: 'id', header: 'ID', accessField: 'id' },
    { key: 'name', header: 'Name', accessField: 'name' },
    { key: 'email', header: 'Email', accessField: 'email' },
    { key: 'role', header: 'Role', accessField: 'role' },
    { key: 'integrator', header: 'Integrator', accessField: 'integrator' },
    { key: 'member', header: 'Member Since', accessField: 'member' },
    {
      key: 'actions',
      header: 'Actions',
      accessField: 'actions',
      td: ({ row }: { row: User }) => (
        <div className="flex space-x-2">
          <button className="text-indigo-600 hover:text-indigo-900">
            Edit
          </button>
          <button className="text-red-600 hover:text-red-900">Delete</button>
        </div>
      ),
    },
  ];

  const handleSelectionChange = (newSelection: User[]) => {
    setSelectedRows(newSelection);
  };

  const searchableFields = [
    { fieldName: 'name', operation: '%' },
    { fieldName: 'email', operation: '%' },
    { fieldName: 'role', operation: '%' },
    { fieldName: 'integrator', operation: '%' },
  ];

  const filterList: FilterItem[] = [
    {
      name: 'role',
      label: 'Admin',
      fieldName: 'role',
      operation: 'eq',
      value: 'Admin',
    },
    {
      name: 'role',
      label: 'User',
      fieldName: 'role',
      operation: 'eq',
      value: 'User',
    },
    {
      name: 'integrator',
      label: 'Integrator A',
      fieldName: 'integrator',
      operation: 'eq',
      value: 'Integrator A',
    },
    {
      name: 'integrator',
      label: 'Integrator B',
      fieldName: 'integrator',
      operation: 'eq',
      value: 'Integrator B',
    },
    {
      name: 'integrator',
      label: 'Integrator C',
      fieldName: 'integrator',
      operation: 'eq',
      value: 'Integrator C',
    },
  ];

  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">
        Users Management
      </h1>
      <Table<User>
        tableName="users"
        columns={columns}
        data={DUMMY_USERS}
        sort={sort}
        setSort={setSort}
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        totalCount={DUMMY_USERS.length}
        pageSize={pageSize}
        setPageSize={setPageSize}
        isSelected={true}
        onSelectedRowsChange={handleSelectionChange}
        searchable={true}
        searchableFields={searchableFields}
        onSearchChange={setSearchQuery}
        filter={filter}
        setFilter={setFilter}
        filterList={filterList}
        filterOption
        isPagination
        customPageSize={true}
        enableScrollX={true}
      />
    </div>
  );
};

export default Customers;
