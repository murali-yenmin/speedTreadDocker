import { getUserRole } from '../utils/auth';
import { ROLES } from '../constants/roles';
import ManagementDashboard from './ManagementDashboard';
import PageTitle from '../components/PageTitle';
import Orders from './Orders';
import Transactions from './Transactions';
import { useEffect } from 'react';

const Dashboard = () => {
  const userRole = getUserRole();

 useEffect(() => {
  // Make dashboard the first history entry
  window.history.pushState(null, '', window.location.href);

  const handleBack = () => {
    window.history.pushState(null, '', window.location.href);
  };

  window.addEventListener('popstate', handleBack);
  return () => window.removeEventListener('popstate', handleBack);
}, []);



  return (
    <>
      <PageTitle title="Dashboard" />

      <div>
        {userRole === ROLES.MANAGEMENT && <ManagementDashboard />}
        {userRole === ROLES.ORDER_MANAGER && <Orders />}
        {userRole === ROLES.TRANSACTION_MANAGER && <Transactions />}
      </div>
    </>
  );
};

export default Dashboard;
