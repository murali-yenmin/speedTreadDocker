import CommissionIcon from '../components/Images/CommissionIcon';
import OrdersIcon from '../components/Images/OrdersIcon';
import SettingsIcon from '../components/Images/SettingsIcon';
import TransactionsIcon from '../components/Images/TransactionsIcon';
import UserManagementIcon from '../components/Images/UserManagementIcon';
import ManagementDashboardCard from '../components/ManagementDashboardCard';
import SettlementModal from '../components/Modal/SettlementModal';
import { useNavigate } from 'react-router-dom';
import React, { useState } from 'react';

const ManagementDashboard = () => {
  const navigate = useNavigate();
  const [showSettlementModal, setShowSettlementModal] = useState(false);

  const dashboardCards = [
    {
      title: 'Orders',
      icon: <OrdersIcon />,
      buttons: [
        // TODO:
        // =====
        // {
        //   text: 'Pending Orders',
        //   onClick: () => {},
        // },
        {
          text: 'Pending Reports',
          onClick: () => {
            navigate('/report');
          },
        },
      ],
    },
    {
      title: 'Transactions',
      icon: <TransactionsIcon />,
      buttons: [
         {
          text: "Today's Settlement",
          onClick: () => {
            setShowSettlementModal(true);
          },
        },
        {
          text: 'Transfer Report',
          onClick: () => {
            navigate('/transaction-reports');
          },
        },
      ],
    },
    // TODO:
    // =====
    // {
    //   title: 'Commission',
    //   icon: <CommissionIcon />,
    //   buttons: [
    //     {
    //       text: 'Agent Rebate',
    //       onClick: () => {},
    //     },
    //   ],
    // },
    {
      title: 'User Management',
      icon: <UserManagementIcon />,
      buttons: [
        {
          text: 'Manage Users',
          onClick: () => {
            navigate('/users');
          },
        },
        // TODO:
        // =====
        // {
        //   text: 'Pending Reports',
        //   onClick: () => {},
        // },
      ],
    },
    {
      title: 'Settings',
      icon: <SettingsIcon />,
      buttons: [
        {
          text: 'Currency Settings',
          onClick: () => {
            navigate('/settings/currency');
          },
        },
        // TODO:
        // =====
        // {
        //   text: 'Unlock Groups',
        //   onClick: () => {},
        // },
      ],
    },
  ];

  return (
   <div className="p-4 m-0 sm:m-4 md:p-8 md:m-12 bg-white rounded-2xl">
      <div className="grid grid-cols-1 md:grid-cols-[repeat(auto-fit,minmax(407px,1fr))] gap-4">
        {dashboardCards.map((card, index) => (
          <ManagementDashboardCard
            key={index}
            title={card.title}
            icon={card.icon}
            buttons={card.buttons}
          />
        ))}
      </div>

      <SettlementModal
        isOpen={showSettlementModal}
        onClose={() => setShowSettlementModal(false)}
      />
    </div>
  );
};

export default ManagementDashboard;
