import React, { useState } from 'react'; // Import useState
import Layout from '../layout/Layout'; // Assuming Layout is used for pages
import Breadcrumb from '../components/Breadcrumb';
import useBreadcrumbs from '../hooks/useBreadcrumbs';

const Notifications: React.FC = () => {
  const breadcrumbItems = useBreadcrumbs();
  // Dummy notification data
  const [notifications, setNotifications] = useState([
    {
      id: '1',
      message: 'Your Password has been Successfully Changed.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: false,
    },
    {
      id: '2',
      message: 'Your Password has been Successfully Changes.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: true,
    },
    {
      id: '3',
      message: 'You have added new Social media Source successfully.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: false,
    },
    {
      id: '4',
      message: 'Your Password has been Successfully Changes.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: true,
    },
    {
      id: '5',
      message: 'You have added new Social media Source successfully.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: false,
    },
    {
      id: '6',
      message: 'Your Password has been Successfully Changes.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: true,
    },
    {
      id: '7',
      message: 'Your Password has been Successfully Changes.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: false,
    },
    {
      id: '8',
      message: 'Your Password has been Successfully Changed.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: true,
    },
    {
      id: '9',
      message: 'Your Password has been Successfully Changes.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: false,
    },
    {
      id: '10',
      message: 'You have added new Social media Source successfully.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: true,
    },
    {
      id: '11',
      message: 'Your Password has been Successfully Changes.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: false,
    },
    {
      id: '12',
      message: 'You have added new Social media Source successfully.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: true,
    },
    {
      id: '13',
      message: 'Your Password has been Successfully Changes.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: false,
    },
    {
      id: '14',
      message: 'Your Password has been Successfully Changes.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: true,
    },
    {
      id: '15',
      message: 'Your Password has been Successfully Changed.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: false,
    },
    {
      id: '16',
      message: 'Your Password has been Successfully Changes.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: true,
    },
    {
      id: '17',
      message: 'You have added new Social media Source successfully.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: false,
    },
    {
      id: '18',
      message: 'Your Password has been Successfully Changes.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: true,
    },
    {
      id: '19',
      message: 'You have added new Social media Source successfully.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: false,
    },
    {
      id: '20',
      message: 'Your Password has been Successfully Changes.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: true,
    },
    {
      id: '21',
      message: 'Your Password has been Successfully Changed.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: false,
    },
    {
      id: '22',
      message: 'Your Password has been Successfully Changes.',
      time: 'Jul 25, 2024 at 09:15 AM',
      read: true,
    },
  ]);

  return (
    <>
      <div className="flex justify-between items-center mb-4 p-4 bg-white">
        <Breadcrumb items={breadcrumbItems} />
      </div>
      <div className="p-4">
        <div className="bg-white rounded-lg shadow-md p-6 max-w-[727px] mx-auto">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold text-gray-800">Notifications</h2>
            {/* More options icon */}
          </div>
          {/* Tabs for All and Unread */}
          <div className="flex space-x-4 mb-4">
            <button className="px-4 py-2 rounded-md bg-gray-200 text-gray-800">
              All
            </button>
            <button className="px-4 py-2 rounded-md text-gray-600 hover:bg-gray-100">
              Unread
            </button>
          </div>
          {/* Notification List */}
          <div className="max-h-[500px] overflow-y-auto">
            {' '}
            {/* Added max-height and overflow */}
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className={`flex items-center p-3 rounded-md`}
              >
                <span
                  className={`w-2 h-2 rounded-full mr-3 mt-2 bg-gray-400`}
                ></span>
                <div>
                  <p className="text-gray-800">{notification.message}</p>
                  <p className="text-sm text-gray-500">{notification.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Notifications;
