import React, { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '../store/store';
import AddGroupModal from '../components/Modal/AddGroupModal';
import { orderGroupGetAllThunk } from '../store/thunks/groups';
import GroupCard from '../components/GroupCard';
import { getAllCurrenciesThunk } from '../store/thunks/settings';
import GroupCardListSkeleton from '../components/GroupCardListSkeleton';
import NoData from '../components/NoData';
import PageTitle from '../components/PageTitle';
import PageHeader from '../components/PageHeader';
import customfilterMap from '../utils/dropdown';

const Orders = () => {
  const dispatch = useAppDispatch();

  const { groups, loading, error } = useAppSelector(
    (state) => state.orderGroupGetAllReducer,
  );

  const [isAddGroupModalOpen, setIsAddGroupModalOpen] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [currentFilter, setCurrentFilter] = useState('show all');

  const handleFavoriteButtonClick = () => {
    setIsFavorite((prev) => !prev);
  };

  const handleFilterChange = (filter: string) => {
    setCurrentFilter(filter);
  };

  const fetchGroups = () => {
    const query = [];
    if (isFavorite) {
      query.push({
        fieldName: 'is_favorite',
        fieldString: true,
        operation: 'eq',
      });
    }
    if (searchTerm) {
      query.push({
        fieldName: 'group_id',
        fieldString: searchTerm,
        operation: '%',
      });
      query.push({
        fieldName: 'name',
        fieldString: searchTerm,
        operation: '%',
      });
    } 

    const fieldString = customfilterMap[currentFilter];

    if (fieldString) {
      query.push({
        fieldName: 'value_status',
        fieldString,
        operation: 'eq',
      });
    }

    dispatch(
      orderGroupGetAllThunk({
        payload: { cp: 0, pl: 0, query: query },
        callbackAfterSuccess: () => {
          if (isInitialLoad) {
            setIsInitialLoad(false);
          }
        },
      }),
    );
  };

  useEffect(() => {
    dispatch(getAllCurrenciesThunk());
  }, [dispatch]);

  useEffect(() => {
    fetchGroups();
  }, [dispatch, isFavorite, searchTerm, currentFilter]);

  return (
    <>
      <PageTitle title="Dashboard" />
      <div className="min-h-full bg-gray-50">
        <div className="p-6 bg-white  z-20 md_lg:sticky top-0">
          <div className="flex flex-wrap justify-between items-center gap-4 mid-range:w-[100%]">
            <h1 className="text-2xl font-semibold text-gray-800">
              Order Records
            </h1>
            <PageHeader
              handleFavoriteButtonClick={handleFavoriteButtonClick}
              isFavorite={isFavorite}
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              onNewGroupClick={() => setIsAddGroupModalOpen(true)}
              searchPlaceholder="Search by Group Name or ID"
              newButtonText="New Group"
              onFilterChange={handleFilterChange}
              currentFilter={currentFilter}
            />
          </div>
        </div>
        <div className="p-6 pt-9 bg-gray-50 ">
          <div>
            {loading && isInitialLoad ? (
              Array.from({ length: 10 }).map((_, index) => (
                <GroupCardListSkeleton key={index} />
              ))
            ) : groups?.customer_groups_list?.length === 0 ? (
              <NoData />
            ) : (
              groups?.customer_groups_list?.map((group) => (
                <GroupCard
                  key={group.unique_id}
                  group={group}
                  sliderType="order"
                  onDataUpdate={fetchGroups}
                />
              ))
            )}
          </div>
          <AddGroupModal
            isOpen={isAddGroupModalOpen}
            onClose={() => setIsAddGroupModalOpen(false)}
            onDataUpdate={fetchGroups}
          />
        </div>
      </div>
    </>
  );
};

export default Orders;
