import React from 'react';

const OrdersDashboard = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold text-gray-800">Orders Dashboard</h1>
    </div>
  );
};

export default OrdersDashboard;
