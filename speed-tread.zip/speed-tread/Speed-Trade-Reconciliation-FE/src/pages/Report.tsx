import React, {
  useCallback,
  useEffect,
  useRef,
  useState,
  useMemo,
} from 'react';
import PageTitle from '../components/PageTitle';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { newReportSchema } from '../validations/order';
import { useTranslation } from 'react-i18next';
import OrderListSkeleton from '../components/OrderListSkeleton';
import NoData from '../components/NoData';
import OrderCard from '../components/OrderCard';
import { RootState, useAppDispatch, useAppSelector } from '../store/store';
import {
  getAllOrdersReportThunk,
  getOrderGroupThunk,
  getOrderStatusThunk,
} from '../store/thunks/order';
import moment from 'moment';
import { defaultDateFormat } from '../components/formFields/DateRangeInput';
import { getAccountNamesThunk } from '../store/thunks/accountName';
import { AccountName } from '../store/interfaces/accountName';
import { getAllCurrenciesThunk } from '../store/thunks/settings';
import useOutsideClick from '../utils/outsideClick';
import { showSuccessToast } from '../utils/toast';

import MultiSelect, {
  MultiSelectOption,
} from '../components/formFields/MultiSelect';
import ReportFilters from '../components/Report/ReportFilters';
import ReportSelectionActions from '../components/Report/ReportSelectionActions';
import { Order } from '../interfaces/order';
import { buildOrderString } from '../utils/copyorder';
import { orderedByOptions } from '../constants/dropdowns';

const pageSize = 10; // Define page size

interface ResetArg {
  fetch?: boolean;
}

const Report = () => {
  const { t } = useTranslation();
  const dispatch = useAppDispatch();
  const currentRequest = useRef<any>(null);

  const disabled = !true;

  const { data: ordersData, loading } = useAppSelector(
    (state: RootState) => state.getAllOrdersReportsReducer,
  );
  const { accountNames } = useAppSelector((state) => state.accountNameReducer);
  const { groups, groupsLoading } = useAppSelector((state) => ({
    groups: state.getOrderGroupReducer.data,
    groupsLoading: state.getOrderGroupReducer.loading,
  }));

  const { currencies, currenciesLoading } = useAppSelector((state) => ({
    currencies:
      state.getAllCurrenciesReducer.data?.map((item) => ({
        label: item?.code,
        value: item?.code,
      })) || [],
    currenciesLoading: state.getAllCurrenciesReducer.loading,
  }));
  const orderStatus = useAppSelector(
    (state) =>
      state.getAllOrdersStatusReducer.data
        ?.slice()
        ?.sort((a, b) => a.localeCompare(b))
        ?.map((item) => ({
          label: item?.charAt(0).toUpperCase() + item?.slice(1).toLowerCase(),
          value: item,
        })) || [],
  );

  const [date, setDate] = useState<{
    startDate: string;
    endDate: string | null;
  }>({
    startDate: moment().subtract(6, 'days').format(defaultDateFormat),
    endDate: moment().format(defaultDateFormat),
  });
  const [account, setAccount] = useState<AccountName | null>(null);
  const [showAccountNameDropdown, setShowAccountNameDropdown] = useState(false);
  const [selectedGroups, setSelectedGroups] = useState<MultiSelectOption[]>([]);
  const [selectedCurrencies, setSelectedCurrencies] = useState<
    MultiSelectOption[]
  >([]);
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [visible, setVisible] = useState(true);
  const [isSelectionModeActive, setIsSelectionModeActive] = useState(false);
  const [selectedOrderIds, setSelectedOrderIds] = useState<Set<string>>(
    new Set(),
  );
  const copyFunctionRef = useRef<(orders: any[]) => void | null>(null);

  const allOrdersInView = useMemo(() => {
    return (
      ordersData?.orders?.flatMap((orderGroup) => orderGroup.orders || []) || []
    );
  }, [ordersData]);

  const isAllSelected = useMemo(() => {
    if (allOrdersInView.length === 0) return false;
    return allOrdersInView.every((order) =>
      selectedOrderIds.has(order.unique_id),
    );
  }, [allOrdersInView, selectedOrderIds]);

  const isIntermediate = useMemo(() => {
    if (allOrdersInView.length === 0) return false;
    return selectedOrderIds.size > 0 && !isAllSelected;
  }, [allOrdersInView, selectedOrderIds, isAllSelected]);

  const items: AccountName[] = accountNames ? [...accountNames] : [];
  const groupOptions: MultiSelectOption[] =
    groups?.map((group) => ({
      label: group.group_id,
      value: group.unique_id,
    })) || [];

  const { control, reset, watch, setValue } = useForm({
    resolver: yupResolver(newReportSchema(t)),
    defaultValues: {
      accountName: '',
      groupName: '',
      status: '',
      orderedBy: 'all',
    },
  });

  useEffect(() => {
    dispatch(getOrderStatusThunk());
    dispatch(getAllCurrenciesThunk());
    handleGroupNameChange('');
    handleAccountNameChange('');
  }, []);

  const status = watch('status');
  const orderedBy = watch('orderedBy');

  const getOrders = async () => {
    if (currentRequest.current) {
      currentRequest.current.abort();
    }
    setSelectedOrderIds(new Set()); // Clear selection on new search
    const query = [];

    if (selectedGroups.length > 0) {
      if (selectedGroups.length === 1) {
        query.push({
          fieldName: 'group_id',
          fieldString: selectedGroups[0].value ?? '',
          operation: 'eq',
        });
      } else {
        query.push({
          fieldName: 'group_id',
          fieldString: selectedGroups.map((group) => group.value ?? ''),
          operation: 'eq',
        });
      }
    }

    if (selectedCurrencies.length > 0) {
      if (selectedCurrencies.length === 1) {
        query.push({
          fieldName: 'currency',
          fieldString: selectedCurrencies[0].value ?? '',
          operation: 'eq',
        });
      } else {
        query.push({
          fieldName: 'currency',
          fieldString: selectedCurrencies.map(
            (currency) => currency.value ?? '',
          ),
          operation: 'eq',
        });
      }
    }

    if (status) {
      query.push({
        fieldName: 'status',
        fieldString: status ?? '',
        operation: 'eq',
      });
    }

    if (orderedBy && orderedBy !== 'all') {
      query.push({
        fieldName: 'order_by',
        fieldString: orderedBy ?? '',
        operation: 'eq',
      });
    }

    if (account?.unique_id) {
      query.push({
        fieldName: 'account_id',
        fieldString: account.unique_id ?? '',
        operation: 'eq',
      });
    }

    currentRequest.current = dispatch(
      getAllOrdersReportThunk({
        payload: {
          cp: 1,
          pl: pageSize,
          query,
          from_date: date.startDate,
          to_date: date.endDate ?? undefined,
        },
        callbackAfterSuccess: () => {
          if (isInitialLoad) setIsInitialLoad(false);
        },
      }),
    );
  };

  useEffect(() => {
    getOrders(); // Fetch first page
  }, [
    selectedGroups,
    account?.unique_id,
    date,
    status,
    orderedBy,
    selectedCurrencies,
  ]);

  const onOrderUpdated = () => {
    getOrders(); // Fetch first page
  };

  const handleOrderSelect = useCallback((orderId: string) => {
    setSelectedOrderIds((prevSelected) => {
      const newSelected = new Set(prevSelected);
      if (newSelected.has(orderId)) {
        newSelected.delete(orderId);
      } else {
        newSelected.add(orderId);
      }
      return newSelected;
    });
  }, []);

  const handleCopyOrder = (order: Order) => {
    navigator.clipboard.writeText(buildOrderString(order)).then(() => {
      showSuccessToast('Order details copied to clipboard!');
    });
  };

  const handleCopySelectedOrders = useCallback(() => {
    const ordersToCopy = ordersData?.orders
      ?.flatMap((orderGroup) => orderGroup.orders || [])
      .filter((order) => selectedOrderIds.has(order.unique_id));

    if (!ordersToCopy?.length) return;

    const copyText = ordersToCopy
      .map((o) => `${buildOrderString(o)}--------------------\n`)
      .join('');

    navigator.clipboard.writeText(copyText).then(() => {
      showSuccessToast('Selected order details copied to clipboard!');
    });
  }, [selectedOrderIds, ordersData]);

  const handleToggleSelectionMode = useCallback(() => {
    setIsSelectionModeActive((prev) => !prev);
    setSelectedOrderIds(new Set()); // Clear selection when toggling mode
  }, []);

  const handleCancelSelectionMode = useCallback(() => {
    setIsSelectionModeActive(false);
    setSelectedOrderIds(new Set());
  }, []);

  const handleSelectAll = useCallback(() => {
    if (isAllSelected) {
      setSelectedOrderIds(new Set());
    } else {
      const allIds = new Set(allOrdersInView.map((order) => order.unique_id));
      setSelectedOrderIds(allIds);
    }
  }, [isAllSelected, allOrdersInView]);

  const handleAccountNameChange = useCallback((value: string) => {
    dispatch(getAccountNamesThunk(value));
  }, []);
  const handleGroupNameChange = useCallback((value: string) => {
    dispatch(getOrderGroupThunk({ search: value }));
  }, []);

  const handleCurrencyChange = useCallback((value: string) => {
    dispatch(getAllCurrenciesThunk({ search: value }));
  }, []);

  const accountNameRef = useRef<HTMLDivElement>(null);
  useOutsideClick(accountNameRef, () => setShowAccountNameDropdown(false));

  useEffect(() => {
    const scrollable = document.querySelector('.scrollable-list');

    if (!scrollable) return;

    const handleScroll = () => {
      const top = (scrollable as HTMLElement).scrollTop;
      if (window.innerWidth <= 640) {
        setVisible(top <= 20); // show if near top
      } else {
        setVisible(true);
      }
    };

    scrollable.addEventListener('scroll', handleScroll);
    return () => scrollable.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <PageTitle title="Reports" />
      <div
        className={`flex flex-col h-[calc(100vh-118px)] ${
          visible && ' mt-4 sm:mt-[51px]'
        } `}
      >
        <ReportFilters
          date={date}
          setDate={setDate}
          selectedGroups={selectedGroups}
          setSelectedGroups={setSelectedGroups}
          handleGroupNameChange={handleGroupNameChange}
          groupsLoading={groupsLoading}
          account={account}
          setAccount={setAccount}
          showAccountNameDropdown={showAccountNameDropdown}
          setShowAccountNameDropdown={setShowAccountNameDropdown}
          handleAccountNameChange={handleAccountNameChange}
          items={items}
          groupOptions={groupOptions}
          orderedByOptions={orderedByOptions}
          selectedCurrencies={selectedCurrencies}
          setSelectedCurrencies={setSelectedCurrencies}
          handleCurrencyChange={handleCurrencyChange}
          currencies={currencies}
          currenciesLoading={currenciesLoading}
          orderStatus={orderStatus}
          control={control}
          setValue={setValue}
          visible={visible}
        />
        <ReportSelectionActions
          isSelectionModeActive={isSelectionModeActive}
          selectedOrderIdsSize={selectedOrderIds.size}
          handleSelectAll={handleSelectAll}
          isAllSelected={isAllSelected}
          isIntermediate={isIntermediate}
          handleCopySelectedOrders={handleCopySelectedOrders}
          handleCancelSelectionMode={handleCancelSelectionMode}
          onToggleSelectionMode={handleToggleSelectionMode}
          hasOrdersInView={
            (ordersData?.orders?.length ?? 0) > 0 && allOrdersInView.length > 0
          }
        />
        <div className="flex-grow scrollable-list overflow-y-auto h-[calc(100vh-100px)]">
          <div className="h-full  flex-grow px-4 sm:px-6 md:px-12">
            <div className="flex flex-col gap-[30px] pb-12">
              {isInitialLoad && loading ? (
                Array.from({ length: 5 }).map((_, index) => (
                  <OrderListSkeleton key={index} />
                ))
              ) : allOrdersInView.length === 0 ? (
                <NoData />
              ) : (
                ordersData?.orders?.map((orderGroup: any) =>
                  orderGroup.orders?.length > 0 ? (
                    <div key={orderGroup.date}>
                      <p className="mb-1 text-sm font-normal text-initialsText">
                        {orderGroup.date}
                      </p>
                      <div className="flex flex-col gap-4 h-full">
                        {orderGroup.orders.map((order: any) => (
                          <OrderCard
                            key={order.unique_id}
                            order={order}
                            onOrderUpdated={onOrderUpdated}
                            showGroup={true}
                            isSelectMode={isSelectionModeActive}
                            isSelected={selectedOrderIds.has(order.unique_id)}
                            onSelect={() => handleOrderSelect(order.unique_id)}
                            onCopyOrder={handleCopyOrder}
                          />
                        ))}
                      </div>
                    </div>
                  ) : null,
                )
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Report;
