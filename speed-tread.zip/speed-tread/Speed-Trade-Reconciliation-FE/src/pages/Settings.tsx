import React from 'react';
import Breadcrumb from '../components/Breadcrumb';
import useBreadcrumbs from '../hooks/useBreadcrumbs';

const Settings: React.FC = () => {
  const breadcrumbItems = useBreadcrumbs();

  return (
    <div className="h-[calc(100vh-160px)]">
      <div className="flex justify-between items-center mb-4 p-4 bg-white">
        <Breadcrumb items={breadcrumbItems} />
      </div>
      <div className="p-4">
        <h1 className="text-2xl font-bold">Settings Page</h1>
      </div>
    </div>
  );
};

export default Settings;
