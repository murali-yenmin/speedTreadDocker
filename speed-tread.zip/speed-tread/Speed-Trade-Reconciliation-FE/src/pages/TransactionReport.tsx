import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import ReportFilters from '../components/Report/ReportFilters';
import { MultiSelectOption } from '../components/formFields/MultiSelect';
import { AccountName } from '../store/interfaces/accountName';
import { useAppDispatch, useAppSelector } from '../store/store';
import { getAllTransactionsThunk } from '../store/thunks/transaction';
import TransactionDetailCard from '../components/TransactionDetailCard';
import TransactionListSkeleton from '../components/TransactionListSkeleton';
import NoData from '../components/NoData';
import moment from 'moment';
import { getAllGroupsThunk } from '../store/thunks/groups';
import { getAccountNamesThunk } from '../store/thunks/accountName';
import { getAllCurrenciesThunk } from '../store/thunks/settings';
import { Group } from '../store/interfaces/group';
import { orderedByOptions } from '../constants/dropdowns';

interface QueryItem {
  operation: string;
  fieldName: string;
  fieldString: string;
}

const TransactionReport = () => {
  const dispatch = useAppDispatch();
  const { data: transactionsData, loading } = useAppSelector(
    (state) => state.getAllTransactionsReducer,
  );
  const { groups, loading: groupsLoading } = useAppSelector(
    (state) => state.getAllGroupsReducer,
  );
  const { accountNames } = useAppSelector((state) => state.accountNameReducer);
  const { data: currencies, loading: currenciesLoading } = useAppSelector(
    (state) => state.getAllCurrenciesReducer,
  );

  const [date, setDate] = useState<{
    startDate: string;
    endDate: string | null;
  }>({
    startDate: moment().subtract(6, 'days').format('DD-MM-YYYY'),
    endDate: moment().format('DD-MM-YYYY'),
  });
  const [selectedGroups, setSelectedGroups] = useState<MultiSelectOption[]>([]);
  const [account, setAccount] = useState<AccountName | null>(null);
  const [showAccountNameDropdown, setShowAccountNameDropdown] = useState(false);
  const [selectedCurrencies, setSelectedCurrencies] = useState<
    MultiSelectOption[]
  >([]);
  const [transferBy, setTransferBy] = useState('');

  const { control, setValue } = useForm();

  const handleGroupNameChange = (value: string) => {
    dispatch(
      getAllGroupsThunk({
        payload: {
          cp: 0,
          pl: 10,
          query: [
            {
              operation: '%',
              fieldName: 'name',
              fieldString: value,
            },
          ],
        },
      }),
    );
  };
  const handleAccountNameChange = (value: string) => {
    dispatch(getAccountNamesThunk(value));
  };
  const handleCurrencyChange = (value: string) => {
    dispatch(getAllCurrenciesThunk({ search: value }));
  };

  const fetchAllTransactions = useCallback(() => {
    const query: QueryItem[] = [];

    if (selectedGroups.length > 0) {
      query.push({
        operation: 'eq',
        fieldName: 'group_id',
        fieldString: selectedGroups.map((g) => g.value) as any,
      });
    }

    if (transferBy && transferBy !== 'all') {
      query.push({
        fieldName: 'transfer_by',
        fieldString: transferBy ?? '',
        operation: 'eq',
      });
    }

    if (account) {
      query.push({
        operation: 'eq',
        fieldName: 'account_id',
        fieldString: account.unique_id,
      });
    }

    if (selectedCurrencies.length > 0) {
      query.push({
        operation: 'eq',
        fieldName: 'sell_currency',
        fieldString: selectedCurrencies.map((c) => c.value) as any,
      });
    }

    dispatch(
      getAllTransactionsThunk({
        payload: {
          cp: 0,
          pl: 0,
          query: query,
          from_date: date.startDate,
          to_date: date.endDate ?? undefined,
        },
      }),
    );
  }, [dispatch, date, selectedGroups, account, selectedCurrencies, transferBy]);

  useEffect(() => {
    fetchAllTransactions();
  }, [fetchAllTransactions]);

  useEffect(() => {
    dispatch(getAllGroupsThunk({ payload: { cp: 0, pl: 10, query: [] } }));
    dispatch(getAllCurrenciesThunk());
  }, [dispatch]);

  const groupOptions = useMemo(
    () =>
      groups?.customer_groups_list?.map((group: Group) => ({
        label: group.group_id,
        value: group.unique_id,
      })) || [],
    [groups],
  );

  const currencyOptions = useMemo(
    () =>
      currencies?.map((currency) => ({
        label: currency.code,
        value: currency.code,
      })) || [],
    [currencies],
  );

  const allTransactionsInView = useMemo(() => {
    return (
      transactionsData?.transactions?.flatMap(
        (transactionsGroup) => transactionsGroup.transactions || [],
      ) || []
    );
  }, [transactionsData]);

  return (
    <>
      <div className="pt-5 pb-5 z-20 bg-gray-50 sm:pt-[51px] md_lg:sticky top-0">
        <ReportFilters
          date={date}
          setDate={setDate}
          selectedGroups={selectedGroups}
          setSelectedGroups={setSelectedGroups}
          handleGroupNameChange={handleGroupNameChange}
          groupsLoading={groupsLoading}
          account={account}
          setAccount={setAccount}
          showAccountNameDropdown={showAccountNameDropdown}
          setShowAccountNameDropdown={setShowAccountNameDropdown}
          handleAccountNameChange={handleAccountNameChange}
          items={accountNames}
          groupOptions={groupOptions}
          orderedByOptions={orderedByOptions}
          onChangeOrderBy={(value) => {
            if (value && 'value' in value) {
              setTransferBy(String(value?.value));
            }
          }}
          selectedCurrencies={selectedCurrencies}
          setSelectedCurrencies={setSelectedCurrencies}
          handleCurrencyChange={handleCurrencyChange}
          currencies={currencyOptions}
          currenciesLoading={currenciesLoading}
          orderStatus={[]}
          control={control}
          setValue={setValue}
          visible={true}
          showStatusFilter={false}
        />
      </div>
      <div className="px-4 pb-4 sm:px-6 md:px-12">
        <div className="flex-grow pb-6">
          <div className="flex flex-col gap-4 h-full">
            {loading ? (
              Array.from({ length: 3 }).map((_, index) => (
                <TransactionListSkeleton key={index} />
              ))
            ) : allTransactionsInView?.length === 0 ? (
              <NoData message="No Transactions Found" />
            ) : (
              transactionsData?.transactions?.map((transactionGroup) => {
                return transactionGroup.transactions?.length > 0 ? (
                  <div key={transactionGroup.date}>
                    <p className="mb-1 text-sm font-normal text-initialsText">
                      {transactionGroup.date}
                    </p>
                    <div className="flex flex-col gap-4 h-full">
                      {transactionGroup.transactions?.map(
                        (transaction, index, self) => {
                          const group = groups?.customer_groups_list?.find(
                            (g) => g.unique_id === transaction.group_id,
                          );
                          return (
                            <TransactionDetailCard
                              key={transaction.unique_id}
                              transaction={transaction}
                              settlementCurrency={
                                transaction?.settlement_currency
                              }
                              context="transactions"
                              onUpdate={() => fetchAllTransactions()}
                              cardStyle="bg-gray-50"
                              selectedDate={transactionGroup.date}
                              showGroup={true}
                              group={group}
                              showCopy={false}
                              index={index}
                              self={self}
                            />
                          );
                        },
                      )}
                    </div>
                  </div>
                ) : null;
              })
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default TransactionReport;
