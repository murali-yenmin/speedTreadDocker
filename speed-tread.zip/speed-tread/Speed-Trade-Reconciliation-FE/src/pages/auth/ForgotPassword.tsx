import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import Input from '../../components/formFields/Input';
import { useTranslation } from 'react-i18next';
import AuthLayout from '../../layout/AuthLayout';
import { Link } from 'react-router-dom';
import Button from '../../components/formFields/Button';
import { ReactComponent as CheckIcon } from '../../assets/svg/CheckIcon.svg';
import { useAppDispatch } from '../../store/store';
import { forgotPasswordThunk } from '../../store/thunks/authentication';
import { forgotSchema } from '../../validations/authentication';
import PageTitle from '../../components/PageTitle';

const ForgotPassword: React.FC = () => {
  const { t } = useTranslation();
  const dispatch = useAppDispatch();

  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  const { handleSubmit, control } = useForm({
    resolver: yupResolver(forgotSchema(t)),
    defaultValues: {
      email_address: '',
    },
  });

  const onSubmit = (formData: { email_address: string }) => {
    dispatch(
      forgotPasswordThunk({
        payload: formData,
        successCallback: () => {
          setShowSuccessMessage(true);
        },
      }),
    );
  };

  return (
    <AuthLayout>
      <PageTitle title="Forgot Password" />

      <div className="w-full">
        <h2 className="text-3xl font-bold text-gray-900">
          {t('reset_password_title')}
        </h2>
        {!showSuccessMessage && (
          <p className="mt-2 text-gray-600">{t('reset_password_subtitle')}</p>
        )}
        {showSuccessMessage ? (
          <div className="mt-8 p-4 bg-light-green border border-secondary-green text-primary-green rounded-md flex items-center">
            <CheckIcon className="h-6 w-6 mr-2 text-secondary-green" />
            <p className="whitespace-pre-line">{t('reset_password_success')}</p>
          </div>
        ) : (
          <form
            className="mt-8 space-y-6"
            onSubmit={handleSubmit(onSubmit)}
            autoComplete="off"
          >
            <Input
              name="email_address"
              control={control}
              label={t('email_label')}
              type="email"
              placeholder="eg:example@gmail.com"
              className="mb-4"
              required
            />

            <div>
              <Button variant="primary" type="submit" className="w-full">
                {t('reset_password_button')}
              </Button>
            </div>
          </form>
        )}
        <div className="mt-4 text-sm text-center">
          <span className="text-gray-600">{t('password_recovered')} </span>
          <Link
            to="/login"
            className="font-medium text-primary-blue hover:text-secondary-blue"
          >
            {t('sign_in_button')}
          </Link>
        </div>
      </div>
    </AuthLayout>
  );
};

export default ForgotPassword;
