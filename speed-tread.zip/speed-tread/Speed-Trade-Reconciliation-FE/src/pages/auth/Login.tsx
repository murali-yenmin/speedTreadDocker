import React from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import Input from '../../components/formFields/Input';
import PasswordInput from '../../components/formFields/PasswordInput';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import AuthLayout from '../../layout/AuthLayout';
import Button from '../../components/formFields/Button';
import { useAppDispatch, useAppSelector } from '../../store/store';
import { loginThunk } from '../../store/thunks/authentication';
import { loginSchema } from '../../validations/authentication';
import { encryptData } from '../../utils/encryption';
import PageTitle from '../../components/PageTitle';

const Login: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const { loading } = useAppSelector((state) => state.loginReducer);

  const { handleSubmit, control } = useForm({
    resolver: yupResolver(loginSchema(t)),
    defaultValues: {
      email_address: '',
      password: '',
    },
  });

  const onSubmit = (data: any) => {
    dispatch(
      loginThunk({
        payload: {
          email_address: data?.email_address,
          password: encryptData(data?.password),
        },
        successCallback: () => {
          navigate('/dashboard', { replace: true });
          window.location.reload();
        },
      }),
    );
  };

  return (
    <AuthLayout>
      <PageTitle title="Login" />

      <div className="w-full">
        <h2 className="text-3xl font-bold text-gray-900">Sign In</h2>
        <p className="mt-2 text-gray-600">
          Please login to continue to your account.
        </p>
        <form
          className="mt-8 space-y-6"
          onSubmit={handleSubmit(onSubmit)}
          autoComplete="off"
        >
          <Input
            name="email_address"
            control={control}
            label={t('email_label')}
            type="email"
            placeholder="eg:example@gmail.com"
            className="mb-4"
            required
          />
          <PasswordInput
            name="password"
            control={control}
            label={t('password_label')}
            placeholder="****************"
            className="mb-4 pass-placeholder"
            required
          />
          <div className="flex items-center justify-end">
            <div className="text-sm">
              <Link
                to="/forgot-password"
                className="font-medium text-gray-600 hover:text-gray-900"
              >
                {t('forgot_password_link')}
              </Link>
            </div>
          </div>
          <div>
            <Button
              variant="primary"
              type="submit"
              className="w-full"
              isLoading={loading}
            >
              Get Started
            </Button>
          </div>
        </form>
      </div>
    </AuthLayout>
  );
};

export default Login;
