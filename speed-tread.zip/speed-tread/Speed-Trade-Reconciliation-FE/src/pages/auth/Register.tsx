import React from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import Input from '../../components/formFields/Input';
import PasswordInput from '../../components/formFields/PasswordInput';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import AuthLayout from '../../layout/AuthLayout';
import Button from '../../components/formFields/Button';

const Register: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();

  const schema = yup.object().shape({
    fullName: yup.string().required(t('validation_fullname_required')),
    email: yup
      .string()
      .email(t('validation_email_invalid'))
      .required(t('validation_email_required')),
    password: yup
      .string()
      .min(6, t('validation_password_min_length'))
      .required(t('validation_password_required')),
    confirmPassword: yup
      .string()
      .oneOf([yup.ref('password')], t('validation_password_mismatch'))
      .required(t('validation_confirm_password_required')),
  });

  const { handleSubmit, control } = useForm({
    resolver: yupResolver(schema),
  });

  const onSubmit = (data: any) => {
    navigate('/login');
  };

  return (
    <AuthLayout>
      <div className="w-full">
        <h2 className="text-3xl font-bold text-gray-900">
          {t('register_title')}
        </h2>
        <p className="mt-2 text-gray-600">Create your account.</p>
        <form
          className="mt-8 space-y-6"
          onSubmit={handleSubmit(onSubmit)}
          autoComplete="off"
        >
          <Input
            name="fullName"
            control={control}
            label={t('full_name_label')}
            type="text"
            placeholder="John Doe"
            className="mb-4"
          />
          <Input
            name="email"
            control={control}
            label={t('email_label')}
            type="email"
            placeholder="eg:example@gmail.com"
            className="mb-4"
          />
          <PasswordInput
            name="password"
            control={control}
            label={t('password_label')}
            placeholder="****************"
            className="mb-4"
          />
          <PasswordInput
            name="confirmPassword"
            control={control}
            label={t('confirm_password_label')}
            placeholder="****************"
            className="mb-4"
          />

          <div>
            <Button variant="primary" type="submit" className="w-full">
              {t('sign_up_button')}
            </Button>
          </div>
        </form>
        <div className="mt-4 text-sm text-center">
          <Link
            to="/login"
            className="font-medium text-gray-600 hover:text-gray-500"
          >
            {t('already_have_account')}
          </Link>
        </div>
      </div>
    </AuthLayout>
  );
};

export default Register;
