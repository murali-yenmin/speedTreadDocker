import React from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { useTranslation } from 'react-i18next';
import AuthLayout from '../../layout/AuthLayout';
import Button from '../../components/formFields/Button';
import PasswordInput from '../../components/formFields/PasswordInput';
import PasswordStrength from '../../components/PasswordStrength';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useAppDispatch } from '../../store/store';
import { resetPasswordThunk } from '../../store/thunks/authentication';
import { encryptData } from '../../utils/encryption';
import PageTitle from '../../components/PageTitle';

const ResetPassword: React.FC = () => {
  const { t } = useTranslation();
  const { token = '' } = useParams();
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const schema = yup.object().shape({
    new_password: yup
      .string()
      .min(8, t('validation_password_min_length'))
      .required(t('validation_password_required')),
    confirm_password: yup
      .string()
      .oneOf([yup.ref('new_password')], t('validation_password_mismatch'))
      .required(t('validation_confirm_password_required')),
  });

  const { handleSubmit, control, watch } = useForm({
    resolver: yupResolver(schema),
  });

  const password = watch('new_password');

  const onSubmit = (data: {
    new_password: string;
    confirm_password: string;
  }) => {
    const result = {
      payload: {
        new_password: encryptData(data?.new_password),
        confirm_password: encryptData(data?.confirm_password),
        secret_key: token,
      },
      successCallback: () => {
        navigate('/login');
      },
    };
    dispatch(resetPasswordThunk(result));
  };

  return (
    <AuthLayout>
      <PageTitle title="Reset Password" />

      <div className="w-full">
        <h2 className="text-3xl font-bold text-gray-900">
          {t('reset_password_title')}
        </h2>
        <p className="mt-2 text-gray-600">{t('reset_password_description')}</p>
        <form
          className="mt-8 space-y-6"
          onSubmit={handleSubmit(onSubmit)}
          autoComplete="off"
        >
          <PasswordInput
            name="new_password"
            control={control}
            label={t('new_password_label')}
            placeholder={t('new_password_placeholder')}
            required
          />
          <PasswordStrength password={password} />
          <PasswordInput
            name="confirm_password"
            control={control}
            label={t('confirm_password_label')}
            placeholder={t('confirm_password_placeholder')}
            required
          />

          <div>
            <Button variant="primary" type="submit" className="w-full">
              {t('reset_password_button')}
            </Button>
          </div>
        </form>
        <div className="mt-4 text-sm text-center">
          <span className="text-gray-600">{t('back_to_login')} </span>
          <Link
            to="/login"
            className="font-medium text-primary-blue hover:text-secondary-blue"
          >
            {t('sign_in_button')}
          </Link>
        </div>
      </div>
    </AuthLayout>
  );
};

export default ResetPassword;
