import ProfileSummarySkeleton from './components/ProfileSummarySkeleton'; 
import PersonalInformationFormSkeleton from './components/PersonalInformationFormSkeleton';
import ProfileNavigationSkeleton from './components/ProfileNavigationSkeleton'; 
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ReactComponent as BackArrowIcon } from '../../assets/svg/BackArrow.svg';
import PersonalInformationForm from './components/PersonalInformationForm';
import PasswordForm from './components/PasswordForm';
import ProfileNavigation from './components/ProfileNavigation';
import ProfileSummary from './components/ProfileSummary';
import { useAppDispatch, useAppSelector } from '../../store/store'; 
import PageTitle from '../../components/PageTitle';

const Profile: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'personal' | 'password'>(
    'personal',
  );

  const dispatch = useAppDispatch();
  const { profileData, profileLoading, error } = useAppSelector(
    (state) => state.profileReducer,
  );

  return (
    <>
      <PageTitle title="Profile" />

      <div className="container mx-auto mt-[31px] flex justify-end pr-4 md:pr-8">
        <div
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 cursor-pointer text-grey-100 font-bold text-16px w-fit"
        >
          <BackArrowIcon />
          <span>Back</span>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row mx-auto transition-all duration-300 ease-in-out md:w-[95%] px-2">
        <div className="w-full lg:w-1/3 p-4 md:p-8 md:pl-4">
          <div className="bg-white rounded-lg shadow">
            {profileLoading && <ProfileSummarySkeleton />}
            {error && <p className="text-red-500">Error: {error}</p>}
            {!profileLoading &&
              profileData && ( // Only show actual data when not loading and data is available
                <>
                  <ProfileSummary />
                </>
              )}
            {profileLoading && <ProfileNavigationSkeleton />}
            {!profileLoading && profileData && (
              <ProfileNavigation
                activeTab={activeTab}
                setActiveTab={setActiveTab}
              />
            )}
          </div>
        </div>
        <div className="w-full lg:w-2/3 p-4 md:p-8 md:pl-4 max-h-screen overflow-hidden">
          {profileLoading && <PersonalInformationFormSkeleton />}
          {error && <p className="text-red-500">Error: {error}</p>}

          {!profileLoading && profileData && (
            <div
              key={activeTab} // this is important for animation reset
              className=""
            >
              {activeTab === 'personal' ? (
                <PersonalInformationForm />
              ) : (
                <PasswordForm />
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Profile;
