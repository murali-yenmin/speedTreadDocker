import React from 'react';

interface IconWrapperProps {
  icon: React.ReactElement;
}

const IconWrapper: React.FC<IconWrapperProps> = ({ icon }) => {
  return (
    <div
      className="
        bg-light-blue
        p-4 
        rounded-lg 
        flex 
        items-center 
        justify-center
      "
    >
      {icon}
    </div>
  );
};

export default IconWrapper;
