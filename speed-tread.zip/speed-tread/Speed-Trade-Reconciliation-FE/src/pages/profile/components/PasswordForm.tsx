import React, { useEffect } from 'react'; // Added useEffect
import { useForm, FormProvider } from 'react-hook-form';
import Button from '../../../components/formFields/Button';
import PasswordInput from '../../../components/formFields/PasswordInput';
import { yupResolver } from '@hookform/resolvers/yup';
import { useTranslation } from 'react-i18next';
import { useAppDispatch, useAppSelector } from '../../../store/store'; // Import Redux hooks
import {
  changePassword,
  resetPasswordChangeState,
} from '../../../store/slices/user/profileSlice'; // Import thunk and reset action
import { encryptData } from '../../../utils/encryption'; // Import encryption utility
import { showSuccessToast, showErrorToast } from '../../../utils/toast'; // Import toast utilities
import { passwordSchema } from '../../../validations/profile/password'; // New import
import { PasswordFormData } from '../../../store/interfaces/profile/password'; // New import
import { ReactComponent as PasswordLockIcon } from '../../../assets/svg/passwordLock.svg';
import ProfileFormHeader from './ProfileFormHeader';
import PasswordStrengthMeter from './PasswordStrengthMeter';

const PasswordForm: React.FC = () => {
  const { t } = useTranslation();
  const methods = useForm<PasswordFormData>({
    resolver: yupResolver(passwordSchema(t)),
    mode: 'onChange',
    defaultValues: {
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    },
  });

  const {
    watch,
    reset,
    formState: { isValid },
  } = methods;

  const newPassword = watch('newPassword');
  const confirmPassword = watch('confirmPassword');

  const passwordStrength = {
    lowercase: /[a-z]/.test(newPassword),
    uppercase: /[A-Z]/.test(newPassword),
    numbers: /\d/.test(newPassword),
  };
  const isStrengthValid = Object.values(passwordStrength).every(Boolean);

  const passwordsMatch = newPassword && newPassword === confirmPassword;

  const { passwordChangeSuccess, passwordChangeError, passwordChangeLoading } =
    useAppSelector((state) => state.profileReducer); // Get password change states and loading
  const dispatch = useAppDispatch(); // Initialize dispatch

  useEffect(() => {
    if (passwordChangeSuccess) {
      showSuccessToast(
        t('password_changed_success'),
        undefined,
        'password-change-toast',
      );
      methods.reset({
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
      }); // Reset form fields to empty strings
      dispatch(resetPasswordChangeState()); // Reset state after toast
    } else if (passwordChangeError) {
      showErrorToast(passwordChangeError, undefined, 'password-change-toast');
      dispatch(resetPasswordChangeState()); // Reset state after toast
    }
  }, [passwordChangeSuccess, passwordChangeError, dispatch, methods, t]);

  const onSubmit = async (data: PasswordFormData) => {
    const payload = {
      current_password: encryptData(data.currentPassword),
      password: encryptData(data.newPassword),
      confirm_password: encryptData(data.confirmPassword),
    };

    try {
      await dispatch(changePassword(payload)).unwrap(); // Use .unwrap() to handle success/failure
    } catch (error) {
      // Error handled by extraReducers and useEffect
    }
  };

  const isButtonDisabled =
    !isValid || !isStrengthValid || !passwordsMatch || passwordChangeLoading;

  return (
    <FormProvider {...methods}>
      <form onSubmit={methods.handleSubmit(onSubmit)} autoComplete="off">
        <div className="bg-white p-8 rounded-lg shadow">
          <ProfileFormHeader
            className="mb-8"
            icon={<PasswordLockIcon />}
            title="Password"
            subtitle="Use a mix of uppercase letters, lowercase letters, and numbers, with a minimum of 8 characters."
          />
          <div className="grid grid-cols-1 gap-8 w-full sm:max-w-[320px]">
            <PasswordInput
              label="Current Password"
              name="currentPassword"
              control={methods.control}
              placeholder="Enter Current Password"
            />
            <div>
              <PasswordInput
                label="New Password"
                name="newPassword"
                control={methods.control}
                placeholder="Enter New Password"
              />
              <PasswordStrengthMeter password={newPassword} />
            </div>
            <PasswordInput
              label="Confirm New Password"
              name="confirmPassword"
              control={methods.control}
              placeholder="Confirm New Password"
            />
          </div>
          <div className="flex justify-start mt-8">
            <Button
              variant="secondary"
              className="mr-4 w-32"
              type="button"
              fullWidth={false}
              onClick={() => reset()}
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              className="w-32"
              type="submit"
              isLoading={passwordChangeLoading}
              disabled={isButtonDisabled}
              fullWidth={false}
            >
              Save
            </Button>
          </div>
        </div>
      </form>
    </FormProvider>
  );
};

export default PasswordForm;
