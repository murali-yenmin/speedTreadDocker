import React from 'react';
import { ReactComponent as ValidTickIcon } from '../../../assets/svg/validTick.svg';
import { ReactComponent as InvalidTickIcon } from '../../../assets/svg/InValidTick.svg';

interface PasswordStrengthMeterProps {
  password?: string;
}

const PasswordStrengthMeter: React.FC<PasswordStrengthMeterProps> = ({
  password = '',
}) => {
  const checks = {
    length: password.length >= 8,
    lowercase: /[a-z]/.test(password),
    uppercase: /[A-Z]/.test(password),
    numbers: /\d/.test(password),
  };

  const validationItems = [
    { label: 'Min 8 characters', key: 'length' as const },
    { label: 'Lowercase', key: 'lowercase' as const },
    { label: 'Uppercase', key: 'uppercase' as const },
    { label: 'Numbers', key: 'numbers' as const },
  ];

  return (
    <div className="grid grid-cols-2 gap-y-[11px] mt-2">
      {validationItems.map((item) => (
        <div key={item.key} className="flex items-center gap-x-[15px]">
          {checks[item.key] ? <ValidTickIcon /> : <InvalidTickIcon />}
          <span className="text-sm text-gray-600">{item.label}</span>
        </div>
      ))}
    </div>
  );
};

export default PasswordStrengthMeter;
