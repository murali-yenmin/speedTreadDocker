import React, { useState } from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import Button from '../../../components/formFields/Button';
import Input from '../../../components/formFields/Input';
import { ReactComponent as EditIcon } from '../../../assets/svg/EditIcon.svg';
import { ReactComponent as UserIcon } from '../../../assets/svg/user.svg';
import { yupResolver } from '@hookform/resolvers/yup';
import { useTranslation } from 'react-i18next';
import InfoIcon from '../../../components/Images/InfoIcon';
import { personalInfoSchema } from '../../../validations/profile/personalInfo';
import { useAppSelector, useAppDispatch } from '../../../store/store';
import { updateUserProfile } from '../../../store/slices/user/profileSlice';
import { showErrorToast } from '../../../utils/toast';
import { PersonalInfoFormData } from '../../../store/interfaces/profile/personalInfo';
import ProfileFormHeader from './ProfileFormHeader';

const PersonalInformationForm: React.FC = () => {
  const { t } = useTranslation();
  const [isEditing, setIsEditing] = useState(false);
  const { profileData, profileLoading } = useAppSelector(
    (state) => state.profileReducer,
  );
  const dispatch = useAppDispatch();

  if (!profileData) {
    return null; // Or a loading spinner/placeholder
  }

  const methods = useForm<PersonalInfoFormData>({
    resolver: yupResolver(personalInfoSchema(t)),
    defaultValues: {
      firstName: profileData.user_name,
      email: profileData.email_address,
    },
  });

  const onSubmit = async (data: PersonalInfoFormData) => {
    const payload = {
      unique_id: profileData.unique_id,
      user_name: data.firstName,
      email_address: data.email,
      role_id: profileData.role_id,
    };

    try {
      await dispatch(updateUserProfile(payload)).unwrap();
      setIsEditing(false);
    } catch (error: any) {
      showErrorToast(
        error.message || 'Failed to update profile.',
        undefined,
        'profile-update-toast',
      );
    }
  };

  const handleCancel = () => {
    methods.reset();
    setIsEditing(false);
  };

  return (
    <FormProvider {...methods}>
      <form onSubmit={methods.handleSubmit(onSubmit)} autoComplete="off">
        <div className="bg-white p-8 rounded-lg shadow">
          <ProfileFormHeader
            className="mb-8"
            icon={<UserIcon />}
            title="Personal Information"
            subtitle="Your username only editable fields."
            action={
              !isEditing && (
                <button
                  type="button"
                  className="p-2 rounded-full hover:bg-gray-200 profile-edit-btn"
                  onClick={() => setIsEditing(true)}
                >
                  <EditIcon className="text-midnight-blue" />
                </button>
              )
            }
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Input
              label="User Name"
              name="firstName"
              placeholder="John"
              control={methods.control}
              readOnly={!isEditing}
            />

            <div>
              <Input
                label="Email Address"
                name="email"
                placeholder="eg:example@gmail.com"
                control={methods.control}
                readOnly
              />
              <p className="text-sm text-gray-500 mt-1 flex items-center">
                <InfoIcon className="mr-1" />
                Email cannot be edited.
              </p>
            </div>


          </div>
          {isEditing && (
            <div className="flex justify-start mt-8">
              <Button
                variant="secondary"
                className="mr-4 w-32"
                type="button"
                onClick={handleCancel}
                fullWidth={false}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                className="w-32"
                type="submit"
                isLoading={profileLoading}
                fullWidth={false}
              >
                Save
              </Button>
            </div>
          )}
        </div>
      </form>
    </FormProvider>
  );
};

export default PersonalInformationForm;
