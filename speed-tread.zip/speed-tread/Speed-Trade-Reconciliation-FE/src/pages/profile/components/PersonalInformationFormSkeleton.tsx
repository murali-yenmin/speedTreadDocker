import React from 'react';

const PersonalInformationFormSkeleton: React.FC = () => {
  return (
    <div className="bg-white p-8 rounded-lg shadow animate-pulse">
      <div className="flex justify-between items-center mb-8">
        <div>
          <div className="h-8 w-64 bg-gray-300 rounded mb-2"></div>
          <div className="h-4 w-96 bg-gray-300 rounded"></div>
        </div>
        <div className="h-10 w-10 bg-gray-300 rounded-full"></div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Input field 1 */}
        <div>
          <div className="h-4 w-24 bg-gray-300 rounded mb-2"></div>
          <div className="h-10 bg-gray-300 rounded"></div>
        </div>
        {/* Input field 2 */}
        <div>
          <div className="h-4 w-24 bg-gray-300 rounded mb-2"></div>
          <div className="h-10 bg-gray-300 rounded"></div>
          <div className="h-4 w-48 bg-gray-300 rounded mt-1"></div>
        </div>
        {/* Input field 3 */}
        <div>
          <div className="h-4 w-24 bg-gray-300 rounded mb-2"></div>
          <div className="h-10 bg-gray-300 rounded"></div>
        </div>
      </div>
      <div className="flex justify-end mt-8">
        <div className="h-10 w-32 bg-gray-300 rounded mr-4"></div>
        <div className="h-10 w-32 bg-gray-300 rounded"></div>
      </div>
    </div>
  );
};

export default PersonalInformationFormSkeleton;
