import React from 'react';
import IconWrapper from './IconWrapper';

interface ProfileFormHeaderProps {
  icon: React.ReactElement;
  title: string;
  subtitle: string;
  action?: React.ReactNode;
  className?: string;
}

const ProfileFormHeader: React.FC<ProfileFormHeaderProps> = ({
  icon,
  title,
  subtitle,
  action,
  className = '',
}) => {
  return (
    <div
      className={`flex justify-between items-center pb-8 border-b border-grey-75 ${className}`}
    >
      <div className="flex items-center flex-grow gap-[18px] profile-information">
        <IconWrapper icon={icon} />
        <div>
          <h2 className="text-2xl font-bold">{title}</h2>
          <p className="text-gray-500">{subtitle}</p>
        </div>
      </div>
      {action}
    </div>
  );
};

export default ProfileFormHeader;
