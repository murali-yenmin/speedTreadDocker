import React from 'react';
import UserIconComponent from '../../../assets/icons/UserIconComponent';
import LockIconComponent from '../../../assets/icons/LockIconComponent';
import { ProfileNavigationProps } from '../../../store/interfaces/profile/navigation';

const ProfileNavigation: React.FC<ProfileNavigationProps> = ({
  activeTab,
  setActiveTab,
}) => {
  const activeColor = '#0075C3'; // strong-blue
  const inactiveColor = '#747474'; // grey-100

  return (
    <div className="p-8 space-y-2 ">
      <button
        className={`w-full flex items-center p-4 rounded-lg ${
          activeTab === 'personal'
            ? 'bg-alice-blue text-strong-blue font-bold'
            : 'text-grey-100'
        }`}
        onClick={() => setActiveTab('personal')}
      >
        <UserIconComponent
          className="mr-4"
          color={activeTab === 'personal' ? activeColor : inactiveColor}
        />
        My Details
      </button>
      <button
        className={`w-full flex items-center p-4 rounded-lg mt-2 ${
          activeTab === 'password'
            ? 'bg-alice-blue text-strong-blue font-bold'
            : 'text-grey-100'
        }`}
        onClick={() => setActiveTab('password')}
      >
        <LockIconComponent
          className="mr-4"
          color={activeTab === 'password' ? activeColor : inactiveColor}
        />
        Change Password
      </button>
    </div>
  );
};

export default ProfileNavigation;
