import React from 'react';

const ProfileNavigationSkeleton: React.FC = () => {
  return (
    <div className="p-8 space-y-2 animate-pulse">
      <div className="w-full flex items-center p-4 rounded-lg bg-gray-200 h-14">
        <div className="w-6 h-6 bg-gray-300 rounded-full mr-4"></div>
        <div className="h-4 w-3/4 bg-gray-300 rounded"></div>
      </div>
      <div className="w-full flex items-center p-4 rounded-lg bg-gray-200 h-14 mt-2">
        <div className="w-6 h-6 bg-gray-300 rounded-full mr-4"></div>
        <div className="h-4 w-3/4 bg-gray-300 rounded"></div>
      </div>
    </div>
  );
};

export default ProfileNavigationSkeleton;
