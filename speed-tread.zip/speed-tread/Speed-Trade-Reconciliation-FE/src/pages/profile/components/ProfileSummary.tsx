import React from 'react';
import { useAppSelector } from '../../../store/store'; // Import useAppSelector

const ProfileSummary: React.FC = () => {
  const { profileData } = useAppSelector((state) => state.profileReducer);

  if (!profileData) {
    return null; // Or a loading spinner/placeholder
  }

  const { user_name, email_address } = profileData;
  const initial = user_name.charAt(0).toUpperCase();

  return (
    <div className="flex flex-col items-center p-4 border-b">
      <div className="w-24 h-24 rounded-full mb-4  bg-light-blue flex items-center justify-center">
        <span className="text-primary-blue text-4xl font-bold">{initial}</span>
      </div>
      <h2 className="text-xl font-bold">{user_name}</h2>
      <p className="text-gray-500">{email_address}</p>
    </div>
  );
};

export default ProfileSummary;
