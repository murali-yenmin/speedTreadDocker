import React from 'react';

const ProfileSummarySkeleton: React.FC = () => {
  return (
    <div className="flex flex-col items-center p-4 border-b animate-pulse">
      <div className="w-24 h-24 rounded-full mb-4 bg-gray-300 flex items-center justify-center">
        {/* Placeholder for initial */}
      </div>
      <div className="h-6 w-3/4 bg-gray-300 rounded mb-2"></div>
      <div className="h-4 w-1/2 bg-gray-300 rounded"></div>
    </div>
  );
};

export default ProfileSummarySkeleton;
