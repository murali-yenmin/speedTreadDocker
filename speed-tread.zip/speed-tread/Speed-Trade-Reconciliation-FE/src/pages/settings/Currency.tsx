import React, { useState, useEffect, useMemo } from 'react';
import Tabs from '../../components/Tabs';
import { AddCurrencyForm } from './components/AddCurrencyForm';
import { CurrencyList } from './components/CurrencyList';
import { AddCurrencyPairForm } from './components/AddCurrencyPairForm';
import { CurrencyPairList } from './components/CurrencyPairList';
import { useAppDispatch, useAppSelector } from '../../store/store';
import {
  getAllCurrenciesThunk,
  getAllCurrencyPairsThunk,
} from '../../store/thunks/settings';
import PageTitle from '../../components/PageTitle';

const Currency: React.FC = () => {
  const dispatch = useAppDispatch();

  const [isMobile, setIsMobile] = useState(false);
  const [activeTab, setActiveTab] = useState('currency'); // 'currency' or 'pair'
  const [resetCurrencyPairFilter, setResetCurrencyPairFilter] = useState(0);

  const { currencies, isLoading, isUpdateLoading } = useAppSelector(
    (state) => ({
      currencies: state.getAllCurrenciesReducer.data,
      isLoading: state.getAllCurrenciesReducer.loading,
      isUpdateLoading: state.updateCurrencyReducer.loading,
    }),
  );
  const { currencyPairs, isCurrencyPairLoading, isCurrencyPairUpdateLoading } =
    useAppSelector((state) => ({
      currencyPairs: state.getAllCurrencyPairsReducer.data,
      isCurrencyPairLoading: state.getAllCurrencyPairsReducer.loading,
      isCurrencyPairUpdateLoading:
        state.currencyPairStatusChangeReducer.loading,
    }));

  const { currenciesSearch, currenciesSearchLoading } = useAppSelector(
    (state) => ({
      currenciesSearch: state.getAllFilterSearchCurrencyReducer.data,
      currenciesSearchLoading: state.getAllFilterSearchCurrencyReducer.loading,
    }),
  );

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 980); // Tailwind's md breakpoint
    };

    handleResize(); // Set initial value
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const initCall = () => {
    dispatch(getAllCurrenciesThunk());
    dispatch(getAllCurrencyPairsThunk());
  };

  useEffect(() => {
    initCall();
  }, []);

  const tabs = useMemo(
    () => [
      {
        id: 'currency',
        label: 'Currency',
        content: (
          <>
            <AddCurrencyForm />
            <CurrencyList
              currencies={currenciesSearch || []}
              isLoading={currenciesSearchLoading}
              isUpdateLoading={isUpdateLoading}
            />
          </>
        ),
      },
      {
        id: 'pair',
        label: 'Currency Pair',
        content: (
          <>
            <AddCurrencyPairForm
              setResetCurrencyPairFilter={setResetCurrencyPairFilter}
            />
            <CurrencyPairList
              isLoading={isCurrencyPairLoading}
              isUpdateLoading={isCurrencyPairUpdateLoading}
              currencies={currencies || []}
              resetCurrencyPairFilter={resetCurrencyPairFilter}
              getAllCb={initCall}
            />
          </>
        ),
      },
    ],
    [
      currencies,
      isLoading,
      isUpdateLoading,
      currencyPairs,
      isCurrencyPairLoading,
      isCurrencyPairUpdateLoading,
    ],
  );

  return (
    <>
      <PageTitle title="Settings" />
      <div className="p-4">
        {isMobile ? (
          <Tabs tabs={tabs} activeTab={activeTab} onTabChange={setActiveTab} />
        ) : (
          <div className="grid grid-cols-1 md_lg:grid-cols-2 gap-6">
            <div>
              <AddCurrencyForm />
              <CurrencyList
                currencies={currenciesSearch || []}
                isLoading={currenciesSearchLoading}
                isUpdateLoading={isUpdateLoading}
              />
            </div>
            <div>
              <AddCurrencyPairForm
                setResetCurrencyPairFilter={setResetCurrencyPairFilter}
              />
              <CurrencyPairList
                isLoading={isCurrencyPairLoading}
                isUpdateLoading={isCurrencyPairUpdateLoading}
                currencies={currencies || []}
                resetCurrencyPairFilter={resetCurrencyPairFilter}
                getAllCb={initCall}
              />
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default Currency;
