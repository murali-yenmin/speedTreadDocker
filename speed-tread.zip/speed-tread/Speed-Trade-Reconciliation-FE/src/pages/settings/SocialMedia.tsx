import React from 'react';
import { AddNewSocialMediaSource } from './components/AddNewSocialMediaSource';
import { SocialMediaSourceList } from './components/SocialMediaSourceList';
import Breadcrumb from '../../components/Breadcrumb';
import useBreadcrumbs from '../../hooks/useBreadcrumbs';

const SocialMedia: React.FC = () => {
  const breadcrumbItems = useBreadcrumbs();

  return (
    <>
      <div className="flex justify-between items-center mb-4 p-4 bg-white">
        <Breadcrumb items={breadcrumbItems} />
      </div>
      <div className="p-4">
        <AddNewSocialMediaSource />
        <SocialMediaSourceList />
      </div>
    </>
  );
};

export default SocialMedia;
