import Button from '../../../components/formFields/Button';
import Input from '../../../components/formFields/Input';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { addCurrencySchema } from '../../../validations/settings';
import { useTranslation } from 'react-i18next';
import { useAppDispatch, useAppSelector } from '../../../store/store';
import {
  addCurrencyThunk,
  getAllFilterSearchCurrenciesThunk,
} from '../../../store/thunks/settings';

export const AddCurrencyForm: React.FC = () => {
  const { t } = useTranslation();
  const dispatch = useAppDispatch();

  const isLoading = useAppSelector((state) => state.addCurrencyReducer.loading);

  const { control, handleSubmit, reset } = useForm({
    resolver: yupResolver(addCurrencySchema(t)),
    defaultValues: {
      name: '',
      code: '',
    },
  });

  const onSave = (data: any) => {
    dispatch(
      addCurrencyThunk({
        payload: data,
        afterSuccessCallback: () => {
          reset();
          dispatch(getAllFilterSearchCurrenciesThunk({ search: '' }));
        },
      }),
    );
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6">Add Currency</h2>
      <form onSubmit={handleSubmit(onSave)} autoComplete="off">
        <div className="grid grid-cols-1 gap-6">
          <Input
            name="name"
            control={control}
            label="Currency"
            placeholder="eg: Singapore Dollar"
          />
          <Input
            name="code"
            control={control}
            label="Currency Code"
            placeholder="eg: SGD"
          />
        </div>
        <div className="flex justify-end gap-4 mt-6">
          <Button
            type="button"
            variant="secondary"
            onClick={() => reset()}
            className="w-32"
            fullWidth={false}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            variant="primary"
            className="w-32"
            fullWidth={false}
            isLoading={isLoading}
          >
            Save
          </Button>
        </div>
      </form>
    </div>
  );
};
