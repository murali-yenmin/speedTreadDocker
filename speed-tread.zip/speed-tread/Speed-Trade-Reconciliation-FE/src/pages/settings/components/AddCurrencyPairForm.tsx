import { yupResolver } from '@hookform/resolvers/yup';
import Button from '../../../components/formFields/Button';
import Dropdown from '../../../components/formFields/Dropdown';
import { useForm, useWatch } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { addCurrencyPairSchema } from '../../../validations/settings';
import { useAppDispatch, useAppSelector } from '../../../store/store';
import {
  addCurrencyPairThunk,
  getAllFilterCurrencyPairsThunk,
} from '../../../store/thunks/settings';
import ArrowHeadButton from '../../../components/Images/ArrowHeadButton';
import { Dispatch, SetStateAction, useEffect, useState } from 'react';

export const AddCurrencyPairForm = ({
  setResetCurrencyPairFilter,
}: {
  setResetCurrencyPairFilter: Dispatch<SetStateAction<number>>;
}) => {
  const { t } = useTranslation();
  const dispatch = useAppDispatch();

  const { currency, loading } = useAppSelector((state) => ({
    currency: state.getAllCurrenciesReducer.data?.map((cur) => ({
      label: cur.code,
      value: cur.unique_id,
    })),
    loading: state.addCurrencyPairReducer.loading,
  }));

  const [grater, setGrater] = useState(true);
  const {
    control,
    handleSubmit,
    reset,
    resetField,
  } = useForm({
    resolver: yupResolver(addCurrencyPairSchema(t)),
    defaultValues: {
      from_currency: '',
      to_currency: '',
    },
  });

  const [watchedFromCurrency, watchedToCurrency] = useWatch({
    control,
    name: ['from_currency', 'to_currency'],
  });

  const filteredFromCurrencyOptions = [
    { label: 'Select', value: '' },
    ...(currency?.filter((option) => option.value !== watchedToCurrency) ?? []),
  ];

  const filteredToCurrencyOptions = [
    { label: 'Select', value: '' },
    ...(currency?.filter((option) => option.value !== watchedFromCurrency) ??
      []),
  ];

  useEffect(() => {
    // Check if watchedFromCurrency is still valid in filteredFromCurrencyOptions
    const isFromCurrencyValid = filteredFromCurrencyOptions.some(
      (option) => option.value === watchedFromCurrency && option.value !== '',
    );
    if (watchedFromCurrency && !isFromCurrencyValid) {
      resetField('from_currency', { defaultValue: '' }); // Clear the field
    }

    // Check if watchedToCurrency is still valid in filteredToCurrencyOptions
    const isToCurrencyValid = filteredToCurrencyOptions.some(
      (option) => option.value === watchedToCurrency && option.value !== '',
    );
    if (watchedToCurrency && !isToCurrencyValid) {
      resetField('to_currency', { defaultValue: '' }); // Clear the field
    }
  }, [
    watchedFromCurrency,
    watchedToCurrency,
    filteredFromCurrencyOptions,
    filteredToCurrencyOptions,
    resetField,
  ]);

  const onSave = (data: { from_currency: string; to_currency: string }) => {
    const payload = {
      from: data?.from_currency,
      to: data?.to_currency,
      is_greater: grater,
    };
    dispatch(
      addCurrencyPairThunk({
        payload,
        afterSuccessCallback: () => {
          dispatch(getAllFilterCurrencyPairsThunk(''));
          setResetCurrencyPairFilter((prev) => prev + 1);
          reset();
        },
      }),
    );
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-[35px] capitalize">
        Add currency pair
      </h2>
      <form onSubmit={handleSubmit(onSave)}>
        <div className="grid grid-cols-1 gap-6">
          <div>
            <div className="flex relative gap-3">
              <Dropdown
                name="from_currency"
                control={control}
                label=""
                options={filteredFromCurrencyOptions}
              />
              <div className="relative border border-border-grey-2 flex items-center justify-center w-[68px] h-[37px] rounded-[35px] p-[3px] gap-[3px]">
                <label className="absolute z-10 top-[-30px] left-[6px] font-medium">
                  Greater
                </label>
                <ArrowHeadButton
                  rotate
                  variant={grater ? 'secondary' : 'primary'}
                  onClick={() => setGrater(false)}
                  active={!grater}
                />
                <ArrowHeadButton
                  variant={grater ? 'primary' : 'secondary'}
                  onClick={() => setGrater(true)}
                  active={grater}
                />
              </div>
              <Dropdown
                name="to_currency"
                control={control}
                label=""
                options={filteredToCurrencyOptions}
              />
            </div>
          </div>
        </div>
        <div className="flex justify-end gap-4 mt-6">
          <Button
            type="button"
            variant="secondary"
            onClick={() => reset()}
            className="w-32"
            fullWidth={false}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            variant="primary"
            className="w-32"
            fullWidth={false}
            isLoading={loading}
          >
            Save
          </Button>
        </div>
      </form>
    </div>
  );
};
