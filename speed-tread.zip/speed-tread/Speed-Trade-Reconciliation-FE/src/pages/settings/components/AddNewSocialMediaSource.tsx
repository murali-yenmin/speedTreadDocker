import { useForm } from 'react-hook-form';
import Input from '../../../components/formFields/Input';
import Button from '../../../components/formFields/Button';
import { yupResolver } from '@hookform/resolvers/yup';
import { useTranslation } from 'react-i18next';
import { addSourceSchema } from '../../../validations/settings';
import { useAppDispatch, useAppSelector } from '../../../store/store';
import { addMediaSourceThunk } from '../../../store/thunks/settings';

export const AddNewSocialMediaSource: React.FC = () => {
  const { t } = useTranslation();
  const dispatch = useAppDispatch();

  const loading = useAppSelector(
    (state) => state.addMediaSourceReducer.loading,
  );

  const { control, handleSubmit, reset } = useForm({
    resolver: yupResolver(addSourceSchema(t)),
    defaultValues: {
      label: '',
    },
  });

  const handleAdd = (data: { label: string }) => {
    dispatch(
      addMediaSourceThunk({
        payload: data,
        afterSuccessCallback: () => reset(),
      }),
    );
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6">Add new social media</h2>
      <form onSubmit={handleSubmit(handleAdd)} autoComplete="off">
        <div className="mb-4">
          <Input
            name="label"
            control={control}
            label="Social media name"
            placeholder="Enter media name (e.g., Facebook or Twitter)"
          />
        </div>
        <div className="flex justify-end gap-4">
          <div className="w-32">
            <Button type="button" variant="secondary" onClick={() => reset()}>
              Cancel
            </Button>
          </div>
          <div className="w-32">
            <Button type="submit" variant="primary" isLoading={loading}>
              Add
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
};
