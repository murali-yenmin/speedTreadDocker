import React, { useEffect, useState } from 'react';
import Badge from '../../../components/Badge';
import CurrencyListSkeleton from './CurrencyListSkeleton';
import { Search } from '../../../components/formFields/Search';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { addCurrencySchema } from '../../../validations/settings';
import { useTranslation } from 'react-i18next';
import Input from '../../../components/formFields/Input';
import Button from '../../../components/formFields/Button';
import { useAppDispatch } from '../../../store/store';
import {
  getAllFilterSearchCurrenciesThunk,
  updateCurrencyThunk,
} from '../../../store/thunks/settings';
import { CurrencyProps } from '../../../store/interfaces/settings';
import NoData from '../../../components/NoData';
import { ReactComponent as ListIcon } from '../../../assets/svg/ListIcon.svg';

interface CurrencyListProps {
  currencies: CurrencyProps[];
  isLoading: boolean;
  isUpdateLoading: boolean;
}

export const CurrencyList: React.FC<CurrencyListProps> = ({
  currencies,
  isLoading,
  isUpdateLoading,
}) => {
  const { t } = useTranslation();
  const dispatch = useAppDispatch();

  const [editingCurrencyId, setEditingCurrencyId] = useState<string | null>(
    null,
  );
  const [searchTerm, setSearchTerm] = useState('');

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<{ name: string; code: string }>({
    resolver: yupResolver(addCurrencySchema(t)),
  });

  const handleAction = (action: string, currency: CurrencyProps) => {
    if (action === 'edit') {
      setEditingCurrencyId(currency.unique_id);
      reset({
        name: currency.name,
        code: currency.code,
      });
    }
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const onSubmit = (data: { name: string; code: string }) => {
    if (editingCurrencyId) {
      dispatch(
        updateCurrencyThunk({ ...data, unique_id: editingCurrencyId }),
      ).then((res) => {
        if (res.payload) {
          setEditingCurrencyId(null);
        }
      });
    }
  };

  const handleCancelEdit = () => {
    setEditingCurrencyId(null);
    reset();
  };

  useEffect(() => {
    dispatch(getAllFilterSearchCurrenciesThunk({ search: searchTerm }));
  }, [searchTerm]);

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mt-6  max-h-[490px]">
      <h2 className="text-2xl font-bold mb-6">Currency List</h2>
      <div className="mb-4 currency-list-search-bar">
        <Search
          placeholder="Search by Currency or Code"
          value={searchTerm}
          onChange={handleSearchChange}
        />
      </div>
      <div className="max-h-[320px] overflow-y-auto">
        {isLoading ? (
          <div className="space-y-2">
            {[...Array(6)].map((_, index) => (
              <CurrencyListSkeleton key={index} />
            ))}
          </div>
        ) : currencies && currencies?.length > 0 ? (
          currencies?.map((currency, index) => (
            <div
              key={currency.unique_id}
              className="flex items-center justify-between p-4 border border-gray-200 rounded-lg mb-2"
            >
              {editingCurrencyId === currency.unique_id ? (
                <form
                  onSubmit={handleSubmit(onSubmit)}
                  className="flex flex-col w-full"
                  autoComplete="off"
                >
                  <div className="flex gap-2 mb-6">
                    <Input
                      name="name"
                      control={control}
                      label="Currency Name"
                      placeholder="Enter currency name"
                      className="flex-1"
                      error={errors.name?.message}
                    />
                    <Input
                      name="code"
                      control={control}
                      maxLength={4}
                      label="Currency Code"
                      placeholder="Enter currency code"
                      className="flex-1"
                      error={errors.code?.message}
                    />
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button
                      type="button"
                      onClick={handleCancelEdit}
                      variant="secondary"
                      fullWidth={false}
                      className="w-24 currency-edit-button-height"
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      fullWidth={false}
                      className="w-24 currency-edit-button-height"
                      isLoading={isUpdateLoading}
                    >
                      Save
                    </Button>
                  </div>
                </form>
              ) : (
                <>
                  <span>{currency.name}</span>
                  <div className="flex items-center gap-2">
                    <Badge color="gray">{currency.code}</Badge>

                    {/* Need in future don't delete */}
                    {/* <ThreeDotDropdown
                      items={CURRENCY_DROPDOWN_ITEMS}
                      onAction={(action) => handleAction(action, currency)}
                    /> */}
                  </div>
                </>
              )}
            </div>
          ))
        ) : (
          <NoData
            message="No Currencies Found"
            minHeight={'280'}
            icon={<ListIcon className="w-12 h-12 text-gray-400" />}
          />
        )}
      </div>
    </div>
  );
};
