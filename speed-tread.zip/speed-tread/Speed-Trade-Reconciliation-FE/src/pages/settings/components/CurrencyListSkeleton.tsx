import React from 'react';

const CurrencyListSkeleton: React.FC = () => {
  return (
    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg mb-2 animate-pulse">
      <div className="h-6 bg-gray-300 rounded w-1/4"></div>
      <div className="flex items-center gap-2">
        <div className="h-6 bg-gray-300 rounded w-16"></div>
        <div className="h-6 w-6 bg-gray-300 rounded-full"></div>
      </div>
    </div>
  );
};

export default CurrencyListSkeleton;
