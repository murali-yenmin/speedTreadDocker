import React from 'react';
import ArrowHeadButton from '../../../components/Images/ArrowHeadButton';
import { CurrencyPairProps } from '../../../store/interfaces/settings';

interface CurrencyPairDisplayProps {
  pair: CurrencyPairProps;
}

const CurrencyPairDisplay: React.FC<CurrencyPairDisplayProps> = ({ pair }) => {
  return (
    <div className="font-bold flex gap-3 px-3 h-[36px] bg-quaternary-grey items-center rounded-[8px]">
      <span className="text-[18px]">{pair?.from}</span> 
      <ArrowHeadButton
        needCursor={false}
        active={pair?.calculation_type === 'multiply'}
        variant={
          pair?.calculation_type === 'multiply'
            ? 'primary'
            : 'tertiary'
        }
        small
        rotate={pair?.calculation_type === 'divide'}
      />
      <span className="text-[18px]">{pair?.to}</span>
    </div>
  );
};

export default React.memo(CurrencyPairDisplay);
