import React, { useEffect, useState } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import Dropdown from '../../../components/formFields/Dropdown';
import Button from '../../../components/formFields/Button';
import ArrowHeadButton from '../../../components/Images/ArrowHeadButton';
import { CurrencyPairProps, CurrencyProps } from '../../../store/interfaces/settings';
import { editCurrencyPairSchema } from '../../../validations/currencyPair'; // Assuming this path is correct

interface CurrencyPairEditFormProps {
  pair: CurrencyPairProps;
  onSave: (data: { from_currency?: string; to_currency?: string; is_greater: boolean }) => void;
  onCancel: () => void;
  isUpdateLoading: boolean;
  allCurrencies: CurrencyProps[]; // Pass all currencies for dropdown options
}

const CurrencyPairEditForm: React.FC<CurrencyPairEditFormProps> = ({
  pair,
  onSave,
  onCancel,
  isUpdateLoading,
  allCurrencies,
}) => {
  const [grater, setGrater] = useState(pair.is_greater); // Initialize from pair data

  const { control, handleSubmit, resetField } = useForm({
    resolver: yupResolver(editCurrencyPairSchema),
    defaultValues: {
      from_currency: pair.from,
      to_currency: pair.to,
      calculation_type: pair.calculation_type, // This might not be needed in the edit form
    },
  });

  const [watchedFromCurrency, watchedToCurrency] = useWatch({
    control,
    name: ['from_currency', 'to_currency'],
  });

  const currencyDropdownOptions = allCurrencies?.map((cur) => ({
    label: cur.code,
    value: cur.unique_id,
  }));

  const filteredFromCurrencyOptions = [
    { label: 'Select', value: '' },
    ...(currencyDropdownOptions?.filter(
      (option) => option.value !== watchedToCurrency,
    ) ?? []),
  ];

  const filteredToCurrencyOptions = [
    { label: 'Select', value: '' },
    ...(currencyDropdownOptions?.filter(
      (option) => option.value !== watchedFromCurrency,
    ) ?? []),
  ];

  useEffect(() => {
    // Check if watchedFromCurrency is still valid in filteredFromCurrencyOptions
    const isFromCurrencyValid = filteredFromCurrencyOptions.some(
      (option) => option.value === watchedFromCurrency && option.value !== '',
    );
    if (watchedFromCurrency && !isFromCurrencyValid) {
      resetField('from_currency', { defaultValue: '' }); // Clear the field
    }

    // Check if watchedToCurrency is still valid in filteredToCurrencyOptions
    const isToCurrencyValid = filteredToCurrencyOptions.some(
      (option) => option.value === watchedToCurrency && option.value !== '',
    );
    if (watchedToCurrency && !isToCurrencyValid) {
      resetField('to_currency', { defaultValue: '' }); // Clear the field
    }
  }, [
    watchedFromCurrency,
    watchedToCurrency,
    currencyDropdownOptions,
    filteredFromCurrencyOptions, // Added to dependencies
    filteredToCurrencyOptions,
    resetField,
  ]);

  const handleFormSubmit = (data: { from_currency?: string; to_currency?: string }) => {
    onSave({ ...data, is_greater: grater });
  };

  return (
    <form onSubmit={handleSubmit(handleFormSubmit)} className="p-4 pt-[35px]">
      <div className="grid grid-cols-1 gap-6">
        <div className="flex items-center relative gap-4">
          <Dropdown
            name="from_currency"
            control={control}
            label=""
            options={[...(filteredFromCurrencyOptions ?? [])]}
            className="currencyPairEditDropdown"
          />
          <div className="relative border border-border-grey-2 flex items-center justify-center w-[68px] h-[37px] rounded-[35px] p-[3px] gap-[3px]">
            <label className="absolute z-10 top-[-30px] left-[6px] font-medium">
              {grater ? 'Greater' : 'Less'}
            </label>
            <ArrowHeadButton
              rotate
              variant={grater ? 'secondary' : 'primary'}
              onClick={() => setGrater(false)}
              active={!grater}
            />
            <ArrowHeadButton
              variant={grater ? 'primary' : 'secondary'}
              onClick={() => setGrater(true)}
              active={grater}
            />
          </div>
          <Dropdown
            name="to_currency"
            control={control}
            label=""
            options={[...(filteredToCurrencyOptions ?? [])]}
            className="currencyPairEditDropdown"
          />
        </div>
      </div>
      <div className="flex justify-end gap-4 mt-6">
        <Button
          type="button"
          variant="secondary"
          onClick={onCancel}
          fullWidth={false}
          className="w-32 currency-edit-button-height"
        >
          Cancel
        </Button>
        <Button
          type="submit"
          fullWidth={false}
          variant="primary"
          className="w-32 currency-edit-button-height"
          isLoading={isUpdateLoading}
        >
          Save
        </Button>
      </div>
    </form>
  );
};

export default CurrencyPairEditForm;
