import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import ThreeDotDropdown from '../../../components/ThreeDotDropdown';
import CurrencyPairListSkeleton from './CurrencyPairListSkeleton';
import Dropdown from '../../../components/formFields/Dropdown';
import { getCurrencyPairDropdownItems } from '../../../constants/dropdowns';
import Button from '../../../components/formFields/Button';
import { useAppDispatch, useAppSelector } from '../../../store/store';
import {
  deleteCurrencyPairThunk,
  getAllFilterCurrencyPairsThunk,
  updateCurrencyPairStatusThunk,
  swapCurrencyPairThunk,
} from '../../../store/thunks/settings';
import ConfirmationModal from '../../../components/Modal/ConfirmationModal';
import NoData from '../../../components/NoData';
import { ReactComponent as ListIcon } from '../../../assets/svg/ListIcon.svg';
import ArrowHeadButton from '../../../components/Images/ArrowHeadButton';
import {
  CurrencyPairProps,
  CurrencyProps,
} from '../../../store/interfaces/settings';
import { editCurrencyPairSchema } from '../../../validations/currencyPair';
import { CurrencyPairListProps } from '../../../interfaces/currency';
import CurrencyPairEditForm from './CurrencyPairEditForm';
import CurrencyPairDisplay from './CurrencyPairDisplay'; // New import

export const CurrencyPairList: React.FC<CurrencyPairListProps> = ({
  isLoading,
  isUpdateLoading,
  currencies: allCurrencies, // Rename to 'allCurrencies' internally
  resetCurrencyPairFilter,
  getAllCb,
}) => {
  const dispatch = useAppDispatch();

  const pairs = useAppSelector(
    (state) => state.getAllFilterCurrencyPairsReducer.data,
  );

  const swapLoading = useAppSelector(
    (state) => state.swapCurrencyPairSlice.loading,
  );

  const [searchTerm, setSearchTerm] = useState('');
  const [editingPairIndex, setEditingPairIndex] = useState<number | null>(null);
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);
  const [selectedPairIndex, setSelectedPairIndex] = useState<number | null>(
    null,
  );
  const [deletePair, setDeletePair] = useState<CurrencyPairProps | null>();
  const [deletePairCustomErr, setDeletePairCustomErr] = useState<string>('');
  const [localLoading, setLocalLoading] = useState(false);
  const [showSwapConfirmationModal, setShowSwapConfirmationModal] =
    useState(false);
  const [pairToSwap, setPairToSwap] = useState<CurrencyPairProps | null>();

  const memoizedCurrencyDropdownOptions = useMemo(
    () =>
      allCurrencies?.map((cur) => ({
        label: cur.code,
        value: cur.unique_id,
      })) || [],
    [allCurrencies],
  );

  // useForm for filter dropdown only
  const { control, handleSubmit, reset, setValue } = useForm({
    // No resolver needed for filter dropdown if no validation
    defaultValues: {
      calculation_type: '',
    },
  });

  const [currencyFilter] = useWatch({
    control,
    name: ['calculation_type'],
  });

  useEffect(() => {
    dispatch(getAllFilterCurrencyPairsThunk(currencyFilter ?? ''));
  }, [currencyFilter]);

  const handleAction = useCallback(
    (action: string, index: number) => {
      if (action === 'edit') {
        setEditingPairIndex(index);
      } else if (action === 'status') {
        setSelectedPairIndex(index);
        setShowConfirmationModal(true);
      } else if (action === 'delete') {
        setShowConfirmationModal(true);
        setDeletePair(pairs?.[index].pair[0]);
      } else if (action === 'swap') {
        setShowSwapConfirmationModal(true);
        const pairCurrency = pairs?.[index]?.pair?.find(
          (item) => item.calculation_type === 'multiply',
        );
        setPairToSwap(pairCurrency);
      }
    },
    [pairs],
  );

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const onSave = useCallback(
    (data: {
      from_currency?: string;
      to_currency?: string;
      is_greater: boolean;
    }) => {
      if (
        typeof editingPairIndex === 'number' &&
        pairs?.[editingPairIndex]?.pair[0]?.unique_id
      ) {
        const payload = {
          unique_id: pairs?.[editingPairIndex]?.pair[0]?.unique_id,
          from: data?.from_currency,
          to: data?.to_currency,
          is_greater: data.is_greater,
        };

        dispatch(
          updateCurrencyPairStatusThunk({
            payload,
            afterSuccessCallback: () => {
              setEditingPairIndex(null);
            },
          }),
        );
      }
    },
    [dispatch, editingPairIndex, pairs],
  );

  const handleCancel = useCallback(() => {
    setEditingPairIndex(null);
  }, []);

  const handleConfirmStatusChange = async () => {
    if (selectedPairIndex !== null && pairs) {
      const pairToUpdate = pairs[selectedPairIndex]?.pair[0];
      const newStatus = !pairToUpdate.is_active; // Toggle the status

      dispatch(
        updateCurrencyPairStatusThunk({
          payload: {
            unique_id: pairToUpdate.unique_id,
            is_active: newStatus,
          },
          afterSuccessCallback: () => {
            setShowConfirmationModal(false);
            setSelectedPairIndex(null);
          },
        }),
      );
    }
  };

  const deletePairItem = () => {
    if (!deletePair) return;
    setLocalLoading(true);
    dispatch(
      deleteCurrencyPairThunk({
        payload: { id: deletePair?.unique_id },
        afterSuccessCallback: deleteCurrencyCb,
      }),
    );
  };

  const deleteCurrencyCb = useCallback(
    (res: any) => {
      if (res?.success === false) {
        setDeletePairCustomErr(res?.message as string);
      } else {
        setShowConfirmationModal(false);
        setDeletePairCustomErr('');
        setDeletePair(null);
        dispatch(getAllFilterCurrencyPairsThunk(''));
        getAllCb && getAllCb();
      }
      setLocalLoading(false);
    },
    [dispatch, getAllCb],
  );

  const handleConfirmSwap = () => {
    if (!pairToSwap) return;
    dispatch(
      swapCurrencyPairThunk({
        payload: {
          unique_id: pairToSwap.unique_id,
        },
        afterSuccessCallback: () => {
          setShowSwapConfirmationModal(false);
          setPairToSwap(null);
          dispatch(getAllFilterCurrencyPairsThunk(currencyFilter ?? ''));
        },
      }),
    );
  };

  const filteredPairs = useMemo(() => {
    if (!pairs) return [];
    return pairs.filter((pairGroup) => {
      return pairGroup.pair.some(
        (pairItem) =>
          pairItem.from.toLowerCase().includes(searchTerm.toLowerCase()) ||
          pairItem.to.toLowerCase().includes(searchTerm.toLowerCase()),
      );
    });
  }, [pairs, searchTerm]);

  useEffect(() => {
    if (resetCurrencyPairFilter) {
      setValue('calculation_type', '');
    }
  }, [resetCurrencyPairFilter, setValue]);

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mt-6">
      <div className="flex justify-between flex-col sm:flex-row">
        <h2 className="text-2xl font-bold mb-6 capitalize">
          Currency pair list
        </h2>
        <div className="mb-4">
          <Dropdown
            className="min-w-[170px]"
            name="calculation_type"
            control={control}
            label=""
            options={[
              { label: 'All', value: '' },
              ...memoizedCurrencyDropdownOptions,
            ]}
            isSearchable
            customPadding="2px"
          />
        </div>
      </div>
      <div className="max-h-[480px] overflow-y-auto">
        {isLoading ? (
          <div className="space-y-2">
            {[...Array(6)].map((_, index) => (
              <CurrencyPairListSkeleton key={index} />
            ))}
          </div>
        ) : filteredPairs && filteredPairs?.length > 0 ? (
          filteredPairs?.map(
            (pair: { pair: CurrencyPairProps[] }, index, _self) => (
              <div
                key={index}
                className="border border-gray-200 rounded-lg mb-2 "
              >
                {editingPairIndex === index ? (
                  <CurrencyPairEditForm
                    pair={pair?.pair[0]}
                    onSave={onSave}
                    onCancel={handleCancel}
                    isUpdateLoading={isUpdateLoading}
                    allCurrencies={allCurrencies}
                  />
                ) : (
                  <>
                    <div className="p-4 flex items-center justify-between">
                      <div className={`flex flex-col xs:flex-row gap-4`}>
                        {pair?.pair?.map((pairItem) => {
                          return (
                            <CurrencyPairDisplay
                              key={`${pairItem?.unique_id}`}
                              pair={pairItem}
                            />
                          );
                        })}
                      </div>
                      <div className="flex items-center gap-2">
                        {/* 
                      Todo: Don't remove it need for future enhancement
                      <span
                        className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${pair?.is_active ? 'bg-strong-green-bg text-strong-green' : 'bg-light-red text-strong-red'}`}
                      >
                        {pair?.is_active ? 'Active' : 'Inactive'}
                      </span> */}

                        <ThreeDotDropdown
                          items={getCurrencyPairDropdownItems()}
                          onAction={(action) => handleAction(action, index)}
                          placement={
                            index === (_self?.length ?? 0) - 1
                              ? 'top-right'
                              : 'bottom-right'
                          }
                        />
                      </div>
                    </div>
                  </>
                )}
              </div>
            ),
          )
        ) : (
          <NoData
            message="No Currency Pairs Found"
            icon={<ListIcon className="w-12 h-12 text-gray-400" />}
          />
        )}
      </div>
      {showConfirmationModal && selectedPairIndex !== null && pairs && (
        <ConfirmationModal
          isOpen={showConfirmationModal}
          onClose={() => setShowConfirmationModal(false)}
          onConfirm={handleConfirmStatusChange}
          title={
            pairs[selectedPairIndex]?.pair[0]?.is_active
              ? 'Deactivate Currency Pair'
              : 'Activate Currency Pair'
          }
          message={`Are you sure you want to ${pairs[selectedPairIndex]?.pair[0]?.is_active ? 'deactivate' : 'activate'} the currency pair ${pairs[selectedPairIndex]?.pair[0]?.from}-${pairs[selectedPairIndex]?.pair[0]?.to} and ${pairs[selectedPairIndex]?.pair[0]?.to}-${pairs[selectedPairIndex]?.pair[0]?.from}?`}
          confirmButtonText="Confirm"
          cancelButtonText="Cancel"
          isLoading={isUpdateLoading}
        />
      )}
      {showConfirmationModal && deletePair && (
        <ConfirmationModal
          isOpen={showConfirmationModal}
          onClose={() => {
            setShowConfirmationModal(false);
            setDeletePairCustomErr('');
          }}
          onConfirm={deletePairItem}
          title={'Delete Currency Pair'}
          message="Do you want to delete this currency pair?"
          confirmButtonText="Confirm"
          cancelButtonText="Cancel"
          isLoading={localLoading}
          info={deletePairCustomErr}
        />
      )}
      {showSwapConfirmationModal && pairToSwap && (
        <ConfirmationModal
          isOpen={showSwapConfirmationModal}
          onClose={() => {
            setShowSwapConfirmationModal(false);
            setPairToSwap(null);
          }}
          onConfirm={handleConfirmSwap}
          title={'Swap Currency Pair'}
          message={`Are you sure you want to swap the ${pairToSwap.from}-${pairToSwap.to}?  currency pair? Previous transactions exist for this pair, and swapping it will affect values based on the current logic.`}
          confirmButtonText="Confirm"
          cancelButtonText="Cancel"
          isLoading={swapLoading}
        />
      )}
    </div>
  );
};
