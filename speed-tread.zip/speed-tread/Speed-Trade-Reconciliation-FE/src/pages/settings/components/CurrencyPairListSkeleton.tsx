import React from 'react';

const CurrencyPairListSkeleton: React.FC = () => {
  return (
    <div className="p-4 flex items-center justify-between border border-gray-200 rounded-lg mb-2 animate-pulse">
      <div className="flex items-center gap-3">
        <div className="h-8 bg-gray-300 rounded w-20"></div>
        <div className="h-6 w-6 bg-gray-300 rounded-full"></div>
        <div className="h-8 bg-gray-300 rounded w-20"></div>
      </div>
      <div className="flex items-center gap-2">
        <div className="h-6 bg-gray-300 rounded w-16"></div>
        <div className="h-6 w-6 bg-gray-300 rounded-full"></div>
      </div>
    </div>
  );
};

export default CurrencyPairListSkeleton;
