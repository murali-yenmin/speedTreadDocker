import { useEffect } from 'react';
import ToggleButton from '../../../components/formFields/ToggleButton';
import SocialMediaSourceListItemSkeleton from '../../../components/SocialMediaSourceListItemSkeleton';
import {
  getAllMediaSourcesThunk,
  updateMediaSourceStatusThunk,
} from '../../../store/thunks/settings';
import { useAppDispatch, useAppSelector } from '../../../store/store';

export const SocialMediaSourceList = () => {
  const dispatch = useAppDispatch();

  const { loading, sources } = useAppSelector((state) => ({
    loading: state.getAllMediaSourceReducer.loading,
    sources: state.getAllMediaSourceReducer.data,
  }));

  const toggleSource = (id: string, status: boolean) => {
    dispatch(
      updateMediaSourceStatusThunk({
        unique_id: id,
        is_active: status,
      }),
    );
  };

  useEffect(() => {
    dispatch(getAllMediaSourcesThunk());
  }, []);

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mt-6">
      <h2 className="text-2xl font-bold mb-6">Social media Source</h2>
      <div className="grid grid-cols-[repeat(auto-fill,minmax(280px,1fr))] gap-4">
        {loading
          ? Array.from({ length: 3 }).map((_, index) => (
              <SocialMediaSourceListItemSkeleton key={index} />
            ))
          : sources?.map((source, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
              >
                <span className="text-gray-800 font-medium">
                  {source?.label}
                </span>
                <ToggleButton
                  id={`toggle-${index}`}
                  checked={source?.is_active}
                  onChange={() =>
                    !loading &&
                    toggleSource(source?.unique_id, !source?.is_active)
                  }
                />
              </div>
            ))}
      </div>
    </div>
  );
};
