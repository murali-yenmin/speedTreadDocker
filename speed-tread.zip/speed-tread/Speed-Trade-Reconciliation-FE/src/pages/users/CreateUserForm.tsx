import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import Input from '../../components/formFields/Input';
import Dropdown from '../../components/formFields/Dropdown';
import Button from '../../components/formFields/Button';
import InfoIcon from '../../components/Images/InfoIcon';
import { RootState, AppDispatch } from '../../store/store';
import { fetchRolesThunk } from '../../store/thunks/roles';
import { createUserThunk } from '../../store/thunks/userCreation';
import { editUserThunk } from '../../store/thunks/userEdit';
import { UserListItem } from '../../store/interfaces/user/userList';
import { resetUserCreationState } from '../../store/slices/user/userCreationSlice';
import { resetUserEditState } from '../../store/slices/user/userEditSlice';
import { userSchema } from '../../validations/user/createUser';
import { handlePhoneNumberKeyPress } from '../../utils/inputValidation';
import { showErrorToast } from '../../utils/toast';
import { formatRoleType } from '../../utils/stringUtils';
import Modal from '../../components/Modal/Modal';

interface CreateUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDataUpdate?: () => void;
  user?: UserListItem;
}

const CreateUserModal: React.FC<CreateUserModalProps> = ({
  isOpen,
  onClose,
  onDataUpdate,
  user,
}) => {
  const { t } = useTranslation();
  const dispatch: AppDispatch = useDispatch();

  const defaultFormValues = {
    username: user?.user_name || '',
    email: user?.email_address || '',
    role: user?.role.unique_id || '',
  };

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(userSchema(t, user ? true : false)),
    defaultValues: defaultFormValues,
  });

  const formGridRef = useRef<HTMLDivElement>(null);
  const [formColumns, setFormColumns] = useState(1);
  const [resetKey, setResetKey] = useState(0);

  const { roles, loading: rolesLoading } = useSelector(
    (state: RootState) => state.rolesReducer,
  );
  const {
    loading: userCreationLoading,
    success: userCreationSuccess,
    error: userCreationError,
  } = useSelector((state: RootState) => state.userCreationReducer);
  const {
    loading: userEditLoading,
    success: userEditSuccess,
    error: userEditError,
  } = useSelector((state: RootState) => state.userEditReducer);

  // Adjust grid layout
  useLayoutEffect(() => {
    const calculateColumns = (width: number, minWidth: number) =>
      Math.max(1, Math.floor(width / minWidth));

    if (!formGridRef.current) return;

    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const newColumns = calculateColumns(entry.contentRect.width, 300);
        setFormColumns(newColumns);
      }
    });

    observer.observe(formGridRef.current);
    return () => observer.disconnect();
  }, []);

  // Fetch roles on open and reset form
  useEffect(() => {
    if (isOpen) {
      dispatch(fetchRolesThunk());
      reset(defaultFormValues);
    }
  }, [dispatch, isOpen, reset, user]);

  const dropdownOptions = roles.map((role) => ({
    value: role.unique_id,
    label: formatRoleType(role.role_type),
  }));

  const onSubmit = (formData: any) => {
    const payload = {
      user_name: formData.username,
      email_address: formData.email,
      role_id: formData.role,
    };

    if (user) {
      // Editing existing user
      dispatch(editUserThunk({ ...payload, unique_id: user.unique_id }));
    } else {
      // Creating new user
      dispatch(createUserThunk(payload));
    }
  };

  // Handle success/error feedback for creation
  useEffect(() => {
    if (userCreationSuccess) {
      reset(defaultFormValues);
      setResetKey((prev) => prev + 1);
      dispatch(resetUserCreationState());
      if (onDataUpdate) onDataUpdate();
      onClose();
    } else if (userCreationError) {
      dispatch(resetUserCreationState());
    }
  }, [
    userCreationSuccess,
    userCreationError,
    reset,
    dispatch,
    t,
    onClose,
    onDataUpdate,
  ]);

  // Handle success/error feedback for editing
  useEffect(() => {
    if (userEditSuccess) {
      reset(defaultFormValues);
      setResetKey((prev) => prev + 1);
      dispatch(resetUserEditState());
      if (onDataUpdate) onDataUpdate();
      onClose();
    } else if (userEditError) {
      showErrorToast(userEditError);
      dispatch(resetUserEditState());
    }
  }, [
    userEditSuccess,
    userEditError,
    reset,
    dispatch,
    t,
    onClose,
    onDataUpdate,
  ]);

  const handleClose = () => {
    reset(defaultFormValues);
    setResetKey((prev) => prev + 1);
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      title={user ? 'Edit User' : t('create_user_form_title')}
      className="w-[90%] lg:w-full m-4"
    >
      <form onSubmit={handleSubmit(onSubmit)} autoComplete="off">
        <div
          ref={formGridRef}
          className="grid gap-4 mt-4"
          style={{
            gridTemplateColumns: `repeat(${formColumns}, 1fr)`,
          }}
        >
          <Input
            label={t('username_label')}
            name="username"
            control={control}
            placeholder={t('username_placeholder')}
          />
          <Input
            label={t('email_label')}
            name="email"
            control={control}
            placeholder={t('email_placeholder')}
            disabled={user ? true : false}
          />
          {/* <Input
            label={t('phone_number_label')}
            name="phoneNumber"
            type="text"
            control={control}
            placeholder={t('phone_number_placeholder')}
            maxLength={15}
            onKeyPress={handlePhoneNumberKeyPress}
          /> */}
          <Dropdown
            key={resetKey}
            label={t('role_label')}
            name="role"
            placeholder="Select Role"
            control={control}
            options={dropdownOptions}
          />
        </div>

        {!user && (
          <p className="text-sm text-gray-500 mt-2 flex items-center">
            <InfoIcon />
            <span className="ml-2">{t('password_email_info')}</span>
          </p>
        )}

        <div className="flex justify-end gap-4 mt-6">
          <Button
            type="button"
            onClick={handleClose}
            variant="secondary"
            fullWidth={true}
          >
            {t('cancel_button')}
          </Button>
          <Button
            type="submit"
            variant="primary"
            fullWidth={true}
            isLoading={user ? userEditLoading : userCreationLoading}
            disabled={rolesLoading}
          >
            {user ? 'Edit User' : t('create_user_button')}
          </Button>
        </div>
      </form>
    </Modal>
  );
};

export default CreateUserModal;
