import React, {
  useState,
  useRef,
  useLayoutEffect,
  useEffect,
  useCallback,
} from 'react';
import useBreadcrumbs from '../../hooks/useBreadcrumbs';
import { Search } from '../../components/formFields/Search';
import UserCard from './components/UserCard';
import UserCardSkeleton from './components/UserCardSkeleton';
import UserTableRowSkeleton from './components/UserTableRowSkeleton';
import { useInfiniteScroll } from '../../hooks/useInfiniteScroll';
import { useUserListFetcher } from '../../hooks/useUserListFetcher';
import {
  UserListItem,
  UserListPayload,
} from '../../store/interfaces/user/userList';
import { FilterOption } from '../../interfaces/filter';
import CreateUserForm from './CreateUserForm';
import UserTableRow from './components/UserTableRow';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { fetchUserListThunk } from '../../store/thunks/userList';
import { RootState, AppDispatch } from '../../store/store';
import { clearUserList } from '../../store/slices/user/userListSlice';
import { resetUserCreationState } from '../../store/slices/user/userCreationSlice';
import { formatRoleType } from '../../utils/stringUtils';
import Button from '../../components/formFields/Button';
import Dropdown from '../../components/formFields/Dropdown';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import { createUserSchema } from '../../validations/user/createUser';
import { fetchRolesThunk } from '../../store/thunks/roles';
import PageTitle from '../../components/PageTitle';

const commonStyle = 'text-gray-900 font-normal text-base font-semibold';

const Users: React.FC = () => {
  const breadcrumbItems = useBreadcrumbs();
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedSearchQuery, setDebouncedSearchQuery] = useState('');
  const gridRef = useRef<HTMLDivElement>(null);
  const [columns, setColumns] = useState(1);
  const isMounted = useRef(false);
  const { t } = useTranslation();
  const dispatch: AppDispatch = useDispatch();
  const { roles } = useSelector((state: RootState) => state.rolesReducer);
  const { users: userList, loading: userListLoading } = useSelector(
    (state: RootState) => state.userListReducer,
  );
  const { success: userCreationSuccess } = useSelector(
    (state: RootState) => state.userCreationReducer,
  );

  const [pageSize, setPageSize] = useState(10);
  const [sort, setSort] = useState({ field: 'updated_at', value: 'desc' });
  const [appliedFilters, setAppliedFilters] = useState<
    { operation: string; fieldName: string; fieldString: string | string[] }[]
  >([]);
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);
  const [isEditUserModalOpen, setIsEditUserModalOpen] = useState(false);
  const [userToEdit, setUserToEdit] = useState<UserListItem | null>(null);

  const { lastElementRef, reset: resetInfiniteScroll } = useInfiniteScroll({
    fetcher: useUserListFetcher({
      appliedFilters,
      debouncedSearchQuery,
      sort,
      pageSize,
    }),
    itemsPerPage: pageSize,
  });

  const handleUserUpdate = useCallback(() => {
    dispatch(clearUserList());
    resetInfiniteScroll();
    // Close modals after update
    setIsEditUserModalOpen(false);
    setIsAddUserModalOpen(false);

    // Construct the payload for fetching the user list, ensuring it's consistent
    const allFilters = [...appliedFilters];
    if (debouncedSearchQuery) {
      allFilters.push(
        {
          operation: '%',
          fieldName: 'user_name',
          fieldString: debouncedSearchQuery,
        },
        {
          operation: '%',
          fieldName: 'email_address',
          fieldString: debouncedSearchQuery,
        },
      );
    }

    const payload: UserListPayload = {
      cp: 1, // Always fetch the first page after an update
      pl: pageSize,
      sort: sort,
      query: allFilters,
    };

    dispatch(fetchUserListThunk(payload));
  }, [
    dispatch,
    resetInfiniteScroll,
    appliedFilters,
    debouncedSearchQuery,
    pageSize,
    sort,
  ]);

  const handleEdit = useCallback((user: UserListItem) => {
    setUserToEdit(user);
    setIsEditUserModalOpen(true);
  }, []);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearchQuery(searchQuery);
    }, 500);

    return () => {
      clearTimeout(handler);
    };
  }, [searchQuery]);

  const { control } = useForm<any>({
    resolver: yupResolver(createUserSchema(t)),
    defaultValues: {},
  });

  const roleFilterOptions: FilterOption[] = [
    { label: 'All', value: 'all', fieldName: 'role_unique_id' },
    ...roles.map((role) => ({
      label: formatRoleType(role.role_type),
      value: role.unique_id,
      fieldName: 'role_unique_id',
    })),
  ];

  useEffect(() => {
    if (isMounted.current) {
      dispatch(clearUserList());
      resetInfiniteScroll();
    } else {
      isMounted.current = true;
    }
  }, [
    appliedFilters,
    debouncedSearchQuery,
    sort,
    dispatch,
    resetInfiniteScroll,
  ]);

  useEffect(() => {
    dispatch(fetchRolesThunk());
  }, [dispatch]);

  useEffect(() => {
    if (userCreationSuccess) {
      dispatch(clearUserList());
      resetInfiniteScroll();
      dispatch(resetUserCreationState());
    }
  }, [userCreationSuccess, dispatch, resetInfiniteScroll]);

  useLayoutEffect(() => {
    const calculateColumns = (width: number, minWidth: number) => {
      return Math.max(1, Math.floor(width / minWidth));
    };

    if (!gridRef.current) return;

    const userGridObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const newColumns = calculateColumns(entry.contentRect.width, 416);
        setColumns(newColumns);
        setPageSize(Math.max(10, newColumns * 3));
      }
    });

    userGridObserver.observe(gridRef.current);

    return () => {
      userGridObserver.disconnect();
    };
  }, []);

  return (
    <>
      <PageTitle title="Users" />
      <div className="h-[calc(100vh-160px)]">
        <div>
          {/* User List Section */}
          <div className="rounded-lg p-0 lg:p-6">
            <div className="flex flex-wrap items-center justify-between mb-4 gap-y-4 z-20 p-4 bg-gray-50 md_lg:sticky top-0 flex-col md_lg:flex-row">
              <h2 className="text-xl font-bold text-gray-800">
                {t('user_list_title')}
              </h2>
              <div className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto ml-100">
                <Search
                  value={searchQuery}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setSearchQuery(e.target.value)
                  }
                  placeholder={t('search_by_name_or_email_placeholder')}
                  className="sm:w-auto w-full"
                  inputClassName="bg-[#E8EDF5] h-[40px] xl:w-[370px]"
                />
                <Dropdown
                  label=""
                  name="role_filter"
                  options={roleFilterOptions}
                  placeholder="Select Role"
                  control={control}
                  className="w-full sm:w-[190px] "
                  onChange={(selectedOption: any) => {
                    if (
                      selectedOption?.value &&
                      selectedOption.value !== 'all'
                    ) {
                      setAppliedFilters([
                        {
                          operation: 'eq',
                          fieldName: 'role_unique_id',
                          fieldString: selectedOption.value,
                        },
                      ]);
                    } else {
                      setAppliedFilters([]);
                    }
                  }}
                />

                <Button
                  type="button"
                  variant="primary"
                  onClick={() => setIsAddUserModalOpen(true)}
                  className="w-full !h-[38px] min-w-28 sm:w-[167px] md:w-auto"
                >
                  Create User
                </Button>
              </div>
            </div>

            <div
              ref={gridRef}
              className="grid gap-4 block lg:hidden p-4 lg_xl:p-0"
              style={{
                gridTemplateColumns: `repeat(${columns}, 1fr)`,
              }}
            >
              {userList && userList.length > 0
                ? userList.map((user: UserListItem, index: number) => {
                    const isLastElement = userList.length === index + 1;
                    return (
                      <div
                        ref={isLastElement ? lastElementRef : null}
                        key={user.unique_id}
                      >
                        <UserCard
                          user={user}
                          onUserUpdate={handleUserUpdate}
                          onEdit={handleEdit}
                        />
                      </div>
                    );
                  })
                : !userListLoading && <p>No Users Found</p>}
              {userListLoading &&
                Array.from({ length: pageSize }).map((_, index) => (
                  <UserCardSkeleton key={`skeleton-${index}`} />
                ))}
            </div>

            {/* Desktop Layout (Table Style) */}
            <div className="hidden lg:flex flex-col gap-3">
              <div className="bg-white grid items-center w-full gap-[24px] grid-cols-[3fr_4fr_2fr_100px_100px] bg-[#F9FAFB] rounded-lg shadow-sm border border-gray-200 p-4">
                <div>
                  <p className={`${commonStyle} min-w-[150px]`}>User Name</p>
                </div>
                <div>
                  <p className={`${commonStyle}`}>Email</p>
                </div>
                <div>
                  <p className={`${commonStyle}`}>Role</p>
                </div>
                <div>
                  <p className={`${commonStyle}`}>Status</p>
                </div>
                <div></div>
              </div>

              {userList && userList.length > 0 ? (
                userList.map((user: UserListItem, index: number) => {
                  const isLastElement = userList.length === index + 1;
                  return (
                    <UserTableRow
                      key={user.unique_id}
                      user={user}
                      onEdit={handleEdit}
                      onUserUpdate={handleUserUpdate}
                      lastElementRef={
                        isLastElement ? lastElementRef : undefined
                      }
                    />
                  );
                })
              ) : userListLoading ? (
                Array.from({ length: 8 }).map((_, index) => (
                  <UserTableRowSkeleton key={`skeleton-${index}`} />
                ))
              ) : (
                <p className="text-center text-gray-500 py-4">No Users Found</p>
              )}
            </div>
          </div>
        </div>

        {(isAddUserModalOpen || isEditUserModalOpen) && (
          <CreateUserForm
            isOpen={isAddUserModalOpen || isEditUserModalOpen}
            onClose={() => {
              setIsAddUserModalOpen(false);
              setIsEditUserModalOpen(false);
              setUserToEdit(null);
            }}
            onDataUpdate={handleUserUpdate}
            user={isEditUserModalOpen ? userToEdit || undefined : undefined}
          />
        )}
      </div>
    </>
  );
};

export default Users;
