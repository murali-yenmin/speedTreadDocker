import React, { useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { UserListItem } from '../../../store/interfaces/user/userList';
import { useDispatch } from 'react-redux';
import { AppDispatch } from '../../../store/store';
import { regeneratePasswordThunk } from '../../../store/thunks/authentication';
import ThreeDotDropdown from '../../../components/ThreeDotDropdown';
import { showErrorToast, showSuccessToast } from '../../../utils/toast';
import ConfirmationModal from '../../../components/Modal/ConfirmationModal';
import { toggleUserStatusThunk } from '../../../store/thunks/user';

interface UserActionsDropdownProps {
  user: UserListItem;
  onEdit: (user: UserListItem) => void;
  onUserUpdate: () => void;
}

const UserActionsDropdown: React.FC<UserActionsDropdownProps> = ({
  user,
  onEdit,
  onUserUpdate,
}) => {
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);
  const [modalActionType, setModalActionType] = useState<
    'deactivate' | 'activate' | 'delete' | null
  >(null);
  const [isTogglingStatus, setIsTogglingStatus] = useState(false); // New state for loading
  const dropdownRef = useRef<HTMLDivElement>(null);

  const { t } = useTranslation();
  const dispatch: AppDispatch = useDispatch();

  const handleAction = (action: string) => {
    switch (action) {
      case 'edit':
        onEdit(user);
        break;
      case 'toggleStatus':
        setModalActionType(user.is_active ? 'deactivate' : 'activate');
        setShowConfirmationModal(true);
        break;
      case 'resendPassword':
        handleResendPassword();
        break; 
      default:
        break;
    }
  };

  const handleResendPassword = async () => {
   await dispatch(regeneratePasswordThunk(user.email_address));  
  };
  
  const handleConfirmToggleStatus = async () => {
    setIsTogglingStatus(true);
    const newStatus = modalActionType === 'deactivate' ? false : true;
    try {
      const result = await dispatch(
        toggleUserStatusThunk({
          unique_id: user.unique_id,
          is_active: newStatus,
        }),
      ).unwrap();
      showSuccessToast(result);
      onUserUpdate();
    } catch (error: any) {
      showErrorToast(error.message || t('toggle_status_error'));
    } finally {
      setIsTogglingStatus(false);
      setShowConfirmationModal(false);
    }
  };

  const items = [
    { label: t('edit_button'), action: 'edit' },
    {
      label: user.is_active ? t('deactivate_button') : t('activate_button'),
      action: 'toggleStatus',
    },
    { label: t('resend_password_button'), action: 'resendPassword' }, 
  ];

  return (
    <div className="relative" ref={dropdownRef}>
      <ThreeDotDropdown
        items={items}
        onAction={handleAction}
        placement="bottom-right"
      />
      {showConfirmationModal && (
        <ConfirmationModal
          isOpen={showConfirmationModal}
          onClose={() => setShowConfirmationModal(false)}
          onConfirm={handleConfirmToggleStatus}
          title={
            modalActionType === 'deactivate'
              ? t('deactivate_user_modal_title')
              : modalActionType === 'activate'
                ? t('activate_user_modal_title')
                : t('delete_user_modal_title')
          }
          message={
            modalActionType === 'deactivate'
              ? t('deactivate_user_modal_message')
              : modalActionType === 'activate'
                ? t('activate_user_modal_message')
                : t('delete_user_modal_message')
          }
          confirmButtonText={t('confirm_button')}
          cancelButtonText={t('cancel_button')}
          isLoading={isTogglingStatus} // Pass loading state to ConfirmationModal
          icon={
            modalActionType === 'deactivate' ? (
              <svg
                className="w-16 h-16 text-red-500"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            ) : (
              <svg
                className="w-16 h-16 text-green-500"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            )
          }
        />
      )}
    </div>
  );
};

export default UserActionsDropdown;
