import React, { useState, useRef, useEffect } from 'react';
import { UserListItem } from '../../../store/interfaces/user/userList';
import MoreIcon from '../../../components/Images/MoreIcon';
import { useTranslation } from 'react-i18next';
import {
  capitalizeFirstLetter,
  formatRoleType,
} from '../../../utils/stringUtils';
import { useDispatch } from 'react-redux';
import { AppDispatch } from '../../../store/store';
import { showSuccessToast, showErrorToast } from '../../../utils/toast';
import { toggleUserStatusThunk } from '../../../store/thunks/user';
import ConfirmationModal from '../../../components/Modal/ConfirmationModal';
import { regeneratePasswordThunk } from '../../../store/thunks/authentication';
import TextTooltip from '../../../components/TextTooltip';
import EmailIcon from '../../../components/Images/EmailIcon';
import PhoneIcon from '../../../components/Images/PhoneIcon';
import DeactivateIcon from '../../../components/Images/DeactivateIcon';
import ActivateIcon from '../../../components/Images/ActivateIcon';
import UserIcon from '../../../assets/icons/UserIcon';

interface UserCardProps {
  user: UserListItem;
  onUserUpdate: () => void;
  onEdit: (user: UserListItem) => void;
}

const UserCard: React.FC<UserCardProps> = ({ user, onUserUpdate, onEdit }) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);
  const [modalActionType, setModalActionType] = useState<
    'deactivate' | 'activate' | null
  >(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const { t } = useTranslation();
  const dispatch: AppDispatch = useDispatch();

  const emailRefs = useRef<{ [key: string]: HTMLParagraphElement | null }>({});
  const [showEmailTooltip, setShowEmailTooltip] = useState<{
    [key: string]: boolean;
  }>({});
  const [isMobile400, setIsMobile400] = useState(window.innerWidth <= 400);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile400(window.innerWidth <= 400);
      checkOverflow();
    };

    const checkOverflow = () => {
      const newTooltipState: { [key: string]: boolean } = {};
      Object.entries(emailRefs.current).forEach(([id, el]) => {
        if (el) {
          newTooltipState[id] = el.scrollWidth > el.clientWidth;
        }
      });
      setShowEmailTooltip(newTooltipState);
    };
    window.addEventListener('resize', handleResize);
    checkOverflow();
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const handleToggleDropdown = () => {
    setIsDropdownOpen((prev) => !prev);
  };

  const handleClickOutside = (event: MouseEvent) => {
    if (
      dropdownRef.current &&
      !dropdownRef.current.contains(event.target as Node)
    ) {
      setIsDropdownOpen(false);
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleEdit = () => {
    onEdit(user);
    setIsDropdownOpen(false);
  };

  const handleResendPassword = () => {
    dispatch(regeneratePasswordThunk(user.email_address));
    setIsDropdownOpen(false);
  };

  const handleToggleStatus = () => {
    if (user.is_active) {
      setModalActionType('deactivate');
    } else {
      setModalActionType('activate');
    }
    setShowConfirmationModal(true);
    setIsDropdownOpen(false);
  };

  const handleConfirmDeactivation = async () => {
    const newStatus = modalActionType === 'deactivate' ? false : true;
    const result = await dispatch(
      toggleUserStatusThunk({
        unique_id: user.unique_id,
        is_active: newStatus,
      }),
    );
    if (toggleUserStatusThunk.fulfilled.match(result)) {
      showSuccessToast(result.payload);
      onUserUpdate();
    } else if (toggleUserStatusThunk.rejected.match(result)) {
      showErrorToast(result.payload as string);
    }
    setShowConfirmationModal(false);
  };

  return (
    <div className="bg-white rounded-lg shadow-md flex flex-col border border-gray-200 transition-all duration-200 ease-in-out hover:shadow-lg hover:border-blue-300 p-5">
      <>
        <div className="flex justify-between items-start mb-4 gap-2">
          <div className="flex flex-col gap-2">
            <div className="flex flex-col items-start gap-2">
              <h3 className="text-xl font-bold text-gray-800 mr-2">
                {capitalizeFirstLetter(user.user_name)}
              </h3>
              <span
                className={` py-1 text-xs font-semibold `}
              >
                {user.is_active ? 'Active' : 'Suspended'}
              </span>
            </div>
            <div className="flex items-center text-sm text-gray-600">
            <UserIcon className="h-5 w-5 mr-2 text-gray-400" />
              <p
                className={`text-gray-900 w-max lg:w-auto `}
              >
                {formatRoleType(user.role.role_type)}
              </p>
            </div>
          </div>
          <div className="relative" ref={dropdownRef}>
            <button
              className="text-gray-500 hover:text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md px-2 py-1 border border-gray-200"
              onClick={handleToggleDropdown}
            >
              <MoreIcon />
            </button>
            {isDropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-lg z-10 top-full">
                <div className="absolute -top-1.5 right-4 w-3 h-3 bg-white transform rotate-45 shadow-lg"></div>
                <ul className="py-1">
                  <li>
                    <button
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 w-full text-left focus:outline-none transition-colors duration-150"
                      onClick={handleEdit}
                    >
                      {t('edit_button')}
                    </button>
                  </li>
                  <li>
                    <button
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 w-full text-left focus:outline-none transition-colors duration-150"
                      onClick={handleToggleStatus}
                    >
                      {user.is_active
                        ? t('deactivate_button')
                        : t('activate_button')}
                    </button>
                  </li>
                  <li>
                    <button
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 w-full text-left focus:outline-none transition-colors duration-150"
                      onClick={handleResendPassword}
                    >
                      {t('resend_password_button')}
                    </button>
                  </li>
                </ul>
              </div>
            )}
          </div>
        </div>
        <div className="space-y-3">
          <div className="flex items-center text-sm text-gray-600">
            <EmailIcon className="h-5 w-5 mr-2 text-gray-400" />

            {isMobile400 && showEmailTooltip[user.unique_id] ? (
              // <TextTooltip text={user.email_address}>
                <p
                  ref={(el) => {
                    emailRefs.current[user.unique_id] = el;
                  }}
                  className="text-gray-900 truncate block max-w-[230px]"
                >
                  {user.email_address}
                </p>
              // </TextTooltip>
            ) : (
              <p
                ref={(el) => {
                  emailRefs.current[user.unique_id] = el;
                }}
                className={`text-gray-900 block ${
                  isMobile400 ? 'truncate max-w-[230px]' : 'max-w-[230px]'
                }`}
              >
                {user.email_address}
              </p>
            )}
          </div>
        </div>
      </>

      {showConfirmationModal && (
        <ConfirmationModal
          isOpen={showConfirmationModal}
          onClose={() => setShowConfirmationModal(false)}
          onConfirm={handleConfirmDeactivation}
          title={
            modalActionType === 'deactivate'
              ? t('deactivate_user_modal_title')
              : t('activate_user_modal_title')
          }
          message={
            modalActionType === 'deactivate'
              ? t('deactivate_user_modal_message')
              : t('activate_user_modal_message')
          }
          confirmButtonText={t('confirm_button')}
          cancelButtonText={t('cancel_button')}
          icon={
            modalActionType === 'deactivate' ? (
              <DeactivateIcon className="w-16 h-16 text-red-500" />
            ) : (
              <ActivateIcon className="w-16 h-16 text-green-500" />
            )
          }
        />
      )}
    </div>
  );
};

export default React.memo(UserCard);
