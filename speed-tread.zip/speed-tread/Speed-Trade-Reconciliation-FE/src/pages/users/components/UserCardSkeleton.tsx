import React from 'react';

const UserCardSkeleton: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-md p-5 w-full animate-pulse">
      {/* Header Section */}
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center gap-2">
          {/* Name placeholder */}
          <div className="h-6 w-3/4 bg-gray-300 rounded"></div>
          {/* Small rounded box moved next to name */}
          <div className="h-4 w-16 bg-gray-300 rounded-full"></div>
        </div>

        {/* Action icon placeholder */}
        <div className="h-8 w-8 bg-gray-300 rounded-md"></div>
      </div>

      {/* Content Section */}
      <div className="space-y-3">
        <div className="flex items-center text-sm text-gray-600">
          <div className="h-5 w-5 bg-gray-300 rounded-full mr-2"></div>
          <div className="h-4 w-full bg-gray-300 rounded"></div>
        </div>
        <div className="flex items-center text-sm text-gray-600">
          <div className="h-5 w-5 bg-gray-300 rounded-full mr-2"></div>
          <div className="h-4 w-3/4 bg-gray-300 rounded"></div>
        </div>
      </div>
    </div>
  );
};

export default UserCardSkeleton;