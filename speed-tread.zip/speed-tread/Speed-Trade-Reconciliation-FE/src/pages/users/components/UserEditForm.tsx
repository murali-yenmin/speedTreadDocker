import React from 'react';
import { useForm } from 'react-hook-form';
import Input from '../../../components/formFields/Input';
import PrimaryButton from '../../../components/formFields/PrimaryButton';
import Dropdown from '../../../components/formFields/Dropdown';
import { useTranslation } from 'react-i18next';
import { UserListItem } from '../../../store/interfaces/user/userList';
import { Role } from '../../../store/interfaces/roles';
import { formatRoleType } from '../../../utils/stringUtils';
import Button from '../../../components/formFields/Button';
import { handlePhoneNumberKeyPress } from '../../../utils/inputValidation';
// Added a comment to force re-evaluation

interface UserEditFormProps {
  user: UserListItem;
  roles: Role[];
  onCancel: () => void;
  onSave: (data: any) => void;
}

import { yupResolver } from '@hookform/resolvers/yup'; // Import yupResolver
import { userEditSchema } from '../../../validations/user/editUser'; // Import userEditSchema

const UserEditForm: React.FC<UserEditFormProps> = ({
  user,
  roles,
  onCancel,
  onSave,
}) => {
  const { t } = useTranslation(); // Move t declaration before useForm
  const { control, handleSubmit } = useForm({
    resolver: yupResolver(userEditSchema(t)), // Use yupResolver with userEditSchema
    defaultValues: {
      username: user.user_name,
      email: user.email_address,
      phoneNumber: user.phone_number,
      role: user.role.unique_id,
    },
  });

  const dropdownOptions = roles.map((role) => ({
    value: role.unique_id,
    label: formatRoleType(role.role_type),
  }));

  return (
    <form onSubmit={handleSubmit(onSave)} className="p-4 " autoComplete="off">
      <div className="grid grid-cols-2 gap-2 mb-3">
        <Input
          label={t('username_label')}
          name="username"
          control={control}
          placeholder={t('username_placeholder')}
          required
          inputClassName="userEditInput"
        />
        <Dropdown
          label={t('role_label')}
          name="role"
          control={control}
          options={dropdownOptions}
          valueContainerClassName="py-1 px-2"
          required
          className="userEditDropdown"
          isSearchable={false}
        />
        <Input
          label={t('phone_number_label')}
          name="phoneNumber"
          type="text"
          control={control}
          placeholder={t('phone_number_placeholder')}
          required
          inputClassName="userEditInput"
          maxLength={15}
          onKeyPress={handlePhoneNumberKeyPress}
        />
        <Input
          label={t('email_label')}
          name="email"
          control={control}
          placeholder={t('email_placeholder')}
          required
          inputClassName="userEditInput"
        />
      </div>
      <div className="flex justify-end space-x-4">
        <Button
          onClick={onCancel}
          className="w-48 bg-gray-100 hover:bg-gray-200 text-gray-800 h-[40px] userEditCardButton"
          variant="secondary"
        >
          {t('cancel_button')}
        </Button>
        <Button
          type="submit"
          className="w-48 bg-gray-800 hover:bg-gray-900 text-white h-[40px] userEditCardButton "
        >
          {t('save_button')}
        </Button>
      </div>
    </form>
  );
};

export default UserEditForm;
