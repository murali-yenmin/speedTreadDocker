import React from 'react';
import { UserListItem } from '../../../store/interfaces/user/userList';
import {
  capitalizeFirstLetter,
  formatRoleType,
} from '../../../utils/stringUtils';
import TextTooltip from '../../../components/TextTooltip';
import UserActionsDropdown from './UserActionsDropdown';

interface UserTableRowProps {
  user: UserListItem;
  onEdit: (user: UserListItem) => void;
  onUserUpdate: () => void;
  lastElementRef?: (node: HTMLDivElement) => void;
}

const UserTableRow: React.FC<UserTableRowProps> = ({
  user,
  onEdit,
  onUserUpdate,
  lastElementRef,
}) => {
  return (
    <div
      ref={lastElementRef}
      className="bg-white grid items-center bg-[#F9FAFB] rounded-lg shadow-sm border border-gray-200 p-4 gap-[24px] grid-cols-[3fr_4fr_2fr_100px_100px]"
    >
      {/* Username */}
      <div>
        <p className="text-gray-900 font-semibold text-base">
          {capitalizeFirstLetter(user.user_name)}
        </p>
      </div>

      {/* Email */}
      <div>
        {/* <TextTooltip text={user.email_address}> */}
          <p className="text-gray-900 truncate block max-w-[180px] lg:max-w-[270px] xl:max-w-[380px]">
            {user.email_address}
          </p>
        {/* </TextTooltip> */}
      </div>

      {/* Role */}
      <div>
        <p
          className={`text-gray-900 block`}
        >
          {formatRoleType(user.role.role_type)}
        </p>
      </div>

      {/* Status */}
      <div>
        <p
          className={`text-gray-900 block`}
        >
          {user.is_active ? 'Active' : 'Suspended'}
        </p>
      </div>

      {/* Right Section (Actions) */}
      <div className="flex justify-end">
        <UserActionsDropdown
          user={user}
          onEdit={onEdit}
          onUserUpdate={onUserUpdate}
        />
      </div>
    </div>
  );
};

export default React.memo(UserTableRow);
