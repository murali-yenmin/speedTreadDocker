import React from 'react';

const UserTableRowSkeleton: React.FC = () => {
  return (
    <div className="grid items-center w-full gap-[36px] grid-cols-[3fr_4fr_2fr_60px_40px] bg-white rounded-lg shadow-sm border border-gray-200 p-4 animate-pulse">
      {/* Username */}
      <div className="min-w-[150px]">
        <div className="h-4 bg-gray-300 rounded w-3/4"></div>
      </div>

      {/* Email */}
      <div className="min-w-[200px]">
        <div className="h-4 bg-gray-300 rounded w-full"></div>
      </div>

      {/* Role */}
      <div className="min-w-[150px]">
        <div className="h-4 bg-gray-300 rounded w-1/2"></div>
      </div>

      {/* Status */}
      <div className="min-w-[100px]">
        <div className="h-4 bg-gray-300 rounded w-1/3"></div>
      </div>

      {/* Actions */}
      <div>
        <div className="h-6 w-6 bg-gray-300 rounded-full ml-auto"></div>
      </div>
    </div>
  );
};

export default UserTableRowSkeleton;
