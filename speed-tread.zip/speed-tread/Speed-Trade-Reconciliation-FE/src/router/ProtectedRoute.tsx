import React from 'react';
import { Navigate } from 'react-router-dom';
import { ProtectedRouteProps } from '../interfaces/components';
import { getUserRole } from '../utils/auth';

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  isAuthenticated,
  allowedRoles,
}) => {
  const userRole = getUserRole();
  if (!isAuthenticated || !userRole || !allowedRoles?.includes(userRole)) {
    // Redirect to login page if not authenticated
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
};

export default ProtectedRoute;
