import React, { useEffect, useState } from 'react';
import { Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { publicRoutes, privateRoutes } from './routes';
import ProtectedRoute from './ProtectedRoute';
import Layout from '../layout/Layout';
import { isAuthenticated } from '../utils/auth';
import { useAppDispatch } from '../store/store';
import { fetchUserProfile } from '../store/slices/user/profileSlice';
import ConfirmationModal from '../components/Modal/ConfirmationModal';
import { useIdleTimer } from '../components/IdelIndicator';

const AppRoutes: React.FC = () => {
  const navigate = useNavigate();
  const [authStatus, setAuthStatus] = useState(isAuthenticated());
  const dispatch = useAppDispatch();

  // Listen authentication changes
  useEffect(() => {
    const handleAuthChange = () => {
      setAuthStatus(isAuthenticated());
    };

    window.addEventListener('auth-change', handleAuthChange);
    return () => {
      window.removeEventListener('auth-change', handleAuthChange);
    };
  }, []);

  // Fetch user profile after login
  useEffect(() => {
    if (authStatus) {
      dispatch(fetchUserProfile());
    }
  }, [authStatus, dispatch]);

  // Logout handler
  const handleLogout = () => {
    localStorage.removeItem('authToken');
    navigate('/login', { replace: true });
    window.location.reload();
    setTimeout(() => {
      window.history.pushState(null, '', window.location.href);
    }, 0);
  };

  // Idle timer
  // const { showPopup, stayActive, secondsRemaining } = useIdleTimer({
  //   idleTime: 5 * 60 * 1000,
  //   popupWaitTime: 30 * 1000,
  //   onLogout: handleLogout,
  // });

  return (
    <>
      <Routes>
        {/* Public Routes — block when authenticated */}
        {publicRoutes.map((route, index) => (
          <Route
            key={index}
            path={route.path}
            element={
              authStatus ? (
                <Navigate to="/dashboard" replace />
              ) : (
                <route.component />
              )
            }
          />
        ))}

        {/* Private Routes wrapped with Layout */}
        {privateRoutes.map((route, index) => (
          <Route
            key={index}
            path={route.path}
            element={
              <ProtectedRoute
                isAuthenticated={authStatus}
                allowedRoles={route.roles}
              >
                <Layout>
                  <route.component />
                </Layout>
              </ProtectedRoute>
            }
          />
        ))}

        {/* Redirect to dashboard if empty / */}
        <Route path="/" element={<Navigate to="/dashboard" replace />} />

        {/* Redirect to login if no match */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>

      {/* Idle popup */}
      {/* {showPopup && (
        <ConfirmationModal
          cancelButtonText="Stay In"
          confirmButtonText={`Logout ${secondsRemaining}'s`}
          isOpen={showPopup}
          message="Your idle for too long please click Stay In to stay otherwise you will be redirected to sign in."
          onClose={stayActive}
          onConfirm={handleLogout}
          title="Alert"
          closeIcon={false}
        />
      )} */}
    </>
  );
};

export default AppRoutes;
