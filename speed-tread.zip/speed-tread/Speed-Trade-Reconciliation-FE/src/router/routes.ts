import React from 'react';
import Login from '../pages/auth/Login';
import ForgotPassword from '../pages/auth/ForgotPassword';
import ResetPassword from '../pages/auth/ResetPassword';
import Dashboard from '../pages/Dashboard';
import Profile from '../pages/profile/Profile';
import Settings from '../pages/Settings';
import Users from '../pages/users/Users';
import Logout from '../pages/Logout';
import Currency from '../pages/settings/Currency';
import SocialMedia from '../pages/settings/SocialMedia';
import Notifications from '../pages/Notifications'; // New import
import Report from '../pages/Report';
import { ROLES } from '../constants/roles';
import TransactionReport from '../pages/TransactionReport';

interface RouteConfig {
  path: string;
  component: React.ComponentType; // Changed to React.ComponentType
  roles?: string[]; // Roles allowed to access this route
}

export const publicRoutes: RouteConfig[] = [
  { path: '/login', component: Login },
  { path: '/forgot-password', component: ForgotPassword },
  { path: '/reset-password/:token', component: ResetPassword },

  // { path: '/', component: HomePage }, // Changed to component reference
];

export const privateRoutes: RouteConfig[] = [
  {
    path: '/dashboard',
    component: Dashboard,
    roles: [
      ROLES.MANAGEMENT,
      ROLES.ORDER_MANAGER,
      ROLES.TRANSACTION_MANAGER,
      ROLES.AGENT,
    ],
  },
  {
    path: '/profile',
    component: Profile,
    roles: [ROLES.TRANSACTION_MANAGER, ROLES.ORDER_MANAGER, ROLES.MANAGEMENT],
  },
  {
    path: '/settings',
    component: Settings,
    roles: [ROLES.MANAGEMENT],
  },
  {
    path: '/settings/currency',
    component: Currency,
    roles: [ROLES.MANAGEMENT],
  },
  {
    path: '/settings/social-media',
    component: SocialMedia,
    roles: [ROLES.MANAGEMENT],
  },
  {
    path: '/users',
    component: Users,
    roles: [ROLES.MANAGEMENT],
  },
  {
    path: '/logout',
    component: Logout,
    roles: [ROLES.TRANSACTION_MANAGER, ROLES.ORDER_MANAGER, ROLES.MANAGEMENT],
  },
  {
    path: '/notifications', // New route
    component: Notifications,
    roles: [ROLES.TRANSACTION_MANAGER, ROLES.ORDER_MANAGER, ROLES.MANAGEMENT], // Assuming all roles can see notifications
  },

  {
    path: '/report',
    component: Report,
    roles: [ROLES.ORDER_MANAGER, ROLES.MANAGEMENT],
  },
  {
    path: '/transaction-reports',
    component: TransactionReport,
    roles: [ROLES.TRANSACTION_MANAGER, ROLES.MANAGEMENT],
  },
];
