export interface AccountName {
  unique_id: string;
  name: string;
  status: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AccountNameState {
  accountNames: AccountName[];
  loading: boolean;
  error: string | null;
}
