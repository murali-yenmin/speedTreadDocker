export interface LoginCredentials {
  email_address: string;
  password: string;
}

export interface LoginProps {
  payload: LoginCredentials;
  successCallback: (token: string) => void;
}

interface LoginData {
  token: string;
  login: boolean;
}

export interface LoginState {
  data: LoginData | null;
  loading: boolean;
  error: string | null;
}

export interface ForgotCredentials {
  email_address: string;
}

export interface ForgotProps {
  payload: ForgotCredentials;
  successCallback: () => void;
}

export interface ForgotState {
  data: any | null;
  loading: boolean;
  error: string | null;
}

export interface ResetPasswordCredentials {
  secret_key: string;
  new_password: string;
  confirm_password: string;
}

export interface ResetPasswordProps {
  payload: ResetPasswordCredentials;
  successCallback: () => void;
}

export interface ResetPasswordState {
  data: any | null;
  loading: boolean;
  error: string | null;
}
