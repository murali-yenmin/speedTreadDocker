import { Currency } from '../../interfaces/currency';

export interface Group {
  unique_id: string;
  name: string;
  group_id: string;
  is_active: boolean;
  updated_at: string;
  currencies: Currency[];
  settlement_currency: string;
  is_favorite: boolean;
}

export interface GetAllGroupsState {
  groups: {
    customer_groups_list: Group[];
    total_count?: number;
  } | null;
  loading: boolean;
  error: string | null;
}

export interface GetGroupByIdState {
  data: Group | null;
  isLoading: boolean;
  error: string | null;
}
