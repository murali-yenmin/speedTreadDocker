export interface AddGroupState {
  group: any;
  loading: boolean;
  error: string | null;
}

export interface UpdateGroupState {
  group: any;
  loading: boolean;
  error: string | null;
}
