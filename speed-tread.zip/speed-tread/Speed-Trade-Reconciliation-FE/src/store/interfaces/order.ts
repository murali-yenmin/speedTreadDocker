import { GetAllOrdersResponse, Order } from '../../interfaces/order';

export interface AddOrderState {
  loading: boolean;
  error: string | null;
}

export interface GetAllOrdersState {
  data: GetAllOrdersResponse | null;
  loading: boolean;
  error: string | null;
}

export interface UpdateOrderState {
  loading: boolean;
  error: string | null;
}

export interface UpdateOrderPayload {
  group_id: string;
  order_by: string;
  currency: string;
  settlement_currency: string;
  amount: number;
  trading: string;
  remarks?: string;
  unique_id: string;
  account_id: string;
  rate?: number;
  fee?: number;
}

export interface AddOrderPayload {
  is_multiOrder: boolean;
  data: {
    group_id: string;
    order_by: string;
    currency?: string;
    settlement_currency?: string;
    amount?: number;
    rate?: number;
    trading?: string;
    remarks?: string;
    account_id?: string;
    ordered_date?: string;
  }[];
}

export interface GetAllOrdersStatusState {
  data: string[] | null;
  loading: boolean;
  error: string | null;
}
export interface defaultState {
  data: null;
  loading: boolean;
  error: string | null;
}
export interface OrderRemainingBalState {
  data: {
    order_amount: number;
    order_fee: number;
    transaction_amount?: number;
    transaction_fee?: number;
  } | null;
  loading: boolean;
  error: string | null;
}

export interface GetOrderByIdState {
  data: Order | null;
  isLoading: boolean;
  error: string | null;
}
