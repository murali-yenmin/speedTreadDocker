export interface AddOrderTransactionState {
  transaction: any;
  loading: boolean;
  error: string | null;
}

export interface OrderTransaction {
  unique_id: string;
  group_id: string;
  transfer_by: string;
  sell_value: string;
  sell_currency: string;
  rate: string;
  account_name: string;
  remarks: string;
  updated_at: string;
  calculated_amount: number;
  settlement_currency: string;
  fee?: string;
  trading: string;
}

export interface GetAllOrderTransactionsState {
  data: {
    transactions: OrderTransaction[];
    total_count: number;
  };
  loading: boolean;
  error: string | null;
}

export interface AddOrderTransactionPayload {
  order_id: string;
  group_id: string;
  transfer_by: string;
  sell_value: number;
  sell_currency: string;
  settlement_currency: string;
  rate?: number;
  remarks?: string;
  fee?: number;
  trading: string;
  transferred_date: string;
}

export interface AmountOverviewPayload {
  currency: string;
  group_id: string;
  date: string;
}

export interface AmountOverviewState {
  data: any;
  loading: boolean;
  error: string | null;
}

export interface EditOrderTransactionPayload
  extends Omit<AddOrderTransactionPayload, 'transferred_date'> {
  unique_id: string;
}

export interface EditOrderTransactionState {
  transaction: any;
  loading: boolean;
  error: string | null;
}
export interface CompleteOrderTransactionPayload {
  order_id: string;
}

export interface GetOrderTransactionByIdState {
  data: OrderTransaction | null;
  isLoading: boolean;
  error: string | null;
}
