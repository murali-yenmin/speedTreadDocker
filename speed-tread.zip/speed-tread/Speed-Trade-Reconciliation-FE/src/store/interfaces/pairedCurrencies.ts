export interface PairedCurrenciesState {
  data: string[] | null;
  loading: boolean;
  error: string | null;
}
