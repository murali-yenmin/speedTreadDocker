export interface ProfileNavigationProps {
  activeTab: 'personal' | 'password';
  setActiveTab: (tab: 'personal' | 'password') => void;
}
