export interface PersonalInfoFormData {
  firstName: string;
  email: string;
}
