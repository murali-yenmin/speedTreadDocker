export interface Role {
  unique_id: string;
  role_type: string;
}

export interface RolesState {
  roles: Role[];
  loading: boolean;
  error: string | null;
}
