export interface MediaSourceProps {
  unique_id: string;
  label: string;
  is_active: boolean;
  is_deleted: boolean;
  created_at: string;
  updated_at: string;
}

export interface GetAllMediaSourceState {
  data: MediaSourceProps[] | null;
  loading: boolean;
  error: string | null;
}

export interface AddMediaSourceState {
  data: any | null;
  loading: boolean;
  error: string | null;
}

export interface CurrencyProps {
  unique_id: string;
  name: string;
  from: string;
  to: string;
  code: string;
  is_active: boolean;
}

export interface GetAllCurrenciesState {
  data: CurrencyProps[] | null;
  loading: boolean;
  error: string | null;
}

export interface AddCurrencyState {
  data: any | null;
  loading: boolean;
  error: string | null;
}

export interface UpdateMediaSourceStatusState {
  data: MediaSourceProps | null;
  loading: boolean;
  error: string | null;
}

export interface UpdateCurrencyStatusState {
  data: any | null;
  loading: boolean;
  error: string | null;
}

export interface CurrencyPairProps {
  unique_id: string;
  calculation_type: string;
  is_active: boolean;
  updated_at: string;
  from: string;
  to: string;
  is_greater: boolean;
}

export interface GetAllCurrencyPairsState {
  data: Array<{ pair: CurrencyPairProps[] }> | null;
  loading: boolean;
  error: string | null;
}

export interface AddCurrencyPairState {
  data: any | null;
  loading: boolean;
  error: string | null;
}

export interface UpdateCurrencyPairStatusState {
  data: any | null;
  loading: boolean;
  error: string | null;
}

export interface GetAllFilterSearchCurrencies {
  data: CurrencyProps[] | null;
  loading: boolean;
  error: string | null;
}

export interface BaseOrderGroup {
  unique_id: string;
  group_id: string;
  name: string;
  settlement_currency: string;
  updated_at: string;
}

export interface GetAllOrderGroup {
  data: BaseOrderGroup[] | null;
  loading: boolean;
  error: string | null;
}

export interface DelCurrencyPair {
  data: any | null;
  loading: boolean;
  error: string | null;
}