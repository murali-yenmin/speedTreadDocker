export interface SettlementDetailsPayload {
  currency_id?: string[];
  group_id?: string[];
  day_filter: string;
}

export interface CurrencyCalculation {
  settlement_currency_id: string;
  settlement_currency_code: string;
  weOwe: number;
  oweUs: number;
  weOweFees: number;
  oweUsFees: number;
  totalWeOwe: number;
  totalOweUs: number;
  grandTotal: number;
  sell_value: number;
  fee: number;
}

export interface GroupCalculation {
  group_unique_id: string;
  group_code: string;
  group_name: string;
  grouped_currency: {
    currencies: CurrencyCalculation[];
  };
  end_date: string;
  start_date: string;
  day: string;
}

export interface SettlementCurrency {
  settlement_currency_code: string;
  totalOweUs: number;
  totalWeOwe: number;
}

export interface GroupedCurrency {
  group_code: string;
  currencies: SettlementCurrency[];
}

export interface SettlementData {
  grouped_currency: GroupedCurrency[];
  start_date: string;
  end_date: string;
  day: string;
}

export interface SettlementDetailsState {
  loading: boolean;
  data: SettlementData | null;
  error: string | null;
}
