export interface AddTransactionState {
  transaction: any;
  loading: boolean;
  error: string | null;
}

export interface Transaction {
  unique_id: string;
  group_id: string;
  transfer_by: string;
  sell_value: string;
  sell_currency: string;
  rate: string;
  account_id: string;
  account: {
    name: string;
    unique_id: string;
  };
  remarks: string;
  updated_at: string;
  created_at: string;
  calculated_amount: string;
  settlement_currency: string;
  running_balance: number;
  running_status: string;
  fee?: string;
  transaction_id?: string;
  trading: string;
  transferred_date: string;
}

export interface GetAllTransactionsState {
  data: {
    transactions: { date: string; transactions: Transaction[] }[];
    total_count: number;
    overall_calculated_amount?: number;
  };
  loading: boolean;
  error: string | null;
}

export interface AddTransactionPayload {
  group_id: string;
  transfer_by: string;
  sell_value: number;
  sell_currency: string;
  settlement_currency: string;
  account_id: string;
  rate?: number;
  remarks?: string;
  fee?: number;
  trading: string;
  transferred_date: string;
}

export interface AmountOverviewPayload {
  currency: string;
  group_id: string;
}

export interface AmountOverviewState {
  data: any;
  loading: boolean;
  error: string | null;
}

export interface EditTransactionPayload
  extends Omit<AddTransactionPayload, 'transferred_date'> {
  unique_id: string;
}

export interface EditTransactionState {
  transaction: any;
  loading: boolean;
  error: string | null;
}

export interface GetTransactionByIdState {
  data: Transaction | null;
  isLoading: boolean;
  error: string | null;
}

export interface AddBulkTransactionPayload {
  transactions: AddTransactionPayload[];
}
