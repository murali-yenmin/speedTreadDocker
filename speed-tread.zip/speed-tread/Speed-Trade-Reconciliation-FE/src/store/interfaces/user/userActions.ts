export interface ToggleUserStatusPayload {
  unique_id: string;
  is_active: boolean;
}
