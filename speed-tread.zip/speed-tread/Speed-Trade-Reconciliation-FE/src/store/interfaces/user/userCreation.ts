export interface UserCreatePayload {
  user_name: string;
  email_address: string;
  role_id: string;
}

export interface UserCreationState {
  loading: boolean;
  success: boolean;
  error: string | null;
}
