export interface UserEditPayload {
  unique_id: string;
  user_name: string;
  email_address: string;
  role_id: string;
}

export interface UserEditState {
  loading: boolean;
  success: boolean;
  error: string | null;
}
