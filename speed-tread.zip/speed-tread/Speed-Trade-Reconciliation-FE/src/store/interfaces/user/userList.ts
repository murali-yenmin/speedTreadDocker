export interface UserListItem {
  unique_id: string;
  user_name: string;
  email_address: string;
  phone_number: string;
  is_active: boolean;
  role: {
    unique_id: string;
    role_type: string;
  };
}

export interface UserListPayload {
  cp: number; // Made optional
  pl: number; // Made optional
  query?: {
    operation: string;
    fieldName: string;
    fieldString: string | string[];
  }[];
  sort?: { field: string; value: string };
}

export interface UserListState {
  users: UserListItem[];
  totalCount: number;
  loading: boolean;
  error: string | null;
}
