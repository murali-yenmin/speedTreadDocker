import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { getAccountNamesThunk } from '../thunks/accountName';
import { AccountNameState, AccountName } from '../interfaces/accountName';

const initialState: AccountNameState = {
  accountNames: [],
  loading: false,
  error: null,
};

const accountNameSlice = createSlice({
  name: 'accountName',
  initialState,
  reducers: {
    resetAccountNames: (state) => {
      state.accountNames = [];
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAccountNamesThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        getAccountNamesThunk.fulfilled,
        (state, action: PayloadAction<AccountName[]>) => {
          state.loading = false;
          state.accountNames = action.payload;
        },
      )
      .addCase(getAccountNamesThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { resetAccountNames } = accountNameSlice.actions;
export default accountNameSlice.reducer;
