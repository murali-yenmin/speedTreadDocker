// src/features/auth/forgotSlice.ts
import { createSlice } from '@reduxjs/toolkit';
import { forgotPasswordThunk } from '../../thunks/authentication';
import { ForgotState } from '../../interfaces/authentication';

const initialState: ForgotState = {
  data: null,
  loading: false,
  error: null,
};

const forgotSlice = createSlice({
  name: 'forgot',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(forgotPasswordThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(forgotPasswordThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(forgotPasswordThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default forgotSlice.reducer;
