// src/features/auth/resetPasswordSlice.ts
import { createSlice } from '@reduxjs/toolkit';
import { resetPasswordThunk } from '../../thunks/authentication';
import { ResetPasswordState } from '../../interfaces/authentication';

const initialState: ResetPasswordState = {
  data: null,
  loading: false,
  error: null,
};

const resetPasswordSlice = createSlice({
  name: 'reset_password',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(resetPasswordThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(resetPasswordThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(resetPasswordThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default resetPasswordSlice.reducer;
