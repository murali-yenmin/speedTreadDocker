import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface ErrorState {
  isVisible: boolean;
  errorCode: number | null;
  message: string | null;
}

const initialState: ErrorState = {
  isVisible: false,
  errorCode: null,
  message: null,
};

const errorSlice = createSlice({
  name: 'error',
  initialState,
  reducers: {
    showErrorModal: (
      state,
      action: PayloadAction<{ errorCode: number; message?: string }>,
    ) => {
      state.isVisible = true;
      state.errorCode = action.payload.errorCode;
      state.message = action.payload.message || null;
    },
    hideErrorModal: (state) => {
      state.isVisible = false;
      state.errorCode = null;
      state.message = null;
    },
  },
});

export const { showErrorModal, hideErrorModal } = errorSlice.actions;

export default errorSlice.reducer;