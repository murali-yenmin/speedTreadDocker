import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { transactions } from '../../helper/backend_helper';

interface Summary {
  status: "we_owe" | "owe_us" | "all_clear" | string;
  value: number;
  currency: string;
  overall_calculated_amount: number;
}

interface TransactionAccount {
  unique_id: string;
  name: string;
}

interface Transaction {
  unique_id: string;
  transaction_id: string;
  group_id: string;
  transfer_by: "we" | "customer" | string;
  sell_value: string;
  sell_currency: string;
  settlement_currency: string;
  rate: string;
  fee: string;
  trading: string;
  remarks: string;
  updated_at: string;
  transferred_date: string;
  created_at: string;
  account_unique_id: string;
  account_name: string;
  calculated_amount: string;
  running_balance: number;
  running_status: string;
  account: TransactionAccount;
}

interface TransactionsResponse {
  summary_till_yesterday: Summary;
  transactions: Transaction[];
  summary_today: Summary;
}

interface ExportTransactionsState {
  exportTransactions: TransactionsResponse | null;
  loading: boolean;
  error: string | null;
}

const initialState: ExportTransactionsState = {
  exportTransactions: null,
  loading: false,
  error: null,
};

export const fetchExportTransactions = createAsyncThunk(
  'exportTransactions/fetchExportTransactions',
  async (payload: { group_id: string; settlement_currency: string }, { rejectWithValue }) => {
    try {
      const response = await transactions.getExportTransactions(payload);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  },
);

const exportTransactionsSlice = createSlice({
  name: 'exportTransactions',
  initialState,
  reducers: {
    clearExportTransactions: (state) => {
      state.exportTransactions = null;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchExportTransactions.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchExportTransactions.fulfilled, (state, action) => {
        state.loading = false;
        state.exportTransactions = action.payload.data;
      })
      .addCase(fetchExportTransactions.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearExportTransactions } = exportTransactionsSlice.actions;
export default exportTransactionsSlice.reducer;
