import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { AddGroupState } from '../../interfaces/groups';
import { addGroupThunk } from '../../thunks/groups';

const initialState: AddGroupState = {
  group: null,
  loading: false,
  error: null,
};

const addGroupSlice = createSlice({
  name: 'addGroup',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(addGroupThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addGroupThunk.fulfilled, (state, action: PayloadAction<any>) => {
        state.loading = false;
        state.group = action.payload;
      })
      .addCase(addGroupThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default addGroupSlice.reducer;
