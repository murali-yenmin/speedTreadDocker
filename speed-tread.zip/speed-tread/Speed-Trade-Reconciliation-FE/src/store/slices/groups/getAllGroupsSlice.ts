import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { GetAllGroupsState, Group } from '../../interfaces/group';
import { getAllGroupsThunk } from '../../thunks/groups';

const initialState: GetAllGroupsState = {
  groups: null,
  loading: false,
  error: null,
};

const getAllGroupsSlice = createSlice({
  name: 'getAllGroups',
  initialState,
  reducers: {
    resetGroups: (state) => {
      state.groups = null;
    },
    updateFavorite: (state, action) => {
      const groupList: Group[] = JSON.parse(
        JSON.stringify(state.groups?.customer_groups_list),
      );
      const newList = groupList?.map((item) => {
        if (item?.unique_id === action.payload.unique_id) {
          return { ...item, is_favorite: action.payload.is_favorite };
        }
        return item;
      });
      state.groups = {
        ...state.groups,
        customer_groups_list: newList,
      };
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllGroupsThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getAllGroupsThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.groups = action.payload;
      })
      .addCase(getAllGroupsThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { resetGroups, updateFavorite } = getAllGroupsSlice.actions;
export default getAllGroupsSlice.reducer;
