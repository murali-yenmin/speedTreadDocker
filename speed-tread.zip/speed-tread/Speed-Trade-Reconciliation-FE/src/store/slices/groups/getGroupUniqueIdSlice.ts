import { createSlice } from '@reduxjs/toolkit';
import { getAllGroupByUniqueIdThunk } from '../../thunks/groups';
import { defaultState } from '../../interfaces/order';

const initialState: defaultState = {
  data: null,
  loading: false,
  error: null,
};

const getGroupUniqueIdSlice = createSlice({
  name: 'getGroupUniqueIdSlice',
  initialState,
  reducers: {
    resetGroupByUniqueId: (state) => {
      state.data = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllGroupByUniqueIdThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getAllGroupByUniqueIdThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(getAllGroupByUniqueIdThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { resetGroupByUniqueId } = getGroupUniqueIdSlice.actions;
export default getGroupUniqueIdSlice.reducer;
