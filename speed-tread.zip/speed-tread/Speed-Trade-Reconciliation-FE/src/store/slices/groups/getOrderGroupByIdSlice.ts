import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { GetGroupByIdState, Group } from '../../interfaces/group';
import { getOrderGroupByIdThunk } from '../../thunks/groups';

const initialState: GetGroupByIdState = {
  data: null,
  isLoading: false,
  error: null,
};

const getOrderGroupByIdSlice = createSlice({
  name: 'getOrderGroupById',
  initialState,
  reducers: {
    resetGetOrderGroupById: (state) => {
      state.data = null;
      state.isLoading = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getOrderGroupByIdThunk.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(
        getOrderGroupByIdThunk.fulfilled,
        (state, action: PayloadAction<Group>) => {
          state.isLoading = false;
          state.data = action.payload;
        },
      )
      .addCase(getOrderGroupByIdThunk.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message || 'Failed to fetch order group';
      });
  },
});

export const { resetGetOrderGroupById } = getOrderGroupByIdSlice.actions;

export default getOrderGroupByIdSlice.reducer;
