import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { GetGroupByIdState, Group } from '../../interfaces/group';
import { getTransactionGroupByIdThunk } from '../../thunks/groups';

const initialState: GetGroupByIdState = {
  data: null,
  isLoading: false,
  error: null,
};

const getTransactionGroupByIdSlice = createSlice({
  name: 'getTransactionGroupById',
  initialState,
  reducers: {
    resetGetTransactionGroupById: (state) => {
      state.data = null;
      state.isLoading = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getTransactionGroupByIdThunk.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(
        getTransactionGroupByIdThunk.fulfilled,
        (state, action: PayloadAction<Group>) => {
          state.isLoading = false;
          state.data = action.payload;
        },
      )
      .addCase(getTransactionGroupByIdThunk.rejected, (state, action) => {
        state.isLoading = false;
        state.error =
          action.error.message || 'Failed to fetch transaction group';
      });
  },
});

export const { resetGetTransactionGroupById } =
  getTransactionGroupByIdSlice.actions;
export default getTransactionGroupByIdSlice.reducer;
