import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { GetAllGroupsState, Group } from '../../interfaces/group';
import { orderGroupGetAllThunk } from '../../thunks/groups';

const initialState: GetAllGroupsState = {
  groups: null,
  loading: false,
  error: null,
};

const orderGroupGetAllSlice = createSlice({
  name: 'orderGroupGetAll',
  initialState,
  reducers: {
    resetOrderGroups: (state) => {
      state.groups = null;
    },
    updateFavoriteInOrderGroup: (state, action) => {
      const groupList: Group[] = JSON.parse(
        JSON.stringify(state.groups?.customer_groups_list),
      );
      const newList = groupList?.map((item) => {
        if (item?.unique_id === action.payload.unique_id) {
          return { ...item, is_favorite: action.payload.is_favorite };
        }
        return item;
      });
      state.groups = {
        ...state.groups,
        customer_groups_list: newList,
      };
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(orderGroupGetAllThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(orderGroupGetAllThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.groups = action.payload;
      })
      .addCase(orderGroupGetAllThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { resetOrderGroups, updateFavoriteInOrderGroup } =
  orderGroupGetAllSlice.actions;
export default orderGroupGetAllSlice.reducer;
