import { createSlice } from '@reduxjs/toolkit';
import { currencyReorderThunk } from '../../thunks/groups';
import { defaultState } from '../../interfaces/order';

const initialState: defaultState = {
  data: null,
  loading: false,
  error: null,
};

const updateCurrencyReorderSlice = createSlice({
  name: 'updateCurrencyReorderSlice',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(currencyReorderThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(currencyReorderThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(currencyReorderThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default updateCurrencyReorderSlice.reducer;
