import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { UpdateGroupState } from '../../interfaces/groups';
import { updateGroupThunk } from '../../thunks/groups';

const initialState: UpdateGroupState = {
  group: null,
  loading: false,
  error: null,
};

const updateGroupSlice = createSlice({
  name: 'updateGroup',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(updateGroupThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        updateGroupThunk.fulfilled,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.group = action.payload;
        },
      )
      .addCase(updateGroupThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default updateGroupSlice.reducer;
