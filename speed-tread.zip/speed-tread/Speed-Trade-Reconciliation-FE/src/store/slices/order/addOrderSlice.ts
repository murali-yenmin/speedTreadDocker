import { createSlice } from '@reduxjs/toolkit';
import { addOrderThunk } from '../../thunks/order';
import { AddOrderState } from '../../interfaces/order';

const initialState: AddOrderState = {
  loading: false,
  error: null,
};

const addOrderSlice = createSlice({
  name: 'add_order',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(addOrderThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addOrderThunk.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(addOrderThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default addOrderSlice.reducer;
