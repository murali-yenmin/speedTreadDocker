import { createSlice } from '@reduxjs/toolkit';
import {
  getAllOrdersThunk,
  deleteMultipleOrdersThunk,
} from '../../thunks/order';
import { GetAllOrdersState } from '../../interfaces/order';

const initialState: GetAllOrdersState = {
  data: null,
  loading: false,
  error: null,
};

const deleteAllOrdersSlice = createSlice({
  name: 'delete_all_orders',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(deleteMultipleOrdersThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteMultipleOrdersThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(deleteMultipleOrdersThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      }) 
  },
});

export default deleteAllOrdersSlice.reducer;
