import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { deleteOrderThunk } from '../../thunks/order';
import { defaultState } from '../../interfaces/order';

const initialState: defaultState = {
  data: null,
  loading: false,
  error: null,
};

const deleteOrderSlice = createSlice({
  name: 'deleteOrderSlice',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(deleteOrderThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteOrderThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(deleteOrderThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default deleteOrderSlice.reducer;
