import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { deleteOrderTransactionThunk } from '../../thunks/order';
import { defaultState } from '../../interfaces/order';

const initialState: defaultState = {
  data: null,
  loading: false,
  error: null,
};

const deleteOrderTransactionSlice = createSlice({
  name: 'deleteOrderTransactionSlice',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(deleteOrderTransactionThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteOrderTransactionThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(deleteOrderTransactionThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default deleteOrderTransactionSlice.reducer;
