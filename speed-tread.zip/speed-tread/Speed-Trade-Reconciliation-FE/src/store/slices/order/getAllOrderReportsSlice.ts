import { createSlice } from '@reduxjs/toolkit';
import { getAllOrdersReportThunk } from '../../thunks/order';
import { GetAllOrdersState } from '../../interfaces/order';

const initialState: GetAllOrdersState = {
  data: null,
  loading: false,
  error: null,
};

const getAllOrdersReportsSlice = createSlice({
  name: 'get_all_orders_reports',
  initialState,
  reducers: {
    clearOrder: (state) => {
      state.data = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllOrdersReportThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getAllOrdersReportThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(getAllOrdersReportThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default getAllOrdersReportsSlice.reducer;
export const { clearOrder } = getAllOrdersReportsSlice.actions;
