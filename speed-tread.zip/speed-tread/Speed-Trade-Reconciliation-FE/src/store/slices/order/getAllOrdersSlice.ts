import { createSlice } from '@reduxjs/toolkit';
import {
  getAllOrdersThunk, 
} from '../../thunks/order';
import { GetAllOrdersState } from '../../interfaces/order';

const initialState: GetAllOrdersState = {
  data: null,
  loading: false,
  error: null,
};

const getAllOrdersSlice = createSlice({
  name: 'get_all_orders',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getAllOrdersThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getAllOrdersThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(getAllOrdersThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      }) ;
  },
});

export default getAllOrdersSlice.reducer;
