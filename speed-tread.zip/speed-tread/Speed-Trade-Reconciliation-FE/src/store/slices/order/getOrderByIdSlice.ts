import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { GetOrderByIdState } from '../../interfaces/order';
import { getOrderByIdThunk } from '../../thunks/order';
import { Order } from '../../../interfaces/order';

const initialState: GetOrderByIdState = {
  data: null,
  isLoading: false,
  error: null,
};

const getOrderByIdSlice = createSlice({
  name: 'getOrderById',
  initialState,
  reducers: {
    resetGetOrderById: (state) => {
      state.data = null;
      state.isLoading = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getOrderByIdThunk.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(
        getOrderByIdThunk.fulfilled,
        (state, action: PayloadAction<Order>) => {
          state.isLoading = false;
          state.data = action.payload;
        },
      )
      .addCase(getOrderByIdThunk.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message || 'Failed to fetch order';
      });
  },
});

export const { resetGetOrderById } = getOrderByIdSlice.actions;
export default getOrderByIdSlice.reducer;
