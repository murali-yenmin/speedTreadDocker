import { createSlice } from '@reduxjs/toolkit';
import { getOrderGroupThunk } from '../../thunks/order';
import { GetAllOrderGroup } from '../../interfaces/settings';

const initialState: GetAllOrderGroup = {
  data: null,
  loading: false,
  error: null,
};

const getOrderGroupSlice = createSlice({
  name: 'getOrderGroupSlice',
  initialState,
  reducers: {
    clearOrderGroups: (state) => {
      state.data = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getOrderGroupThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getOrderGroupThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(getOrderGroupThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});
export default getOrderGroupSlice.reducer;
export const { clearOrderGroups } = getOrderGroupSlice.actions;
