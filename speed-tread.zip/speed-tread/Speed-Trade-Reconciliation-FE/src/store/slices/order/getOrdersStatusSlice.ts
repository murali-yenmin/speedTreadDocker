import { createSlice } from '@reduxjs/toolkit';
import { getOrderStatusThunk } from '../../thunks/order';
import { GetAllOrdersStatusState } from '../../interfaces/order';

const initialState: GetAllOrdersStatusState = {
  data: null,
  loading: false,
  error: null,
};

const getOrdersStatusSlice = createSlice({
  name: 'getOrdersStatusSlice',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getOrderStatusThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getOrderStatusThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(getOrderStatusThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default getOrdersStatusSlice.reducer;
