import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { getGroupBasedOrderCurrenciesThunk } from '../../thunks/groupBasedOrderCurrencies';

interface GroupBasedOrderCurrenciesState {
  data: string[];
  loading: boolean;
  error: string | null;
}

const initialState: GroupBasedOrderCurrenciesState = {
  data: [],
  loading: false,
  error: null,
};

const groupBasedOrderCurrenciesSlice = createSlice({
  name: 'groupBasedOrderCurrencies',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getGroupBasedOrderCurrenciesThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        getGroupBasedOrderCurrenciesThunk.fulfilled,
        (state, action: PayloadAction<string[]>) => {
          state.loading = false;
          state.data = action.payload;
        },
      )
      .addCase(getGroupBasedOrderCurrenciesThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default groupBasedOrderCurrenciesSlice.reducer;
