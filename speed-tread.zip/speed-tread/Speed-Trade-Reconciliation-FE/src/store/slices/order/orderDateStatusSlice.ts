import { createSlice } from '@reduxjs/toolkit';
import { getOrderDateStatusThunk } from '../../thunks/order';

interface OrderDateStatusState {
  loading: boolean;
  data: string[];
  error: string | null;
}

const initialState: OrderDateStatusState = {
  loading: false,
  data: [],
  error: null,
};

const orderDateStatusSlice = createSlice({
  name: 'orderDateStatus',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getOrderDateStatusThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getOrderDateStatusThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(getOrderDateStatusThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default orderDateStatusSlice.reducer;
