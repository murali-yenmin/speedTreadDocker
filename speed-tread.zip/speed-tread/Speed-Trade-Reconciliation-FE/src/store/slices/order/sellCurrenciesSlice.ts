import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { getOrderSellCurrenciesThunk } from '../../thunks/order/sellCurrencies';

interface SellCurrenciesState {
  data: string[];
  loading: boolean;
  error: string | null;
}

const initialState: SellCurrenciesState = {
  data: [],
  loading: false,
  error: null,
};

const orderSellCurrenciesSlice = createSlice({
  name: 'orderSellCurrencies',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getOrderSellCurrenciesThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        getOrderSellCurrenciesThunk.fulfilled,
        (state, action: PayloadAction<string[]>) => {
          state.loading = false;
          state.data = action.payload;
        },
      )
      .addCase(getOrderSellCurrenciesThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default orderSellCurrenciesSlice.reducer;
