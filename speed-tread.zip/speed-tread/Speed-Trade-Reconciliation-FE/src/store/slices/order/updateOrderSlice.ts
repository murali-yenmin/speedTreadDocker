import { createSlice } from '@reduxjs/toolkit';
import { updateOrderThunk } from '../../thunks/order';
import { UpdateOrderState } from '../../interfaces/order';

const initialState: UpdateOrderState = {
  loading: false,
  error: null,
};

const updateOrderSlice = createSlice({
  name: 'update_order',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(updateOrderThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateOrderThunk.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(updateOrderThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default updateOrderSlice.reducer;
