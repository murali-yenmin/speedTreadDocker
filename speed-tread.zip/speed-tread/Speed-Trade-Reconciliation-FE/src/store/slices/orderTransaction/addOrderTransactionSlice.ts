import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { AddOrderTransactionState } from '../../interfaces/orderTransaction';
import { addOrderTransactionThunk } from '../../thunks/orderTransaction';

const initialState: AddOrderTransactionState = {
  transaction: null,
  loading: false,
  error: null,
};

const addOrderTransactionSlice = createSlice({
  name: 'addOrderTransaction',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(addOrderTransactionThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        addOrderTransactionThunk.fulfilled,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.transaction = action.payload;
        },
      )
      .addCase(
        addOrderTransactionThunk.rejected,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.error = action.payload?.message || 'An error occurred';
        },
      );
  },
});

export default addOrderTransactionSlice.reducer;
