import { createSlice } from '@reduxjs/toolkit';
import { completeOrderThunk } from '../../thunks/orderTransaction';
import { AddOrderState } from '../../interfaces/order';

const initialState: AddOrderState = {
  loading: false,
  error: null,
};

const completeOrderSlice = createSlice({
  name: 'complete_order',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(completeOrderThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(completeOrderThunk.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(completeOrderThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default completeOrderSlice.reducer;
