import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { EditOrderTransactionState } from '../../interfaces/orderTransaction';
import { editOrderTransactionThunk } from '../../thunks/orderTransaction';

const initialState: EditOrderTransactionState = {
  transaction: null,
  loading: false,
  error: null,
};

const editOrderTransactionSlice = createSlice({
  name: 'editOrderTransaction',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(editOrderTransactionThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        editOrderTransactionThunk.fulfilled,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.transaction = action.payload;
        },
      )
      .addCase(
        editOrderTransactionThunk.rejected,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.error = action.payload?.message || 'An error occurred';
        },
      );
  },
});

export default editOrderTransactionSlice.reducer;
