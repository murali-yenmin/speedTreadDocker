import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import {
  GetOrderTransactionByIdState,
  OrderTransaction,
} from '../../interfaces/orderTransaction';
import { getOrderTransactionByIdThunk } from '../../thunks/orderTransaction';

const initialState: GetOrderTransactionByIdState = {
  data: null,
  isLoading: false,
  error: null,
};

const getOrderTransactionByIdSlice = createSlice({
  name: 'getOrderTransactionById',
  initialState,
  reducers: {
    resetGetOrderTransactionById: (state) => {
      state.data = null;
      state.isLoading = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getOrderTransactionByIdThunk.pending, (state) => {
        state.isLoading = true;
        state.data = null;
        state.error = null;
      })
      .addCase(
        getOrderTransactionByIdThunk.fulfilled,
        (state, action: PayloadAction<OrderTransaction>) => {
          state.isLoading = false;
          state.data = action.payload;
        },
      )
      .addCase(getOrderTransactionByIdThunk.rejected, (state, action) => {
        state.isLoading = false;
        state.error =
          action.error.message || 'Failed to fetch order transaction';
      });
  },
});

export const { resetGetOrderTransactionById } =
  getOrderTransactionByIdSlice.actions;
export default getOrderTransactionByIdSlice.reducer;
