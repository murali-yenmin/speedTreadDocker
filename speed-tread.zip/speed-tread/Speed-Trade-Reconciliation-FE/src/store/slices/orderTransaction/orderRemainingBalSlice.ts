import { createSlice } from '@reduxjs/toolkit';
import { getAddTransRemindBalThunk } from '../../thunks/orderTransaction';
import { OrderRemainingBalState } from '../../interfaces/order';

const initialState: OrderRemainingBalState = {
  data: null,
  loading: false,
  error: null,
};

const orderRemainingBalSlice = createSlice({
  name: 'orderRemainingBalSlice',
  initialState,
  reducers: {
    clearRemindBal: (state) => {
      state.data = null;
      state.error = null;
      state.loading = false;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAddTransRemindBalThunk.pending, (state) => {
        state.loading = true;
        state.data = null;
        state.error = null;
      })
      .addCase(getAddTransRemindBalThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload?.data;
        state.error = null;
      })
      .addCase(getAddTransRemindBalThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});
export const { clearRemindBal } = orderRemainingBalSlice.actions;
export default orderRemainingBalSlice.reducer;
