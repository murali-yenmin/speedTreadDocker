import { createSlice } from '@reduxjs/toolkit';
import { getPairedCurrenciesThunk } from '../thunks/pairedCurrencies';
import { PairedCurrenciesState } from '../interfaces/pairedCurrencies';

const initialState: PairedCurrenciesState = {
  data: null,
  loading: false,
  error: null,
};

const pairedCurrenciesSlice = createSlice({
  name: 'pairedCurrencies',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getPairedCurrenciesThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getPairedCurrenciesThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(getPairedCurrenciesThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default pairedCurrenciesSlice.reducer;
