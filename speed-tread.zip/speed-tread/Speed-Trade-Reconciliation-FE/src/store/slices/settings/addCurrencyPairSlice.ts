import { createSlice } from '@reduxjs/toolkit';
import { addCurrencyPairThunk } from '../../thunks/settings';
import { AddCurrencyPairState } from '../../interfaces/settings';

const initialState: AddCurrencyPairState = {
  data: null,
  loading: false,
  error: null,
};

const addCurrencyPairSlice = createSlice({
  name: 'add_currency_pair',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(addCurrencyPairThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addCurrencyPairThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(addCurrencyPairThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default addCurrencyPairSlice.reducer;
