import { createSlice } from '@reduxjs/toolkit';
import { addCurrencyThunk } from '../../thunks/settings';
import { AddCurrencyState } from '../../interfaces/settings';

const initialState: AddCurrencyState = {
  data: null,
  loading: false,
  error: null,
};

const addCurrencySlice = createSlice({
  name: 'add_currency',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(addCurrencyThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addCurrencyThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(addCurrencyThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default addCurrencySlice.reducer;
