import { createSlice } from '@reduxjs/toolkit';
import { addMediaSourceThunk } from '../../thunks/settings';
import { AddMediaSourceState } from '../../interfaces/settings';

const initialState: AddMediaSourceState = {
  data: null,
  loading: false,
  error: null,
};

const addMediaSourceSlice = createSlice({
  name: 'add_source',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(addMediaSourceThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addMediaSourceThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(addMediaSourceThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default addMediaSourceSlice.reducer;
