import { createSlice } from '@reduxjs/toolkit';
import { updateCurrencyPairStatusThunk } from '../../thunks/settings';
import { UpdateCurrencyPairStatusState } from '../../interfaces/settings';

const initialState: UpdateCurrencyPairStatusState = {
  data: null,
  loading: false,
  error: null,
};

const currencyPairStatusChangeSlice = createSlice({
  name: 'currency_pair_status_change',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(updateCurrencyPairStatusThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateCurrencyPairStatusThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(updateCurrencyPairStatusThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default currencyPairStatusChangeSlice.reducer;
