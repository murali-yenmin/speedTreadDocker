import { createSlice } from '@reduxjs/toolkit';
import { updateCurrencyStatusThunk } from '../../thunks/settings';
import { UpdateCurrencyStatusState } from '../../interfaces/settings';

const initialState: UpdateCurrencyStatusState = {
  data: null,
  loading: false,
  error: null,
};

const currencyStatusChangeSlice = createSlice({
  name: 'currency_status_change',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(updateCurrencyStatusThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateCurrencyStatusThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(updateCurrencyStatusThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default currencyStatusChangeSlice.reducer;
