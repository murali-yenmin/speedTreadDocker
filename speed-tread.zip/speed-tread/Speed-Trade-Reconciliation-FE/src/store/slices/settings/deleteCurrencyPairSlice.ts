import { createSlice } from '@reduxjs/toolkit';
import { deleteCurrencyPairThunk } from '../../thunks/settings';
import { DelCurrencyPair } from '../../interfaces/settings';

const initialState: DelCurrencyPair = {
  data: null,
  loading: false,
  error: null,
};

const deleteCurrencyPairSlice = createSlice({
  name: 'deleteCurrencyPairSlice',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(deleteCurrencyPairThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteCurrencyPairThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(deleteCurrencyPairThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default deleteCurrencyPairSlice.reducer;
