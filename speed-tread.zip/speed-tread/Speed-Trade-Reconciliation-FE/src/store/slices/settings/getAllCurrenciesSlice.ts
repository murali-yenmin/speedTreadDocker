import { createSlice } from '@reduxjs/toolkit';
import {
  getAllCurrenciesThunk,
  updateCurrencyThunk,
} from '../../thunks/settings';
import {
  CurrencyProps,
  GetAllCurrenciesState,
} from '../../interfaces/settings';

const initialState: GetAllCurrenciesState = {
  data: null,
  loading: false,
  error: null,
};

const getAllCurrenciesSlice = createSlice({
  name: 'get_all_currencies',
  initialState,
  reducers: {
    replaceCurrency: (state, action) => {
      const data = JSON.parse(JSON.stringify(state.data));
      const index = data?.findIndex(
        (currency: CurrencyProps) =>
          currency.unique_id === action.payload.unique_id,
      );
      if (index !== -1) {
        data[index] = action.payload;
        state.data = data;
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllCurrenciesThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getAllCurrenciesThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(getAllCurrenciesThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(updateCurrencyThunk.fulfilled, (state, action) => {
        if (action.payload?.data) {
          const data = JSON.parse(JSON.stringify(state.data));
          const index = data?.findIndex(
            (currency: CurrencyProps) =>
              currency.unique_id === action.payload.data.unique_id,
          );
          if (index !== -1) {
            data[index] = action.payload.data;
            state.data = data;
          }
        }
      });
  },
});

export const { replaceCurrency } = getAllCurrenciesSlice.actions;

export default getAllCurrenciesSlice.reducer;
