import { createSlice } from '@reduxjs/toolkit';
import { getAllCurrencyPairsThunk } from '../../thunks/settings';
import {
  CurrencyPairProps,
  GetAllCurrencyPairsState,
} from '../../interfaces/settings';

const initialState: GetAllCurrencyPairsState = {
  data: null,
  loading: false,
  error: null,
};

const getAllCurrencyPairsSlice = createSlice({
  name: 'get_all_currency_pairs',
  initialState,
  reducers: {
    replaceCurrencyPair: (state, action) => {
      const data = JSON.parse(JSON.stringify(state.data));
      const index = data?.findIndex(
        (currency: CurrencyPairProps) =>
          currency.unique_id === action.payload.unique_id,
      );
      if (index !== -1) {
        data[index] = action.payload;
        state.data = data;
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllCurrencyPairsThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getAllCurrencyPairsThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(getAllCurrencyPairsThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { replaceCurrencyPair } = getAllCurrencyPairsSlice.actions;

export default getAllCurrencyPairsSlice.reducer;
