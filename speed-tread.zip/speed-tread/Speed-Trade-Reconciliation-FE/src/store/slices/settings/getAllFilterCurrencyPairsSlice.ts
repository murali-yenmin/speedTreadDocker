import { createSlice } from '@reduxjs/toolkit';
import { getAllFilterCurrencyPairsThunk } from '../../thunks/settings';
import {
  CurrencyPairProps,
  GetAllCurrencyPairsState,
} from '../../interfaces/settings';

const initialState: GetAllCurrencyPairsState = {
  data: null,
  loading: false,
  error: null,
};

const getAllFilterCurrencyPairsSlice = createSlice({
  name: 'getAllFilterCurrencyPairsSlice',
  initialState,
  reducers: {
    clearFilterCurrencyPair: (state, action) => {
      state.data = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllFilterCurrencyPairsThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getAllFilterCurrencyPairsThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(getAllFilterCurrencyPairsThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearFilterCurrencyPair } =
  getAllFilterCurrencyPairsSlice.actions;

export default getAllFilterCurrencyPairsSlice.reducer;
