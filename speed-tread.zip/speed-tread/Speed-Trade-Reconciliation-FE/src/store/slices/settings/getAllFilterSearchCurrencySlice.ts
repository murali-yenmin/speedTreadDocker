import { createSlice } from '@reduxjs/toolkit';
import { getAllFilterSearchCurrenciesThunk } from '../../thunks/settings';
import {
  CurrencyPairProps,
  GetAllCurrencyPairsState,
  GetAllFilterSearchCurrencies,
} from '../../interfaces/settings';

const initialState: GetAllFilterSearchCurrencies = {
  data: null,
  loading: false,
  error: null,
};

const getAllFilterSearchCurrencySlice = createSlice({
  name: 'getAllFilterSearchCurrencySlice',
  initialState,
  reducers: {
    clearFilterSearchCurrencyPair: (state, action) => {
      state.data = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllFilterSearchCurrenciesThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getAllFilterSearchCurrenciesThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(getAllFilterSearchCurrenciesThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearFilterSearchCurrencyPair } =
  getAllFilterSearchCurrencySlice.actions;

export default getAllFilterSearchCurrencySlice.reducer;
