import { createSlice } from '@reduxjs/toolkit';
import { getAllMediaSourcesThunk } from '../../thunks/settings';
import {
  GetAllMediaSourceState,
  MediaSourceProps,
} from '../../interfaces/settings';

const initialState: GetAllMediaSourceState = {
  data: null,
  loading: false,
  error: null,
};

const getAllMediaSourceSlice = createSlice({
  name: 'get_all_source',
  initialState,
  reducers: {
    replaceSource: (state, action) => {
      const data = JSON.parse(JSON.stringify(state.data));
      const index = data?.findIndex(
        (source: MediaSourceProps) =>
          source.unique_id === action.payload.unique_id,
      );
      if (index !== -1) {
        data[index] = action.payload;
        state.data = data;
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllMediaSourcesThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getAllMediaSourcesThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(getAllMediaSourcesThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { replaceSource } = getAllMediaSourceSlice.actions;

export default getAllMediaSourceSlice.reducer;
