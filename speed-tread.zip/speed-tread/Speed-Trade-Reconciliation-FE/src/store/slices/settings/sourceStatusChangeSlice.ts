import { createSlice } from '@reduxjs/toolkit';
import { updateMediaSourceStatusThunk } from '../../thunks/settings';
import { UpdateMediaSourceStatusState } from '../../interfaces/settings';

const initialState: UpdateMediaSourceStatusState = {
  data: null,
  loading: false,
  error: null,
};

const sourceStatusChangeSlice = createSlice({
  name: 'source_status_change',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(updateMediaSourceStatusThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateMediaSourceStatusThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(updateMediaSourceStatusThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default sourceStatusChangeSlice.reducer;
