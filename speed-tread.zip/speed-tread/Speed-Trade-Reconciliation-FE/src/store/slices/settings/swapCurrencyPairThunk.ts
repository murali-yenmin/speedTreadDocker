import { createSlice } from '@reduxjs/toolkit';
import { swapCurrencyPairThunk } from '../../thunks/settings';
import { DelCurrencyPair } from '../../interfaces/settings';

const initialState: DelCurrencyPair = {
  data: null,
  loading: false,
  error: null,
};

const swapCurrencyPairSlice = createSlice({
  name: 'deleteCurrencyPairSlice',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(swapCurrencyPairThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(swapCurrencyPairThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(swapCurrencyPairThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default swapCurrencyPairSlice.reducer;
