import { createSlice } from '@reduxjs/toolkit';
import { updateCurrencyThunk } from '../../thunks/settings';
import { AddCurrencyState } from '../../interfaces/settings';

const initialState: AddCurrencyState = {
  data: null,
  loading: false,
  error: null,
};

const updateCurrencySlice = createSlice({
  name: 'update_currency',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(updateCurrencyThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateCurrencyThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(updateCurrencyThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default updateCurrencySlice.reducer;
