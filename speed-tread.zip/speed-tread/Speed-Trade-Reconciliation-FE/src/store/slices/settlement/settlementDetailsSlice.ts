import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { SettlementDetailsState } from '../../interfaces/settlement';
import { getSettlementDetailsThunk } from '../../thunks/settlement';

const initialState: SettlementDetailsState = {
  data: null,
  loading: false,
  error: null,
};

const settlementDetailsSlice = createSlice({
  name: 'settlementDetails',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getSettlementDetailsThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        getSettlementDetailsThunk.fulfilled,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.data = action.payload;
        },
      )
      .addCase(
        getSettlementDetailsThunk.rejected,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.error = action.payload?.message || 'An error occurred';
        },
      );
  },
});

export default settlementDetailsSlice.reducer;
