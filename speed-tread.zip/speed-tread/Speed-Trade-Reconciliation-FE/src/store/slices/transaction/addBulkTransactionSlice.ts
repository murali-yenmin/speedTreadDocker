import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { AddTransactionState } from '../../interfaces/transaction';
import { addBulkTransactionThunk } from '../../thunks/transaction';

const initialState: AddTransactionState = {
  transaction: null,
  loading: false,
  error: null,
};

const addBulkTransactionSlice = createSlice({
  name: 'addBulkTransactionSlice',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(addBulkTransactionThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        addBulkTransactionThunk.fulfilled,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.transaction = action.payload;
        },
      )
      .addCase(
        addBulkTransactionThunk.rejected,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.error = action.payload?.message || 'An error occurred';
        },
      );
  },
});

export default addBulkTransactionSlice.reducer;
