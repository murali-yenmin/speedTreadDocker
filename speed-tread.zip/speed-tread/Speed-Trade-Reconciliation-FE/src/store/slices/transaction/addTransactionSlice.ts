import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { AddTransactionState } from '../../interfaces/transaction';
import { addTransactionThunk } from '../../thunks/transaction';

const initialState: AddTransactionState = {
  transaction: null,
  loading: false,
  error: null,
};

const addTransactionSlice = createSlice({
  name: 'addTransaction',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(addTransactionThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        addTransactionThunk.fulfilled,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.transaction = action.payload;
        },
      )
      .addCase(
        addTransactionThunk.rejected,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.error = action.payload?.message || 'An error occurred';
        },
      );
  },
});

export default addTransactionSlice.reducer;
