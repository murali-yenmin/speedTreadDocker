import { createSlice } from '@reduxjs/toolkit';
import { AmountOverviewState } from '../../interfaces/transaction';
import { amountOverviewThunk } from '../../thunks/transaction';

const initialState: AmountOverviewState = {
  data: null,
  loading: false,
  error: null,
};

const amountOverviewSlice = createSlice({
  name: 'amountOverview',
  initialState,
  reducers: {
    resetAmountOverview: (state) => {
      state.data = null;
      state.loading = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(amountOverviewThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(amountOverviewThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(amountOverviewThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { resetAmountOverview } = amountOverviewSlice.actions;

export default amountOverviewSlice.reducer;
