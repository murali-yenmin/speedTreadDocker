import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { deleteMultipleTransactionsThunk } from '../../thunks/transaction';

interface IDeleteState {
  loading: boolean;
  data: any;
  error: boolean;
}

const initialState: IDeleteState = {
  loading: false,
  data: null,
  error: false,
};

const deleteMultipleTransactionsSlice = createSlice({
  name: 'deleteMultipleTransactionsSlice',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(deleteMultipleTransactionsThunk.pending, (state) => {
        state.loading = true;
        state.data = null;
        state.error = false;
      })
      .addCase(
        deleteMultipleTransactionsThunk.fulfilled,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.data = action.payload;
          state.error = false;
        },
      )
      .addCase(deleteMultipleTransactionsThunk.rejected, (state) => {
        state.loading = false;
        state.data = null;
        state.error = true;
      });
  },
});

export default deleteMultipleTransactionsSlice.reducer;
