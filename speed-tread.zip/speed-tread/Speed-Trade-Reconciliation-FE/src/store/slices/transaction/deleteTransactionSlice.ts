import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { EditTransactionState } from '../../interfaces/transaction';
import { deleteTransactionThunk } from '../../thunks/transaction';

const initialState: EditTransactionState = {
  transaction: null,
  loading: false,
  error: null,
};

const deleteTransactionSlice = createSlice({
  name: 'deleteTransactionSlice',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(deleteTransactionThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        deleteTransactionThunk.fulfilled,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.transaction = action.payload;
        },
      )
      .addCase(
        deleteTransactionThunk.rejected,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.error = action.payload?.message || 'An error occurred';
        },
      );
  },
});

export default deleteTransactionSlice.reducer;
