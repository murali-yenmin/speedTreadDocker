import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { EditTransactionState } from '../../interfaces/transaction';
import { editTransactionThunk } from '../../thunks/transaction';

const initialState: EditTransactionState = {
  transaction: null,
  loading: false,
  error: null,
};

const editTransactionSlice = createSlice({
  name: 'editTransaction',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(editTransactionThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        editTransactionThunk.fulfilled,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.transaction = action.payload;
        },
      )
      .addCase(
        editTransactionThunk.rejected,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.error = action.payload?.message || 'An error occurred';
        },
      );
  },
});

export default editTransactionSlice.reducer;
