import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import {
  GetAllTransactionsState,
  Transaction,
} from '../../interfaces/transaction';
import { getAllTransactionsThunk } from '../../thunks/transaction';

const initialState: GetAllTransactionsState = {
  data: {
    transactions: [],
    total_count: 0,
  },
  loading: false,
  error: null,
};

const getAllTransactionsSlice = createSlice({
  name: 'getAllTransactions',
  initialState,
  reducers: {
    resetGetAllTransactions: (state) => {
      state.data = initialState.data;
      state.loading = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllTransactionsThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getAllTransactionsThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(getAllTransactionsThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { resetGetAllTransactions } = getAllTransactionsSlice.actions;

export default getAllTransactionsSlice.reducer;
