import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { GetTransactionByIdState } from '../../interfaces/transaction';
import { getTransactionByIdThunk } from '../../thunks/transaction';
import { Transaction } from '../../interfaces/transaction';

const initialState: GetTransactionByIdState = {
  data: null,
  isLoading: false,
  error: null,
};

const getTransactionByIdSlice = createSlice({
  name: 'getTransactionById',
  initialState,
  reducers: {
    resetGetTransactionById: (state) => {
      state.data = null;
      state.isLoading = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getTransactionByIdThunk.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(
        getTransactionByIdThunk.fulfilled,
        (state, action: PayloadAction<Transaction>) => {
          state.isLoading = false;
          state.data = action.payload;
        },
      )
      .addCase(getTransactionByIdThunk.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message || 'Failed to fetch transaction';
      });
  },
});

export const { resetGetTransactionById } = getTransactionByIdSlice.actions;
export default getTransactionByIdSlice.reducer;
