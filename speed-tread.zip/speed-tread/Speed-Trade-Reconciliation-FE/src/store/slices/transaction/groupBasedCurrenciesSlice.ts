import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { getGroupBasedCurrenciesThunk } from '../../thunks/groupBasedCurrencies';

interface GroupBasedCurrenciesState {
  data: string[];
  loading: boolean;
  error: string | null;
}

const initialState: GroupBasedCurrenciesState = {
  data: [],
  loading: false,
  error: null,
};

const groupBasedCurrenciesSlice = createSlice({
  name: 'groupBasedCurrencies',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getGroupBasedCurrenciesThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        getGroupBasedCurrenciesThunk.fulfilled,
        (state, action: PayloadAction<string[]>) => {
          state.loading = false;
          state.data = action.payload;
        },
      )
      .addCase(getGroupBasedCurrenciesThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default groupBasedCurrenciesSlice.reducer;
