import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { getTransactionSellCurrenciesThunk } from '../../thunks/transaction/sellCurrencies';

interface SellCurrenciesState {
  data: string[];
  loading: boolean;
  error: string | null;
}

const initialState: SellCurrenciesState = {
  data: [],
  loading: false,
  error: null,
};

const sellCurrenciesSlice = createSlice({
  name: 'sellCurrencies',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getTransactionSellCurrenciesThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        getTransactionSellCurrenciesThunk.fulfilled,
        (state, action: PayloadAction<string[]>) => {
          state.loading = false;
          state.data = action.payload;
        },
      )
      .addCase(getTransactionSellCurrenciesThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default sellCurrenciesSlice.reducer;
