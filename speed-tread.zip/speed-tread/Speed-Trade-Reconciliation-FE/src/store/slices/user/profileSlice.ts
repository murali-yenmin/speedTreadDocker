import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { users, auth } from '../../../helper/backend_helper'; // Adjust path as needed

// Define the type for the profile data
interface UserProfileData {
  unique_id: string;
  user_name: string;
  email_address: string;
  role_id: string; // Added role_id based on update payload requirement
}

// Define the state interface
interface ProfileState {
  profileData: UserProfileData | null;
  profileLoading: boolean; // Renamed from loading
  passwordChangeLoading: boolean; // New loading state for password change
  error: string | null;
  passwordChangeSuccess: boolean;
  passwordChangeError: string | null;
}

// Initial state
const initialState: ProfileState = {
  profileData: null,
  profileLoading: false, // Renamed from loading
  passwordChangeLoading: false, // New loading state
  error: null,
  passwordChangeSuccess: false,
  passwordChangeError: null,
};

// Async thunk for fetching user profile
export const fetchUserProfile = createAsyncThunk(
  'profile/fetchUserProfile',
  async (_, { rejectWithValue }) => {
    try {
      const response = await users.getUserProfile();
      if (response.data.success) {
        // Access success from response.data
        return response.data.data; // Return the actual data object
      } else {
        return rejectWithValue(
          response.data.message || 'Failed to fetch profile data',
        ); // Access message from response.data
      }
    } catch (error: any) {
      return rejectWithValue(error.message || 'An unknown error occurred');
    }
  },
);

export const updateUserProfile = createAsyncThunk(
  'profile/updateUserProfile',
  async (
    payload: {
      unique_id: string;
      user_name: string;
      email_address: string;
      role_id: string;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await users.updateUserProfile(payload);
      if (response.data.success) {
        return response.data.data;
      } else {
        return rejectWithValue(
          response.data.message || 'Failed to update profile data',
        );
      }
    } catch (error: any) {
      return rejectWithValue(
        error.message || 'An unknown error occurred during update',
      );
    }
  },
);

export const changePassword = createAsyncThunk(
  'profile/changePassword',
  async (
    payload: {
      current_password: string;
      password: string;
      confirm_password: string;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await auth.changePassword(payload);
      if (response.data.success) {
        return response.data.message; // Assuming success message is returned
      } else {
        return rejectWithValue(
          response.data.message || 'Failed to change password',
        );
      }
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message ||
          'An unknown error occurred during password change',
      );
    }
  },
);

// Create the profile slice
const profileSlice = createSlice({
  name: 'profile',
  initialState,
  reducers: {
    resetPasswordChangeState: (state) => {
      state.passwordChangeSuccess = false;
      state.passwordChangeError = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchUserProfile.pending, (state) => {
        state.profileLoading = true; // Use profileLoading
        state.error = null;
      })
      .addCase(fetchUserProfile.fulfilled, (state, action) => {
        state.profileLoading = false; // Use profileLoading
        state.profileData = action.payload;
      })
      .addCase(fetchUserProfile.rejected, (state, action) => {
        state.profileLoading = false; // Use profileLoading
        state.error = action.payload as string;
        state.profileData = null;
      })
      .addCase(updateUserProfile.pending, (state) => {
        state.profileLoading = true; // Use profileLoading
        state.error = null;
      })
      .addCase(updateUserProfile.fulfilled, (state, action) => {
        state.profileLoading = false; // Use profileLoading
        state.profileData = action.payload; // Update profileData with the new data
      })
      .addCase(updateUserProfile.rejected, (state, action) => {
        state.profileLoading = false; // Use profileLoading
        state.error = action.payload as string;
        // Optionally, revert profileData or show a specific error message
      })
      .addCase(changePassword.pending, (state) => {
        state.passwordChangeLoading = true; // Use passwordChangeLoading
        state.passwordChangeSuccess = false;
        state.passwordChangeError = null;
      })
      .addCase(changePassword.fulfilled, (state) => {
        state.passwordChangeLoading = false; // Use passwordChangeLoading
        state.passwordChangeSuccess = true;
        state.passwordChangeError = null;
      })
      .addCase(changePassword.rejected, (state, action) => {
        state.passwordChangeLoading = false; // Use passwordChangeLoading
        state.passwordChangeSuccess = false;
        state.passwordChangeError = action.payload as string;
      });
  },
});

export const { resetPasswordChangeState } = profileSlice.actions;
export default profileSlice.reducer;
