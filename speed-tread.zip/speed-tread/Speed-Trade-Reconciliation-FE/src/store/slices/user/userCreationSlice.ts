import { createSlice } from '@reduxjs/toolkit';
import { createUserThunk } from '../../thunks/userCreation';
import { UserCreationState } from '../../interfaces/user/userCreation';

const initialState: UserCreationState = {
  loading: false,
  success: false,
  error: null,
};

const userCreationSlice = createSlice({
  name: 'userCreation',
  initialState,
  reducers: {
    resetUserCreationState: (state) => {
      state.loading = false;
      state.success = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createUserThunk.pending, (state) => {
        state.loading = true;
        state.success = false;
        state.error = null;
      })
      .addCase(createUserThunk.fulfilled, (state) => {
        state.loading = false;
        state.success = true;
        state.error = null;
      })
      .addCase(createUserThunk.rejected, (state, action) => {
        state.loading = false;
        state.success = false;
        state.error = action.payload || 'Failed to create user';
      });
  },
});

export const { resetUserCreationState } = userCreationSlice.actions;
export default userCreationSlice.reducer;
