import { createSlice } from '@reduxjs/toolkit';
import { editUserThunk } from '../../thunks/userEdit';
import { UserEditState } from '../../interfaces/user/userEdit';

const initialState: UserEditState = {
  loading: false,
  success: false,
  error: null,
};

const userEditSlice = createSlice({
  name: 'userEdit',
  initialState,
  reducers: {
    resetUserEditState: (state) => {
      state.loading = false;
      state.success = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(editUserThunk.pending, (state) => {
        state.loading = true;
        state.success = false;
        state.error = null;
      })
      .addCase(editUserThunk.fulfilled, (state) => {
        state.loading = false;
        state.success = true;
        state.error = null;
      })
      .addCase(editUserThunk.rejected, (state, action) => {
        state.loading = false;
        state.success = false;
        state.error = action.payload || 'Failed to edit user';
      });
  },
});

export const { resetUserEditState } = userEditSlice.actions;
export default userEditSlice.reducer;
