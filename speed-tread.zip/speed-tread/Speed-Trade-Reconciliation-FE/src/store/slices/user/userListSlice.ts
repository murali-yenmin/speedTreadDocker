import { createSlice } from '@reduxjs/toolkit';
import { fetchUserListThunk } from '../../thunks/userList';
import {
  UserListItem,
  UserListPayload,
  UserListState,
} from '../../interfaces/user/userList';

const initialState: UserListState = {
  users: [],
  totalCount: 0,
  loading: false,
  error: null,
};

const userListSlice = createSlice({
  name: 'userList',
  initialState,
  reducers: {
    clearUserList: (state) => {
      state.users = [];
      state.totalCount = 0;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchUserListThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchUserListThunk.fulfilled, (state, action) => {
        state.loading = false;
        if (action.meta.arg.cp === 1) {
          state.users = action.payload.users;
        } else {
          state.users = [...state.users, ...action.payload.users];
        }
        state.totalCount = action.payload.totalCount;
      })
      .addCase(fetchUserListThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || 'Failed to fetch user list';
      });
  },
});

export const { clearUserList } = userListSlice.actions;
export default userListSlice.reducer;
