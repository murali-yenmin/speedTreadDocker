import { configureStore } from '@reduxjs/toolkit';
import { TypedUseSelectorHook, useDispatch, useSelector } from 'react-redux';

// Slices
import accountNameReducer from './slices/accountNameSlice';
import {
  forgotSlice,
  loginSlice,
  resetPasswordSlice,
} from './slices/authentication';
import errorReducer from './slices/errorSlice';
import {
  addGroupSlice,
  getAllGroupsSlice,
  getGroupUniqueIdSlice,
  getOrderGroupByIdSlice,
  getTransactionGroupByIdSlice,
  orderGroupGetAllSlice,
  updateCurrencyReorderSlice,
  updateGroupSlice,
} from './slices/groups';
import {
  addOrderReducer,
  deleteOrderSlice,
  deleteOrderTransactionSlice,
  getAllOrdersReducer,
  getAllOrdersReportsReducer,
  getOrdersStatusSlice,
  getOrderByIdSlice,
  getOrderGroupSlice,
  groupBasedOrderCurrenciesReducer,
  orderDateStatusSlice,
  orderSellCurrenciesReducer,
  updateOrderReducer, 
  deleteAllOrdersSlice,
} from './slices/order';
import {
  addOrderTransactionReducer,
  completeOrderSlice,
  editOrderTransactionReducer,
  getOrderTransactionByIdSlice,
  orderRemainingBalSlice,
} from './slices/orderTransaction';
import pairedCurrenciesReducer from './slices/pairedCurrencies';
import { rolesReducer } from './slices/roles';
import {
  addCurrencyPairSlice,
  addCurrencySlice,
  addMediaSourceSlice,
  currencyPairStatusChangeSlice,
  currencyStatusChangeSlice,
  getAllCurrenciesSlice,
  getAllCurrencyPairsSlice,
  getAllFilterCurrencyPairsSlice,
  getAllFilterSearchCurrencySlice,
  getAllMediaSourceSlice,
  sourceStatusChangeSlice,
  updateCurrencySlice,
  swapCurrencyPairSlice,
} from './slices/settings';
import {
  addTransactionSlice,
  amountOverviewReducer,
  deleteTransactionSlice,
  editTransactionSlice,
  getAllTransactionsSlice,
  groupBasedCurrenciesReducer,
  getTransactionByIdSlice,
  sellCurrenciesReducer,
  addBulkTransactionSlice,
  deleteMultipleTransactionsReducer,
} from './slices/transaction';
import exportTransactionsReducer from './slices/exportTransactionsSlice';
import settlementDetailsReducer from './slices/settlement/settlementDetailsSlice';
import {
  profileReducer,
  userCreationReducer,
  userEditReducer,
  userListReducer,
} from './slices/user';

export const store = configureStore({
  reducer: {
    error: errorReducer,
    loginReducer: loginSlice,
    forgotReducer: forgotSlice,
    resetPasswordReducer: resetPasswordSlice,
    rolesReducer: rolesReducer,
    userCreationReducer: userCreationReducer,
    userListReducer: userListReducer,
    userEditReducer: userEditReducer,
    profileReducer: profileReducer,
    getAllMediaSourceReducer: getAllMediaSourceSlice,
    addMediaSourceReducer: addMediaSourceSlice,
    getAllCurrenciesReducer: getAllCurrenciesSlice,
    addCurrencyReducer: addCurrencySlice,
    sourceStatusChangeReducer: sourceStatusChangeSlice,
    currencyStatusChangeReducer: currencyStatusChangeSlice,
    getAllCurrencyPairsReducer: getAllCurrencyPairsSlice,
    addCurrencyPairReducer: addCurrencyPairSlice,
    currencyPairStatusChangeReducer: currencyPairStatusChangeSlice,
    updateCurrencyReducer: updateCurrencySlice,
    addGroupReducer: addGroupSlice,
    getAllGroupsReducer: getAllGroupsSlice,
    orderGroupGetAllReducer: orderGroupGetAllSlice,
    updateGroupReducer: updateGroupSlice,
    addTransactionReducer: addTransactionSlice,
    editTransactionReducer: editTransactionSlice,
    getAllTransactionsReducer: getAllTransactionsSlice,
    amountOverviewReducer: amountOverviewReducer,
    addOrderReducer: addOrderReducer,
    getAllOrdersReducer: getAllOrdersReducer,
    getAllOrdersReportsReducer: getAllOrdersReportsReducer,
    updateOrderReducer: updateOrderReducer,
    addOrderTransactionReducer: addOrderTransactionReducer,
    editOrderTransactionReducer: editOrderTransactionReducer,
    groupBasedCurrenciesReducer: groupBasedCurrenciesReducer,
    groupBasedOrderCurrenciesReducer: groupBasedOrderCurrenciesReducer,
    sellCurrenciesReducer: sellCurrenciesReducer,
    orderSellCurrenciesReducer: orderSellCurrenciesReducer,
    pairedCurrenciesReducer: pairedCurrenciesReducer,
    completeOrderReducer: completeOrderSlice,
    accountNameReducer: accountNameReducer,
    getAllFilterCurrencyPairsReducer: getAllFilterCurrencyPairsSlice,
    getAllFilterSearchCurrencyReducer: getAllFilterSearchCurrencySlice,
    getAllOrdersStatusReducer: getOrdersStatusSlice,
    getOrderGroupReducer: getOrderGroupSlice,
    deleteTransactionReducer: deleteTransactionSlice,
    deleteOrderTransactionReducer: deleteOrderTransactionSlice,
    deleteOrderReducer: deleteOrderSlice,
    getGroupUniqueIdCurrencyReducer: getGroupUniqueIdSlice,
    updateCurrencyReorderReducer: updateCurrencyReorderSlice,
    orderRemainingBalanceReducer: orderRemainingBalSlice,
    getTransactionByIdReducer: getTransactionByIdSlice,
    getTransactionGroupByIdReducer: getTransactionGroupByIdSlice,
    getOrderGroupByIdReducer: getOrderGroupByIdSlice,
    getOrderByIdReducer: getOrderByIdSlice,
    getOrderTransactionByIdReducer: getOrderTransactionByIdSlice,
    orderDateStatusReducer: orderDateStatusSlice,
    addBulkTransactionReducer: addBulkTransactionSlice,
    deleteMultipleTransactionsReducer: deleteMultipleTransactionsReducer,
    settlementDetailsReducer: settlementDetailsReducer,
    exportTransactionsReducer: exportTransactionsReducer, 
    deleteAllOrdersSlice:deleteAllOrdersSlice,
    swapCurrencyPairSlice:swapCurrencyPairSlice,
  },
});

// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<typeof store.getState>;
// Inferred type: {posts: PostsState, comments: CommentsState, users: UsersState}
export type AppDispatch = typeof store.dispatch;

export const useAppDispatch: () => AppDispatch = useDispatch;
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;
