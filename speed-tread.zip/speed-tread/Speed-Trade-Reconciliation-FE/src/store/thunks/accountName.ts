import { createAsyncThunk } from '@reduxjs/toolkit';
import { accounts } from '../../helper/backend_helper';
import { showErrorToast } from '../../utils/toast';
import { handleThunkError } from './groups';

export const getAccountNamesThunk = createAsyncThunk(
  'accounts/getAccountNames',
  async (query: string, { rejectWithValue }) => {
    try {
      const response = await accounts.getAccountNames(query);
      if (!response?.data?.success) {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);
