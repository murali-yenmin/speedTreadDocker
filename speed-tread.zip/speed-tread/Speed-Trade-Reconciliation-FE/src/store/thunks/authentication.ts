import { createAsyncThunk } from '@reduxjs/toolkit';
import { auth } from '../../helper/backend_helper';
import {
  LoginProps,
  ForgotProps,
  ResetPasswordProps,
} from '../interfaces/authentication';
import { toast } from 'react-toastify';
import { showErrorToast, showSuccessToast } from '../../utils/toast';

// loginThunk
import { fetchUserProfile } from './../slices/user/profileSlice'; // Import fetchUserProfile thunk
import { handleThunkError } from './groups';

export const loginThunk = createAsyncThunk(
  'login/loginThunk', // action type
  async (data: LoginProps, thunkAPI) => {
    // Added thunkAPI
    const { rejectWithValue, dispatch } = thunkAPI; // Destructure dispatch
    try {
      const response = await auth.login(data?.payload);

      if (response?.data?.data?.token) {
        const token = response?.data?.data?.token;

        localStorage.setItem('authToken', token);
        window.dispatchEvent(new Event('auth-change'));

        dispatch(fetchUserProfile()); // Dispatch the thunk

        data?.successCallback(token);

        // return both token & decoded payload
        return response?.data?.data;
      }

      showErrorToast(response?.data?.data?.message);
      return rejectWithValue('Invalid login response');
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

// forgotPasswordThunk
export const forgotPasswordThunk = createAsyncThunk(
  'forgot/forgotPasswordThunk', // action type
  async (data: ForgotProps, { rejectWithValue }) => {
    try {
      const response = await auth.forgotPassword(data?.payload);

      if (response?.data?.success === true) {
        data?.successCallback();
        return response?.data?.data;
      }

      showErrorToast(response?.data?.message);
      return rejectWithValue('Invalid forgot password response');
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

// resetPasswordThunk
export const resetPasswordThunk = createAsyncThunk(
  'reset_password/resetPasswordThunk', // action type
  async (data: ResetPasswordProps, { rejectWithValue }) => {
    try {
      const response = await auth.resetPassword(data?.payload);

      if (response?.data?.success === true) {
        showSuccessToast('The password has been reset successfully');
        data?.successCallback();
        return response?.data?.data;
      }

      showErrorToast(response?.data?.message);
      return rejectWithValue('Invalid reset password response');
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

// regeneratePasswordThunk
export const regeneratePasswordThunk = createAsyncThunk(
  'user/regeneratePassword',
  async (email_address: string, { rejectWithValue }) => {
    try {
      const response = await auth.regeneratePassword({ email_address });
      if (response?.data?.success === true) {
        showSuccessToast(response?.data?.message);
        return response?.data?.message;
      } else {
        showErrorToast(response?.data?.message);
        return rejectWithValue(response?.data?.message);
      }
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);
