import { createAsyncThunk } from '@reduxjs/toolkit';
import { transactions } from '../../helper/backend_helper';
import { showErrorToast } from '../../utils/toast';
import { handleThunkError } from './groups';

export const getGroupBasedCurrenciesThunk = createAsyncThunk(
  'transaction/getGroupBasedCurrencies',
  async (id: string, { rejectWithValue }) => {
    try {
      const response = await transactions.getGroupBasedCurrencies(id);
      if (!response?.data?.success) {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);
