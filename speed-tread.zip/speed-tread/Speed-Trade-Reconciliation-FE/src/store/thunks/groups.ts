import { createAsyncThunk } from '@reduxjs/toolkit';
import { groups } from '../../helper/backend_helper';
import { GetProps } from '../../interfaces/files';
import { showErrorToast } from '../../utils/toast';
import { ReOrderCurrencyPayload } from '../../interfaces/order';

// Reusable error handler function
export const handleThunkError = (error: any, rejectWithValue: any) => {
  const excludedStatuses = [401, 403, 404, 500];
  const errorStatus = error?.response?.status;

  if (!excludedStatuses.includes(errorStatus)) {
    showErrorToast(error?.response?.data?.message);
  }

  return rejectWithValue(error.response.data);
};

export const addGroupThunk = createAsyncThunk(
  'group/addGroup',
  async (
    data: {
      payload: { name: string; settlement_currency: string; group_id: string };
      callbackAfterSuccess: () => void;
      callbackAfterFailure: (errorFields: Record<string, string>) => void;
    },
    { rejectWithValue, dispatch },
  ) => {
    try {
      const response = await groups.addGroup({
        name: data.payload.name,
        settlement_currency: data.payload.settlement_currency,
        group_id: data.payload.group_id,
      });
      if (response?.data?.success) {
        data.callbackAfterSuccess();
      } else if (response?.data?.data?.errorField) {
        data?.callbackAfterFailure(response?.data?.data?.errorField);
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getAllGroupsThunk = createAsyncThunk(
  'group/getAllGroups',
  async (
    data: { payload: GetProps; callbackAfterSuccess?: () => void },
    { rejectWithValue },
  ) => {
    try {
      const response = await groups.getAllGroups(data.payload);
      if (response?.data?.success) {
        data?.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const updateGroupThunk = createAsyncThunk(
  'group/updateGroup',
  async (
    data: {
      payload: {
        unique_id: string;
        name: string;
        settlement_currency?: string;
        is_favorite?: boolean;
      };
      callbackAfterSuccess: () => void;
      callbackAfterFailure?: (errorFields: Record<string, string>) => void;
    },
    { rejectWithValue, dispatch },
  ) => {
    try {
      const response = await groups.updateGroup(data.payload);
      if (response?.data?.success) {
        data.callbackAfterSuccess();
      } else if (response?.data?.data?.errorField) {
        data?.callbackAfterFailure?.(response?.data?.data?.errorField);
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const orderGroupGetAllThunk = createAsyncThunk(
  'group/orderGroupGetAll',
  async (
    data: { payload: GetProps; callbackAfterSuccess?: () => void },
    { rejectWithValue },
  ) => {
    try {
      const response = await groups.orderGroupGetAll(data.payload);
      if (response?.data?.success) {
        data?.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getAllGroupByUniqueIdThunk = createAsyncThunk(
  'group/getAllGroupByUniqueIdThunk',
  async (
    data: {
      payload: { groupId: string; role: string };
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      let response: any = null;

      if (data.payload.role === 'order') {
        response = await groups.getGroupByUniqueId(data.payload.groupId);
      } else if (data.payload.role === 'transaction') {
        response = await groups.getGroupByUniqueIdTransactionFlow(
          data.payload.groupId,
        );
      }

      if (!response) {
        throw new Error('Invalid role provided');
      }

      if (response?.data?.success) {
        data?.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }

      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const currencyReorderThunk = createAsyncThunk(
  'group/currencyReorderThunk',
  async (
    data: {
      payload: ReOrderCurrencyPayload;
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await groups.currencyReorder(data.payload);
      if (response?.data?.success) {
        data?.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getTransactionGroupByIdThunk = createAsyncThunk(
  'group/getTransactionGroupById',
  async (
    data: {
      payload: { id: string };
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await groups.getTransactionGroupById(data.payload.id);
      if (response?.data?.success) {
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getOrderGroupByIdThunk = createAsyncThunk(
  'group/getOrderGroupById',
  async (
    data: {
      payload: { id: string };
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await groups.getOrderGroupById(data.payload.id);
      if (response?.data?.success) {
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);
