import { createAsyncThunk } from '@reduxjs/toolkit';
import { groups, order } from '../../helper/backend_helper';
import { GetProps } from '../../interfaces/files';
import { AddOrderPayload, UpdateOrderPayload } from '../interfaces/order';
import { showErrorToast, showSuccessToast } from '../../utils/toast';
import { OrderSummary } from '../../interfaces/components';
import { handleThunkError } from './groups';

export const addOrderThunk = createAsyncThunk(
  'order/addOrder',
  async (
    data: {
      payload: AddOrderPayload;
      callbackAfterSuccess: (orderSummary: OrderSummary) => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await order.addOrder(data.payload);
      if (response.data?.success) {
        data.callbackAfterSuccess(response.data.data);
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getAllOrdersThunk = createAsyncThunk(
  'order/getAllOrders',
  async (
    {
      payload,
      callbackAfterSuccess,
    }: { payload: GetProps; callbackAfterSuccess?: () => void },
    { rejectWithValue },
  ) => {
    try {
      const response = await order.getAllOrders(payload);
      if (response?.data?.success) {
        callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);
export const getAllOrdersReportThunk = createAsyncThunk(
  'order/getAllOrdersReports',
  async (
    {
      payload,
      callbackAfterSuccess,
    }: { payload: GetProps; callbackAfterSuccess?: () => void },
    { rejectWithValue },
  ) => {
    try {
      const response = await order.getAllReportOrders(payload);
      if (response?.data?.success) {
        callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const updateOrderThunk = createAsyncThunk(
  'order/updateOrder',
  async (
    {
      payload,
      callbackAfterSuccess,
    }: { payload: UpdateOrderPayload; callbackAfterSuccess: () => void },
    { rejectWithValue },
  ) => {
    try {
      const response = await order.updateOrder(payload);
      if (response.data?.success) {
        callbackAfterSuccess();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getOrderStatusThunk = createAsyncThunk(
  'order/getOrderStatusThunk',
  async (_, { rejectWithValue }) => {
    try {
      const response = await order.getOrderStatus();
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getOrderGroupThunk = createAsyncThunk(
  'order/getOrderGroupThunk',
  async (payload: { search?: string }, { rejectWithValue }) => {
    try {
      const response = await groups.getOrderGroups(payload.search);
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const deleteOrderTransactionThunk = createAsyncThunk(
  'transaction/deleteOrderTransactionThunk',
  async (
    data: {
      payload: { id: string };
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await order.deleteOrderTransaction(data.payload);
      if (response?.data?.success) {
        // Temporary stop success message
        // showSuccessToast(response.data?.message);
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);
export const deleteOrderThunk = createAsyncThunk(
  'transaction/deleteOrderThunk',
  async (
    data: {
      payload: { id: string };
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await order.deleteOrder(data.payload);
      if (response?.data?.success) {
        // Temporary stop show tost message
        // showSuccessToast(response.data?.message);
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const deleteMultipleOrdersThunk = createAsyncThunk(
  'order/deleteMultipleOrders',
  async (
    data: {
      payload: { ids: string[] };
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await order.deleteMultipleOrders(data.payload);
      if (response?.data?.success) {
        showSuccessToast(response.data?.message);
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return { ...response.data?.data, ids: data.payload.ids };
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getOrderByIdThunk = createAsyncThunk(
  'order/getOrderById',
  async (
    data: {
      payload: { id: string };
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await order.getOrderById(data.payload.id);
      if (response?.data?.success) {
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getOrderDateStatusThunk = createAsyncThunk(
  'order/getOrderDateStatus',
  async (
    payload: { group_id: string; settlement_currency: string },
    { rejectWithValue },
  ) => {
    try {
      const response = await order.getOrderDateStatus(payload);
      if (response.data?.success) {
        return response.data.data;
      } else { 
        return rejectWithValue(response.data?.message);
      }
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);
