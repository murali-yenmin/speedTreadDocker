import { createAsyncThunk } from '@reduxjs/toolkit';
import { orderTransaction } from '../../helper/backend_helper';
import {
  AddOrderTransactionPayload,
  CompleteOrderTransactionPayload,
  EditOrderTransactionPayload,
} from '../interfaces/orderTransaction';
import { showErrorToast } from '../../utils/toast';
import { handleThunkError } from './groups';

export const addOrderTransactionThunk = createAsyncThunk(
  'orderTransaction/addOrderTransaction',
  async (
    data: {
      payload: AddOrderTransactionPayload;
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue, dispatch },
  ) => {
    try {
      const response = await orderTransaction.addOrderTransaction(data.payload);
      if (response?.data?.success) {
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const editOrderTransactionThunk = createAsyncThunk(
  'orderTransaction/editOrderTransaction',
  async (
    data: {
      payload: EditOrderTransactionPayload;
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue, dispatch },
  ) => {
    try {
      const response = await orderTransaction.editOrderTransaction(
        data.payload,
      );
      if (response?.data?.success) {
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const completeOrderThunk = createAsyncThunk(
  'order/completeOrder',
  async (
    data: {
      payload: CompleteOrderTransactionPayload;
      callbackAfterSuccess: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await orderTransaction.completeOrder(data.payload);
      if (response.data?.success) {
        data.callbackAfterSuccess();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getOrderTransactionByIdThunk = createAsyncThunk(
  'orderTransaction/getOrderTransactionById',
  async (
    data: {
      payload: { id: string };
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await orderTransaction.getOrderTransactionById(
        data.payload.id,
      );
      if (response?.data?.success) {
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getAddTransRemindBalThunk = createAsyncThunk(
  'order/getAddTransRemindBalThunk',
  async (
    data: {
      payload: {
        order_id: string;
        transaction_id?: string;       
      };
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await orderTransaction.getAddTransRemindBal(
        data.payload,
      );
      if (response.data?.success) {
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);
