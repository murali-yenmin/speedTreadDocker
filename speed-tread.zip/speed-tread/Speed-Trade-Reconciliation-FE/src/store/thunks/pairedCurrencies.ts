import { createAsyncThunk } from '@reduxjs/toolkit';
import { settings } from '../../helper/backend_helper';
import { showErrorToast } from '../../utils/toast';
import { handleThunkError } from './groups';

export const getPairedCurrenciesThunk = createAsyncThunk(
  'pairedCurrencies/getPairedCurrencies',
  async (payload: { settlement_currency: string }, { rejectWithValue }) => {
    try {
      const response = await settings.getPairedCurrencies(payload);
      if (!response?.data?.success) {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);
