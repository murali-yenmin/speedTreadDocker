import { createAsyncThunk } from '@reduxjs/toolkit';
import { users } from '../../helper/backend_helper';
import { showErrorToast } from '../../utils/toast';
import { Role } from '../interfaces/roles';
import { handleThunkError } from './groups';

export const fetchRolesThunk = createAsyncThunk<
  Role[],
  void,
  { rejectValue: string }
>('roles/fetchRoles', async (_, { rejectWithValue }) => {
  try {
    const response = await users.getRoles();
    if (response.data && response.data.data) {
      return response.data.data;
    }
    if (!response?.data?.success) {
      showErrorToast(response?.data?.message);
    }
    return rejectWithValue('Failed to fetch roles: Invalid response data');
  } catch (error: any) {
    return handleThunkError(error, rejectWithValue);
  }
});
