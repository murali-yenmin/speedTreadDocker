import { createAsyncThunk } from '@reduxjs/toolkit';
import { settings } from '../../helper/backend_helper';
import { replaceSource } from '../slices/settings/getAllMediaSourceSlice';
import { showErrorToast, showSuccessToast } from '../../utils/toast';
import { replaceCurrencyPair } from '../slices/settings/getAllCurrencyPairsSlice';
import { replaceCurrency } from '../slices/settings/getAllCurrenciesSlice';
import { handleThunkError } from './groups';

export const getAllMediaSourcesThunk = createAsyncThunk(
  'settings/getAllMediaSources',
  async (_, { rejectWithValue }) => {
    try {
      const response = await settings.getAllMediaSources();
      if (!response?.data?.success) {
        showErrorToast(response?.data?.message);
      }
      return response?.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const addMediaSourceThunk = createAsyncThunk(
  'settings/addMediaSource',
  async (
    data: { payload: { label: string }; afterSuccessCallback: () => void },
    { rejectWithValue, dispatch },
  ) => {
    try {
      const response = await settings.addMediaSource(data.payload);
      if (response.data?.success) {
        dispatch(getAllMediaSourcesThunk());
        data.afterSuccessCallback();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response?.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getAllCurrenciesThunk = createAsyncThunk(
  'settings/getAllCurrencies',
  async (payload: { search?: string } | undefined, { rejectWithValue }) => {
    try {
      const response = await settings.getAllCurrencies(payload?.search);
      if (!response?.data?.success) {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const addCurrencyThunk = createAsyncThunk(
  'settings/addCurrency',
  async (
    data: {
      payload: { name: string; code: string };
      afterSuccessCallback: () => void;
    },
    { rejectWithValue, dispatch },
  ) => {
    try {
      const response = await settings.addCurrency(data.payload);
      if (response.data?.success) {
        dispatch(getAllCurrenciesThunk());
        data.afterSuccessCallback();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const updateMediaSourceStatusThunk = createAsyncThunk(
  'settings/updateMediaSourceStatus',
  async (
    payload: { unique_id: string; is_active: boolean },
    { rejectWithValue, dispatch },
  ) => {
    try {
      const response = await settings.updateMediaSourceStatus(payload);
      if (response.data?.data) {
        dispatch(replaceSource(response.data?.data));
      }
      if (!response?.data?.success) {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const updateCurrencyStatusThunk = createAsyncThunk(
  'settings/updateCurrencyStatus',
  async (
    { id, status }: { id: string; status: { enabled: boolean } },
    { rejectWithValue },
  ) => {
    try {
      const response = await settings.updateCurrencyStatus(id, status);
      if (!response?.data?.success) {
        showErrorToast(response?.data?.message);
      }
      return response.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getAllCurrencyPairsThunk = createAsyncThunk(
  'settings/getAllCurrencyPairs',
  async (_, { rejectWithValue }) => {
    try {
      const response = await settings.getAllCurrencyPairs();
      if (!response?.data?.success) {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const addCurrencyPairThunk = createAsyncThunk(
  'settings/addCurrencyPair',
  async (
    data: {
      payload: {
        from: string;
        to: string;
        is_greater: boolean;
      };
      afterSuccessCallback: () => void;
    },
    { rejectWithValue, dispatch },
  ) => {
    try {
      const response = await settings.addCurrencyPair(data?.payload);
      if (response.data?.success) {
        dispatch(getAllCurrencyPairsThunk());
        data.afterSuccessCallback();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const updateCurrencyPairStatusThunk = createAsyncThunk(
  'settings/updateCurrencyPairStatus',
  async (
    data: {
      payload: {
        unique_id: string;
        is_active?: boolean;
        buy_currency_id?: string;
        sell_currency_id?: string;
        calculation_type?: string;
      };
      afterSuccessCallback: () => void;
    },
    { rejectWithValue, dispatch },
  ) => {
    try {
      const response = await settings.updateCurrencyPair(data.payload);
      if (response.data?.success) {
        showSuccessToast(response.data?.message);
        dispatch(replaceCurrencyPair(response.data?.data));
        data.afterSuccessCallback();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const updateCurrencyThunk = createAsyncThunk(
  'settings/updateCurrency',
  async (
    currencyData: { name: string; code: string; unique_id: string },
    { rejectWithValue, dispatch },
  ) => {
    try {
      const response = await settings.updateCurrency(currencyData);
      if (response.data?.success) {
        showSuccessToast(response.data?.message);
        dispatch(replaceCurrency(response.data?.data));
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getAllFilterCurrencyPairsThunk = createAsyncThunk(
  'settings/getAllFilterCurrencyPairsThunk',
  async (id: string, { rejectWithValue }) => {
    try {
      const response = await settings.getAllFilterCurrencyPairs(id);
      if (!response?.data?.success) {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getAllFilterSearchCurrenciesThunk = createAsyncThunk(
  'settings/getAllFilterSearchCurrenciesThunk',
  async (payload: { search: string }, { rejectWithValue }) => {
    try {
      const response = await settings.getAllFilterSearchCurrencies(
        payload.search,
      );
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const deleteCurrencyPairThunk = createAsyncThunk(
  'settings/deleteCurrencyPairThunk',
  async (
    data: {
      payload: { id: string };
      afterSuccessCallback: (data: any) => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await settings.deleteCurrencyPair(data.payload);
      if (response.data?.success) {
         showSuccessToast(response.data?.message);
          data.afterSuccessCallback(response.data);
      } else {
        data.afterSuccessCallback(response.data);
      }
      return response.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const swapCurrencyPairThunk = createAsyncThunk(
  'settings/swapCurrencyPair',
  async (
    data: {
      payload: {
        unique_id: string; 
      };
      afterSuccessCallback: () => void;
    },
    { rejectWithValue, dispatch },
  ) => {
    try {
      const response = await settings.swapCurrencyPair(data.payload);
      if (response.data?.success) {
        showSuccessToast(response.data?.message);
        data.afterSuccessCallback();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);
