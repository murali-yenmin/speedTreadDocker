import { createAsyncThunk } from '@reduxjs/toolkit';
import { settlement } from '../../helper/backend_helper';
import { SettlementDetailsPayload } from '../interfaces/settlement';
import { handleThunkError } from './groups';
import { showErrorToast } from '../../utils/toast';

export const getSettlementDetailsThunk = createAsyncThunk(
  'settlement/getSettlementDetails',
  async (
    data: {
      payload: SettlementDetailsPayload;
      role:string;
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await settlement.getSettlementDetails(
        data.payload,
        data.role,
      );
      if (response?.data?.success) {
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);
