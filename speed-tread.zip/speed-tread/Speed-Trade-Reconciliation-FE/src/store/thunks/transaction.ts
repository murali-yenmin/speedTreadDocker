import { createAsyncThunk } from '@reduxjs/toolkit';
import { transactions } from '../../helper/backend_helper';
import {
  AddBulkTransactionPayload,
  AddTransactionPayload,
  AmountOverviewPayload,
  EditTransactionPayload,
} from '../interfaces/transaction';
import { GetProps } from '../../interfaces/files';
import { showErrorToast, showSuccessToast } from '../../utils/toast';
import { handleThunkError } from './groups';

export const addTransactionThunk = createAsyncThunk(
  'transaction/addTransaction',
  async (
    data: {
      payload: AddTransactionPayload;
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await transactions.addTransaction(data.payload);
      if (response?.data?.success) {
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getAllTransactionsThunk = createAsyncThunk(
  'transaction/getAllTransactions',
  async (
    data: { payload: GetProps; callbackAfterSuccess?: () => void },
    { rejectWithValue },
  ) => {
    try {
      const response = await transactions.getAllTransactions(data.payload);
      if (response?.data?.success) {
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const amountOverviewThunk = createAsyncThunk(
  'transaction/amountOverview',
  async (data: { payload: AmountOverviewPayload }, { rejectWithValue }) => {
    try {
      const response = await transactions.getAmountOverview(data.payload);
      if (!response?.data?.success) {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const editTransactionThunk = createAsyncThunk(
  'transaction/editTransaction',
  async (
    data: {
      payload: EditTransactionPayload;
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await transactions.editTransaction(data.payload);
      if (response?.data?.success) {
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const deleteTransactionThunk = createAsyncThunk(
  'transaction/deleteTransactionThunk',
  async (
    data: {
      payload: { id: string };
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await transactions.deleteTransaction(data.payload);
      if (response?.data?.success) {
        // Temporary stop success message
        // showSuccessToast(response.data?.message);
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const getTransactionByIdThunk = createAsyncThunk(
  'transaction/getTransactionById',
  async (
    data: {
      payload: { id: string };
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await transactions.getTransactionById(data.payload.id);
      if (response?.data?.success) {
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const addBulkTransactionThunk = createAsyncThunk(
  'transaction/addBulkTransactionThunk',
  async (
    data: {
      payload: AddBulkTransactionPayload;
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await transactions.addBulkTransaction(data.payload);
      if (response?.data?.success) {
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data?.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);

export const deleteMultipleTransactionsThunk = createAsyncThunk(
  'transaction/deleteMultipleTransactions',
  async (
    data: {
      payload: { ids: string[] };
      callbackAfterSuccess?: () => void;
    },
    { rejectWithValue },
  ) => {
    try {
      const response = await transactions.deleteMultipleTransactions(
        data.payload,
      );
      if (response?.data?.success) {
        showSuccessToast(response.data?.message);
        data.callbackAfterSuccess?.();
      } else {
        showErrorToast(response?.data?.message);
      }
      return response.data;
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);
