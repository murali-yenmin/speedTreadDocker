import { createAsyncThunk } from '@reduxjs/toolkit';
import { users } from '../../helper/backend_helper';
import { showErrorToast } from '../../utils/toast';
import { ToggleUserStatusPayload } from '../interfaces/user/userActions'; // New import
import { handleThunkError } from './groups';

export const toggleUserStatusThunk = createAsyncThunk(
  'user/toggleUserStatus',
  async (payload: ToggleUserStatusPayload, { rejectWithValue }) => {
    try {
      const response = await users.updateUserStatus(
        payload.unique_id,
        payload.is_active,
      );
      if (response.data && response.data.success) {
        return response.data.message;
      } else {
        showErrorToast(response?.data?.message);
        return rejectWithValue(response.data.message);
      }
    } catch (error: any) {
      return handleThunkError(error, rejectWithValue);
    }
  },
);
