import { createAsyncThunk } from '@reduxjs/toolkit';
import { users } from '../../helper/backend_helper';
import { UserCreatePayload } from '../interfaces/user/userCreation';
import { showErrorToast, showSuccessToast } from '../../utils/toast';
import { t } from 'i18next';
import { handleThunkError } from './groups';

export const createUserThunk = createAsyncThunk<
  any,
  UserCreatePayload,
  { rejectValue: string }
>('user/createUser', async (payload, { rejectWithValue }) => {
  try {
    const response = await users.createUser(payload);
    if (response.data && response.data.success) {
      showSuccessToast(t('user_created_success'));
      return response.data;
    } else {
      showErrorToast(response.data.message || 'Failed to create user.');
      return rejectWithValue(response.data.message || 'Failed to create user.');
    }
  } catch (error: any) {
    return handleThunkError(error, rejectWithValue);
  }
});
