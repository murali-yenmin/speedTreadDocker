import { createAsyncThunk } from '@reduxjs/toolkit';
import { users } from '../../helper/backend_helper';
import { UserEditPayload } from '../interfaces/user/userEdit';
import { showErrorToast } from '../../utils/toast';
import { handleThunkError } from './groups';

export const editUserThunk = createAsyncThunk<
  any,
  UserEditPayload,
  { rejectValue: string }
>('user/editUser', async (payload, { rejectWithValue }) => {
  try {
    const response = await users.editUser(payload);
    if (response.data && response.data.success) {
      return response.data;
    } else {
      showErrorToast(response.data.message);
      return rejectWithValue(response.data.message);
    }
  } catch (error: any) {
    return handleThunkError(error, rejectWithValue);
  }
});
