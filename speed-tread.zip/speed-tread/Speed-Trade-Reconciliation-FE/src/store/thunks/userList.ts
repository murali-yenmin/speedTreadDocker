import { createAsyncThunk } from '@reduxjs/toolkit';
import { users } from '../../helper/backend_helper';
import { showErrorToast } from '../../utils/toast';
import { UserListPayload, UserListItem } from '../interfaces/user/userList';
import { handleThunkError } from './groups';

export const fetchUserListThunk = createAsyncThunk<
  { users: UserListItem[]; totalCount: number },
  UserListPayload,
  { rejectValue: string }
>('userList/fetchUserList', async (payload, { rejectWithValue }) => {
  try {
    const response = await users.getUsersList({
      cp: payload.cp || 1, // Ensure string, default to '1'
      pl: payload.pl || 10, // Ensure string, default to '10'
      query: payload.query || [], // Ensure query is always an array
      sort: payload.sort || {}, // Ensure sort is always an object
    });
    if (response.data && response.data.success) {
      // Assuming response.data.data is an array of user objects
      // and response.data.totalCount is available
      return {
        users: response.data.data.users_list,
        totalCount: response.data.data.total_count || 0,
      };
    } else {
      showErrorToast(response.data.message);
      return rejectWithValue(response.data.message);
    }
  } catch (error: any) {
    return handleThunkError(error, rejectWithValue);
  }
});
