import { jwtDecode } from 'jwt-decode';
import { DecodedToken } from '../interfaces/components';

export const isAuthenticated = (): boolean => {
  const token = localStorage.getItem('authToken');

  if (!token) {
    return false;
  }

  try {
    const decodedToken = jwtDecode<DecodedToken>(token);
    const currentTime = Date.now() / 1000;
    return decodedToken.exp > currentTime;
  } catch (error) {
    return false;
  }
};

export const getUserRole = (token?: string): string | undefined => {
  const tokenToDecode = token || localStorage.getItem('authToken');

  if (!tokenToDecode) {
    return undefined;
  }

  try {
    const decodedToken = jwtDecode<DecodedToken>(tokenToDecode);
    return decodedToken?.role.role_type;
  } catch (error) {
    return undefined;
  }
};
