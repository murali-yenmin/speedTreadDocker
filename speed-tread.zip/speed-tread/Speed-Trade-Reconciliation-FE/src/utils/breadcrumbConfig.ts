export const breadcrumbConfig: { [key: string]: string } = {
  '/dashboard': 'Dashboard',
  '/groups': 'Groups',
  '/users': 'Users',
  '/settings': 'Settings',
  '/settings/currency': 'Currency',
  '/settings/social-media': 'Social Media',
  '/notifications': 'Notifications', // New entry
};

export const breadcrumbParents: { [key: string]: string | undefined } = {
  '/groups': '/dashboard',
  '/users': '/dashboard',
  '/settings': '/dashboard',
  '/settings/currency': '/settings',
  '/settings/social-media': '/settings',
};
