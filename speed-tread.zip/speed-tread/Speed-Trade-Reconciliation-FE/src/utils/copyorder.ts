import moment from 'moment-timezone';
import { Order } from '../interfaces/order';
import { formatAmount } from './numberUtils';
import { formatOrderId } from './stringUtils';
import { showSuccessToast } from './toast';
import { Transaction } from '../store/interfaces/transaction';

export const buildOrderString = (order: Order) => {
  let timezone: string = process.env.REACT_APP_TIMEZONE || 'Asia/Singapore';
  let str = ``;
  str += `${formatOrderId(order.order_id)}\n`;
  str += `${moment.utc(order.ordered_date).tz(timezone).format('DD MMM, hh:mm A')}\n`;
  str += `${order.account.name}\n`;
  str += `ODR: ${order.currency} ${formatAmount(Number(order.amount))}\n`;

  if (order.rate && Number(order.rate) !== 0) {
    str += `Rate: ${formatAmount(Number(order.rate), 3)}\n`;
  }

  if (
    order.calculation?.transferred_amount &&
    Number(order.calculation?.transferred_amount) !== 0
  ) {
    str += `TRF: ${order.currency} ${formatAmount(Number(order.calculation.transferred_amount))}${
      order.transfer_percent > 0
        ? ` (${Math.floor(order.transfer_percent * 10) / 10}%)`
        : ''
    }\n`;
  }

  const pending = order.calculation?.pending_amount ?? order.calculation?.value;
  if (pending && Number(pending) !== 0) {
    str += `PEN: ${order.currency} ${formatAmount(Number(pending))}\n`;
  }

  if (order.fee && Number(order.fee) !== 0) {
    str += `Fee: ${formatAmount(Number(order.fee), 2)}\n`;
  }

  if (order.remarks) {
    str += `${order.remarks}\n`;
  }

  return str;
};

export const buildTransactionString = (transaction: Transaction) => {
  let transactionString = ``;
  // Using selectedDate if available, otherwise current date
  const dateToUse = moment(transaction?.transferred_date); // Use transaction.updated_at for date and time

  transactionString += `${formatOrderId(transaction?.transaction_id)}\n`;
  transactionString += `${dateToUse.format('DD MMM, hh:mm A')}\n`; // Include time with new format
  transactionString += `${transaction?.account?.name}\n`;
  transactionString += `${transaction.transfer_by === 'we' ? 'Out' : 'In'} / ${transaction.sell_currency} ${formatAmount(Number(transaction.sell_value))}\n`;

  if (transaction?.rate && Number(transaction?.rate) > 0) {
    transactionString += `Rate ${formatAmount(Number(transaction.rate), 3)}\n`;
  }
  if (transaction?.fee && Number(transaction?.fee) > 0) {
    transactionString += `Fee ${formatAmount(Number(transaction.fee), 2)}\n`;
  }
  if (transaction?.remarks) {
    transactionString += `Remark ${transaction.remarks}`;
  }
  return transactionString;
};

export const handleCopyTransaction = (transaction: Transaction, isBulkCopy?: boolean) => {
  const transactionString = buildTransactionString(transaction);
  if (isBulkCopy) {
    return transactionString;
  }
  navigator.clipboard.writeText(transactionString).then(() => {
    showSuccessToast('Transaction details copied to clipboard!');
  });
};
