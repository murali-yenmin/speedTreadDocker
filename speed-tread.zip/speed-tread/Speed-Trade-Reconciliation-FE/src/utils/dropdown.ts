const customfilterMap: Record<string, string> = {
    'cus own': 'owe_us',
    'owns us': 'we_owe',
    'not tally': 'not_tally',
};

export default customfilterMap